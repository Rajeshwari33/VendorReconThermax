import { headers, baseUrl } from "../../common/credentials";

const port = "8001";

export const getExcelReportFromServer = () => {
    let url = baseUrl + port + "/api/v2/compliance_certificate/generic/reports/";
    return ([headers, url]);
};

export const getCCPdfFromServer = () => {
    let url = baseUrl + port + "/api/v2/compliance_certificate/generic/pdf_report/";
    return ([headers, url]);
};

export const getSendEmail = () => {
    let url = baseUrl + port + "/api/v2/compliance_certificate/generic/send_email/";
    return ([headers, url]);
}
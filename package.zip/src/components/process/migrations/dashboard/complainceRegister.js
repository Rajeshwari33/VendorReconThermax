import React from 'react';


function ComplainceRegister({hidden})
{
    return (
        <>
            <div hidden={hidden}>
            ComplainceRegister
            </div>
        </>
    );
}

export default  ComplainceRegister;
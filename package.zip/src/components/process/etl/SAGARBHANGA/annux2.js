// App.js
import { useEffect, useState } from "react";
// import "./App.css";
import "../etlsecound.css";
import hdfcs from '../../../../assets/images/banks/thermax.png';


function Annux2() 
{
  

  return (
  <div>
   <table className="table1">
    <tr className="bold">
        <td colSpan={7}>Sales considered by vendor but not accounted by Thermax</td>
        
    </tr>
    <br></br>
    <tr className="fontcolor">
        <td>DATE</td>
        <td>PARTICULARS</td>
        <td>VCH TYPE</td>
        <td>VCH NO.</td>
        <td>Cr/Dr</td>
        <td>DEBIT</td>
        <td>CREDIT</td>
    </tr>
    <tr>
        <td>1/24/22</td>
        <td>To</td>
        <td>Fabrication Machining</td>
        <td>Journal</td>
        <td>2249</td>
        <td> 1,599,391.47 </td>
        <td></td>
    </tr>
    <tr>
        <td>2/12/22</td>
        <td>To</td>
        <td>Fabrication Machining</td>
        <td>Journal</td>
        <td>2475</td>
        <td> 204,847.76 </td>
        <td></td>
    </tr>
    <tr>
        <td>3/22/22</td>
        <td>To</td>
        <td>Fabrication Machining</td>
        <td>Journal</td>
        <td>2796</td>
        <td> 3,248,173.02 </td>
        <td></td>
    </tr>
    <tr>
        <td>3/25/22</td>
        <td>To</td>
        <td>Fabrication Machining</td>
        <td>Journal</td>
        <td>2810</td>
        <td> 1,786,495.16 </td>
        <td></td>
    </tr>
    <tr>
        <td>3/31/22</td>
        <td>To</td>
        <td>Fabrication Machining</td>
        <td>Journal</td>
        <td>2857</td>
        <td> 3,248,173.02 </td>
        <td></td>
    </tr>
    <tr>
        <td>1/11/22</td>
        <td>To</td>
        <td>Tax Deducted at Source (F.Y 2021-22)-NSDL</td>
        <td>Journal</td>
        <td>2140</td>
        <td> 3,850.00 </td>
        <td></td>
    </tr>
    <tr>
        <td>2/16/22</td>
        <td>To</td>
        <td>Tax Deducted at Source (F.Y 2021-22)-NSDL</td>
        <td>Journal</td>
        <td>2507</td>
        <td> 2,264.00 </td>
        <td></td>
    </tr>
    
    <tr>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td> 10,093,194.43</td>
    </tr>
</table>
  </div>
  )
}



export default Annux2;
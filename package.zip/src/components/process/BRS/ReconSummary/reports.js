import React, { useEffect, useState, useRef, useCallback} from "react";
import Select from "react-select";
import './reports.css';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-balham.css';
import { AgGridReact } from 'ag-grid-react';
import LoaderComponent from "../../../../libraries/loader/loader";
import { getReportGridDataFromServer, port } from '../../../../services/process/medical-insurance/medicalInsuranceReportService';
import axios from "axios";
import excelIcon from '../../../../assets/images/excel.png';
import * as XLSX from 'xlsx';
import { Icon, Input, Button, Dropdown, Grid, Popup, Segment, Tab, Menu, Form, TextArea, Label } from 'semantic-ui-react';
import Paper from '@mui/material/Paper';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TablePagination from '@mui/material/TablePagination';
import TableRow from '@mui/material/TableRow';
import { baseUrl } from "../../../../services/common/credentials";


var aggCallCount = 0;

var compareCallCount = 0;

var filterCallCount = 0;

const localhost_url = baseUrl + port;


function AlcsReport() {
    const [inputMonth, setInputMonth] = useState(undefined);
    const [hideResultGrid, setHideResultGrid] = useState(true);
    const [loaderOpen, setLoaderOpen] = useState(false);
    // const [userCredentials] = useState(JSON.parse(sessionStorage.getItem("userCredentials")));
    const [rowData, setRowData] = useState([]);
    const [paginationSize] = useState(15);
    const [companyname, setCompanyName] = useState({});
    const [type, setType] = useState(undefined);
    const [gridColumns, setGridColumns] = useState([]);
    const gridRef = useRef();
    const [isutr, isSetUtr] = useState(false);


    var utr_columns = [
       
        { field: 'Bank Name', headerName: 'Bank Name', sortable: true, filter: true, resizable: true},
        { field: 'Account No', headerName: 'Account No', sortable: true, filter: true, resizable: true },
        { field: 'Accpac Code', headerName: 'Accpac Code', sortable: true, filter: true, resizable: true },
        { field: 'Date', headerName: 'Date', sortable: true, filter: true, resizable: true },
        { field: 'Acc #', headerName: 'Acc #', sortable: true, filter: true, resizable: true },
        { field: 'Issued Amt', headerName: 'Issued Amt', sortable: true, filter: true, resizable: true },
        { field: 'Name', headerName: 'Name', sortable: true, filter: true, resizable: true },
        { field: 'Company', headerName: 'Company', sortable: true, filter: true, resizable: true },
        { field: 'Emp#', headerName: 'Emp#', sortable: true, filter: true, resizable: true },       
        { field: 'Client Id', headerName: 'Client Id', sortable: true, filter: true, resizable: true },
        { field: 'Remarks', headerName: 'Remarks', sortable: true, filter: true, resizable: true },
        { field: 'invoice no', headerName: 'invoice no', sortable: true, filter: true, resizable: true },
        { field: 'IFSC CODES', headerName: 'IFSC CODES', sortable: true, filter: true, resizable: true },
        { field: 'Letter upload No', headerName: 'Letter upload No', sortable: true, filter: true, resizable: true },
        { field: 'PM_Payment_Date', headerName: 'PM_Payment_Date', sortable: true, filter: true, resizable: true },
        { field: 'UTR Number', headerName: 'UTR Number', sortable: true, filter: true, resizable: true, editable: true },
        { field: 'Debit Date', headerName: 'Debit Date', sortable: true, filter: true, resizable: true, editable: true  },
        { field: 'Payment_Id', headerName: 'Payment_Id', sortable: true, filter: true, resizable: true },
        { field: 'BatchID', headerName: 'BatchID', sortable: true, filter: true, resizable: true },
        { field: 'Advice Squence', headerName: 'Advice Squence', sortable: true, filter: true, resizable: true },
        
    ];


    var utr_columns1 = [
        { field: '', headerCheckboxSelection: true, checkboxSelection: true, showDisabledCheckboxes: true, width:50},
        { field: 'Bank Name', headerName: 'Bank Name', sortable: true, filter: true, resizable: true, editable: true },
        { field: 'Account No', headerName: 'Account No', sortable: true, filter: true, resizable: true },
        { field: 'Accpac Code', headerName: 'Accpac Code', sortable: true, filter: true, resizable: true },
        { field: 'Date', headerName: 'Date', sortable: true, filter: true, resizable: true },
        { field: 'Acc #', headerName: 'Acc #', sortable: true, filter: true, resizable: true },
        { field: 'Issued Amt', headerName: 'Issued Amt', sortable: true, filter: true, resizable: true },
        { field: 'Name', headerName: 'Name', sortable: true, filter: true, resizable: true },
        { field: 'Company', headerName: 'Company', sortable: true, filter: true, resizable: true },
        { field: 'Emp#', headerName: 'Emp#', sortable: true, filter: true, resizable: true },       
        { field: 'Client Id', headerName: 'Client Id', sortable: true, filter: true, resizable: true },
        { field: 'Remarks', headerName: 'Remarks', sortable: true, filter: true, resizable: true },
        { field: 'invoice no', headerName: 'invoice no', sortable: true, filter: true, resizable: true },
        { field: 'IFSC CODES', headerName: 'IFSC CODES', sortable: true, filter: true, resizable: true },
        { field: 'Letter upload No', headerName: 'Letter upload No', sortable: true, filter: true, resizable: true },
        { field: 'PM_Payment_Date', headerName: 'PM_Payment_Date', sortable: true, filter: true, resizable: true },
        { field: 'UTR Number', headerName: 'UTR Number', sortable: true, filter: true, resizable: true },
        { field: 'Debit Date', headerName: 'Debit Date', sortable: true, filter: true, resizable: true },
        { field: 'Payment_Id', headerName: 'Payment_Id', sortable: true, filter: true, resizable: true },
        { field: 'BatchID', headerName: 'BatchID', sortable: true, filter: true, resizable: true },
        { field: 'Advice Squence', headerName: 'Advice Squence', sortable: true, filter: true, resizable: true },
        
        
    ];

    // var utr_columns1 = [
    //      { field: '', headerCheckboxSelection: true, checkboxSelection: true, showDisabledCheckboxes: true, width:50},
    //      { field: 'Bank Name', headerName: 'Bank Name', sortable: true, filter: true, resizable: true },
    //      { field: 'Account No', headerName: 'Account No', sortable: true, filter: true, resizable: true },
    //      { field: 'Accpac Code', headerName: 'Accpac Code', sortable: true, filter: true, resizable: true },
    //      { field: 'Date', headerName: 'Date', sortable: true, filter: true, resizable: true },
    //      { field: 'Acc #', headerName: 'Acc #', sortable: true, filter: true, resizable: true },
    //      { field: 'Issued Amt', headerName: 'Issued Amt', sortable: true, filter: true, resizable: true },
    //      { field: 'Name', headerName: 'Name', sortable: true, filter: true, resizable: true },
    //      { field: 'Company', headerName: 'Company', sortable: true, filter: true, resizable: true },
         
    //      { field: 'Emp#', headerName: 'Emp#', sortable: true, filter: true, resizable: true },
        
    //      { field: 'Client Id', headerName: 'Client Id', sortable: true, filter: true, resizable: true },
    //      { field: 'Remarks', headerName: 'Remarks', sortable: true, filter: true, resizable: true },
    //      { field: 'invoice no', headerName: 'invoice no', sortable: true, filter: true, resizable: true },
    //      { field: 'IFSC CODES', headerName: 'IFSC CODES', sortable: true, filter: true, resizable: true },
    //      { field: 'Letter upload No', headerName: 'Letter upload No', sortable: true, filter: true, resizable: true },
    //      { field: 'PM_Payment_Date', headerName: 'PM_Payment_Date', sortable: true, filter: true, resizable: true },
    //      { field: 'UTR Number', headerName: 'UTR Number', sortable: true, filter: true, resizable: true, editable: true },
    //      { field: 'Debit Date', headerName: 'Debit Date', sortable: true, filter: true, resizable: true, editable: true },
    //      { field: 'Payment_Id', headerName: 'Payment_Id', sortable: true, filter: true, resizable: true },
    //      { field: 'BatchID', headerName: 'BatchID', sortable: true, filter: true, resizable: true },
    //      { field: 'Advice Squence', headerName: 'Advice Squence', sortable: true, filter: true, resizable: true },
         
    //  ];
    // var utr_columns1 = [
        
    //     { id: 'Bank Name', label: 'Bank Name' },
    //     { id: 'Account No', label: 'Account No' },
    //     { id: 'Accpac Code', label: 'Accpac Code' },
    //     { id: 'Date', label: 'Date' },
    //     { id: 'Acc #', label: 'Acc #' },
    //     { id: 'Issued Amt', label: 'Issued Amt' },
    //     { id: 'Name', label: 'Name' },
    //     { id: 'Company', label: 'Company' },
        
    //     { id: 'Emp#', label: 'Emp#' },
       
    //     { id: 'Client Id', label: 'Client Id' },
    //     { id: 'Remarks', label: 'Remarks'},
    //     { id: 'invoice no', label: 'invoice no' },
    //     { id: 'IFSC CODES', label: 'IFSC CODES' },
    //     { id: 'Letter upload No', label: 'Letter upload No'},
    //     { id: 'PM_Payment_Date', label: 'PM_Payment_Date' },
    //     { id: 'UTR Number', label: 'UTR Number'},
    //     { id: 'Debit Date', label: 'Debit Date' },
    //     { id: 'Payment_Id', label: 'Payment_Id' },
    //     { id: 'BatchID', label: 'BatchID' },
    //     { id: 'Advice Squence', label: 'Advice Squence' },
        
    // ];

    var advice_columns = [
        { field: 'advice column', headerName: 'advice column', sortable: true, filter: true, resizable: true },
        { field: 'total', headerName: 'total', sortable: true, filter: true, resizable: true },
        { field: 'Withdrawed Amount', headerName: 'Withdrawed Amount', sortable: true, filter: true, resizable: true },
        { field: 'debit date', headerName: 'debit date', sortable: true, filter: true, resizable: true }
    ]
 

    const insuranceCompanyOptionsList = [
        { value: "All", label: "All" },
        { value: "AXIS", label: "AXIS"},
        { value: "HDFC", label: "HDFC"},
        { value: "ICICI", label: "ICICI"},
        { value: "SBI", label: "SBI"},
    ];
    
    const OptionsList = [
        { value: "advice", label: "advice" },
        { value: "utr", label: "utr"},
    ];

    useEffect(() => {
        setLoaderOpen(false);
    }, []);

    const makeAPICall = async (url) => {
        try {
            setLoaderOpen(true);
            console.log(url);
            const response = await fetch(url);
            const data = await response.json();
            setRowData(data);
           console.log('data', data);
            setHideResultGrid(false);
            setLoaderOpen(false);
        }
        catch (e) {
            console.log(e);
            setLoaderOpen(false);
            setHideResultGrid(true);
        }
    }
  
    

    const customStyles = {
        control: base => ({
            ...base,
            height: 35,
            minHeight: 35,
            marginTop: 0,
            paddingTop: -5,
            fontSize: 14,
            left: -31
        })
    };


    function searchClick(event) {
        if (companyname === undefined) {
            alert("Please Select Report Type!!!");
        }

        else{
            let url = '';
            console.log('companyname', companyname.value);
            let month = String(inputMonth)
            if (companyname && companyname.value && type && type.value) {
                let param = String(companyname.value)
                let param1 = String(type.value)
                url = localhost_url+`/api/v2/alcs/alcsreport/?companyname=${param}&&clientname=${param1}&&month=${month}`;
            }
            else if (companyname && companyname.value) {
                let param = String(companyname.value)
                console.log('paam' + param);
                url = localhost_url+`/api/v2/alcs/alcsreport/?companyname=${param}&&month=${month}`;
            }
            else if (type && type.value) {
                let param1 = String(type.value)
                url = localhost_url+`/api/v2/alcs/alcsreport/?clientname=${param1}&&month=${month}`;
            } else {
                url = localhost_url+`/api/v2/alcs/alcsreport/?month=${month}`;
            }
            makeAPICall(url);
        }

    }

    function exportJsonToXLSX(data, sheetName, excelFileName) {
        try {
            var workBook = XLSX.utils.book_new();
            var workSheet = XLSX.utils.json_to_sheet(data, {
                skipHeader: false,
            });
            XLSX.utils.book_append_sheet(workBook, workSheet, sheetName);
            XLSX.writeFile(workBook, excelFileName);
            return true;
        }
        catch
        {
            return false;
        }
    }

    function exportToExcel() {
        let fileNameChange = "Report.xlsx";
        let sheetName = "sheet";

        let excelExportData = [];

        for (let i = 0; i < rowData.length; i++) {
            let data = {};
            for (let key in rowData[i]) {
                for (let j = 0; j < gridColumns.length; j++) {
                    if (key === gridColumns[j]["field"]) {
                        data[gridColumns[j]["headerName"]] = rowData[i][key]
                    }
                }
            }

            excelExportData.push(data);
        };

        exportJsonToXLSX(excelExportData, sheetName, fileNameChange);

    }


    function handleChange(data) {
        setCompanyName(data);
        console.log(data.value);
        setHideResultGrid(true);

    }

    function handleChange1(data) {
        setType(data);
        console.log(data.value);
        if(data.value == 'advice'){
            setGridColumns(advice_columns);
            isSetUtr(false);
        }else{
            setGridColumns(utr_columns);
            isSetUtr(true);
        }
        setHideResultGrid(true);
    }

    function onChangeMonth(e){
        setInputMonth(e.target.value);
        console.log(e.target.value);
    }

    
    const timeOperation = (name, operation) => {
        aggCallCount = 0;
        compareCallCount = 0;
        filterCallCount = 0;
        var start = new Date().getTime();
        operation();
        var end = new Date().getTime();
        console.log(
        name +
            ' finished in ' +
            (end - start) +
            'ms, aggCallCount = ' +
            aggCallCount +
            ', compareCallCount = ' +
            compareCallCount +
            ', filterCallCount = ' +
            filterCallCount
        );
    };


    const onBtDelete = () => {
    var api = gridRef.current.api;
    // get the first child of the
    console.log('rowData', rowData);
    var selectedRows = api.getSelectedRows();
    console.log('selectedRows', selectedRows);
    var rowdata = rowData;
    selectedRows.map(data =>{
        rowdata && rowdata.map((data1, index) =>{
            if(data1.ISSUED_AMT == data.ISSUED_AMT && data1.EMP_ACCOUNT_NUMBER == data.EMP_ACCOUNT_NUMBER && data1.REMARKS == data.REMARKS){
                console.log('index',index);
                rowdata.splice(index, 1); 
                setRowData(rowData);
            }
        })
    })
    

        if (!selectedRows || selectedRows.length === 0) {
            console.log('No rows selected!');
            return;
        }
        timeOperation('Delete', function () {
            api.applyTransaction({ remove: selectedRows });
        });
    };

    const onBtEdit = () =>{
        setHideResultGrid(true);
        setGridColumns(utr_columns1);
        setHideResultGrid(false);
    }
    return (
        <>
            <div className="report-cardBox">
                <div className="" style={{ marginLeft: "-10px" }}>
                    <div>
                        <label id="underline_select" htmlFor="underline_select " style={{ fontSize: '15px', marginLeft:'15px' }}>Date</label><br />
                        <Input type="date" className="cardName filetype" style={{ paddingLeft: "10px", marginTop:'5px' }} onChange={(e) => onChangeMonth(e)} />
                    </div>
                </div>
                <div className="">
                    <div>
                        <label htmlFor="underline_select " style={{ fontSize: '15px', marginLeft:'-25px' }}> Select Type</label> <br />
                        <div className="cardName">
                            <div className="dropdown-container">
                                <Select
                                    options={OptionsList}
                                    placeholder="Select type"
                                    value={type}
                                    onChange={handleChange1}
                                    isSearchable={true}
                                    styles={customStyles}
                                />
                            </div>
                        </div>
                    </div>
                </div>
                <div className="">
                    <div>
                        <label htmlFor="underline_select " style={{ fontSize: '15px', marginLeft:'-25px' }}>Bank Name</label> <br />
                        <div className="cardName">
                            <div className="dropdown-container">
                                <Select
                                    options={insuranceCompanyOptionsList}
                                    placeholder="Select Company Name"
                                    value={companyname}
                                    onChange={handleChange}
                                    isSearchable={true}
                                    styles={customStyles}
                                />
                            </div>
                        </div>
                    </div>
                </div>
               
                
                {inputMonth && type ?
                    <button className="btn" style={{ height: "35px", width: "92px", marginTop: "28px", backgroundColor: "#000055", color: "#ffffff" }} onClick={(e) => { searchClick(e) }}>Search</button>
                    : <button className="btn" disabled={true} style={{ height: "35px", width: "92px", marginTop: "28px", backgroundColor: "#000055", color: "#ffffff" }}>Search</button>
                }
            </div>
            <div className="report" hidden={hideResultGrid}>
                <div>
                    <img src={excelIcon} alt="No Images" style={{ width: '40px', height: '37px' }} className="excel-icon-class" onClick={() => { exportToExcel() }} title="Export" />
                    { isutr ? (<>
                    <button style={{ height: "35px", width: "92px", marginTop: "28px", backgroundColor: "#000055", color: "#ffffff", marginLeft:'2em' }} onClick={onBtEdit}>Edit</button>
                    <button style={{ height: "35px", width: "92px", marginTop: "28px", backgroundColor: "#000055", color: "#ffffff", marginLeft:'2em' }} onClick={onBtDelete}>Delete</button></>):(<></>)
                    }
                
                </div>
                <div className="ag-theme-balham report-layer" style={{width:'100%', heidght:'100%'}}>
                    <AgGridReact
                        columnDefs={gridColumns}
                        rowData={rowData}
                        // paginationPageSize={paginationSize}
                        // pagination={true}
                        animateRows={true}
                        rowSelection={'multiple'}
                        groupSelectsChildren={true}
                        ref={gridRef}
                        suppressAggAtRootLevel={true}
                        suppressRowClickSelection={true}
                        
                    >
                    </AgGridReact>
                </div>
            </div>
          
            <LoaderComponent loaderOpen={loaderOpen} />

        </>
    )
}

export default AlcsReport;











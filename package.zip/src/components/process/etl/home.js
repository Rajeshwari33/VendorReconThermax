// App.js
import { useEffect, useState } from "react";
// import "./App.css";
import "./etlsecound.css";
import hdfcs from './../../../assets/images/banks/thermax.png';


function Home() 
{
  

  return (
  <div>
    <table class=" table">
    <tr style={{fontWeight:"900"}}>
        <td>ORGANIZATION</td>
        <td ><img src={hdfcs} alt="" height="70px" width="90px" />THERMAX LIMITED </td>
    </tr>
    <tr>
        <td>REPORT GENERATION DATE</td>
        <td>2023-02-10 17:19:42.831549</td>
    </tr>
   
   <br></br>
   <br></br>
   <br></br>
    <tr style={{fontWeight:"900",backgroundColor:" #92c9e6"}}>
        <td>VEDNOR NAME</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
    </tr>
    <tr>
        <td>REPORT FROM DATE</td>
        <td>2021-04-01</td>
    </tr>
    <tr>
        <td>REPORT TO DATE</td>
        <td>2022-03-31</td>
    </tr>
    <tr>
        <td>VENDOR CODE</td>
        <td>146491</td>
    </tr>
    <tr>
        <td>VENDOR SITE CODE</td>
        <td>DURGAPUR</td>
    </tr>
    <tr>
        <td>VENDOR CATEGORY</td>
        <td>E&amp;C</td>
    </tr>
    <tr>
        <td>LIABILITY ACCOUNT</td>
        <td>08-103000-3005-20321-110001-000000-000000</td>
    </tr>
    <tr>
        <td>DIVISION</td>
        <td>Power</td>
    </tr>
    <tr>
        <td>PAN NUMBER</td>
        <td>ALSPK3740Q</td>
    </tr>
    <tr>
        <td>GST NUMBER</td>
        <td>19ALSPK3740Q1Z7</td>
    </tr>
</table>
  </div>
  )
}



export default Home;
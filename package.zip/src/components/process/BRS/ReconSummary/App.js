import { useEffect, useState } from 'react';
import './App.css';
import {Chart as ChartJs, Tooltip, Title, ArcElement, Legend} from 'chart.js';
import { Doughnut } from 'react-chartjs-2';
ChartJs.register(
  Tooltip, Title, ArcElement, Legend
);


const initialData = {
  datasets: [
    {
      data: [10, 20, 30],
      backgroundColor: ['red', 'blue', 'yellow'],
    },
  ],
  labels: ['Red', 'Yellow', 'Blue'],
};

function App() {
  const [chartData, setChartData] = useState(initialData);

  useEffect(() => {
    const fetchData = () => {
      fetch('https://jsonplaceholder.typicode.com/users')
        .then((response) => response.json())
        .then((res) => {
          const labels = [];
          const values = [];

          for (const item of res) {
            labels.push(item.name);
            values.push(item.id);
          }

          setChartData((prevData) => ({
            ...prevData,
            datasets: [
              {
                data: values,
                backgroundColor: ['red', 'blue', 'yellow'],
              },
            ],
            labels: labels,
          }));
        })
        .catch((error) => {
          console.log('Error:', error);
        });
    };

    fetchData();
  }, []);

  return (
    <div className="App" style={{ width: '30%', height: '30%' }}>
      <Doughnut data={chartData} />
    </div>
  );
}

export default App;
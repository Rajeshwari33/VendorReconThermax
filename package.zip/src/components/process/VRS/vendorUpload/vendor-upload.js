import React, { useState } from 'react';

function VendorUpload() {
  const [activeTab, setActiveTab] = useState('tab1');

  const handleTabClick = (tab) => {
    setActiveTab(tab);
  };

  return (
    <div>
      <div className="tabs">
        <div
          className={`tab ${activeTab === 'tab1' ? 'active' : ''}`}
          onClick={() => handleTabClick('tab1')}
        >
          Tab 1
        </div>
        <div
          className={`tab ${activeTab === 'tab2' ? 'active' : ''}`}
          onClick={() => handleTabClick('tab2')}
        >
          Tab 2
        </div>
      </div>

      <div className="tab-content">
        {activeTab === 'tab1' && <Screen1 />}
        {activeTab === 'tab2' && <Screen2 />}
      </div>
    </div>
  );
}

function Screen1() {
  return (
    <div>
      <h2>Screen 1</h2>
      {/* Content for Screen 1 */}
    </div>
  );
}

function Screen2() {
  return (
    <div>
      <h2>Screen 2</h2>
      {/* Content for Screen 2 */}
    </div>
  );
}

export default VendorUpload;

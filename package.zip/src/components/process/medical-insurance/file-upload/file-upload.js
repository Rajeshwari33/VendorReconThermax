import React, { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import './file-upload.css';
import Select from "react-select";
import { getFileUploadListFromServer, port } from '../../../../services/process/medical-insurance/medicalInsuranceFileUploadService';
import { getFileProcessFromServer } from '../../../../services/process/medical-insurance/medicalInsuranceReportService.js';
import axios from "axios";
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-balham.css';
import { AgGridReact } from 'ag-grid-react';
import LoaderComponent from "../../../../libraries/loader/loader";
import refreshIcon from "../../../../assets/images/refresh.png";
import {baseUrl} from "../../../../services/common/credentials";

var local_host = baseUrl + port;


function MedicalInsuranceFileUpload()
{
    const gridColumnDefs = [
        {field: 'source_type', headerName: 'Source Type', sortable: true, filter: true, resizable: true, width: 130},
        {field: 'file_type', headerName: 'File Type', sortable: true, filter: true, resizable: true, width: 150},
        {field: 'month', headerName: 'Process Month', sortable: true, filter: true, resizable: true, width: 100},
        {field: 'extraction_type', headerName: 'Extraction Type', sortable: true, filter: true, resizable: true, width: 125},
        {field: 'file_name', headerName: 'File Name', sortable: true, filter: true, resizable: true, width: 200},
        {field: 'file_size_bytes', headerName: 'File Size (KB)', sortable: true, filter: true, resizable: true, width: 100},
        {field: 'status', headerName: 'Status', sortable: true, filter: true, resizable: true, width: 100},
        {field: 'comments', headerName: 'Comments', sortable: true, filter: true, resizable: true, width: 200},
        {field: 'created_date', headerName:'Upload Date Time', sortable: true, filter: true, resizable: true, width: 200}
    ]

    const [selectedOptions, setSelectedOptions] = useState();
    const [inputMonth, setInputMonth] = useState(undefined);
    const [userCredentials] = useState(JSON.parse(sessionStorage.getItem("userCredentials")));
    const { register, handleSubmit } = useForm();
    const [columnDefs] = useState(gridColumnDefs);
    const [rowData, setRowData] = useState(undefined);
    const [paginationSize] = useState(15);
    const [loaderOpen, setLoaderOpen] = useState(false);

    useEffect(() => {
        fileUploadsList();
    }, []);

    const optionList = [
        { value: "MIS", label: "MIS Data", m_source_id: 1},
        { value: "Associates", label: "Associates Data", m_source_id: 2},
        { value: "Exit", label: "Exit InterView Report", m_source_id: 3},
        { value: "Death", label: "Death Tracker", m_source_id: 4},
        { value: "Staffing", label: "Staffing Pay Register", m_source_id: 5},
        { value: "Opp register", label: "Opp Salary Register", m_source_id: 6},
        { value: "Dependency Data", label: "Dependency Data", m_source_id: 7},
        { value: "Health Card", label: "Health Card", m_source_id: 8},
    ];

    const onSubmit = async (data) => {
        
        if (selectedOptions === undefined)
        {
            alert("Please Select a File Type before Upload!!!");
        }
        else if (inputMonth === undefined)
        {
            alert("Please Choose the Month of file before Upload!!!");
        }
        else if (data.file[0] === undefined)
        {
            alert("Please Choose a File for Upload!!!");
        }
        else
        {
            const formData = new FormData();

            formData.append("file", data.file[0]);
            formData.append("file_type", selectedOptions["label"]);
            formData.append("tenants_id", userCredentials["tenants_id"]);
            formData.append("groups_id", userCredentials["groups_id"]);
            formData.append("entities_id", userCredentials["entities_id"]);
            formData.append("user_id", userCredentials["user_id"]);
            formData.append("m_processing_layer_id", userCredentials["m_processing_layer_id"]);
            formData.append("m_processing_sub_layer_id", userCredentials["m_processing_sub_layer_id"]);
            formData.append("processing_layer_id", userCredentials["processing_layer_id"]);
            formData.append("processing_layer_name", "Medical Insurence");
            // formData.append("processing_layer_name", userCredentials["processing_layer_name"]);
            formData.append("source_type", "FILE");
            formData.append("extraction_type", "Upload");
            formData.append("month", inputMonth);
            formData.append("type", "post_file_upload");
            formData.append("m_source_id", selectedOptions["m_source_id"]);
            formData.append("is_processing", 0);


            // console.log("Form Data", data.file[0]);
            // console.log("selected", selectedOptions);
            // console.log("Month", inputMonth);
            try
            {
                setLoaderOpen(true);
                const fileUploadResponse = await fetch(local_host+"/api/v2/user_modules/medical_insurance/file_uploads/", {
                    method: "POST",
                    body: formData,
                }).then((res) => res.json());

                console.log("response", fileUploadResponse);
                if (fileUploadResponse["Status"] !== "Success")
                {
                    alert("Error in Uploading File!!!");
                    setLoaderOpen(false);
                }
                else
                {
                      fileUploadsList();
                    alert("File Uploaded Successfully!!!");
                    setInputMonth(undefined);
                    setSelectedOptions(undefined);
                    document.getElementById("file-upload-form").reset();
                    document.getElementById("file-upload-month").value = '';
                    setSelectedOptions([]);
                    setLoaderOpen(false);
                }
            }
            catch (err)
            {
                console.log("Error", err);
                setLoaderOpen(false);
            }

            // console.log(JSON.stringify(`${res.message}, status: ${res.status}`));
        }
    };

    function fileUploadsList()
    {
        setLoaderOpen(true);
        let payload = {
            "tenants_id": userCredentials["tenants_id"],
            "groups_id": userCredentials["groups_id"],
            "entities_id": userCredentials["entities_id"],
            "m_processing_layer_id": userCredentials["m_processing_layer_id"],
            "m_processing_sub_layer_id": userCredentials["m_processing_sub_layer_id"],
            "processing_layer_id": userCredentials["processing_layer_id"],
            "is_active": "yes"
        }

        var getFileUploadsList = getFileUploadListFromServer();

        axios.get(getFileUploadsList[1], {params : payload}, getFileUploadsList[0])
        .then(
            response => {
                console.log("File Upload Response!!!", response)
                let data = response["data"];
                if (data["Status"] === "Success")
                {
                    let rowData = data["response_data"];
                    for(let i = 0; i < rowData.length; i++)
                    {
                        rowData[i]["file_size_bytes"] = Math.round( rowData[i]["file_size_bytes"] * 0.001 ) / 100;
                    }

                    setRowData(rowData);
                    setLoaderOpen(false);
                }
            }
        ).catch(
            error => {
                console.log("Error in File Upload List!!!", error);
                setLoaderOpen(false);
            }
        );

    }

    function handleSelect(data) {
        // console.log(data);
        setSelectedOptions(data);
    }

    const customStyles = {
        control: base => ({
          ...base,
          height: 35,
          minHeight: 35,
          marginTop: 0,
          paddingTop: -5,
          fontSize: 14,

        })
    };

    function searchForm(){
        setLoaderOpen(true);
        let payload = {
            "tenants_id": 1,
            "groups_id": 1,
            "entities_id": 1,
            "m_processing_layer_id": 1,
            "m_processing_sub_layer_id": 1,
            "processing_layer_id": 1,
            "is_active": "yes",
            "month" : inputMonth,
        }

        var getFileProcess = getFileProcessFromServer();

        axios.post(getFileProcess[1], {params : payload}, getFileProcess[0])
        .then(
            response => {
                console.log("File Process Response!!!", response)
                let data = response["data"];
                // console.log("response", data["data"])
                if (data["Status"] === "Success")
                {
                    alert("File Processed Successfully!!!");
                    setLoaderOpen(false);
                }
                else
                {
                    alert("File Processed Failed!!!");
                    setLoaderOpen(false);
                }
            }
        ).catch(
            error => {
                console.log("Error in File Process List!!!", error);
                setLoaderOpen(false);
            }
        );
    }

    return (
        <>
            <div className="file-upload-cardBox">
                <div className="file-upload-card">
                    <div>
                        <label htmlFor="underline_select " className="sr-only numbers" style={{fontSize: '15px', left: '-30px'}}>File Type</label><br />
                        <div className="cardName">
                            <div className="dropdown-container">
                                <Select id="file-upload-select"
                                options={optionList}
                                placeholder="Select Type"
                                value={selectedOptions}
                                onChange={handleSelect}
                                isSearchable={true}
                                styles = {customStyles}
                                //   isMulti
                                />
                            </div>
                        </div>
                    </div>
                </div>

                <div className="file-upload-card">
                    <div>
                        <label  id="underline_select" htmlFor="underline_select " className="sr-only numbers" style={{fontSize: '15px'}}>Month</label><br />
                        <input type="month" className="cardName filetype" style={{paddingLeft: "10px"}} onChange={(e) => {setInputMonth(e.target.value)}} id="file-upload-month" />
                    </div>
                </div>

                <div className="file-upload-card">
                    <div>
                        <label htmlFor="underline_select " className="sr-only numbers " style={{fontSize: '15px'}}>File Upload</label><br />
                        <form onSubmit={handleSubmit(onSubmit)} id="file-upload-form">
                            <input type="file" {...register("file")} />
                            <input type="submit" value="Upload" className="btn" style={{height:"35px",marginTop: "-60px",marginLeft:"330px",backgroundColor:"#000055",color:"#ffffff"}} />
                        </form>
                        {/* <button style={{height:"35px",marginTop: "-60px",marginLeft:"330px",backgroundColor:"#000055",color:"#ffffff"}} onClick={searchForm}>
                                        Run
                        </button> */}
                        
                    </div>
                    {/* <div className="cardHeader">
                        
                        <h4><a href={""} className="btn" style={{marginTop: "43px"}}> Upload</a></h4>  
                    </div> */}
                </div>
            </div>

            <div className="file-upload">
                <img src={refreshIcon} alt="No Images" style={{width: '40px', height: '37px'}}  className="referesh-icon-class" title="Refresh" />
                <button style={{height:"35px",marginTop: "-47px",marginLeft:"61px",backgroundColor:"#000055",color:"#ffffff", width:"7%", borderRadius:"9%"}} onClick={searchForm}>
                                    Run
                </button>
                <div className="ag-theme-balham fileupload-layer">
                    <AgGridReact
                        columnDefs = {columnDefs}
                        rowData = {rowData}
                        paginationPageSize = {paginationSize}
                        pagination = {true}
                        animateRows = {true}
                    ></AgGridReact>
                </div>
            </div>
            <LoaderComponent loaderOpen = {loaderOpen} />
        </>
    )
}


export default MedicalInsuranceFileUpload;



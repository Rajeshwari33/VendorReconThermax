import { event } from 'jquery';
import React,{useEffect, useState} from 'react';

import Select from "react-select";
import './brs.css';
// import './dashboard.css';
import axios from 'axios';
import icici from '../../../../assets/images/banks/icici.png';
import axis from '../../../../assets/images/banks/axisbank.png';
import hdfc from '../../../../assets/images/banks/hdfc.png';
import yes from '../../../../assets/images/banks/yesbank.png';
import indusind from '../../../../assets/images/banks/indusind.png';
import sbi from '../../../../assets/images/banks/sbi1.png';

import {monthWiseBrsToServer, approvedBrsToServer} from  '../../../../services/process/migrations/migrationService.js';
import {NavLink} from 'react-router-dom';
// import {Bar} from 'react-chartjs-2';
// import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, AreaChart, Area, BarChart, Bar } from 'recharts';
import {
    BarChart,
    Bar,
    XAxis,
    YAxis,
    CartesianGrid,
    Tooltip,
    Legend
  } from "recharts";


function BRS({hidden})
{
    const bankList = [{"bank_name": 'HDFC062', "balance": '1455322778.43'}]
    const [hideBrsDetailsContent, setHideBrsDetailsContent] = useState(true);
    const [hideBrsBankDetailsContent, setHideBrsBankDetailsContent] = useState(true);
    const [approverHidden, setApproverHidden] = useState(true);
    const [inputMonth, setInputMonth] = useState(undefined);
    const [selectedOptionsAccountType, setSelectedOptionsAccountType] = useState(undefined);
    const [selectedOptionsBank, setSelectedOptionsBank] = useState(undefined);
    const [selectedOptions, setSelectedOptions] = useState(undefined);
    const [selectedType, setSelected] = useState('');
    const[selectedBank,setBankSelected]= useState('');
    const[brsBankDetails,setBrsBankDetails]= useState(bankList);
    
    const[approverName,setApproverName]= useState('');
    const[approvedOn,setApprovedOn]= useState('');
    const[closedBrsBankDetails,setClosedBrsBankDetails]= useState(bankList);
    const[bankImages,setBankImages]=useState('');
    const[cardOnclik,setCardOnclick]=useState('');
    // const bankList = useState('');

    // console.log("hi bankList", bankList);


    // useEffect(() => {
    // }, []);
    
    const accountTypeOptionsList=[
        { value: "select type", label: "Select Type"},
        { value: "opex", label: "Opex"},
        { value: "regular", label: "Regular"}
    ];

    const BankOptionsList=[
        { value: "0", label: "SBI"},
        { value: "1", label: "ICICI"},
        { value: "2", label: "AXIS"},
        { value: "3", label: "HDFC"},
        { value: "4", label: "YES"},
        { value: "4", label: "INDUSIND"},

    ];


    const customStyles = {
        control: base => ({
          ...base,
          width:"20%",
          marginLeft:"27%",
          marginTop:"-20%"
        //   height: 35,
        //   minHeight: 35,
        //   marginTop:10,
        //   paddingTop: -5,
        //   fontSize: 14,
        //   left: -31
        })
    };



    function getSetInputMonth(data){
        setInputMonth(data);
        console.log(data);
    }

    function getAccountType(data){
        setSelectedOptionsAccountType(data);
        console.log("acount", data);
    }

    function getBank(data){
        console.log("bank",data);
        setSelectedOptionsBank(data);
        
    } 
    // console.log("setBankSelected",selectedBank);
    console.log("setSelected", selectedType);
    console.log("inputMonth", inputMonth);

    // if(selectedBank === "SBI"){
    //     setBankImages(sbi);
    // }
    // else if(selectedBank === "ICICI"){
    //     setBankImages(icici);
    // }
    // else if(selectedBank === "INDUSIND"){
    //     setBankImages(indusind);
    // }
    // else if(selectedBank === "HDFC"){
    //     setBankImages(hdfc);
    // }
    // else if(selectedBank === "YES"){
    //     setBankImages(yes);
    // }
    // else if(selectedBank === "AXIS"){
    //     setBankImages(axis);
    // }

    function monthWiseBrs()
    {
        let payload = {
            month: inputMonth,
            bank: selectedBank,
            type: selectedType,
            name: "BRS Month Wise"
        }

        var brsCredentials = monthWiseBrsToServer();
        console.log("brsCredentials", brsCredentials);

        axios.post(brsCredentials[1], payload, brsCredentials[0])
        .then(
            response => {
                console.log("Getting Month Wise BRS!!!", response);
                let responseData = response["data"]; 
                console.log("responseData", responseData);
                if (responseData["Status"] === "Success")
                {
                    let closedBrsDetails = responseData["closedDetails"];
                    let brsDetails = responseData["brsCount"]; 
                    
                    // sessionStorage.setItem("userCredentials", JSON.stringify(userCredentials));
                    // navigate(userCredentials["config"]["default_page"]);
                    console.log("closedBrsDetails", closedBrsDetails["data"].length);
                    // console.log("demoBrsDetails", brsCount["data"].length);


                    setBrsBankDetails(brsDetails["data"]);
                    setClosedBrsBankDetails(closedBrsDetails["data"]);
                    
                    setHideBrsDetailsContent(false);
                    if (selectedType === "Current"){
                        setHideBrsDetailsContent(false);
                        setHideBrsBankDetailsContent(true);
                    }
                    else if (selectedType === "Lastsixmonth"){
                        console.log("hiiii")
                        setHideBrsDetailsContent(true);
                        setHideBrsBankDetailsContent(false);
                    }

                    setApproverHidden(true);
                    let bankImage = ''
                    if(selectedBank === "SBI"){
                        bankImage = sbi;
                    }
                    else if(selectedBank === "ICICI"){
                        bankImage = icici;
                    }
                    else if(selectedBank === "INDUSIND"){
                        bankImage = indusind;
                    }
                    else if(selectedBank === "HDFC"){
                        bankImage = hdfc;
                    }
                    else if(selectedBank === "YES"){
                        bankImage = yes;
                    }
                    else if(selectedBank === "AXIS"){
                        bankImage = axis;
                    }
                    setBankImages(bankImage);
                    // const bankList = useState(brsBankDetails);
                    // if (closedBrsDetails["data"].length === 0){
                    //     setApproverHidden(true);
                    // }
                    // else{
                    //     setApproverHidden(true);
                    // }
                    // getBankList(brsBankDetails);
                }
            }
            
        ).catch(
            error => {
                console.log("Error", error);
                alert("Error in Getting BRS Details!!!");
            }
        );
    };
    // console.log("closedBrsBankDetails", closedBrsBankDetails);

    function getBankList()
    {
        // const bankList = brsBankDetails;
        console.log("hi bankList1", brsBankDetails);

        return (
            
            <div className="brsbanklayer brsoverflow">
                {brsBankDetails.map(item => (
                <div>
                <div class="popup-link-13"  onClick={deleteUserWithName(item.bank_name)}>
                    <a href="#popup13" >
                    {/*} */}
                    <div className="brsbankbox" >
                    <table>
                        <tbody>
                            <thead>
                                
                                <tr>
                                    <td><img src={bankImages} alt="" height="100px" width="100px" /></td><div class="circleBase circle1"></div>
                                </tr>
                                
                                <tr>
                                    <td>{item.bank_name}</td>
                                </tr>
                                <tr>
                                    <td>{item.balance}</td>
                                </tr>
                            </thead>
                        </tbody>
                    </table>
                    </div> 
                    </a>
                </div> 
                </div>
                ))}
            </div>
        );
    }

   console.log("cardonclick",cardOnclik);
    function deleteUserWithName (bank_name) {
        
        console.log("cardonclick",bank_name)
        
      }

    function barChartOnClick(e)
    {
        const balance = e.balance
        const bank_name = e.bank_name
        console.log("barClicked",balance);
        console.log("bank",bank_name);
        let payload = {
            month: inputMonth,
            bank: selectedBank,
            type: selectedType,
            name: "BRS Month Wise",
            balance: balance
        }

        var approverDetails = approvedBrsToServer();
        // console.log("brsCredentials", brsCredentials);

        axios.post(approverDetails[1], payload, approverDetails[0])
        .then(
            response => {
                console.log("Getting Approved BRS!!!", response);
                let responseData = response["data"]; 
                console.log("responseData", responseData);
                if (responseData["Status"] === "Success")
                {
                    let approverDetails = responseData["approverDetails"];
                    // let brsDetails = responseData["brsCount"]; 
                    
                    // sessionStorage.setItem("userCredentials", JSON.stringify(userCredentials));
                    // navigate(userCredentials["config"]["default_page"]);
                    console.log("approverDetails", approverDetails["data"].length);
                    
                    
                    setApproverName(approverDetails["data"][0]["approved_by"]);
                    setApprovedOn(approverDetails["data"][0]["approved_date"]);
                    if (approverDetails["data"].length > 0){
                        setApproverHidden(false);
                    }
                    else{
                        setApproverHidden(true);
                    }
                        
                    // getBankList();
                }
            }
        ).catch(
            error => {
                console.log("Error", error);
                alert("Error in Getting BRS Details!!!");
            }
        );
    }



    const DataFormater = (number) => {
        if(number > 1000000000){
          return (number/1000000000).toString() + 'B';
        }else if(number > 1000000){
          return (number/1000000).toString() + 'M';
        }else if(number > 1000){
          return (number/1000).toString() + 'K';
        }else{
          return number.toString();
        }
      }

    
    return (
        <div>
            <div hidden = {hidden}>
            <div>
            <div className="brschartbox1">
                <div className="brschart-box-layer">
                    <table style={{width:"85%",marginTop:"-8px"}}>
                    
                        <tbody>
                            <tr>
                                <td className="brsaddcontracttext">Month</td>
                                <td>:</td>
                                <td><input type="month" name="" onChange={(e) => {setInputMonth(e.target.value)}}/></td>
                                <td className="brsaddcontracttext">Account type</td>
                                <td>:</td>
                                <td>
                                    <select style={{padding:"4px 16px"}}
                                    onChange={(e) => {setSelected(e.target.value)}}>
                                        <option >Selecte Type :</option>
                                        <option >Opex</option>
                                        <option>Regular</option>
                                    
                                    </select>
                                </td>
                                <td className="brsaddcontracttext">Bank</td>
                                <td>:</td>
                                <td >
                                    <select style={{padding:"4px 16px"}}
                                    onChange={(e) => {setBankSelected(e.target.value)}}>
                                        <option >Select Bank:</option>
                                        <option value="SBI">SBI</option>
                                        <option value="ICICI">ICICI</option>
                                        <option value="INDUSIND">INDUSIND</option>
                                        <option value="HDFC">HDFC</option>
                                        <option value="YES">YES</option>
                                        <option value="AXIS">AXIS</option>
                                    
                                    </select>
                                </td>
                                <td><button style={{textAlign: "center",  border: ".1px solid #000055", color: "#ffffff", padding:"4px 16px", borderRadius: "15px", backgroundColor: "#024f9d" }} onClick={monthWiseBrs}>
                                    Search
                                </button>&nbsp;</td>
                            </tr>
                            
                        </tbody>
                    
                    </table>
                    
                
                </div>
            </div>
            <div className="brschartbox">
                <div className="brsrecentOrders" hidden = {hideBrsDetailsContent}>
                        {/* bank layer */}
                
                    <div>
                        {getBankList()}
                        

                    </div>

                    {/* chart */}
                    <div className="brsbanklayer" >
                        <div>
                        <h5 style={{textAlign:"center"}}>Closed Accounts</h5>
                        <br></br>
                        <div class="popup-link-3">
                            <a href="#popup3">
                            <BarChart width={550} height={300} data={closedBrsBankDetails} margin={{left:0,top:0,bottom:0,right:0}} style={{margin:"auto"}} >
                            <Legend />
                                <Bar dataKey="balance" fill="#0A2352 " background={{ fill: '#eee' }} minPointSize={5} barSize={45} onClick={barChartOnClick} />
                                {/* <Bar dataKey="balance" fill="#82ca9d" barSize={45} onClick={barChartOnClick} /> */}

                                {/* <CartesianGrid stroke="#ccc" /> */}
                                <XAxis dataKey="bank_name" />
                                <YAxis dataKey="balance"/>
                                <Tooltip  cursor={false} color="black"/>
                            </BarChart>
                            </a>
                         </div>
                        
                        
                        </div>
                        <br/><br/>
                        <div hidden={approverHidden}>
                          <div>
                                <div id="popup3" class="popup-container-3 popup-style-3">
                                    <div class="popup-content-3">
                                        <a href="#" class="close-3">&times;</a>
                                        <table style={{width:"40%"}}>
                                            <tr>
                                                <td className='brsfontApproved'> <label>Approved By :</label></td>
                                                <td> <div style={{marginLeft:"4%"}}>{approverName}</div></td>
                                            </tr>
                                            <tr>
                                                <td className='brsfontApproved'> <label>Approved On :</label></td>
                                                <td><div style={{marginLeft:"4%"}}>{approvedOn}</div></td>
                                            </tr>
                                        </table>
                                    </div>
                                </div>
                          </div>
                        </div>

                        {/* cardbank output */}
                         <div>
                             <div id="popup13" class="popup-container-13 popup-style-13">
                                    <div class="popup-content-13">
                                        <a href="#" class="close-13">&times;</a>
                                        <table style={{width:"40%"}}>
                                            <tr>
                                                <td><div class="circleBase circle3"></div></td>
                                                <td> </td>
                                                <td> Jun</td>
                                            </tr>
                                             <tr>
                                                <td><div class="circleBase circle3"></div></td>
                                                <td></td>
                                                <td>July</td>
                                            </tr>
                                            <tr>
                                                <td><div class="circleBase circle3"></div></td>
                                                <td></td>
                                                <td>August</td>
                                            </tr>
                                            <tr>
                                                <td><div class="circleBase circle3"></div></td>
                                                <td></td>
                                                <td>September</td>
                                            </tr>
                                            <tr>
                                                <td><div class="circleBase circle3"></div></td>
                                                <td></td>
                                                <td>October</td>
                                            </tr>
                                            <tr>
                                                <td><div class="circleBase circle3"></div></td>
                                                <td></td>
                                                <td>November</td>
                                            </tr>
                                        </table>
                                       
                                    </div>
                                </div>
                         </div>
                        {/* endcardbank output */}
                    </div>
                </div>
            </div>
    
                </div>
            </div>
        </div>
    );
}

export default BRS;
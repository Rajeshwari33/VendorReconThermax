import React, { useState } from "react";
import Chart from "react-apexcharts";

const ChartComponent = () => {
  const [labelnames, setLabelNames] = useState([
    "Apple",
    "Mango",
    "Orange",
    "Watermelon",
    "fruit"
  ]);
  const [seriesdata, setSeriesdata] = useState([44, 55, 41, 17, 67]);
  const [highlightedIndex, setHighlightedIndex] = useState(null);
  const [showLegend, setShowLegend] = useState(true);

  const [data, setData] = useState({});

  const handleDataPointSelection = (event, chartContext, config) => {
    const selectedLabel = config.w.config.labels[config.dataPointIndex];
    const index = labelnames.indexOf(selectedLabel);
    console.log("index", index);

    let data1 = data;
    data1[labelnames[index]] = seriesdata[index];

    setData(data1);

    // setData(prevData => ({
    //     ...prevData, // Spread the previous data
    //     [`{index}`]: seriesdata[index] // Update the specific key's value
    //   }));
    
    if (index !== -1) {
        
      const updatedLabels = labelnames.filter((label, i) => i !== index);
      const updatedSeries = seriesdata.filter((data, i) => i !== index);

      setLabelNames(updatedLabels);
      setSeriesdata(updatedSeries);
      console.log('seriesdata', data)
    }
  };

  const handleDataPointHover = (event, chartContext, config) => {
    setHighlightedIndex(config.dataPointIndex);
  };

  const chartOptions = {
    labels: labelnames,
    theme: {
      monochrome: {
        enabled: false
      }
    },
    responsive: [
      {
        breakpoint: 480,
        options: {
          legend: {
            show: true
          }
        }
      }
    ],
    chart: {
      events: {
        dataPointSelection: handleDataPointSelection,
        dataPointMouseEnter: handleDataPointHover,
        dataPointMouseLeave: () => setHighlightedIndex(null)
      }
    },
    legend: {
      show: showLegend
    }
  };

  const chartSeries = seriesdata;


  const addLableTochart = ({key}) =>{

    let val = data[key];
    console.log('val', val);
    labelnames.push(key);
    seriesdata.push(val);
    setSeriesdata(seriesdata);
    setLabelNames(labelnames);
    

    delete data[key];

  }

  return (
    <>
    <div className="d-flex">
    {Object.keys(data).map(key => (
        <span key={key} style={{padding:'1em', textDecoration: 'line-through'}} onClick={e => addLableTochart({ key })}><a>{key}</a></span>
      ))}
    </div>
    <div className="pie">
    
      <Chart
        options={chartOptions}
        series={chartSeries}
        type="donut"
        width={380}
      />
    </div>
    </>
  );
};

export default ChartComponent;

import React, { useState, useEffect, useRef } from 'react';
import LoaderComponent from "../../../../libraries/loader/loader";
import { getSendMailFromServer, getReadMailToServer } from '../../../../services/process/VRS/vrsService';
import { Input, Button } from 'semantic-ui-react';
import axios from 'axios';
import Select, { AriaOnFocus } from 'react-select';


function VRSEmailsList() {
    const [loaderOpen, setLoaderOpen] = useState(false);
    const [options, setOptions] = useState({});
    const [fromDate, setFromDate] = useState('');
    const [toDate, setToDate] = useState('');
    const [userCredentials] = useState(JSON.parse(sessionStorage.getItem("userCredentials")));

    const Options = [
        { value: "1", label: "monthly" },
        { value: "2", label: "quaterly" },
        { value: "3", label: "halferly" },
        { value: "4", label: "yearly" },
    ];

    const customStyles = {
        control: base => ({
            ...base,
            height: 35,
            minHeight: 35,
            marginTop: 0,
            paddingTop: -5,
            fontSize: 14,

        })
    };


    function sendemails() {
        setLoaderOpen(true);
        let payload = {
            "fromDate": fromDate,
            "toDate": toDate,
            "period": options.value,
            'entities_id': userCredentials["entities_id"],
        }
        console.log('payload', payload);

        var getSingleMailSent = getSendMailFromServer();

        axios.post(getSingleMailSent[1], JSON.stringify(payload), getSingleMailSent[0])
            .then(
                response => {
                    console.log("Mail Sent Response!!!", response)
                    let data = response["data"];
                    if (data["Status"] === "Success") {
                        alert("Mail Sent Successfully!!!");
                        setLoaderOpen(false);

                    }
                    else if (data["Status"] === "Unsuccess") {
                        alert("Client Id Not Found!!!");
                        setLoaderOpen(false);

                    }
                }
            ).catch(
                error => {
                    console.log("Error in emails Upload List!!!", error);
                    setLoaderOpen(false);

                }
            );
    }

    function get_report() {
        setLoaderOpen(true);
        let payload = {
            "period": options.value,
            "fromDate": fromDate,
            "toDate": toDate,
            'entities_id': userCredentials["entities_id"],
        }
        console.log('payload', payload);

        var getSingleMailSent = getReadMailToServer();

        axios.post(getSingleMailSent[1], payload, getSingleMailSent[0])
            .then(
                response => {
                    console.log("fetch processed emails list", response)
                    let data = response["data"];
                    console.log('data', data);
                    setLoaderOpen(false);
                }
            ).catch(
                error => {
                    console.log("Error in Fetching processed emails list", error);
                    setLoaderOpen(false);
                }
            );
    }

    function handleChange1(data) {
        setOptions(data);
    }


    return (
        <>
            <div className="side" style={{ padding: "10px", marginLeft: '10px' }}>

                <div className='row' style={{ backgroundColor: "#e9e8d9", borderRadius: "12px", marginTop: "10px" }}>

                    <div className='col-md-3 pt-2 pb-2'>
                        <label htmlFor="underline_select " style={{ fontSize: '15px', paddingBottom: '0.3em' }}> Frequency</label>
                        <Select
                            options={Options}
                            placeholder="Select frequency"
                            value={options}
                            onChange={handleChange1}
                            isSearchable={true}
                            styles={customStyles}
                        />
                    </div>
                    <div className='col-md-2 pt-2 pb-2'>
                        <label htmlFor="underline_select" style={{ fontSize: '15px', paddingBottom: '0.3em' }}> From</label><br />
                        <Input type="date" onChange={e => setFromDate(e.target.value)} />
                    </div>
                    <div className='col-md-2 pt-2 pb-2' style={{ marginLeft: '-1.7em' }}>
                        <label htmlFor="underline_select" style={{ fontSize: '15px', paddingBottom: '0.3em' }}> To</label><br />
                        <Input type="date" onChange={e => setToDate(e.target.value)} />
                    </div>
                    <div className='col-md-2 pt-2 pb-2'>
                        <Button className='mt-4' style={{ float: 'right' }} variant="contained" color="primary" type="button" onClick={sendemails}>Send Email</Button>
                    </div>
                    <div className='col-md-2 pt-2 pb-2' >
                        <Button className='mt-4' style={{ float: 'right' }} variant="contained" color="primary" type="button" onClick={get_report}>Read Email</Button>
                    </div>
                </div>
            </div>
            <LoaderComponent loaderOpen={loaderOpen} />
        </>
    );
}


export default VRSEmailsList;


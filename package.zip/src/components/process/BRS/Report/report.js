import React, { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import './report.css';
import Select from "react-select";
import { getProcessingLayerListFromServer, getBRSReportFromServer } from '../../../../services/process/BRS/brsService.js';
import axios from "axios";
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-balham.css';
import { AgGridReact } from 'ag-grid-react';
import LoaderComponent from "../../../../libraries/loader/loader";
import refreshIcon from "../../../../assets/images/refresh.png";




function MedicalInsuranceFileUpload()
{
    const [userCredentials] = useState(JSON.parse(sessionStorage.getItem("userCredentials")));
    const [inputMonth, setInputMonth] = useState(undefined);
    const { register, handleSubmit } = useForm();
    const [rowData, setRowData] = useState([]);
    const [paginationSize] = useState(15);
    const [loaderOpen, setLoaderOpen] = useState(false);
    const [options, setOptions] = useState([]);
    const [selectedOption, setSelectedOption] = useState('');
    const [layerId, setLayerId] = useState('');
    const [fileUploaded, setFileUploaded] = useState('');
    const [link, setLink] = useState('');
    const [downloadHidden, setDownloadHidden] = useState(true);

    useEffect(() => {
        BrsTypeList();
    }, []);

    function handleSelection(event) {
    const selectedValue = event.target.value;
    const selectedOption = options.find(option => option.processing_layer_name === selectedValue); // Find the option with the selected value
    const layerId = selectedOption ? selectedOption.processing_layer_id : null; 
    console.log("layerId", layerId);
    setSelectedOption(selectedValue);
    setLayerId(layerId);
    setLink('');
    setDownloadHidden(true);

    }

    function BrsTypeList()
    {
        setLoaderOpen(true);
        let payload = {
            "tenantId": userCredentials["tenants_id"],
            "groupId": userCredentials["groups_id"],
            "entityId": userCredentials["entities_id"],
            "mProcessingLayerId": userCredentials["m_processing_layer_id"],
            "mProcessingSubLayerId": userCredentials["m_processing_sub_layer_id"],
            "typeId": userCredentials["processing_layer_id"]
        }

        var getProcessingLayerList = getProcessingLayerListFromServer();
        console.log("brs", getProcessingLayerList[0])

        axios.post(getProcessingLayerList[1], {params : payload}, getProcessingLayerList[0])
        .then(
            response => {
                console.log("Processing Layer List!!!", response)
                let data = response["data"];
                if (data["Status"] === "Success")
                {
                let options = data["processing_layer_list"]
                setOptions(options);
                setLoaderOpen(false);
                }
            }
        ).catch(
            error => {
                console.log("Error in Processing Layer List!!!", error);
                setLoaderOpen(false);
            }
        );

    }


    function reportClick()
    {
        setDownloadHidden(true);
        setLoaderOpen(true);
        let payload = {
            "tenants_id": userCredentials["tenants_id"],
            "groups_id": userCredentials["groups_id"],
            "entities_id": userCredentials["entities_id"],
            "processing_layer_id": layerId,
            "month" : inputMonth,
            "processing_layer" : selectedOption
        }

        var getBrsReport = getBRSReportFromServer();

        axios.post(getBrsReport[1], {params : payload}, getBrsReport[0])
        .then(
            response => {
                console.log("Report Generated Response!!!", response)
                let data = response["data"];
                if (data["Status"] === "Success")
                {
                    console.log("data", data);
                    setLink(data["file"]);
                    setLoaderOpen(false);
                    setDownloadHidden(false);
                }
                else{
                    setDownloadHidden(true);
                    setLoaderOpen(false);
                }
            }
        ).catch(
            error => {
                console.log("Error in File Generated!!!", error);
                setLoaderOpen(false);
            }
        );

    }

    return (
        <>
            <div className="report-cardBox">
                <div>
                    <div className="dropdown-container">
                        <h3>Reconciliation Type</h3>
                        <select className="selectOptions" onChange={handleSelection} value={selectedOption}>
                            <option value="Choose">Choose</option>
                            {options.map(option => (
                            <option key={option.processing_layer_id} value={option.processing_layer_name}>{option.processing_layer_name}</option>
                            ))}
                        </select>
                    </div>
                </div>
                <div className="reportMonth">
                    <h3>Month</h3>
                    <input type="month" className="cardName filetype" style={{paddingLeft: "10px", height:"40%", marginLeft:"-57%", width:"89%"}} onChange={(e) => {setInputMonth(e.target.value), setLink(''), setDownloadHidden(true)}} id="file-upload-month" />
                    <button className="btn" style={{height:"35px", width: "125px", marginTop: "-3px", marginLeft:"-24%", backgroundColor:"#000055", color:"rgb(248 252 248)", marginRight: "2%"}} onClick={(e) => {reportClick(e)}}>Generate BRS</button>
                    <div hidden={downloadHidden}>
                        <a href={link} style={{ textDecoration: 'underline', color:"green", fontSize:"130%", marginTop:"21%", marginLeft:"10%" }}>Download Report</a>
                    </div>
                </div>
                {/* <div>
                    <div>
                        <button className="btn" style={{height:"35px", width: "125px", marginTop: "38px", marginLeft:"-72%", backgroundColor:"#000055", color:"rgb(248 252 248)", marginRight: "2%"}} onClick={(e) => {reportClick(e)}}>Generate BRS</button>
                    </div>
                </div> */}
                {/* <div hidden={downloadHidden}  style={{marginTop:"36%", marginLeft:"-192%"}}>
                    <a href={link} style={{ textDecoration: 'underline', color:"green", fontSize:"130%" }}>Download Report</a>
                </div> */}
            </div>
            <LoaderComponent loaderOpen = {loaderOpen} />
        </>
    )
}


export default MedicalInsuranceFileUpload;



from rest_framework import serializers
from datetime import datetime
from .models import *

class ModuleSettingsSerializer(serializers.ModelSerializer):
    class Meta:
        model = ModuleSettings
        fields = '__all__'

    def create(self, validated_data):
        current_time = str(datetime.today())
        validated_data["created_date"] = current_time
        validated_data["modified_date"] = current_time

        module_settings = ModuleSettings.objects.create(**validated_data)
        return module_settings

class TenantsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Tenants
        fields = '__all__'
        # fields = ['tenants_id', 'name', 'address', 'salutation', 'contact_person_name', 'contact_person_number', 'contact_person_email_id', 'pan', 'gst', 'tan', 'scrip_code',
        #           'is_active', 'created_by_user_id', 'created_date', 'modified_by_user_id', 'modified_date']

    def create(self, validated_data):
        current_time = str(datetime.today())
        validated_data["created_date"] = current_time
        validated_data["modified_date"] = current_time

        tenants = Tenants.objects.create(**validated_data)
        return tenants

class GroupsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Groups
        fields = '__all__'

    def create(self, validated_data):
        current_time = str(datetime.today())
        validated_data["created_date"] = current_time
        validated_data["modified_date"] = current_time

        groups = Groups.objects.create(**validated_data)
        return groups


class EntitiesSerializer(serializers.ModelSerializer):
    class Meta:
        model = Entities
        fields = '__all__'

    def create(self, validated_data):
        current_time = str(datetime.today())
        validated_data["created_date"] = current_time
        validated_data["modified_date"] = current_time

        entities = Entities.objects.create(**validated_data)
        return entities


class DivisionsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Divisions
        fields = '__all__'

    def create(self, validated_data):
        current_time = str(datetime.today())
        validated_data["created_date"] = current_time
        validated_data["modified_date"] = current_time

        divisions = Divisions.objects.create(**validated_data)
        return divisions

class ExternalEntitiesSerializer(serializers.ModelSerializer):
    class Meta:
        model = ExternalEntities
        fields = '__all__'

    def create(self, validated_data):
        current_time = str(datetime.today())
        validated_data["created_date"] = current_time
        validated_data["modified_date"] = current_time

        external_entities = ExternalEntities.objects.create(**validated_data)
        return external_entities

class ShareHoldingHeaderSerializer(serializers.ModelSerializer):
    class Meta:
        model = ShareHoldingHeader
        fields = '__all__'

    def create(self, validated_data):
        current_time = str(datetime.today())
        validated_data["created_date"] = current_time
        validated_data["modified_date"] = current_time

        share_holding_header = ShareHoldingHeader.objects.create(**validated_data)
        return share_holding_header

class ShareHoldingDetailsSerializer(serializers.ModelSerializer):
    class Meta:
        model = ShareHoldingDetails
        fields = '__all__'

    def create(self, validated_data):
        current_time = str(datetime.today())
        validated_data["created_date"] = current_time
        validated_data["modified_date"] = current_time

        share_holding_details = ShareHoldingDetails.objects.create(**validated_data)
        return share_holding_details

class UserRolesSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserRoles
        fields = '__all__'

    def create(self, validated_data):
        current_time = str(datetime.today())
        validated_data["created_date"] = current_time
        validated_data["modified_date"] = current_time

        user_roles = UserRoles.objects.create(**validated_data)
        return user_roles

class UserPermissionGroupsSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserPermissionGroups
        fields = '__all__'

    def create(self, validated_data):
        current_time = str(datetime.today())
        validated_data["created_date"] = current_time
        validated_data["modified_date"] = current_time

        user_permission_groups = UserPermissionGroups.objects.create(**validated_data)
        return user_permission_groups

class ProcessingLayerAPISerializer(serializers.ModelSerializer):
    class Meta:
        model = ProcessingLayerAPIS
        fields = '__all__'

class RegisterSerializer(serializers.ModelSerializer):
    password = serializers.CharField(max_length=68, min_length=6, write_only=True)
    class Meta:
        model = Users
        fields = ['email', 'name', 'password']

    def validate(self, attrs):
        return attrs

    def create(self, validated_data):
        return Users.objects.create_superuser(**validated_data)

class UserMappingSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserMapping
        fields = '__all__'

class UserAuthTokenSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserAuthToken
        fields = '__all__'

class PagesSerializer(serializers.ModelSerializer):
    class Meta:
        model = Pages
        fields = '__all__'

class PermissionsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Permissions
        fields = '__all__'

class PermissionGroupsMappingSerializer(serializers.ModelSerializer):
    class Meta:
        model = PermissionGroupsMapping
        fields = '__all__'

class UserProcessMappingSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserProcessMapping
        fields = '__all__'


class JobSerializer(serializers.ModelSerializer):
    class Meta:
        model = Job
        fields = '__all__'


class TaskSerializer(serializers.ModelSerializer):
    class Meta:
        model = Task
        fields = '__all__'


class ConditionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Condition
        fields = '__all__'


class ActionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Action
        fields = '__all__'
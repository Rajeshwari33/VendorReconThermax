import React, { useState } from 'react';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import * as XLSX from 'xlsx';

const ExcelTabsGrid = () => {
  const [fileContent, setFileContent] = useState(null);
  const [sheetNames, setSheetNames] = useState([]);
  const [selectedSheet, setSelectedSheet] = useState(null);
  const [rowData, setRowData] = useState([]);
  const [columnDefs, setColumnDefs] = useState([]);
  const [headers, setHeaders] = useState([]);

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];

    if (selectedFile) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const data = event.target.result;
        const workbook = XLSX.read(data, { type: 'binary' });
        const sheetNames = workbook.SheetNames;
        setSheetNames(sheetNames);
        setFileContent(data); // Set the file content
      };
      reader.readAsBinaryString(selectedFile);
    }
  };

  const handleSheetChange = (sheetName) => {
    if (fileContent) {
      const workbook = XLSX.read(fileContent, { type: 'binary' });
      const sheetData = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName]);

      // Extract headers from the first row (assuming it's a header row)
      const headerRow = sheetData[0];
      const headers = headerRow ? Object.keys(headerRow) : [];

      // Detect the maximum number of columns across all rows
      const maxColumns = Math.max(...sheetData.map((row) => Object.keys(row).length));

      // Create column definitions based on the detected headers and max columns
      const newColumnDefs = Array.from({ length: maxColumns }, (_, index) => ({
        headerName: headers[index] || `Column ${index + 1}`,
        field: headers[index] || `Column${index + 1}`,
      }));

      // Set the rowData with the data from the selected sheet
      setRowData(sheetData);

      // Set the selected sheet name and column definitions
      setSelectedSheet(sheetName);
      setColumnDefs(newColumnDefs);
    }
  };

  return (
    <div>
      <input type="file" accept=".xlsx" onChange={handleFileChange} />
      {sheetNames.length > 0 && (
        <div>
          <h3>Select a Sheet:</h3>
          <ul>
            {sheetNames.map((sheetName) => (
              <li key={sheetName} onClick={() => handleSheetChange(sheetName)}>
                {sheetName}
              </li>
            ))}
          </ul>
          {selectedSheet && (
            <div>
              <h3>Selected Sheet: {selectedSheet}</h3>
              <div className="ag-theme-alpine" style={{ height: '400px', width: '100%' }}>
                <AgGridReact columnDefs={columnDefs} rowData={rowData} />
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default ExcelTabsGrid;

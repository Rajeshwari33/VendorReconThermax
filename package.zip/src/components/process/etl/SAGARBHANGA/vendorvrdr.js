// App.js
import { useEffect, useState,useMemo,useCallback } from "react";
// import "./App.css";
import "../etlsecound.css";
import hdfcs from '../../../../assets/images/banks/thermax.png';


import record from './vendorcrdr.json';
import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
const GridExample2 = () => {
    const containerStyle = useMemo(() => ({ width: "100%", height: "100%" }), []);
    const gridStyle = useMemo(() => ({ height: "100%", width: "100%" }), []);
    const [rowData, setRowData] = useState();
    const [columnDefs, setColumnDefs] = useState([
      { field: "DATE", minWidth: 170 },
      { field: "PARTICULARS" },
      { field: "VCH TYPE" },
      { field: "VCH NO" },
      { field: "Cr/Dr" },
      { field: "DEBIT" },
      { field: "CREDIT" },
      { field: "BALANCE" },
      { field: "INVOICE/ PO NO." },
      { field: "GRN NO" },
      { field: "GST AMT" },
      { field: "TDS AMT" },
      { field: "RETENTION" },
      { field: "UTR NO" },
      { field: "REFERENCE TEXT" },
      { field: "" },
      { field: "Document No" },
      { field: "Remark" },

    ]);
    const defaultColDef = useMemo(() => {
      return {
        editable: true,
        sortable: true,
        filter: true,
        resizable: true,
      };
    }, []);
  
    const onGridReady = useCallback((params) => {
      fetch('./vendorstatement.json')
        .then((resp) => resp.json())
        .then((data) => setRowData(data));
    }, []);
  
   
    return (
      <div style={containerStyle}>
        <div style={gridStyle} className="ag-theme-alpine">
          <AgGridReact
            rowData={record}
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}
            sideBar={true}
            suppressMenuHide={true}
            onGridReady={onGridReady}
          ></AgGridReact>
         
        </div>
      </div>
    );
  };

function VendorDR() 
{
  

  return (
  <div className="scroll">
    <table className="table1 bold" >
    <tr>
        <td colSpan={5}><img src={hdfcs} alt="" height="40px" width="60px" /> THERMAX LIMITED</td>
        
    </tr>
   <br></br>
    <tr className="bold">
        <td colSpan={6}>VRS AS ON 30 NOVEMBER 2022</td>
        <td></td>
        <td></td>
       
        <td colSpan={2}> VENDOR DR AMT </td>
        <td colSpan={2}> VENDOR CR AMT </td>
        
    </tr>
    <tr>
        <td colSpan={6} >VENDOR DEBITS AND CREDITS NOT MATCHED</td>
        <td></td>
        
        <td> TOTAL </td>
        <td colSpan={2}> 37,819,000.00 </td>
        <td colSpan={2}> 34,794,839.67 </td>
       
    </tr>
    <br></br>
   
</table>

    <div  style={{height:"400px"}}>
    <GridExample2/>
    </div>
  </div>
  )
}



export default VendorDR;
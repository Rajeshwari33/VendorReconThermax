import React from 'react';

class ComplainceCertificateDashboard extends React.Component
{
    render()
    {
        return (
            <div>
                Dashboard
            </div>
        );
    }
}

export default ComplainceCertificateDashboard;
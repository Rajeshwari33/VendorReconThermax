import React, { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import './file-upload.css';
import Select from "react-select";
import { getProcessingLayerListFromServer, getFileUploadListFromServer } from '../../../../services/process/BRS/brsService.js';
import axios from "axios";
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-balham.css';
import { AgGridReact } from 'ag-grid-react';
import LoaderComponent from "../../../../libraries/loader/loader";
import refreshIcon from "../../../../assets/images/refresh.png";




function BRSFileUpload()
{
    const [userCredentials] = useState(JSON.parse(sessionStorage.getItem("userCredentials")));
    const { register, handleSubmit } = useForm();
    const [rowData, setRowData] = useState([]);
    const [paginationSize] = useState(15);
    const [loaderOpen, setLoaderOpen] = useState(false);
    const [options, setOptions] = useState([]);
    const [selectedOption, setSelectedOption] = useState('');
    const [layerId, setLayerId] = useState('');
    const [fileUploaded, setFileUploaded] = useState('');
    const [inputMonth, setInputMonth] = useState(undefined);

    useEffect(() => {
        BrsTypeList();
        fileUploadsList();
    }, []);

    function handleSelection(event) {
    const selectedValue = event.target.value;
    const selectedOption = options.find(option => option.processing_layer_name === selectedValue); // Find the option with the selected value
    const layerId = selectedOption ? selectedOption.processing_layer_id : null; 
    console.log("layerId", layerId);
    setSelectedOption(selectedValue);
    setLayerId(layerId);

    }

    function BrsTypeList()
    {
        setLoaderOpen(true);
        let payload = {
            "tenantId": userCredentials["tenants_id"],
            "groupId": userCredentials["groups_id"],
            "entityId": userCredentials["entities_id"],
            "mProcessingLayerId": userCredentials["m_processing_layer_id"],
            "mProcessingSubLayerId": userCredentials["m_processing_sub_layer_id"],
            "typeId": userCredentials["processing_layer_id"]
        }

        var getProcessingLayerList = getProcessingLayerListFromServer();
        console.log("brs", getProcessingLayerList[0])

        axios.post(getProcessingLayerList[1], {params : payload}, getProcessingLayerList[0])
        .then(
            response => {
                console.log("Processing Layer List!!!", response)
                let data = response["data"];
                if (data["Status"] === "Success")
                {
                let options = data["processing_layer_list"]
                setOptions(options);
                setLoaderOpen(false);
                }
            }
        ).catch(
            error => {
                console.log("Error in Processing Layer List!!!", error);
                setLoaderOpen(false);
            }
        );

    }

    const onSubmit = async (data) => {

        console.log("fileExt", data.fileExt[0]);
        console.log("fileInt", data.fileInt[0]);
        if (selectedOption.length <= 0)
        {
            alert("Please Select a Reconciliation Type before Upload!!!");
        }
        else if (inputMonth === undefined)
        {
            alert("Please Choose a Month before file upload!!!");
        }
        else if (data.fileExt[0] === undefined && data.fileInt[0] === undefined)
        {
            alert("Please Choose a File for Upload!!!");
        }
        else 
        {
            setLoaderOpen(true);
            let upload = ''
            if (data.fileExt[0] != undefined && data.fileInt[0] != undefined){
                upload = "BOTH";
                setFileUploaded(upload);
            }
            else if (data.fileExt[0] != undefined && data.fileInt[0] === undefined){
                upload = "EXTERNAL";
                setFileUploaded(upload);
            }
            else if (data.fileExt[0] === undefined && data.fileInt[0] != undefined){
                upload = "INTERNAL";
                setFileUploaded(upload);
            }
            const formData = new FormData();

            formData.append("internalFileName", data.fileInt[0]);
            formData.append("externalFileName", data.fileExt[0]);
            formData.append("processingLayerId", layerId);
            formData.append("tenantId", userCredentials["tenants_id"]);
            formData.append("groupId", userCredentials["groups_id"]);
            formData.append("entityId", userCredentials["entities_id"]);
            formData.append("userId", userCredentials["user_id"]);
            formData.append("mProcessingLayerId", userCredentials["m_processing_layer_id"]);
            formData.append("mProcessingSubLayerId", userCredentials["m_processing_sub_layer_id"]);
            formData.append("fileUploaded", upload);
            formData.append("month", inputMonth);

            try
            {
                const fileUploadResponse = await fetch("http://localhost:50004/recon/get_file_upload_transactions/", {
                    method: "POST",
                    body: formData,
                }).then((res) => res.json());

                console.log("response", fileUploadResponse);
                if (fileUploadResponse["Status"] !== "Success")
                {
                    alert("Error in Uploading File!!!");
                    setLoaderOpen(false);
                }
                else
                {
                    fileUploadsList();
                    alert("File Uploaded Successfully!!!");
                    setSelectedOption(undefined);
                    document.getElementById("file-upload-form").reset();
                    setSelectedOption([]);
                    setLoaderOpen(false);
                }
            }
            catch (err)
            {
                console.log("Error", err);
                setLoaderOpen(false);
            }
        }
    };

    function fileUploadsList()
    {
        setLoaderOpen(true);
        let payload = {
            "tenants_id": userCredentials["tenants_id"],
            "groups_id": userCredentials["groups_id"],
            "entities_id": userCredentials["entities_id"],
            "m_processing_layer_id": userCredentials["m_processing_layer_id"],
            "m_processing_sub_layer_id": userCredentials["m_processing_sub_layer_id"],
            "user_id": userCredentials["user_id"],
            "is_active": "yes"
        }

        var getFileUploadsList = getFileUploadListFromServer();

        axios.post(getFileUploadsList[1], {params : payload}, getFileUploadsList[0])
        .then(
            response => {
                console.log("File Upload Response!!!", response)
                let data = response["data"];
                if (data["Status"] === "Success")
                {
                    setRowData(data["list_data"]);
                    setLoaderOpen(false);
                }
            }
        ).catch(
            error => {
                console.log("Error in File Upload List!!!", error);
                setLoaderOpen(false);
            }
        );

    }

    const columnDefs = React.useMemo(() => {
        if (rowData.length > 0) {
          // Get the column names from the first row of the JSON data
          const keys = Object.keys(rowData[0]);
      
          // Create column definitions with the checkbox as the first column
          const columnDefs = [
            // {
            //   headerName: '',
            //   checkboxSelection: true,
            //   width: 50,
            // },
            ...keys.map((key) => ({
              headerName: key,
              field: key,
              sortable: true, 
              filter: true, 
              resizable: true,
              width: 250
            })),
          ];
      
          return columnDefs;
        }
        return [];
      }, [rowData]);

    function handleClick(){
        fileUploadsList();
    };

    return (
        <>
            <div className="file-upload-cardBox">
                <div className="typeSelectionupload">
                    <div className="dropdown-container">
                        <h3>Reconciliation Type</h3>
                        <select className="selectOptions" onChange={handleSelection} value={selectedOption}>
                            <option value="Choose">Choose</option>
                            {options.map(option => (
                            <option key={option.processing_layer_id} value={option.processing_layer_name}>{option.processing_layer_name}</option>
                            ))}
                        </select>
                    </div>
                    <div className="monthFilterUpload">
                    <h3>Month</h3>
                    <input type="month" className="cardName filetype" style={{paddingLeft: "10px", height:"58%", marginTop:"0%", width:"48%", marginLeft:"-85%"}} onChange={(e) => {setInputMonth(e.target.value)}} id="file-upload-month" />
                    </div>
                </div>

                <div>
                    <div>
                        <label htmlFor="underline_select " className="sr-only numbers " style={{fontSize: '15px'}}>File Upload</label><br />
                        <form onSubmit={handleSubmit(onSubmit)} id="file-upload-form">
                            <div className="file-upload-card-upload">
                                <div>
                                    <h3><label htmlFor="fileInput">Bank Statement</label></h3>
                                    <input type="file" {...register("fileExt")} />
                                </div>
                                <div>
                                    <h3><label htmlFor="fileInput">ERP Statement</label></h3>
                                    <input type="file" {...register("fileInt")} />
                                </div>
                                <div>
                                    <input type="submit" value="Upload" className="btn" style={{height:"35px",backgroundColor:"#000055",color:"#ffffff", marginTop: "9%", width:"33%"}} />
                                </div>
                            </div>
                        </form>
                        
                    </div>
                </div>
            </div>

            <div className="file-upload">
                <img src={refreshIcon} alt="No Images" style={{width: '40px', height: '37px'}}  className="referesh-icon-class" title="Refresh" onClick={handleClick} />
                <div className="ag-theme-balham fileupload-layer">
                    <AgGridReact
                        columnDefs = {columnDefs}
                        rowData = {rowData}
                        paginationPageSize = {paginationSize}
                        pagination = {true}
                        animateRows = {true}
                    ></AgGridReact>
                </div>
            </div>
            <LoaderComponent loaderOpen = {loaderOpen} />
        </>
    )
}


export default BRSFileUpload;



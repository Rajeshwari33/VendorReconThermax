// App.js
import { useEffect, useState } from "react";
// import "./App.css";
import "./etlsecound.css";

function VRS() 
{
  

  return (
  <div>
    <table className="table">
    <tr>
        <td>VENDOR CODE : </td>
        <td>146491</td>
        <td></td>
    </tr>
    <tr className="fontcolor">
        <td></td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td></td>
    </tr>
    <br></br>
    <br></br>
    <tr className="fontcolor">
        <td>Si. No</td>
        <td>Particulars</td>
        <td> Amount </td>
    </tr>
   
    <tr>
        <td></td>
        <td>Balance as per Thermax</td>
        <td> 7,430,290.52 </td>
    </tr>
    
    <tr>
        <td></td>
        <td>Balance as per Vendor</td>
        <td> 2,837,666.84 </td>
    </tr>
   
    <tr>
        <td></td>
        <td>Variance</td>
        <td> 10,267,957.36 </td>
    </tr>
    
    <tr>
        <td></td>
        <td>Reasons for Variance</td>
        <td></td>
    </tr>
    
    <tr>
        <td>1</td>
        <td>Purchase Invoices booked by Thermax not accounted by vendor</td>
        <td> -4,935,095.04 </td>
    </tr>
    
    <tr>
        <td>2</td>
        <td>Payment received by vendor but not accounted by Thermax</td>
        <td></td>
    </tr>
    
    <tr>
        <td>3</td>
        <td>Sales considered by vendor but not accounted by Thermax</td>
        <td> 10,093,194.43 </td>
    </tr>
    
    <tr>
        <td>4</td>
        <td>Payment made by Thermax not accounted by vendor</td>
        <td> 18,745.99 </td>
    </tr>
    
    <tr>
        <td>5</td>
        <td>Difference in Opening balance of Thermax &amp; Vendor statement</td>
        <td> 5,093,636.56 </td>
    </tr>
   
    <tr>
        <td></td>
        <td>Sum total of variance</td>
        <td> 10,270,481.94 </td>
    </tr>
   
    <tr>
        <td></td>
        <td>Check</td>
        <td>2524.58</td>
    </tr>
    
    <tr>
        <td></td>
        <td>Reconciliation done till</td>
        <td>31-Mar-2022</td>
    </tr>
   
    <tr className="fontcolor">
        <td></td>
        <td>Vendor Reconciliation Statement as on 31 MARCH 2022</td>
        <td></td>
    </tr>
</table>
  </div>
  )
}



export default VRS;
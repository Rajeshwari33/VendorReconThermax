
import React,{useEffect, useState,} from "react";
import Box from "@mui/material/Box";
import Tab from "@mui/material/Tab";
import { Grid, Button } from 'semantic-ui-react';
import './resource_master.css';
import TabContext from '@material-ui/lab/TabContext';
import TabList from '@material-ui/lab/TabList';
import TabPanel from '@material-ui/lab/TabPanel';
import axios from 'axios';  


import Paper from '@mui/material/Paper';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TablePagination from '@mui/material/TablePagination';
import TableRow from '@mui/material/TableRow';


const columns = [
  { id: 'action_id', label: 'Action_id', minWidth: 10},
  { id: 'action_name', label: 'Action_name',minWidth: 10 },
  {
    id: 'action_description',
    label: 'Action_description',
    minWidth: 10
  },
  {
    id: 'action_details',
    label: 'Action_details',
    minWidth: 10
  },
  {
    id: 'restapi_address',
    label: 'Restapi_address',
    minWidth: 10
  },
  {
    id: 'action_category',
    label: 'Action_category',
    minWidth: 10
  },
  {
    id: 'task',
    label: 'Task',
    minWidth: 10
  },
  {
    id: 'actions',
    label: 'Actions',
    minWidth: 10
  },
];

const columns2 = [
  { id: 'job_id', label: 'Job_id', minWidth: 15},
  { id: 'job_name', label: 'Job_name',minWidth: 15 },
  {
    id: 'job_description',
    label: 'Job_description',
    minWidth: 15
  },
  {
    id: 'job_category',
    label: 'Job_category',
    minWidth: 15
  },
  {
    id: 'actions',
    label: 'Actions',
    minWidth: 15
  },

];





const StickyHeadTable = ({data}) => {
  const [page, setPage] = useState(0);
  const [rowdata, setRowdata] = useState(data);
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const [formCreate, setFormCreate] = useState(true);
  const [formValues, setFormValues] = useState({
  action_id: "",action_name: "",action_category: "",action_description: "",action_details: "",restapi_address: "",task: "" })

  let handleChange = (e) => {
      setFormValues({
        ...formValues,
        [e.target.name]: e.target.value
        })
    }
  
    const makeapicall = async (url) => {
      try {
        const response = await fetch(url);
        const data = await response.json();
        console.log('data'+data);
        setRowdata(data); 
        
      }
      catch (e) {
        console.log(e);
     
      }
    }
  
  let handleSubmit = (event) => {
      event.preventDefault();
      let url;
      if(formCreate == true){
        url = `http://127.0.0.1:8000/api/v2/user_modules/create_actions/`;
      }else{
       url = `http://127.0.0.1:8000/api/v2/user_modules/update_action/${formValues.action_id}/`;
      }
      fetch(url, {method: 'POST',
      headers:{
        'Accept':'application/json',
        'Content-Type':'application/json'
      },
      body:JSON.stringify(formValues)
    }).then((result)=>{
      result.json().then((resp)=>{
        console.log(resp);
        if(resp.message === 'updated successfully.' || resp.message === 'created successfully.'){
          const url = `http://127.0.0.1:8000/api/v2/user_modules/all_actions/`;
          makeapicall(url);
          setFormCreate(true);
          setFormValues({
            action_id: "",action_name: "",action_category: "",action_description: "",action_details: "",restapi_address: "",task: "" });
        }
      })
    })
  }


  useEffect(() => {
    const url = `http://127.0.0.1:8000/api/v2/user_modules/all_actions/`;
    makeapicall(url);
  },[]);

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(+event.target.value);
    setPage(0);
  };

  const EditActions = ({row}) =>{
    setFormCreate(false);
    setFormValues({action_id:row.action_id,action_name: row.action_name,action_category:row.action_category,action_description: row.action_description,action_details: row.action_details,restapi_address: row.restapi_address,task: row.task });
  };

const DeleteActions = ({row}) =>{
  console.log('id'+row.action_id);
  axios.delete(`http://127.0.0.1:8000/api/v2/user_modules/delete_actions/${row.action_id}/`)  
      .then(res => {  
        console.log(res);  
        console.log(res.data);  
        const url = `http://127.0.0.1:8000/api/v2/user_modules/all_actions/`;
        makeapicall(url);
        
  });
};

  return (
    <>
    <form  onSubmit={handleSubmit} style={{justifyContent:'center', marginLeft:'25em', marginBottom:'2em'}}>
      
        <div className="form-inline">
          <label className="label">Action Id: </label>
          <input type="text" name="action_id" value={formValues && formValues.action_id || ""} disabled={true} /><br /> <br />
          <label className="label">Action Name: </label>
          <input type="text" name="action_name" value={formValues && formValues.action_name || ""} onChange={e => handleChange(e)} /><br /> <br />
          <label className="label">action desc: </label>
          <input type="text" name="action_description" value={formValues && formValues.action_description || ""} onChange={e => handleChange(e)} /><br /><br/>
          <label className="label">action details: </label>
          <input type="text" name="action_details" value={formValues && formValues.action_details || ""} onChange={e => handleChange(e)} /><br /><br/>
          <label className="label">restapi address: </label>
          <input type="text" name="restapi_address" value={formValues && formValues.restapi_address || ""} onChange={e => handleChange(e)} /><br /><br/>
          <label className="label">Action Category: </label>
          <input type="text" name="action_category" value={formValues && formValues.action_category || ""} onChange={e => handleChange(e)} /><br /><br/>
          <label className="label">task: </label>
          <input type="text" name="task" value={formValues && formValues.task || ""} onChange={e => handleChange(e)} /><br /><br/>
        </div>
      
      <div className="button-section">  
      {formCreate ? <Button variant="contained" color="primary" type="submit">Create</Button>:
        <Button variant="contained" color="primary" type="submit">Save</Button>}
      </div>
  </form>

    <Paper sx={{ width: '100%', overflow: 'hidden' }}>
      <TableContainer sx={{ maxHeight: 240 }}>
        <Table stickyHeader aria-label="sticky table">
          <TableHead>
            <TableRow style={{backgroundColor: 'rgb(233, 232, 217)'}}>
              {columns.map((column) => (
                <TableCell
                  key={column.id}
                  align={column.align}
                  class="header_column"
                >
                  {column.label}
                </TableCell>
              ))}
            </TableRow>
          </TableHead>
          <TableBody>
                    
            {rowdata && rowdata
              .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
              .map((row, index) => {
                return (
                  <TableRow hover role="checkbox" tabIndex={-1} key={index}>
                    <TableCell className="cell_data"> {row.action_id}</TableCell>
                    <TableCell className="cell_data"> {row.action_name}</TableCell>
                    <TableCell className="cell_data"> {row.action_description}</TableCell>
                    <TableCell className="cell_data"> {row.action_details}</TableCell>
                    <TableCell className="cell_data"> {row.restapi_address}</TableCell>
                    <TableCell className="cell_data"> {row.action_category}</TableCell>
                    <TableCell className="cell_data"> {row.task}</TableCell>
                    <TableCell className="cell_data">
                        <span onClick={e => EditActions({row})}><i class='fa-solid fa-pen-to-square' ></i></span> 
                        <span style={{marginLeft:'1em'}} onClick={e => DeleteActions({row})}><i class='fa fa-trash-o'></i></span>  
                    </TableCell>
                  </TableRow>
                );
              })}
                           
          </TableBody>
        </Table>
      </TableContainer>
      <TablePagination
        rowsPerPageOptions={[5, 10]}
        component="div"
        count={rowdata?.length}
        rowsPerPage={rowsPerPage}
        page={page}
        onPageChange={handleChangePage}
        onRowsPerPageChange={handleChangeRowsPerPage}
      />
    </Paper>
    </>
  );
}

const StickyHeadTable2 = ({data}) => {
  const [page, setPage] = useState(0);
  const [rowdata, setRowdata] = useState(data);
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const [formCreate, setFormCreate] = useState(true);
  const [formValues, setFormValues] = useState({
  job_id: "",job_name: "",job_category: "",job_description: "" })

  let handleChange = (e) => {
      setFormValues({
        ...formValues,
        [e.target.name]: e.target.value
        })
    }
  
    const makeapicall = async (url) => {
      try {
        const response = await fetch(url);
        const data = await response.json();
        console.log('data'+data);
        setRowdata(data); 
        
      }
      catch (e) {
        console.log(e);
     
      }
    }
  
  let handleSubmit = (event) => {
      event.preventDefault();
      let url;
      if(formCreate == true){
        url = `http://127.0.0.1:8000/api/v2/user_modules/createjob/`;
      }else{
       url = `http://127.0.0.1:8000/api/v2/user_modules/updatejob/${formValues.job_id}/`;
      }
      fetch(url, {method: 'POST',
      headers:{
        'Accept':'application/json',
        'Content-Type':'application/json'
      },
      body:JSON.stringify(formValues)
    }).then((result)=>{
      result.json().then((resp)=>{
        console.log(resp);
        if(resp == 'updated successfully' || resp == 'created successfully'){
          const url = `http://127.0.0.1:8000/api/v2/user_modules/job_details/`;
          makeapicall(url);
          setFormCreate(true);
          setFormValues({
            job_id: "",job_name: "",job_category: "",job_description: "" });
        }
      })
    })
  }


  useEffect(() => {
    const url = `http://127.0.0.1:8000/api/v2/user_modules/job_details/`;
    makeapicall(url);
  },[]);

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(event.target.value);
    setPage(0);
  };

  const EditActions = ({row}) =>{
    setFormCreate(false);
    setFormValues({job_id:row.job_id,job_name: row.job_name,job_category:row.job_category,job_description: row.job_description });
  };

const DeleteActions = ({row}) =>{
  console.log('id'+row.action_id);
  axios.delete(`http://127.0.0.1:8000/api/v2/user_modules/deletejob/${row.action_id}/`)  
      .then(res => {  
        console.log(res);  
        console.log(res.data);  
        const url = `http://127.0.0.1:8000/api/v2/user_modules/job_details/`;
        makeapicall(url);
        
  });
};

  return (
    <>
    <form  onSubmit={handleSubmit} style={{justifyContent:'center', marginLeft:'25em', marginBottom:'2em'}}>
      
        <div className="form-inline">
          <label className="label">Job Id: </label>
          <input type="text" name="job_id" value={formValues && formValues.job_id || ""} disabled={true} /><br /> <br />
          <label className="label">Job Name: </label>
          <input type="text" name="job_name" value={formValues && formValues.job_name || ""} onChange={e => handleChange(e)} /><br /> <br />
          <label className="label">job desc: </label>
          <input type="text" name="job_description" value={formValues && formValues.job_description || ""} onChange={e => handleChange(e)} /><br /><br/>
          <label className="label">job category: </label>
          <input type="text" name="job_category" value={formValues && formValues.job_category || ""} onChange={e => handleChange(e)} /><br /><br/>
          <br /><br/>
        </div>
      
      <div className="button-section">  
      {formCreate ? <Button variant="contained" color="primary" type="submit">Create</Button>:
        <Button variant="contained" color="primary" type="submit">Save</Button>}
      </div>
  </form>

    <Paper sx={{ width: '100%', overflow: 'hidden' }}>
      <TableContainer sx={{ maxHeight: 240 }}>
        <Table stickyHeader aria-label="sticky table">
          <TableHead>
            <TableRow style={{backgroundColor: 'rgb(233, 232, 217)'}}>
              {columns2.map((column) => (
                <TableCell
                  key={column.id}
                  align={column.align}
                  class="header_column"
                >
                  {column.label}
                </TableCell>
              ))}
            </TableRow>
          </TableHead>
          <TableBody>
                    
            {rowdata && rowdata
              .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
              .map((row, index) => {
                return (
                  <TableRow hover role="checkbox" tabIndex={-1} key={index}>
                    <TableCell className="cell_data"> {row.job_id}</TableCell>
                    <TableCell className="cell_data"> {row.job_name}</TableCell>
                    <TableCell className="cell_data"> {row.job_description}</TableCell>
                    <TableCell className="cell_data"> {row.job_category}</TableCell>
                    <TableCell className="cell_data">
                        <span onClick={e => EditActions({row})}><i class='fa-solid fa-pen-to-square' ></i></span> 
                        <span style={{marginLeft:'1em'}} onClick={e => DeleteActions({row})}><i class='fa fa-trash-o'></i></span>  
                    </TableCell>
                  </TableRow>
                );
              })}
                           
          </TableBody>
        </Table>
      </TableContainer>
      <TablePagination
        rowsPerPageOptions={[5, 10]}
        component="div"
        count={rowdata?.length}
        rowsPerPage={rowsPerPage}
        page={page}
        onPageChange={handleChangePage}
        onRowsPerPageChange={handleChangeRowsPerPage}
      />
    </Paper>
    </>
  );
}



const ResourceMasterTabs = () => {
  const [value, setValue] = useState("1");
  const [rowData, setRowData] = useState(undefined);
 
  const [hideResultGrid, setHideResultGrid] = useState(true);
  const [tab, setTab] = useState(null);
  
  const makeAPICall = async (url) => {
    try {
      const response = await fetch(url);
      const data = await response.json();
      console.log('data'+data);
      setRowData(data);
      setHideResultGrid(false);
      // setColumnData(gridColumnDefs);
      
    }
    catch (e) {
      console.log(e);
      setHideResultGrid(true);
    }
  }
 
  const handleChange = (event, newValue) => {
    console.log('newValue'+newValue);
    let url='';
    switch(newValue){
      case 0:
        url = `http://127.0.0.1:8000/api/v2/user_modules/action/${1}`;
        makeAPICall(url);
        break;
      case 1:
        url = `http://127.0.0.1:8000/api/v2/user_modules/action/${1}`;
        makeAPICall(url);
        break;
      case 2:
        url = `http://127.0.0.1:8000/api/v2/user_modules/job_details/`;
        makeAPICall(url);
        break;
      default:
        break;
    }
    setValue(newValue);
  };

  return (
    
    <Box>
      <TabContext value={value}>
        <Box sx={{ borderBottom: 1, borderColor: "divider" }}>
          <TabList onChange={handleChange} aria-label="lab API tabs example">
            <Tab label="Action" value="1" />
            <Tab label="Task" value="2" />
            <Tab label="Job" value="3" />
          </TabList>
        </Box>
        <TabPanel value="1" style={{backgroundColor:'white'}}><StickyHeadTable data={rowData}/></TabPanel>
        <TabPanel value="2" style={{backgroundColor:'white'}}><StickyHeadTable data={rowData}/></TabPanel>
        <TabPanel value="3" style={{backgroundColor:'white'}}><StickyHeadTable2 data={rowData}/></TabPanel>
      </TabContext>
    </Box>
    
  );
}



const ResourceMaster = () => {
 
  return (
    
     <div className="side" style={{ padding:"10px"}}>
     <Grid columns='equal'>
          <Grid.Row style={{ backgroundColor:"#e9e8d9",borderRadius:"12px",marginTop:"10px"}}>
          <Grid.Column>
              <ResourceMasterTabs />
          </Grid.Column>
          </Grid.Row> 
      </Grid>
     </div>
    
  );
}


export default ResourceMaster;
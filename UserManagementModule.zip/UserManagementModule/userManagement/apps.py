from django.apps import AppConfig


class UsermanagementConfig(AppConfig):
    name = 'userManagement'

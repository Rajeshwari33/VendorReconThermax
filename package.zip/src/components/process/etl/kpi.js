import React from "react";
// import React,{useEffect, useState} from 'react';

import "./etlsecound.css";
import { Icon, Input, Button,Dropdown, Grid, Popup,Segment,Select,Tab,Table,Menu , Form, TextArea, Label, Checkbox, GridColumn,Search,Pagination } from 'semantic-ui-react'

const options = [
    { key: 'a', value: 'a', text: 'HDFC1' },
    { key: 'b', value: 'b', text: 'HDFC 2' },
    { key: 'c', value: 'c', text: 'HDFC 3' },
    { key: 'd', value: 'd', text: 'SBI 1' },
    { key: 'e', value: 'e', text: 'ICICI' },
    { key: 'f', value: 'f', text: 'ICICI 2' },
  ]
  
  const DropdownExampleSearchSelection = () => (
    <Dropdown
      deburr
      
      options={options}
      placeholder='Search Your "HDFC"'
      search
      selection
     
    />
  )
  
  const CheckboxExampleShorthandElement = (props) => (
    <Checkbox label={<label>{props.name}</label> } />
  )

const TableExampleVeryCompact = () => (

    <Table compact='very' >
      <Table.Header>
        <Table.Row>
        <Table.HeaderCell><Checkbox /></Table.HeaderCell>
          <Table.HeaderCell>Name</Table.HeaderCell>
          <Table.HeaderCell>Status</Table.HeaderCell>
          <Table.HeaderCell>Notes</Table.HeaderCell>
          <Table.HeaderCell>Name</Table.HeaderCell>
          <Table.HeaderCell>Status</Table.HeaderCell>
          <Table.HeaderCell>Notes</Table.HeaderCell>
        </Table.Row>
      </Table.Header>
  
      <Table.Body>
        <Table.Row>
          <Table.Cell><Checkbox /></Table.Cell>
          <Table.Cell>John</Table.Cell>
          <Table.Cell>Approved</Table.Cell>
          <Table.Cell>None</Table.Cell>
          <Table.Cell>John</Table.Cell>
          <Table.Cell>Approved</Table.Cell>
          <Table.Cell>None</Table.Cell>
         
          
        </Table.Row>
        <Table.Row>
          <Table.Cell><Checkbox /></Table.Cell>

          <Table.Cell>Jamie</Table.Cell>
          <Table.Cell>Approved</Table.Cell>
          <Table.Cell>Requires call</Table.Cell>
          <Table.Cell>Jamie</Table.Cell>
          <Table.Cell>Approved</Table.Cell>
          <Table.Cell>Requires call</Table.Cell>
        </Table.Row>
        <Table.Row>
          <Table.Cell><Checkbox /></Table.Cell>

          <Table.Cell>John</Table.Cell>
          <Table.Cell>Approved</Table.Cell>
          <Table.Cell>None</Table.Cell>
          <Table.Cell>John</Table.Cell>
          <Table.Cell>Approved</Table.Cell>
          <Table.Cell>None</Table.Cell>
        </Table.Row>
        <Table.Row>
          <Table.Cell><Checkbox /></Table.Cell>

          <Table.Cell>Jamie</Table.Cell>
          <Table.Cell>Approved</Table.Cell>
          <Table.Cell>Requires call</Table.Cell>
          
          <Table.Cell>Jamie</Table.Cell>
          <Table.Cell>Approved</Table.Cell>
          <Table.Cell>Requires call</Table.Cell>
        </Table.Row>
        <Table.Row>
          <Table.Cell><Checkbox /></Table.Cell>

          <Table.Cell>John</Table.Cell>
          <Table.Cell>Approved</Table.Cell>
          <Table.Cell>None</Table.Cell>
          <Table.Cell>John</Table.Cell>
          <Table.Cell>Approved</Table.Cell>
          <Table.Cell>None</Table.Cell>
        </Table.Row>
        <Table.Row>
          <Table.Cell><Checkbox /></Table.Cell>

          <Table.Cell>Jamie</Table.Cell>
          <Table.Cell>Approved</Table.Cell>
          <Table.Cell>Requires call</Table.Cell>
          <Table.Cell>Jamie</Table.Cell>
          <Table.Cell>Approved</Table.Cell>
          <Table.Cell>Requires call</Table.Cell>
        </Table.Row>
        <Table.Row>
          <Table.Cell><Checkbox /></Table.Cell>

          <Table.Cell>John</Table.Cell>
          <Table.Cell>Approved</Table.Cell>
          <Table.Cell>None</Table.Cell>
          
          <Table.Cell>John</Table.Cell>
          <Table.Cell>Approved</Table.Cell>
          <Table.Cell>None</Table.Cell>
        </Table.Row>
        <Table.Row>
          <Table.Cell><Checkbox /></Table.Cell>

          <Table.Cell>Jamie</Table.Cell>
          <Table.Cell>Approved</Table.Cell>
          <Table.Cell>Requires call</Table.Cell>
          <Table.Cell>Jamie</Table.Cell>
          <Table.Cell>Approved</Table.Cell>
          <Table.Cell>Requires call</Table.Cell>
        </Table.Row>
      </Table.Body>
    </Table>
  )
  
const TableExampleVeryCompact2 = () => (

    <Table compact='very' >
      <Table.Header>
        <Table.Row>
        <Table.HeaderCell><Checkbox /></Table.HeaderCell>
          <Table.HeaderCell>Name</Table.HeaderCell>
          <Table.HeaderCell>Status</Table.HeaderCell>
          <Table.HeaderCell>Notes</Table.HeaderCell>
          <Table.HeaderCell>Name</Table.HeaderCell>
          <Table.HeaderCell>Status</Table.HeaderCell>
          <Table.HeaderCell>Notes</Table.HeaderCell>
        </Table.Row>
      </Table.Header>
  
      <Table.Body>
       
        <Table.Row>
          <Table.Cell><Checkbox /></Table.Cell>

          <Table.Cell>John</Table.Cell>
          <Table.Cell>Approved</Table.Cell>
          <Table.Cell>None</Table.Cell>
          <Table.Cell>John</Table.Cell>
          <Table.Cell>Approved</Table.Cell>
          <Table.Cell>None</Table.Cell>
        </Table.Row>
       
      </Table.Body>
    </Table>
  )
  const PaginationExamplePagination = () => (
    <Pagination defaultActivePage={5} totalPages={10} />
  )
class Kpi extends React.Component {

  

    render() {
        
      return (
        <div>
         {/* <h1>hi</h1> */}
         <div className="side">
         <Grid columns='equal' style={{ padding:"10px"}}>
              <Grid.Row style={{ backgroundColor:"#e9e8d9",borderRadius:"12px"}}>
              <Grid.Column >
                    <label>Source Name</label> <br></br>
                    <div style={{marginLeft:"-3%" ,width:"100px"}}><DropdownExampleSearchSelection />  </div>     
              </Grid.Column>
              
              
             </Grid.Row>
             <Grid.Row style={{ backgroundColor:"#e9e8d9",borderRadius:"12px",marginTop:"10px"}}>
              <Grid.Column>
                <div style={{marginLeft:"63%"}}>
                <Search icon='search plus' iconPosition='right' placeholder="Search Here ..."/>
                </div>
                <TableExampleVeryCompact/>
                < PaginationExamplePagination/>
              </Grid.Column>
              <Grid.Column>
              <div style={{marginLeft:"63%"}}>
                <Search icon='search plus' iconPosition='right' placeholder="Search Here ..."/>
                </div>
                <TableExampleVeryCompact/>
                < PaginationExamplePagination/>
              </Grid.Column>
             </Grid.Row>
             <Grid.Row style={{ backgroundColor:"#e9e8d9",borderRadius:"12px",marginTop:"10px"}}>
              <Grid.Column>
             
                <TableExampleVeryCompact2/>
               
              </Grid.Column>
              <Grid.Column>
             
                <TableExampleVeryCompact2/>
                
              </Grid.Column>
             </Grid.Row>
              
             

          </Grid>
  
  
         </div>
        </div>
      );
    }
  }
  
  export default Kpi;
  
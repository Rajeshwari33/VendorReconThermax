import { headers, baseUrl } from "../../common/credentials";

const port = "8000";

export const getFileUploadListFromServer = () => {
    let url = baseUrl + port + "/api/v2/user_modules/compliance_certificate/file_uploads/";
    return ([headers, url]);
}
import React, { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import './file-upload.css';
import Select from "react-select";
// import { getFileUploadListFromServer, port } from '../../../../services/process/medical-insurance/medicalInsuranceFileUploadService';
// import { getFileProcessFromServer } from '../../../../services/process/medical-insurance/medicalInsuranceReportService.js';
import { SheetData, port1 } from '../../../../../services/auth-service/authService';
import { getTargetValuesFromServer, createExcelFile, getFileUploadListFromServer, FetchErrorMessages } from '../../../../../services/consolidation/file_upload_services';


import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-balham.css';
import { AgGridReact } from 'ag-grid-react';
import LoaderComponent from "../../../../../libraries/loader/loader";
import refreshIcon from "../../../../../assets/images/refresh.png";
import { baseUrl } from "../../../../../services/common/credentials";

import Box from "@mui/material/Box";
import Tab from "@mui/material/Tab";
import { Grid, Button } from 'semantic-ui-react';

import TabContext from '@material-ui/lab/TabContext';
import TabList from '@material-ui/lab/TabList';
import TabPanel from '@material-ui/lab/TabPanel';
import axios from 'axios';

import excelIcon from '../../../../../assets/images/excel.png';
import * as XLSX from 'xlsx';



var local_host = baseUrl + port1;

function ConsolidationFileUpload() {
    const gridColumnDefs = [
        { field: 'source_type', headerName: 'Source Type', sortable: true, filter: true, resizable: true, width: 130 },
        { field: 'file_type', headerName: 'File Type', sortable: true, filter: true, resizable: true, width: 150 },
        { field: 'month', headerName: 'Process Month', sortable: true, filter: true, resizable: true, width: 100 },
        { field: 'extraction_type', headerName: 'Extraction Type', sortable: true, filter: true, resizable: true, width: 125 },
        { field: 'file_name', headerName: 'File Name', sortable: true, filter: true, resizable: true, width: 200 },
        { field: 'file_size_bytes', headerName: 'File Size (KB)', sortable: true, filter: true, resizable: true, width: 100 },
        { field: 'status', headerName: 'Status', sortable: true, filter: true, resizable: true, width: 100 },
        { field: 'comments', headerName: 'Comments', sortable: true, filter: true, resizable: true, width: 200 },
        { field: 'created_date', headerName: 'Upload Date Time', sortable: true, filter: true, resizable: true, width: 200 }
    ]

    const error_file_columns = [
        { field: 'id', headerName: 'Id', sortable: true, filter: true, resizable: true, width: 200 },
        { field: 'file_name', headerName: 'File Name', sortable: true, filter: true, resizable: true, width: 200 },
        { field: 'sheet_name', headerName: 'Sheet Name', sortable: true, filter: true, resizable: true, width: 200 },
        { field: 'error_message', headerName: 'Error Message', sortable: true, filter: true, resizable: true, width: 200 },
        { field: 'position_error', headerName: 'Position Error', sortable: true, filter: true, resizable: true, width: 200 },
        { field: 'row_no', headerName: 'Row Number', sortable: true, filter: true, resizable: true, width: 200 },
        { field: 'col_no', headerName: 'Column Number', sortable: true, filter: true, resizable: true, width: 200 },

    ]

    const [selectedOptions, setSelectedOptions] = useState();
    const [targetOptions, setTargetOptions] = useState();
    const [inputMonth, setInputMonth] = useState(undefined);
    const [userCredentials] = useState(JSON.parse(sessionStorage.getItem("userCredentials")));
    const { register, handleSubmit } = useForm();
    const [columnDefs] = useState(gridColumnDefs);
    const [rowData, setRowData] = useState([]);
    const [rowData1, setRowData1] = useState([]);
    const [paginationSize] = useState(15);
    const [loaderOpen, setLoaderOpen] = useState(false);
    const [selectedValues, setSelectedValues] = useState();
    const [sourceId, setSourceId] = useState();
    const [selectedValues1, setSelectedValues1] = useState();
    const [sourceId1, setSourceId1] = useState();

    const [isfileuploadlist, setisfileuploadlist] = useState(true);
    const [iserrormessageslist, setiserrormessageslist] = useState(false);
    const [value, setValue] = useState("1");



    // const optionList = [
    //     { value: "MIS", label: "MIS Data", m_source_id: 1},
    //     { value: "Associates", label: "Associates Data", m_source_id: 2},
    //     { value: "Exit", label: "Exit InterView Report", m_source_id: 3},
    //     { value: "Death", label: "Death Tracker", m_source_id: 4},
    //     { value: "Staffing", label: "Staffing Pay Register", m_source_id: 5},
    //     { value: "Opp register", label: "Opp Salary Register", m_source_id: 6},
    // ];

    const onSubmit = async (data) => {

        // if (selectedOptions === undefined)
        // {
        //     alert("Please Select a File Type before Upload!!!");
        // }
        if (inputMonth === undefined) {
            alert("Please Choose the Month of file before Upload!!!");
        }
        // else if (data.file[0] === undefined)
        // {
        //     alert("Please Choose a File for Upload!!!");
        // }
        else {
            const formData = new FormData();

            formData.append("file", data.file[0]);
            // formData.append("file_type", selectedValues["label"]);
            formData.append("tenants_id", userCredentials["tenants_id"]);
            formData.append("groups_id", userCredentials["groups_id"]);
            formData.append("entities_id", userCredentials["entities_id"]);
            formData.append("user_id", userCredentials["user_id"]);
            formData.append("m_processing_layer_id", userCredentials["m_processing_layer_id"]);
            formData.append("m_processing_sub_layer_id", userCredentials["m_processing_sub_layer_id"]);
            formData.append("processing_layer_id", userCredentials["processing_layer_id"]);
            formData.append("processing_layer_name", "Consolidation");
            // formData.append("processing_layer_name", userCredentials["processing_layer_name"]);
            formData.append("source_type", "FILE");
            formData.append("extraction_type", "Upload");
            formData.append("month", inputMonth);
            formData.append("type", "post_file_upload");
            formData.append("m_source_id", userCredentials["user_id"]);
            formData.append("is_processing", 0);


            // console.log("Form Data", data.file[0]);
            // console.log("selected", selectedOptions);
            // console.log("Month", inputMonth);
            try {
                setLoaderOpen(true);
                const fileUploadResponse = await fetch(local_host + "/api/v2/user_modules/file_uploads/", {
                    method: "POST",
                    body: formData,
                }).then((res) => res.json());

                console.log("response", fileUploadResponse);
                if (fileUploadResponse["status"] !== "Success") {
                    alert("Error in Uploading File!!!");
                    setLoaderOpen(false);
                }
                else {
                    fileUploadsList();
                    alert("File Uploading started!!!");
                    setInputMonth(undefined);

                    document.getElementById("file-upload-form").reset();
                    document.getElementById("file-upload-month").value = '';

                    setLoaderOpen(false);
                }
            }
            catch (err) {
                console.log("Error", err);
                setLoaderOpen(false);
            }

            // console.log(JSON.stringify(`${res.message}, status: ${res.status}`));
        }
    };

    function fileUploadsList() {
        setLoaderOpen(true);
        let payload = {
            "tenants_id": userCredentials["tenants_id"],
            "groups_id": userCredentials["groups_id"],
            "entities_id": userCredentials["entities_id"],
            "m_processing_layer_id": userCredentials["m_processing_layer_id"],
            "m_processing_sub_layer_id": userCredentials["m_processing_sub_layer_id"],
            "processing_layer_id": userCredentials["processing_layer_id"],
            "is_active": "yes"
        }

        var getFileUploadsList = getFileUploadListFromServer();

        axios.get(getFileUploadsList[1], { params: payload }, getFileUploadsList[0])
            .then(
                response => {
                    console.log("get upload file data!!!", response);
                    // setLoaderOpen(false);
                    let data = response["data"];
                    if (response["statusText"] === "OK") {
                        setRowData(data);
                        setLoaderOpen(false);
                    }
                }
            ).catch(
                error => {
                    console.log("Error in File Upload List!!!", error);
                    setLoaderOpen(false);
                }
            );

    }

    function handleSelect(data) {
        // console.log(data);
        setSelectedOptions(data);
    }

    const customStyles = {
        control: base => ({
            ...base,
            height: 35,
            minHeight: 35,
            marginTop: 0,
            paddingTop: -5,
            fontSize: 14,
            left: -31
        })
    };

    // function searchForm(){
    //     setLoaderOpen(true);
    //     let payload = {
    //         "tenants_id": 1,
    //         "groups_id": 1,
    //         "entities_id": 1,
    //         "m_processing_layer_id": 1,
    //         "m_processing_sub_layer_id": 1,
    //         "processing_layer_id": 1,
    //         "is_active": "yes",
    //         "month" : inputMonth,
    //     }

    //     var getFileProcess = getFileProcessFromServer();

    //     axios.post(getFileProcess[1], {params : payload}, getFileProcess[0])
    //     .then(
    //         response => {
    //             console.log("File Process Response!!!", response)
    //             let data = response["data"];
    //             // console.log("response", data["data"])
    //             if (data["Status"] === "Success")
    //             {
    //                 alert("File Processed Successfully!!!");
    //                 setLoaderOpen(false);
    //             }
    //         }
    //     ).catch(
    //         error => {
    //             console.log("Error in File Process List!!!", error);
    //             setLoaderOpen(false);
    //         }
    //     );
    // }


    const fetchTargetdata = () => {
        let payload = {
            File_data: 'hi',
        }

        var FileUploadCredentials = getTargetValuesFromServer();

        axios.post(FileUploadCredentials[1], payload, FileUploadCredentials[0])
            .then(
                response => {
                    console.log("fetch the target data!!!", response);
                    let table_data = response.data;
                    let names = [{ value: "", label: "Select All" },]
                    table_data.map((data) => {
                        let obj = {
                            value: data.target_id,
                            label: data.target_name
                        }
                        names.push(obj);
                    })
                    setTargetOptions(names);
                }
            )
    }


    const fetchsourcenames = () => {
        let payload = {
            File_data: 'hi',
        }

        var FileUploadCredentials = SheetData();

        axios.post(FileUploadCredentials[1], payload, FileUploadCredentials[0])
            .then(
                response => {
                    console.log("Validate Credentials Response!!!", response);
                    let table_data = response.data;

                    let names = [{ value: "", label: "Select Source" },]
                    table_data.map((data) => {

                        let obj = {
                            value: data.source_id,
                            label: data.source_name
                        }
                        names.push(obj);
                    })
                    setSelectedOptions(names);
                }
            )

    }

    useEffect(() => {
        fileUploadsList();
        fetchsourcenames();
        fetchTargetdata();
    }, [])


    const handleChange1 = (event) => {
        const newValue = event;
        console.log('selected val' + newValue);
        setSelectedValues(newValue);
        setSourceId(event.value);

    }

    const handleChange2 = (event) => {
        const newValue = event;
        console.log('selected val' + newValue);
        setSelectedValues1(newValue);
        setSourceId1(event.value);
        console.log(event.value);

    }

    const CreateexcelFile = () => {
        setLoaderOpen(true);
        console.log('clicked run button');
        let payload = {
            id: sourceId1,
            month: inputMonth,
            tenants_id: userCredentials["tenants_id"],
            groups_id: userCredentials["groups_id"],
            entities_id: userCredentials["entities_id"],
            user_id: userCredentials["user_id"],
            m_processing_layer_id: userCredentials["m_processing_layer_id"],
            m_processing_sub_layer_id: userCredentials["m_processing_sub_layer_id"],
            processing_layer_id: userCredentials["processing_layer_id"]
        }

        var FileUploadCredentials = createExcelFile();

        axios.post(FileUploadCredentials[1], payload, FileUploadCredentials[0])
            .then(
                response => {
                    console.log("create excel file", response);
                    alert('successfully created target config file')
                    setLoaderOpen(false);
                }
            ).catch(
                error => {
                    console.log("Error in craeted target config file!!!", error);
                    alert('Error in created target config file')
                    setLoaderOpen(false);
                }
            );
    }

    const FetchErrorMesssages = () => {
        setLoaderOpen(true);
        console.log('clicked run11 button');
        let payload = {
            "hi": "hi"
        }

        var FileUploadCredentials = FetchErrorMessages();

        axios.post(FileUploadCredentials[1], payload, FileUploadCredentials[0])
            .then(
                response => {
                    console.log("get upload file data!!!", response);
                    // setLoaderOpen(false);
                    let data = response["data"];
                    if (data) {
                        setRowData1(data);
                        setLoaderOpen(false);
                    }
                }
            ).catch(
                error => {
                    console.log("Error in File Upload List!!!", error);
                    setLoaderOpen(false);
                }
            );
    }




    function exportJsonToXLSX(data, sheetName, excelFileName) {
        try {
            var workBook = XLSX.utils.book_new();
            var workSheet = XLSX.utils.json_to_sheet(data, {
                skipHeader: false,
            });
            XLSX.utils.book_append_sheet(workBook, workSheet, sheetName);
            XLSX.writeFile(workBook, excelFileName);
            return true;
        }
        catch
        {
            return false;
        }
    }

    function exportToExcel() {
        let fileNameChange = "Report.xlsx";
        let sheetName = "sheet";

        let excelExportData = [];

        for (let i = 0; i < rowData1.length; i++) {
            let data = {};
            for (let key in rowData1[i]) {
                for (let j = 0; j < error_file_columns.length; j++) {
                    if (key === error_file_columns[j]["field"]) {
                        data[error_file_columns[j]["headerName"]] = rowData1[i][key]
                    }
                }
            }

            excelExportData.push(data);
        };

        exportJsonToXLSX(excelExportData, sheetName, fileNameChange);

    }

    const TabChange = (event, newValue) => {
        setValue(newValue);
        if (newValue == "1") {
            setiserrormessageslist(false);
            setisfileuploadlist(true);
        } else if (newValue == "2") {
            setisfileuploadlist(false);
            setiserrormessageslist(true);
            FetchErrorMesssages();
        }
    }

    const contextMenuItems = params => {
        return [
          {
            name: 'Copy',
            action: () => {
              const cellValue = params.value;
              // Use clipboard library to copy the cell value to clipboard
              // Implement the clipboard.copy() function based on your clipboard library
              params.api.copySelectedRangeToClipboard();
            },
          },
          'separator',
          'copy',
          'copyWithHeaders',
        ];
      };

    return (
        <>
            <div className="file-upload-cardBox">
                <div className="file-upload-card">
                    <div>
                        <label htmlFor="underline_select " className="sr-only numbers" style={{ fontSize: '15px', left: '-30px' }}>File Type</label><br />
                        <div className="cardName">
                            <div className="dropdown-container">
                                <Select
                                    clearable
                                    options={selectedOptions}
                                    selection
                                    placeholder='Choose source name'
                                    size='mini'
                                    onChange={handleChange1}
                                    value={selectedValues}
                                />
                                {/* <select class="sheet_names" value={selectedValues} onChange={handleChange1}>
                                {selectedOptions?.map((option) => (
                                    <option class="sheet_names" key={option.value} value={option.value}>
                                    {option.label}
                                    </option>
                                ))}
                            </select> */}
                            </div>
                        </div>
                    </div>
                </div>

                <div className="file-upload-card">
                    <div>
                        <label id="underline_select" htmlFor="underline_select " className="sr-only numbers" style={{ fontSize: '15px' }}>Month</label><br />
                        <input type="month" className="cardName filetype" style={{ paddingLeft: "10px" }} onChange={(e) => { setInputMonth(e.target.value) }} id="file-upload-month" />
                    </div>
                </div>

                <div className="file-upload-card">
                    <div>
                        <label htmlFor="underline_select " className="sr-only numbers" style={{ fontSize: '15px', left: '-30px' }}>File Type</label><br />
                        <div className="cardName">
                            <div className="dropdown-container">
                                <Select
                                    clearable
                                    options={targetOptions}
                                    selection
                                    placeholder='Choose target id'
                                    size='mini'
                                    onChange={handleChange2}
                                    value={selectedValues1}
                                />

                            </div>
                        </div>
                    </div>
                </div>

                <div className="file-upload-card">
                    <div>
                        <label htmlFor="underline_select " className="sr-only numbers " style={{ fontSize: '15px' }}>File Upload</label><br />
                        <form onSubmit={handleSubmit(onSubmit)} id="file-upload-form">
                            <input type="file" {...register("file")} />
                            <input type="submit" value="Upload" className="btn" style={{ height: "35px", marginTop: "-60px", marginLeft: "330px", backgroundColor: "#000055", color: "#ffffff" }} />
                        </form>
                        {/* <button style={{height:"35px",marginTop: "-60px",marginLeft:"330px",backgroundColor:"#000055",color:"#ffffff"}} onClick={searchForm}>
                                        Run
                        </button> */}

                    </div>
                    {/* <div className="cardHeader">
                        
                        <h4><a href={""} className="btn" style={{marginTop: "43px"}}> Upload</a></h4>  
                    </div> */}
                </div>
            </div>

            <div className="file-upload d-flex p-3 rounded">
                <img src={refreshIcon} alt="No Images" style={{ width: '40px', height: '37px' }} className="referesh-icon-class" title="Refresh" />
                <button className="btn" style={{ height: "35px", width: "7%", borderRadius: "9%", backgroundColor: "#000055", color: "#ffffff" }} onClick={CreateexcelFile}>
                    Run
                </button>

                {iserrormessageslist && (
                    <img src={excelIcon} alt="No Images" style={{ width: '40px', height: '37px' }} className="excel-icon-class" onClick={exportToExcel} title="Export" />
                )}
            </div>
            <Box style={{ backgroundColor: 'rgb(233, 232, 217)', borderRadius: '12px', marginTop: '10px' }}>
                <TabContext value={value}>
                    <Box sx={{ display: 'flex', justifyContent: 'flex-end', borderBottom: 1, borderColor: 'divider' }}>
                        <TabList onChange={TabChange} aria-label="lab API tabs example">
                            <Tab label="File Uploads List" value="1" />
                            <Tab label="Error Messages" value="2" />

                        </TabList>
                    </Box>

                </TabContext>
            </Box>
            {isfileuploadlist &&
                <div className="ag-theme-balham fileupload-layer">
                    <AgGridReact
                        // context={{
                        //     clipboard: true,
                        //   }}
                        // getContextMenuItems={contextMenuItems}
                        columnDefs={gridColumnDefs}
                        rowData={rowData}
                        paginationPageSize={paginationSize}
                        pagination={true}
                        animateRows={true}
                        // enableRangeSelection={true}
                        // enableRangeCopy={true}
                    ></AgGridReact>
                </div>}
            {iserrormessageslist &&
                <div className="ag-theme-balham fileupload-layer">
                    <AgGridReact
                        columnDefs={error_file_columns}
                        rowData={rowData1}
                        paginationPageSize={paginationSize}
                        pagination={true}
                        animateRows={true}
                    ></AgGridReact>
                </div>}
            <LoaderComponent loaderOpen={loaderOpen} />
        </>
    )
}


export default ConsolidationFileUpload;



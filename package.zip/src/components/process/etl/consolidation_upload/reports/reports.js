import React, { useEffect, useState, useRef, useCallback} from "react";
import Select from "react-select";
import './reports.css';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-balham.css';
import { AgGridReact } from 'ag-grid-react';
import LoaderComponent from "../../../../../libraries/loader/loader";

import { getFileProcessFromServer1, saveJsonfileToServer } from '../../../../../services/process/medical-insurance/medicalInsuranceReportService';
import axios from "axios";
import excelIcon from '../../../../../assets/images/excel.png';
import * as XLSX from 'xlsx';
import { Icon, Input, Button, Dropdown, Grid, Popup, Segment, Tab, Menu, Form, TextArea, Label } from 'semantic-ui-react';


import refreshIcon from "../../../../../assets/images/refresh.png";


var aggCallCount = 0;

var compareCallCount = 0;

var filterCallCount = 0;


function ConsolidationReport() {
    const [inputMonth, setInputMonth] = useState(undefined);
    const [hideResultGrid, setHideResultGrid] = useState(true);
    const [loaderOpen, setLoaderOpen] = useState(false);
    // const [userCredentials] = useState(JSON.parse(sessionStorage.getItem("userCredentials")));
    const [rowData, setRowData] = useState([]);
    const [paginationSize] = useState(15);
    const [companyname, setCompanyName] = useState({});
    const [type, setType] = useState(undefined);
    const [gridColumns, setGridColumns] = useState([]);
    const gridRef = useRef();
    const [isutr, isSetUtr] = useState(false);

    	
 

    var utr_columns = [
       
        { field: 'cs', headerName: 'cs', sortable: true, filter: true, resizable: true, editable: true },
        { field: 'client name', headerName: 'client name', sortable: true, filter: true, resizable: true },
        { field: 'alcs id', headerName: 'alcs id', sortable: true, filter: true, resizable: true },
        { field: 'corp id', headerName: 'corp id', sortable: true, filter: true, resizable: true },
        { field: 'tl gst no', headerName: 'tl gst no', sortable: true, filter: true, resizable: true },
        { field: 'from state code', headerName: 'from state code', sortable: true, filter: true, resizable: true },
        { field: 'from state name', headerName: 'from state name', sortable: true, filter: true, resizable: true },
        { field: 'to state code', headerName: 'to state code', sortable: true, filter: true, resizable: true },
        
        
        { field: 'to state name', headerName: 'to state name', sortable: true, filter: true, resizable: true },
        { field: 'client address', headerName: 'client address', sortable: true, filter: true, resizable: true },
        { field: 'client gst no', headerName: 'client gst no', sortable: true, filter: true, resizable: true },
        { field: 'gm id gst code', headerName: 'gm id gst code', sortable: true, filter: true, resizable: true },
        { field: 'client sez exemption', headerName: 'client sez exemption', sortable: true, filter: true, resizable: true },
        { field: 'invoice date', headerName: 'invoice date', sortable: true, filter: true, resizable: true },
        { field: 'invoice time', headerName: 'invoice time', sortable: true, filter: true, resizable: true },
        { field: 'type', headerName: 'type', sortable: true, filter: true, resizable: true },
        { field: 'invoice #', headerName: 'invoice #', sortable: true, filter: true, resizable: true },
        { field: 'revenue location', headerName: 'revenue location', sortable: true, filter: true, resizable: true },
        { field: 'pf service charges part of ctc yes or no', headerName: 'pf service charges part of ctc yes or no', sortable: true, filter: true, resizable: true },
        { field: 'invoice version', headerName: 'invoice version', sortable: true, filter: true, resizable: true },
        { field: 'assc number', headerName: 'assc number', sortable: true, filter: true, resizable: true },
        { field: 'insurance charges', headerName: 'insurance charges', sortable: true, filter: true, resizable: true },
        { field: 'labour welfare fund', headerName: 'labour welfare fund', sortable: true, filter: true, resizable: true },
        { field: 'edli admin charges', headerName: 'edli admin charges', sortable: true, filter: true, resizable: true },
        { field: 'workman compensation', headerName: 'workman compensation', sortable: true, filter: true, resizable: true },
        { field: 'ctc', headerName: 'ctc', sortable: true, filter: true, resizable: true },
        { field: 'reimbursement', headerName: 'reimbursement', sortable: true, filter: true, resizable: true },
        { field: 'insurance others ctc', headerName: 'insurance others ctc', sortable: true, filter: true, resizable: true },
        { field: 'gtl cost', headerName: 'gtl cost', sortable: true, filter: true, resizable: true },
        { field: 'sourcing fee', headerName: 'sourcing fee', sortable: true, filter: true, resizable: true },
        { field: 'others', headerName: 'others', sortable: true, filter: true, resizable: true },
        { field: 'loan recovery', headerName: 'loan recovery', sortable: true, filter: true, resizable: true },
        { field: 'advance recovery', headerName: 'advance recovery', sortable: true, filter: true, resizable: true },
        { field: 'imprest recovery', headerName: 'imprest recovery', sortable: true, filter: true, resizable: true },
        { field: 'setup fees', headerName: 'setup fees', sortable: true, filter: true, resizable: true },
        { field: 'pf service charges', headerName: 'pf service charges', sortable: true, filter: true, resizable: true },
        { field: 'absorption fee', headerName: 'absorption fee', sortable: true, filter: true, resizable: true },
        { field: 'mark up', headerName: 'mark up', sortable: true, filter: true, resizable: true },
        { field: 'bbo cost', headerName: 'bbo cost', sortable: true, filter: true, resizable: true },
        { field: 'hiring cost', headerName: 'hiring cost', sortable: true, filter: true, resizable: true },
        { field: 'on site cost', headerName: 'on site cost', sortable: true, filter: true, resizable: true },
        { field: 'on campus cost', headerName: 'on campus cost', sortable: true, filter: true, resizable: true },
        { field: 'online training cost', headerName: 'online training cost', sortable: true, filter: true, resizable: true },
        { field: 'imprest payment', headerName: 'imprest payment', sortable: true, filter: true, resizable: true },
        { field: 'loan payment', headerName: 'loan payment', sortable: true, filter: true, resizable: true },
        { field: 'cand sourcing fee', headerName: 'cand sourcing fee', sortable: true, filter: true, resizable: true },
        { field: 'dws markup', headerName: 'dws markup', sortable: true, filter: true, resizable: true },
        { field: 'one time revenue', headerName: 'one time revenue', sortable: true, filter: true, resizable: true },
        { field: 'recurring revenue', headerName: 'recurring revenue', sortable: true, filter: true, resizable: true },
        { field: 'govt fee', headerName: 'govt fee', sortable: true, filter: true, resizable: true },
        { field: 'associate charges', headerName: 'associate charges', sortable: true, filter: true, resizable: true },
        { field: 'payroll fee', headerName: 'payroll fee', sortable: true, filter: true, resizable: true },
        { field: 'sourcing fee 1', headerName: 'sourcing fee 1', sortable: true, filter: true, resizable: true },
        { field: 'project fee', headerName: 'project fee', sortable: true, filter: true, resizable: true },
        { field: 'other income', headerName: 'other income', sortable: true, filter: true, resizable: true },
        { field: 'asset transfer', headerName: 'asset transfer', sortable: true, filter: true, resizable: true },
        { field: 'deposit amount', headerName: 'deposit amount', sortable: true, filter: true, resizable: true },
        { field: 'contigency deduction', headerName: 'contigency deduction', sortable: true, filter: true, resizable: true },
        { field: 'professional charges', headerName: 'professional charges', sortable: true, filter: true, resizable: true },
        { field: 'rent charges', headerName: 'rent charges', sortable: true, filter: true, resizable: true },
        { field: 'pf admin charges new', headerName: 'pf admin charges new', sortable: true, filter: true, resizable: true },
        { field: 'compliance setup fee', headerName: 'compliance setup fee', sortable: true, filter: true, resizable: true },
        { field: 'pf service charges part of ctc', headerName: 'pf service charges part of ctc', sortable: true, filter: true, resizable: true },
        { field: 'insugtl charges', headerName: 'insugtl charges', sortable: true, filter: true, resizable: true },
        { field: 'gross', headerName: 'gross', sortable: true, filter: true, resizable: true },
        { field: 's tax 14 percentage', headerName: 's tax 14 percentage', sortable: true, filter: true, resizable: true },
        { field: 'cess 0 percentage', headerName: 'cess 0 percentage', sortable: true, filter: true, resizable: true },
        { field: 'se cess 0 percentage', headerName: 'se cess 0 percentage', sortable: true, filter: true, resizable: true },
        { field: 'sb cess 0 5 percentage', headerName: 'sb cess 0 5 percentage', sortable: true, filter: true, resizable: true },
        { field: 'kk cess 0 5 percentage', headerName: 'kk cess 0 5 percentage', sortable: true, filter: true, resizable: true },
        { field: 'sgst ugst', headerName: 'sgst ugst', sortable: true, filter: true, resizable: true },
        { field: 'cgst', headerName: 'cgst', sortable: true, filter: true, resizable: true },
        { field: 'igst', headerName: 'igst', sortable: true, filter: true, resizable: true },
        { field: 'bus deduction', headerName: 'bus deduction', sortable: true, filter: true, resizable: true },
        { field: 'food deduction', headerName: 'food deduction', sortable: true, filter: true, resizable: true },
        { field: 'other deduction', headerName: 'other deduction', sortable: true, filter: true, resizable: true },
        { field: 'notice recovery', headerName: 'notice recovery', sortable: true, filter: true, resizable: true },
        { field: 'invoice total', headerName: 'invoice total', sortable: true, filter: true, resizable: true },
        { field: 'remarks', headerName: 'remarks', sortable: true, filter: true, resizable: true },
        { field: 'fin approved status', headerName: 'fin approved status', sortable: true, filter: true, resizable: true },
        { field: 'fin approved by', headerName: 'fin approved by', sortable: true, filter: true, resizable: true },
        { field: 'hsn', headerName: 'hsn', sortable: true, filter: true, resizable: true },
        { field: 'place of supply', headerName: 'place of supply', sortable: true, filter: true, resizable: true },
        { field: 'is draft invoice', headerName: 'is draft invoice', sortable: true, filter: true, resizable: true },
        { field: 'draft invoice number', headerName: 'draft invoice number', sortable: true, filter: true, resizable: true },
        { field: 'draft invoice date', headerName: 'draft invoice date', sortable: true, filter: true, resizable: true },
        { field: 'supply type code', headerName: 'supply type code', sortable: true, filter: true, resizable: true },
        { field: 'document type', headerName: 'document type', sortable: true, filter: true, resizable: true },
        { field: 'irn number', headerName: 'irn number', sortable: true, filter: true, resizable: true },
        { field: 'irn generated date', headerName: 'irn generated date', sortable: true, filter: true, resizable: true },
        { field: 'source name', headerName: 'source name', sortable: true, filter: true, resizable: true },
  
        
    ];

    
    const OptionsList = [
        { value: "all", label: "all" },
        { value: "tax_invoice", label: "tax invoice"},
    ];

    useEffect(() => {
        setLoaderOpen(false);
    }, []);

    const makeAPICall = async (url) => {
        try {
            setLoaderOpen(true);
            
            const response = await fetch(url);
            const data = await response.json();
            setRowData(data);
            console.log('data', data);
            setHideResultGrid(false);
            setLoaderOpen(false);
        }
        catch (e) {
            console.log(e);
            setLoaderOpen(false);
            setHideResultGrid(true);
        }
    }
  
    

    const customStyles = {
        control: base => ({
            ...base,
            height: 35,
            minHeight: 35,
            marginTop: 0,
            paddingTop: -5,
            fontSize: 14,
            left: -31
        })
    };


    function searchClick(event) {
        if (type === undefined) {
            alert("Please Select Report Type!!!");
        }

        else{
            let url = '';
            console.log('companyname', type.value);
            let month = String(inputMonth)
            if (type && type.value && month) {
                let param = String(type.value)
                url = `http://127.0.0.1:8002/api/v2/user_modules/fetch_generated_output_file/?type=${param}&&month=${month}`;
            }
           
            makeAPICall(url);
        }

    }

    function exportJsonToXLSX(data, sheetName, excelFileName) {
        try {
            var workBook = XLSX.utils.book_new();
            var workSheet = XLSX.utils.json_to_sheet(data, {
                skipHeader: false,
            });
            XLSX.utils.book_append_sheet(workBook, workSheet, sheetName);
            XLSX.writeFile(workBook, excelFileName);
            return true;
        }
        catch
        {
            return false;
        }
    }

    function exportToExcel() {
        let fileNameChange = "ConsolidationReport.xlsx";
        let sheetName = "sheet";

        let excelExportData = [];

        for (let i = 0; i < rowData.length; i++) {
            let data = {};
            for (let key in rowData[i]) {
                for (let j = 0; j < utr_columns.length; j++) {
                    if (key === utr_columns[j]["field"]) {
                        data[utr_columns[j]["headerName"]] = rowData[i][key]
                    }
                }
            }

            excelExportData.push(data);
        };

        exportJsonToXLSX(excelExportData, sheetName, fileNameChange);

    }


    

    function handleChange1(data) {
        setType(data);
        console.log('type',data.value);
        setHideResultGrid(true);
    }

    function onChangeMonth(e){
        setInputMonth(e.target.value);
        console.log(e.target.value);
    }

    
  


    return (
        <>
            <div className="report-cardBox">
                <div className="" style={{ marginLeft: "-10px" }}>
                    <div>
                        <label id="underline_select" htmlFor="underline_select " style={{ fontSize: '15px', marginLeft:'15px' }}>Date</label><br />
                        <Input type="month" className="cardName filetype" style={{ paddingLeft: "10px", marginTop:'5px' }} onChange={(e) => onChangeMonth(e)} />
                    </div>
                </div>
                <div className="">
                    <div>
                        <label htmlFor="underline_select " style={{ fontSize: '15px', marginLeft:'-25px' }}> Select Type</label> <br />
                        <div className="cardName">
                            <div className="dropdown-container">
                                <Select
                                    options={OptionsList}
                                    placeholder="Select type"
                                    value={type}
                                    onChange={handleChange1}
                                    isSearchable={true}
                                    styles={customStyles}
                                />
                            </div>
                        </div>
                    </div>
                </div>
                {/* <div className="">
                    <div>
                        <label htmlFor="underline_select " style={{ fontSize: '15px', marginLeft:'-25px' }}>Bank Name</label> <br />
                        <div className="cardName">
                            <div className="dropdown-container">
                                <Select
                                    options={insuranceCompanyOptionsList}
                                    placeholder="Select Company Name"
                                    value={companyname}
                                    onChange={handleChange}
                                    isSearchable={true}
                                    styles={customStyles}
                                />
                            </div>
                        </div>
                    </div>
                </div> */}
               
                
                {inputMonth && type ?
                    <button className="btn" style={{ height: "35px", width: "92px", marginTop: "28px", backgroundColor: "#000055", color: "#ffffff" }} onClick={(e) => { searchClick(e) }}>Search</button>
                    : <button className="btn" disabled={true} style={{ height: "35px", width: "92px", marginTop: "28px", backgroundColor: "#000055", color: "#ffffff" }}>Search</button>
                }
            </div>
            {/* <div className="file-upload">
                <img src={refreshIcon} alt="No Images" style={{width: '40px', height: '37px'}}  className="referesh-icon-class" title="Refresh" />
                <button style={{height:"35px",marginTop: "-47px",marginLeft:"61px",backgroundColor:"#000055",color:"#ffffff", width:"7%", borderRadius:"9%"}} onClick={searchForm}>
                    Run
                </button>
            </div> */}
            <div className="report" hidden={hideResultGrid}>
                <div>
                    <img src={excelIcon} alt="No Images" style={{ width: '40px', height: '37px' }} className="excel-icon-class" onClick={() => { exportToExcel() }} title="Export" />
                    
                </div>
                <div className="ag-theme-balham report-layer" style={{width:'100%', heidght:'100%'}}>
                    <AgGridReact
                        columnDefs={utr_columns}
                        rowData={rowData}
                        paginationPageSize={25}
                        pagination={true}
                        animateRows={true}
                        rowSelection={'multiple'}
                        groupSelectsChildren={true}
                        ref={gridRef}
                        suppressAggAtRootLevel={true}
                        suppressRowClickSelection={true}
                        
                    >
                    </AgGridReact>
                </div>
            </div>
          
            <LoaderComponent loaderOpen={loaderOpen} />

        </>
    )
}

export default ConsolidationReport;











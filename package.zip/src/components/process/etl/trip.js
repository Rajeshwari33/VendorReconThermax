import React, { useState } from 'react';

const Trip = ({ trip, toggleRoundUpOption }) => {
  const [pickupLocation, setPickupLocation] = useState(trip.pickupLocation);
  const [dropoffLocation, setDropoffLocation] = useState(trip.dropoffLocation);
  const [roundUpMileage, setRoundUpMileage] = useState(trip.roundUpMileage);

  const handlePickupLocationChange = (event) => {
    setPickupLocation(event.target.value);
    setRoundUpMileage(null);
  };

  const handleDropoffLocationChange = (event) => {
    setDropoffLocation(event.target.value);
    setRoundUpMileage(null);
  };

  const handleRoundUpOptionToggle = () => {
    toggleRoundUpOption(!roundUpMileage);
    setRoundUpMileage(!roundUpMileage ? roundUp(trip.mileage) : null);
  };

  const roundUp = (mileage) => {
    // Round up the mileage to the nearest whole number
    return Math.ceil(mileage);
  };

  return (
    <div>
      <div>
        <label htmlFor="pickup-location">Pickup Location:</label>
        <input
          type="text"
          id="pickup-location"
          value={pickupLocation}
          onChange={handlePickupLocationChange}
        />
      </div>
      <div>
        <label htmlFor="dropoff-location">Dropoff Location:</label>
        <input
          type="text"
          id="dropoff-location"
          value={dropoffLocation}
          onChange={handleDropoffLocationChange}
        />
      </div>
      <div>
        <label htmlFor="round-up-option">
          Round Up Mileage:
          <input
            type="checkbox"
            id="round-up-option"
            checked={roundUpMileage}
            onChange={handleRoundUpOptionToggle}
          />
        </label>
      </div>
      <div>
        Mileage: {roundUpMileage || trip.mileage}
      </div>
    </div>
  );
};

export default Trip;
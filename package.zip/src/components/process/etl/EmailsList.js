import React, { useState, useEffect, useRef } from 'react';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-balham.css';
import { AgGridReact } from 'ag-grid-react';
import LoaderComponent from "../../../libraries/loader/loader";
import Paper from '@mui/material/Paper';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TablePagination from '@mui/material/TablePagination';
import TableRow from '@mui/material/TableRow';
// import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import { Form, Input, Button, Grid, Checkbox } from 'semantic-ui-react';
import axios from 'axios';
import Select, { AriaOnFocus } from 'react-select';



var selectedOptionss;
var col_data = new Array();

const CustomAriaLive = ({data})  => {
  
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  // const [value, setValue] = useState(undefined);
  const onMenuOpen = () => setIsMenuOpen(true);
  const onMenuClose = () => setIsMenuOpen(false);
 
  const selectedOption = (e) =>{
    // selectedOption.pop();
    // selectedOptionss=[];
    selectedOptionss = e;
    console.log('clicked', e);
  }
  // const Options = [
  //   {value:"1", label:"anh"},
  //   {value:"2", label:"ank"},
  //   {value:"3", label:"an123"},
  //   {value:"4", label:"anhjhg"}
  // ]

  return (
    <form>
      <Select
        aria-labelledby="aria-label"
        inputId="aria-example-input"
        name="aria-live-color"
        onMenuOpen={onMenuOpen}
        onMenuClose={onMenuClose}
        options={data}
        onChange={e => selectedOption(e)}
        
      />
    </form>
  );
}


function EmailsList() {
  // const [paginationSize] = useState(15);
  const [loaderOpen, setLoaderOpen] = useState(false);
  const [hideResultGrid, setHideResultGrid] = useState(true);
  const [rowData, setRowData] = useState(undefined);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const [formValues, setFormValues] = useState({ id: "", client_id: "", client_name: "",email_id: "" });
  const [show, setShow] = useState(false);
  const [show1, setShow1] = useState(false);
  const [show2, setShow2] = useState(false);
  const [show3, setShow3] = useState(false);
  const [userCredentials] = useState(JSON.parse(sessionStorage.getItem("userCredentials")));
  // const [filteredData, setFilteredData] = useState(undefined);
  // const [tenantId, settenantId] = useState(undefined);
  const [formCreate, setFormCreate] = useState(true);
  const [options, setOptions] = useState(undefined);
  const [fromDate, setFromDate] = useState(undefined);
  const [toDate, setToDate] = useState(undefined);
  // const [checkbox, setCheckbox] = useState(false);
  const [selectedColumns, setSelectedColumns] = useState({});
  const ref = useRef([]);
 




  const columns = [
    // { id: 'all', label: 'all', minWidth: 10 },
    { id: 'id', label: 'id', minWidth: 10 },
    { id: 'client_id', label: 'client_id', minWidth: 10 },
    { id: 'client_name', label: 'client_name', minWidth: 10 },
    {
      id: 'email_id',
      label: 'email_id',
      minWidth: 10
    },
    {
      id: 'actions',
      label: 'actions',
      minWidth: 10
    },

  ];

  useEffect(() => {
    setLoaderOpen(false);
    let url = `http://127.0.0.1:8002/api/v2/medical_insurance/emails_list/`;
    makeAPICall(url);
  }, []);

  const makeAPICall = async (url) => {
    try {
      setLoaderOpen(true);
      console.log(url);
      const response = await fetch(url);
      const data = await response.json();
      // setRowData(data);
      // console.log('data', data);
      let options = [];
      data.map(data =>{
        console.log('{value:"1", label:"anh"},{id: 1, client_id: "vgfd", client_name: "ramu"}', data);
        options.push({value:data.client_name, label:data.client_id})
      })
      console.log(options);
      setOptions(options)
      setLoaderOpen(false);
    }
    catch (e) {
      console.log(e);
      setLoaderOpen(false);
      
    }
  }

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(+event.target.value);
    setPage(0);
  };

  const EditActions = ({ row }) => {
    setFormCreate(false);
    setShow(true);
    setFormValues({ id: row.id, client_id: row.client_id, client_name:row.client_name, email_id: row.email_id });
  };

  
  const handleClose = () => {
    setFormValues({ id: "", client_id: "", client_name: "",email_id: "" });
    setShow(false);
    setShow1(false);
    setShow2(false);
    setShow3(false);
  };

  const handleChange = (e) => {
    
    setFormValues({
      ...formValues,
      [e.target.name]: e.target.value
    })
  }

  let handleSubmit = (event) => {
    event.preventDefault();
    if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(formValues.email_id)) {
      alert('Invalid email address')
    }else{
      let url;
      if (formCreate == true) {
        url = `http://127.0.0.1:8002/api/v2/medical_insurance/createmail/`;
      } else {
        url = `http://127.0.0.1:8002/api/v2/medical_insurance/updateemails/${formValues.id}/`;
      }
      fetch(url, {
        method: 'POST',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(formValues)
      }).then((result) => {
        result.json().then((resp) => {
          console.log(resp);
          if (formCreate == true) {
            setFormValues({ id: "", client_id: "", client_name: "",email_id: "" });
            setFormCreate(true);
            setShow(false); 
            setShow2(true);
            let value = selectedOptionss.label;
          console.log('selectedOptionss', selectedOptionss);
          let url = `http://127.0.0.1:8002/api/v2/medical_insurance/filteremails/${value}/`;
          makeAPICall1(url);
          }else{
          if (resp == 'updated successfully' || resp == 'created successfully') {
            setFormValues({ id: "", client_id: "", client_name: "",email_id: "" });
            setFormCreate(true);
            setShow(false); 
            let value = selectedOptionss.label;
            console.log('selectedOptionss', selectedOptionss);
            let url = `http://127.0.0.1:8002/api/v2/medical_insurance/filteremails/${value}/`;
            makeAPICall1(url);
          }
        }
        })
      })
    }
  }

  // const handleFilterChange = (value) => {
  //   settenantId(value);
  //   if (value) {
  //     let url = `http://127.0.0.1:8000/api/v2/user_modules/filteremails/${value}/`;
  //     makeAPICall(url);
  //   }
  // };

  const displayDialogbox = () =>{
    setFormValues({ id: '', client_id: selectedOptionss.label, client_name:selectedOptionss.value, email_id: '' });
    setFormCreate(true);
    setShow(true);
  }

  const makeAPICall1 = async (url) => {
    try {
      setLoaderOpen(true);
      console.log(url);
      const response = await fetch(url);
      const data = await response.json();
      setRowData(data);
      console.log('data', data);
      
      setHideResultGrid(false);
      setLoaderOpen(false);
    }
    catch (e) {
      console.log(e);
      setLoaderOpen(false);
      setHideResultGrid(true);
    }
  }

  const viewTable = ()=> {
    if(selectedOptionss && selectedOptionss.label){
    let value = selectedOptionss.label;
    console.log('selectedOptionss', selectedOptionss);
    let url = `http://127.0.0.1:8002/api/v2/medical_insurance/filteremails/${value}/`;
    makeAPICall1(url);
    // setHideResultGrid(true);
    }
  }

  
  function handleDropdownChange(event, item) {
    console.log('data' + event);
    
    if (event.target.checked == false) {
      // setCheckbox(false);
      // setSelectedColumns({});
      // col_data.remove(item);
      const index = col_data.indexOf(item);
      col_data.splice(index, 1);
    }
    else if (event.target.checked) {
      col_data.push(item);
      
    }
    console.log('123' + col_data);
  }


  const Unchecked = (event) => {
    
    if(event.target.checked == false){
    for (let i = 0; i < rowData.length; i++) {
        ref.current[i].checked = false;
    }
    rowData.map(data =>{
      col_data.push(data);
    })
  }else{
    for (let i = 0; i < rowData.length; i++) {
      ref.current[i].checked = true;
    }
    col_data = [];
  }
  }
  const DeleteEmails = () => {
    setShow1(true); 
  }

  const DeleteEmails1 = () => {
    console.log('col_data', col_data);
    col_data.map(id =>{
      axios.delete(`http://127.0.0.1:8002/api/v2/medical_insurance/deletemails/${id}/`)
      .then(res => {
        console.log(res);
        console.log(res.data);
        const url = `http://127.0.0.1:8002/api/v2/medical_insurance/emails_list/`;
        makeAPICall1(url);
      });
    })
    setShow1(false);
  }

  

  const sendemails = async () =>{
    let value = selectedOptionss.label;
    console.log('selectedOptionss', selectedOptionss);
    let url = `http://127.0.0.1:8002/api/v2/medical_insurance/filteremails/${value}/`;
    // makeAPICall1(url);
    try {
      setLoaderOpen(true);
      console.log(url);
      const response = await fetch(url);
      const data = await response.json();
      // setRowData(data);
      // console.log('data', data);
      let data1 = [];
      data.map(data =>{
        data1.push(data.email_id)
      })
      
      let url1 = `http://127.0.0.1:50010/api/v1/alcs/common/alcs_clent_mail_sent_revised/`;
      fetch(url1, {
        method: 'POST',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(data1)
      }).then((result) => {
        result.json().then((resp) => {
        console.log(resp); 
        })
      })
      
      setLoaderOpen(false);
    }
    catch (e) {
      console.log(e);
      setLoaderOpen(false);
    }
    
  };

  const displaySendEmail = () =>{
    setShow3(true);
  }

  // const HandleSubmitEmail = () => {
  //   let data = [];

  //   rowData.map(data =>{
  //     data.push(data.email_id)
  //   })
  //   console.log('email submit');
  //   let url = `http://127.0.0.1:50010/api/v1/alcs/common/alcs_clent_mail_sent_revised/`;
  //     fetch(url, {
  //       method: 'POST',
  //       headers: {
  //         'Accept': 'application/json',
  //         'Content-Type': 'application/json'
  //       },
  //       body: JSON.stringify(data)
  //     }).then((result) => {
  //       result.json().then((resp) => {
  //       console.log(resp); 
  //       })
  //     })
  // }

  return (
    <>
      <div className="side" style={{ padding:"10px"}}>
     <Grid columns='equal'>
          <Grid.Row style={{ backgroundColor:"#e9e8d9",borderRadius:"12px",marginTop:"10px"}}>
          <Grid.Column>
              <CustomAriaLive data={options}/>
          </Grid.Column>
          <Grid.Column style={{width:'12em'}}>
          <Button variant="contained" color="primary" type="button" onClick={viewTable}>View</Button>
          </Grid.Column>
          <Grid.Column style={{marginLeft:'-23em'}}>
          <Button variant="contained" color="primary" type="button" onClick={displaySendEmail}>Send Email</Button>
          </Grid.Column>
          <Grid.Column>
          <Button variant="contained" color="primary" type="button" onClick={displayDialogbox}>Add</Button>
          </Grid.Column>
          </Grid.Row> 
       
          <Grid.Row style={{ backgroundColor:"#e9e8d9",borderRadius:"12px",marginTop:"5.3em"}} hidden={hideResultGrid}>
          <Paper sx={{ width: '97%', overflow: 'hidden',marginLeft:'1em'}}>
        <TableContainer sx={{ maxHeight: 260 }} style={{width:'102%', marginLeft:'-0.8em'}}>
          <Table stickyHeader aria-label="sticky table">
            <TableHead>
              <TableRow style={{ backgroundColor: 'rgb(233, 232, 217)' }}>
              <TableCell
                  key={'all'}
                  align={'all'}
                  class="header_column"
                >
                  <input
                    type="checkbox"
                    onChange={(event) => Unchecked(event)}
                    value='All'
                    name='All'
                    id="All"
                  />
                </TableCell>
                {columns.map((column) => (
                  <TableCell
                    key={column.id}
                    align={column.align}
                    class="header_column"
                  >
                    {column.label}
                  </TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>

              {rowData && rowData
                .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                .map((row, index) => {
                  return (
                    <TableRow hover role="checkbox" tabIndex={-1} key={index}>
                      <TableCell className="cell_data">
                        <input
                          type="checkbox"
                          onChange={(event) => handleDropdownChange(event, row.id)}
                          value={row.id}
                          name={row.id}
                          ref={(element) => { ref.current[index] = element }}
                          id={index}
                        />
                      </TableCell>
                      <TableCell className="cell_data"> {row.id}</TableCell>
                      <TableCell className="cell_data"> {row.client_id}</TableCell>
                      <TableCell className="cell_data"> {row.client_name}</TableCell>
                      <TableCell className="cell_data"> {row.email_id}</TableCell>
                      <TableCell className="cell_data">
                        <span onClick={e => EditActions({ row })}><i class='fa-solid fa-pen-to-square' ></i></span>
                        {/* <span style={{ marginLeft: '1em' }} onClick={e => DeleteActions({ row })}><i class='fa fa-trash-o'></i></span> */}
                      </TableCell>
                    </TableRow>
                  );
                })}

            </TableBody>
          </Table>
        </TableContainer>
        <TablePagination
          rowsPerPageOptions={[5, 10]}
          component="div"
          count={rowData?.length}
          rowsPerPage={rowsPerPage}
          page={page}
          onPageChange={handleChangePage}
          onRowsPerPageChange={handleChangeRowsPerPage}
        />
      </Paper>
      
      <Modal
        show={show}
        onHide={handleClose}
        backdrop="static"
        keyboard={false}
      >
        <Modal.Header closeButton>
          <Modal.Title>Emails Add/Update</Modal.Title>
        </Modal.Header>
        <Modal.Body>
        <Form>
            {/* <Form.Field style={{marginBottom:'0em'}}>
            <label>id</label>
          <input type="text" name="id" value={formValues && formValues.id || ""} disabled={true} /><br /> <br />
            </Form.Field> */}
            <Form.Field style={{marginBottom:'0em'}}><label>Client id</label>
            {formCreate ? <input type="text" disabled={true} name="client_id" value={formValues && formValues.client_id || ""} onChange={e => handleChange(e)} /> :
              <input type="text" required name="client_id" value={formValues && formValues.client_id || ""} onChange={e => handleChange(e)} />}
          
          </Form.Field>
          <Form.Field style={{marginBottom:'0em'}}>
            <label>Client Name</label>
            {formCreate ? <input type="text" disabled={true} name="client_name" value={formValues && formValues.client_name || ""} onChange={e => handleChange(e)}/> :
              <input type="text" required name="client_name" value={formValues && formValues.client_name || ""} onChange={e => handleChange(e)}/> }
          
            </Form.Field>
            <Form.Field style={{marginBottom:'0em'}}>
              <label >Email Id</label>
          <input type="email" required name="email_id" value={formValues && formValues.email_id || ""} onChange={e => handleChange(e)} /><br /><br />
          </Form.Field>
            
        </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          {formCreate ? <Button type='submit' onClick={handleSubmit}>Save</Button> :
            <Button type='submit' onClick={handleSubmit}>Update</Button>}
        </Modal.Footer>
      </Modal>

      <Modal
        show={show1}
        onHide={handleClose}
        backdrop="static"
        keyboard={false}
      >
        <Modal.Header closeButton>
          <Modal.Title>Delete Emails list</Modal.Title>
        </Modal.Header>
        <Modal.Body>
              <p>Are you sure you want to delete !!!</p>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Cancel
          </Button>
          
            <Button type='submit' onClick={DeleteEmails1}>Ok</Button>
        </Modal.Footer>
      </Modal>
      <Modal
        show={show3}
        onHide={handleClose}
        backdrop="static"
        keyboard={false}
      >
        <Modal.Header closeButton>
          <Modal.Title> Send Emails List</Modal.Title>
        </Modal.Header>
        <Modal.Body> 
              <Form>
              <Form.Field style={{marginBottom:'0em'}}>
                <label>From Date</label>
                <input type="date" required name="from_date" value={fromDate} onChange={e =>setFromDate(e.target.value)}/>
              </Form.Field>
              <Form.Field style={{marginBottom:'0em'}}>
                <label>To Date</label>
                <input type="date" required name="to_date" value={toDate}onChange={e => setToDate(e.target.value)}/>
              </Form.Field>
              </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Cancel
          </Button>
          <Button type='submit' onClick={sendemails}>Send</Button>
        </Modal.Footer>
      </Modal>
      <Modal
        show={show2}
        onHide={handleClose}
        backdrop="static"
        keyboard={false}
      >
        <Modal.Header closeButton>
          <Modal.Title>Add Email</Modal.Title>
        </Modal.Header>
        <Modal.Body>
              <p>Email is added successfully !!!</p>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Ok
          </Button>
        </Modal.Footer>
      </Modal>
      <LoaderComponent loaderOpen={loaderOpen} />
      </Grid.Row>
 
      </Grid>

      <Button variant="contained" color="primary" type="button" style={{marginTop:'2.2em'}} onClick={DeleteEmails} hidden={hideResultGrid}>Delete</Button>
     </div>


      {/* <form onSubmit={handleSubmit} style={{ justifyContent: 'center', marginLeft: '25em', marginTop: '2em' }}>

        <div className="form-inline">

         

          <label className="label">Tenant_id:</label>
          <input type="text" name="tenant_id" value={formValues && formValues.tenant_id || ""} onChange={e => handleChange(e)} /><br /> <br />

          <label className="label">mail Id:</label>
          <input type="text" name="mail_id" value={formValues && formValues.mail_id || ""} onChange={e => handleChange(e)} /><br /><br />

          <br /><br />
        </div>

        <div className="button-section">
          {formCreate ? <Button variant="contained" color="primary" type="submit" style={{ marginLeft: '6em' }}>Create</Button> :
            <Button variant="contained" color="primary" type="submit" style={{ marginLeft: '6em' }}>Save</Button>}
        </div>
      </form> */}

      {/* <div style={{ marginTop: '1em', marginLeft: '1em', marginBottom: '1em' }}>
        <Input
          type="text"
          value={tenantId}
          onChange={e => handleFilterChange(e.target.value)}
          placeholder="Filter by tenant id"
        />
      </div> */}

     
    </>
  );
}


export default EmailsList;


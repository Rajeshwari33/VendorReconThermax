// App.js
import { useEffect, useState } from "react";
// import "./App.css";
import "../etlsecound.css";
import hdfcs from '../../../../assets/images/banks/thermax.png';


function Annux1() 
{
  

  return (
  <div>
   <table className="table1">
    <tr className="bold">
        <td colSpan={7}>Purchase Invoices booked by Thermax not accounted by vendor</td>
        
    </tr>
    <tr className="fontcolor">
        <td>DATE</td>
        <td>PARTICULARS</td>
        <td>VCH TYPE</td>
        <td>VCH NO.</td>
        <td>Cr/Dr</td>
        <td>DEBIT</td>
        <td>CREDIT</td>
    </tr>
    <tr>
        <td>11-Jan-22</td>
        <td>Tax Deducted at Source (F.Y 2021-22)-NSDL</td>
        <td>Journal</td>
        <td>2139</td>
        <td></td>
        <td></td>
        <td>5499.00</td>
    </tr>
    <tr>
        <td>16-Feb-22</td>
        <td>Tax Deducted at Source (F.Y 2021-22)-NSDL</td>
        <td>Journal</td>
        <td>2506</td>
        <td></td>
        <td></td>
        <td>3235.00</td>
    </tr>
    <tr>
        <td>17-Apr-21</td>
        <td>Fabrication Machining</td>
        <td>Journal -diff in sale</td>
        <td>47</td>
        <td></td>
        <td></td>
        <td>-468.78</td>
    </tr>
    <tr>
        <td>21-May-21</td>
        <td>Fabrication Machining</td>
        <td>Journal -diff in sale</td>
        <td>225</td>
        <td></td>
        <td></td>
        <td>-118.19</td>
    </tr>
    <tr>
        <td>30-Jun-21</td>
        <td>Fabrication Machining</td>
        <td>Journal -diff in sale</td>
        <td>440</td>
        <td></td>
        <td></td>
        <td>-4.41</td>
    </tr>
   
    <tr>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td> -   </td>
        <td> 8,142.62</td>
    </tr>
</table>
  </div>
  )
}



export default Annux1;
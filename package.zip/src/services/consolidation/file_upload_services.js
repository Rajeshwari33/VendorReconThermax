import { headers, baseUrl } from "../common/credentials";

const port = "8000";
const port1 = "8002";

export const getTargetValuesFromServer = () => {
    let url = baseUrl + port1 + "/api/v2/user_modules/fetchtargetdata/";
    return ([headers, url]);
} 

export const FetchSourceNames = () => {
    let url = baseUrl + port + "/api/v2/user_modules/fetchsourcemasterdata/";
    return ([headers, url]);
}


export const createExcelFile = () => {
    let url = baseUrl + port1 + "/api/v2/user_modules/createexcelfile/";
    return ([headers, url]);
}

export const getFileUploadListFromServer = () => {
    let url = baseUrl + port1 + "/api/v2/user_modules/file_uploads_list/";
    return ([headers, url]);
}

export const FetchErrorMessages = () => {
    let url = baseUrl + port1 + "/api/v2/user_modules/error_messages/";
    return ([headers, url]);
}


import React from "react";

function ComplianceCertificateProcess()
{
    render()
    {
        return (
            <div>
                ComplianceCertificateProcess
            </div>
        );
    }
}

export default ComplianceCertificateProcess;
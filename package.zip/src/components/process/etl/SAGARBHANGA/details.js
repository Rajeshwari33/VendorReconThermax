// App.js
import { useEffect, useState } from "react";
// import "./App.css";
import "../etlsecound.css";
import hdfcs from '../../../../assets/images/banks/thermax.png';


function Details() 
{
  

  return (
  <div>
    <table className="table">
    <tr>
        <td className="bold"><img src={hdfcs} alt="" height="40px" width="60px" />THERMAX LIMITED</td>
       
    </tr>
   
    <tr>
        <td>VENDOR CODE</td>
        <td>150350</td>
        
    </tr>
    <tr className="fontcolor">
        <td>THERMAX VENDOR NAME</td>
        <td>HEIN LEHMANN INDIA PRIVATE LIMITED</td>
        
    </tr>
    <tr>
        <td>RECON DATE</td>
        <td>2023-01-04 10:15:07.937875</td>
        
    </tr>
    <tr>
        <td>RECON DONE TILL</td>
        <td>2022-11-30</td>
        
    </tr>
    <tr>
        <td>VEDNOR CLOSING BAL</td>
        <td> -   </td>
        
    </tr>
    <tr>
        <td>THERMAX CLOSING BAL</td>
        <td> 2,583,975.01</td>
    </tr>
</table>
  </div>
  )
}



export default Details;
// App.js
import { useEffect, useState } from "react";
// import "./App.css";
import "../etlsecound.css";
import hdfcs from '../../../../assets/images/banks/thermax.png';


function Observation() 
{
  

  return (
  <div>
   <table className="table">
    <tr className="fontcolor">
        <td>Sr. No</td>
        <td>Observation while recon</td>
    </tr>
    <tr>
        <td>1</td>
        <td>Have a opening balance of in Thermax SOA</td>
    </tr>
    <tr>
        <td>2</td>
        <td>Have a opening balance of in Supplier SOA</td>
    </tr>
    <tr>
        <td>3</td>
        <td>Input to be received from Suppliers as per The standard min items</td>
    </tr>
    <tr>
        <td>4</td>
        <td>Advance adj at the time of validation should be refelected in separate row</td>
    </tr>
    <tr>
        <td>5</td>
        <td>Need very clear statement of all statement, for eg Common ref,date, balance as per Thermax, Bal as per supplier and diff</td>
    </tr>
    <tr>
        <td>6</td>
        <td>Retention to be reflected as seprate recon items</td>
    </tr>
    <tr>
        <td>7</td>
        <td>In payment line retention adjsuted in same line which should be seprate</td>
    </tr>
</table>
  </div>
  )
}



export default Observation;
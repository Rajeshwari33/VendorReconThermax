import React, { useState } from "react";
import Chart from "react-apexcharts";

const ChartComponent = () => {
  const [labelnames, setLabelNames] = useState([
    "Apple",
    "Mango",
    "Orange",
    "Watermelon",
    "fruit"
  ]);
  const [seriesdata, setSeriesdata] = useState([44, 55, 41, 17]);

  const handleDataPointSelection = (event, chartContext, config) => {
    const selectedLabel = config.w.config.labels[config.dataPointIndex];
    const index = labelnames.indexOf(selectedLabel);

    if (index !== -1) {
      const updatedLabels = labelnames.filter((label, i) => i !== index);
      const updatedSeries = seriesdata.filter((data, i) => i !== index);

      setLabelNames(updatedLabels);
      setSeriesdata(updatedSeries);
    }
  };

  const chartOptions = {
    labels: labelnames,
    theme: {
      monochrome: {
        enabled: false
      }
    },
    responsive: [
      {
        breakpoint: 480,
        options: {
          legend: {
            show: true
          }
        }
      }
    ],
    chart: {
      events: {
        dataPointSelection: handleDataPointSelection
      }
    }
  };

  const chartSeries = seriesdata;

  return (
    <div className="pie">
      <Chart
        options={chartOptions}
        series={chartSeries}
        type="donut"
        width={380}
      />
    </div>
  );
};

export default ChartComponent;
import React, { useState, useEffect } from 'react';
// import React,{useEffect, useState} from 'react';
import axios from 'axios';
import "./etlsecound1.css";
import { SheetData } from '../../../services/auth-service/authService.js'
import { Icon, Input, Button, Dropdown, Grid, Popup, Segment, Select, Tab, Table, Menu, Form, TextArea, Label, Checkbox, GridColumn } from 'semantic-ui-react'

import loader from "../../../assets/images/1476.gif"

var table_data_val;
var sheet_drp_val;
var col_id;
var col_name_val;

// const DropdownExampleMultipleSelection = (props) => (
//   <Dropdown placeholder={props.filename} fluid multiple selection options={options} />
// )

const renderLabel = (label) => ({
  color: '#0A2352',
  content: `${label.text}`,
  icon: 'check',
})
const CheckboxExampleShorthandElement = (props) => (
  <Checkbox label={<label>{props.name}</label>} />
)
const panes = [
  {
    menuItem: { key: 'users', icon: 'file alternate outline', content: 'Sheet 1' },
    render: () => <Tab.Pane>Sheets</Tab.Pane>,
  },
  {
    menuItem: { key: 'users', icon: 'file alternate outline', content: 'Sheet 2' },
    render: () => <Tab.Pane>Sheets data</Tab.Pane>,
  },
  {
    menuItem: { key: 'users', icon: 'file alternate outline', content: 'Sheet 3' },
    render: () => <Tab.Pane>Sheets</Tab.Pane>,
  },
  {
    menuItem: { key: 'users', icon: 'file alternate outline', content: 'Sheet 4' },
    render: () => <Tab.Pane>Sheets data</Tab.Pane>,
  },
  {
    menuItem: { key: 'users', icon: 'file alternate outline', content: 'Sheet 5' },
    render: () => <Tab.Pane>Sheets</Tab.Pane>,
  },
  {
    menuItem: { key: 'users', icon: 'file alternate outline', content: 'Sheet 6' },
    render: () => <Tab.Pane>Sheets data</Tab.Pane>,
  },
  {
    menuItem: { key: 'users', icon: 'file alternate outline', content: 'Sheet 7' },
    render: () => <Tab.Pane>Sheets</Tab.Pane>,
  },
  // {
  //   menuItem: (
  //     <Menu.Item key='messages'>
  //       Sheet 2<Label>15</Label>
  //     </Menu.Item>
  //   ),
  //   render: () => <Tab.Pane>Tab 2 Content</Tab.Pane>,
  // },
]

// const TabExampleCustomMenuItem = () => <Tab panes={panes} />

// button
const ButtonExampleLabeledIcon = () => (
  <div>
    <Button icon labelPosition='left'>
      <Icon name='pause' color="red" />
      Add Sheets
    </Button>

  </div>
)
const ButtonExampleSocial = (props) => (
  <div>
    <Button color={props.color}  >
      <Icon name={props.buttonicon} />{props.buttonname}
    </Button>
  </div>
)

const IconExampleSize = (props) => (
  <div>

    <Icon name={props.icon} size='big' />
  </div>
)
const InputExampleIconPosition2 = () => (

  <Input placeholder='' type='file' icon='upload' />
)

function hello() {
  // alert('in');
  // const [tableData, setTableData] = useState([]);
  let payload = {
    File_data: 'hi',
  }
  var table_data;
  var FileUploadCredentials = SheetData();

  axios.post(FileUploadCredentials[1], payload, FileUploadCredentials[0])
    .then(
      response => {
        console.log("Validate Credentials Response!!!", response);
        table_data = response.data;
        console.log(table_data)
        table_data_val = table_data;
        sheet_drp_val = table_data;
        // Form_data();
        // table_file(table_data);
        // alert('data');

        // setTableData(response.data);
        // let responseData = response["data"];
        // if (responseData["Status"] === "Success")
        // {
        //     let userCredentials = responseData["user_credentials"]; 
        //     sessionStorage.setItem("userCredentials", JSON.stringify(userCredentials));
        //     // navigate(userCredentials["config"]["default_page"]);
        // }
      }
    )

}
function column_name() {
  // alert(col_id);
  // document.getElementById('dataoffcol').click();
  // document.getElementById('dataoncol').click()
  var i_num = Number(col_id)
  const data_val = table_data_val;
  console.log(data_val)
  const a = data_val[i_num].column;
  // a = a.replace(/'/g, '"');
  // a = JSON.parse(a);
  // console.log(a)
  // var carArray = new Array();  
  // for(var c in a) {
  //   var jsonObj = new Object();
  //   jsonObj.text = a[c];
  //   carArray.push(jsonObj);
  // }
  var col_data = new Array();
  function handleDropdownChange(data) {
    console.log(data);
    col_data.push(data);
    console.log(col_data)
    col_name_val = col_data
    // document.getElementById('dataoffcolname').click();
    // }
  }
  console.log(col_data)
  // const CheckboxExampleShorthandElement_col = (props) => (
  //   <Checkbox label={<label>{props.name}</label> } />
  // )
  return (
    <table id="customers">
      {/* <tr> */}
      {a.map((item) => (
        <tr key={item.text}>
          <th>
            <Checkbox
              Checkbox label={<label>{item.text}</label>}
              onChange={(event, data) => handleDropdownChange(item.text)}
              value={item.text}
              name={item.text} />
            <th>Property</th>
          </th>
        </tr>
      ))}
    </table>
  )
}
// function Table_file(){
//   // hello();
//   // alert('in')
//   // if(table_data){
//     // alert('inside')
//     const data = table_data_val
//     // document.getElementById('dataon').click();
//     // const data = [
//     //   { id: 1, name: 'Alice', age: 25 },
//     //   { id: 2, name: 'Bob', age: 30 },
//     //   { id: 3, name: 'Charlie', age: 35 },
//     // ];
//     // const options = column.map(data => ({
//     //   menuItem: {
//     //     content: data.column 
//     //   },
//     // }));
//     console.log(data)
//     let drp_data = [];
//     var a= data[0].column;
//     a = a.replace(/'/g, '"');
//     a = JSON.parse(a);
//     console.log(a)
//     var carArray = new Array();  
//     for(var c in a) {
//       var jsonObj = new Object();
//       jsonObj.text = a[c];
//       carArray.push(jsonObj);
//     }
//     // const DropdownExampleClearable = () => {
//       // const [selectedOption, setSelectedOption] = useState(null);
//       let selectedValue = '';
//       function handleDropdownChange(event) {
//         selectedValue = event.target.value;
//         console.log('Selected value:', selectedValue);
//       }

//       // return (

//       // );
//     // };
//     console.log(carArray)
//   const DropdownExampleMultipleSelection_data = (props) => (
//     // <Dropdown placeholder={props.filename} fluid multiple selection onClick={() => column_name('myFileInput')} options={carArray} value={carArray} />
//     <Dropdown
//     clearable
//     options={carArray}
//     selection
//     // placeholder={props.filename}
//     size='mini'
//     onChange={handleDropdownChange}
//     // value={selectedOption}
//   />
//   )
//     return(
//         <table id="customers">
//           {data.map(item => (
//             <tr key={item.source_id}>
//               <th><DropdownExampleMultipleSelection_data filename={item.source_name} /></th>
//               {/* <th><DropdownExampleMultipleSelection_data filename={item.source_name} /></th> */}
//             </tr>
//           ))}
//         </table>
//     )
//   // }

// }
function Table_file() {
  const data = table_data_val;
  const datas = table_data_val

  const DropdownExampleMultipleSelection_data = ({ filename }) => {
    const [selectedValue, setSelectedValue] = useState(null);

    function handleDropdownChange(event, data) {
      setSelectedValue(data.value);
      console.log(data.value)
      const indices = datas.map((item, index) => {
        if (item.source_name === filename) {
          return index;
        }
      }).filter(index => index !== undefined);
      console.log('mini'+indices[0]);
      col_id = indices[0];
      document.getElementById('dataoffcol').click();

      // column_name(indices[0]);
    }

    return (
      <Dropdown
        clearable
        options={getDropdownOptions(filename)}
        placeholder={filename}
        selection
        size='mini'
        onChange={handleDropdownChange}
        value={selectedValue}
      />
    );
  }

  function getDropdownOptions(filename) {
    const columns = getColumnNames(filename);
    return columns.map((sheets, index) => ({ key: sheets, text: sheets, value: index }));
  }

  function getColumnNames(filename) {
    const columnData = data.find((item) => item.source_name === filename)?.sheets;
    // const index = data.findIndex((item) => item.source_name === filename);
    // const columnData = index !== -1 ? data[index]?.sheets : null;
    console.log(columnData)

    if (columnData) {
      try {
        return JSON.parse(columnData.replace(/'/g, '"'));
      } catch (error) {
        console.error('Error parsing column data:', error);
      }
    }
    return [];
  }

  return (
    <table id="customers">
      {data?.map((item) => (
        <tr key={item.source_id}>
          <th>
            <DropdownExampleMultipleSelection_data filename={item.source_name} />
          </th>
        </tr>
      ))}
    </table>
  );
}

//     var carArray = new Array();  
//     for(var c in a) {
//       var jsonObj = new Object();
//       jsonObj.text = a[c];
//       carArray.push(jsonObj);
//     }
const optionsa = [
  { text: 'Sheet 1', value: 1 },
  { text: 'Sheet 2', value: 2 },
  { text: 'Sheet 3', value: 3 },
  { text: 'Sheet 4', value: 4 },
  { text: 'Sheet 5', value: 5 },
  { text: 'Sheet 6', value: 6 },
]
function Form_data() {
  // alert('in');
  const data = sheet_drp_val;
  // const [options, setOptions] = useState([]);
  // const [selectedValue, setSelectedValue] = useState(null);
  var a = data;
  // console.log(a)
  // a = a.replace(/'/g, '"');
  // a = JSON.parse(a);
  // console.log(a)
  var carArray = new Array();
  // for(var c in a) {
  //   var jsonObj = new Object();
  //   jsonObj.value = a[c];
  //   jsonObj.text = a[c];
  //   carArray.push(jsonObj);
  // }
  console.log(a.length)
  for (let i = 0; i <= a.length - 1; i++) {
    var jsonObj = new Object();
    jsonObj.value = a[i].source_id;
    jsonObj.text = a[i].source_name;
    carArray.push(jsonObj);
  }
  console.log(carArray)
  const col_data = carArray
  // const fetchData = async () => {
  //   try {
  //     const response = await fetch('https://example.com/api/options');
  //     const data = await response.json();
  // setOptions(carArray);
  //   } catch (error) {
  //     console.error(error);
  //   }
  // };

  // useEffect(() => {
  //   fetchData();
  // }, []);

  // const handleDropdownChange = (event, { value }) => {
  //   setSelectedValue(value);
  //   // console.log(value)
  // };

  return (
    <div>
      <Dropdown
        clearable
        options={col_data}
        placeholder='Select an option'
        fluid
        selection
      />
    </div>
  );
}
function datavalue() {
  const data_val = col_name_val
  // if(data_val){
  //   alert('in');
  // }else{
  //   alert('no');
  // }
  // console.log('data');
  // document.getElementById('dataoncol').click()
  // var i_num = Number(col_id)
  // const data_val = table_data_val;
  console.log(data_val)
  console.log(data_val)
  var carArray = new Array();
  for (var c in data_val) {
    var jsonObj = new Object();
    jsonObj.text = data_val[c];
    carArray.push(jsonObj);
  }
  // const CheckboxExampleShorthandElement_col = (props) => (
  //   <Checkbox label={<label>{props.name}</label> } />
  // )
  return (
    <table id="customers">
      {/* <tr> */}
      {carArray.map((item) => (
        <tr key={item.text}>
          <th>
            <Checkbox
              Checkbox label={<label>{item.text}</label>}
              // onChange={(event, data) => handleDropdownChange(item.text)}
              value={item.text}
              name={item.text} />
            {/* <th>Property</th> */}
          </th>
        </tr>
      ))}
    </table>
  )
  // setTimeout( function() { 
  // document.getElementById('dataoff').click();
  // <DropdownExampleMultipleSelection/> 
  // }, 5000);
}
function colSheet() {
  const data_val = col_name_val;
  console.log(data_val)
  console.log(data_val)
  var carArray = new Array();
  for (var c in data_val) {
    var jsonObj = new Object();
    jsonObj.text = data_val[c];
    carArray.push(jsonObj);
  }

  // const panes = [
  //   {
  //     menuItem: { key: 'users', icon: 'file alternate outline', content: 'Sheet 1' },
  //     render: () => <Tab.Pane></Tab.Pane>,
  //   },
  // ]
  const panes = carArray.map(data => ({
    menuItem: {
      key: 'users',
      icon: 'file alternate outline',
      content: data.text
    },
    // render: () => <Tab.Pane onClick={datamodify(data.text)}></Tab.Pane>
  }));
  return (
    <><Tab panes={panes} /><Table celled structured>
      <Table.Header>
        <Table.Row>
          <Table.HeaderCell rowSpan='2'>Name</Table.HeaderCell>
          <Table.HeaderCell rowSpan='2'>Type</Table.HeaderCell>
          <Table.HeaderCell rowSpan='2'>Files</Table.HeaderCell>
        </Table.Row>
      </Table.Header>

      <Table.Body>
        {carArray.map(item => (
          <Table.Row key={item.text}>
            <Table.Cell>{item.text}</Table.Cell>
            <Table.Cell>Project 1</Table.Cell>
            <Table.Cell textAlign='right'>2</Table.Cell>
          </Table.Row>
        ))}
      </Table.Body>
    </Table></>
  );

}

export default function MyComponent() {
  hello();
  const [showTable, setShowTable] = useState(false);
  const [showColumn, setShowColumn] = useState(false);
  const [showColumnName, setShowColumnName] = useState(false);
  const [isLoading, setLoading] = useState(false);


  const makeLoading = () => {
    setLoading(true);
    setTimeout(() => {
      setShowTable(true);
      setLoading(false);
    }, 3500)
  }

  useEffect(() => {
    makeLoading();
  }, [])
  // setShowTable(true);

  const handleClick = () => {
    setShowTable(true);
  };
  const handleClick_old = () => {
    setShowTable(false);
  };
  const handleClick_col = () => {
    setShowColumn(true);
  };
  const handleClick_old_col = () => {
    setShowColumn(false);
  };
  const handleClick_col_name = () => {
    setShowColumnName(true);
  };
  const handleClick_old_col_name = () => {
    setShowColumnName(false);
  };
  return (

    <div>
      {/* <h1>hi</h1> */}
      {isLoading ? (<div class="center"><h4 style={{ fontSize: '2rem' }}>Loading...</h4>
        <img style={{ width: '150px', height: "150px" }} src={loader} /></div>
      ) : (
        <div className="side">
          <Grid columns='equal' style={{ padding: "10px" }}>

            <Grid.Row style={{ backgroundColor: "#e9e8d9", borderRadius: "12px", marginTop: "10px" }}>
              <Grid.Column style={{ width: "400px", height: "227px", overflowY: "scroll" }}>
                {/* {hello()} */}
                {true && Table_file()}
                {/* <table id="customers">
                  {table_data.map(item => (
                      <tr key={item.source_id}>
                      <th><DropdownExampleMultipleSelection />{item.source_name}</th>
                     
                    </tr>
                  ))}
                    </table> */}
              </Grid.Column>
              <Grid.Column style={{ width: "300px", height: "227px", overflowY: "scroll" }} >
                {showColumn && column_name()}
              </Grid.Column>
              <Grid.Column style={{ textAlign: 'center' }}>
                <div style={{ paddingTop: "75px" }}>
                  <IconExampleSize icon="arrow circle right" style={{ textAlign: 'center' }} />
                  <br></br>
                  <IconExampleSize icon="arrow circle left" style={{ textAlign: 'center' }} />
                </div>

              </Grid.Column>
              <Grid.Column style={{ width: "250px" }}>

                {showColumnName && datavalue()}
                {/* <button id = 'datagen'>Generate</button> */}
              </Grid.Column>
              <Grid.Column >
                <div style={{ paddingTop: "75px" }}>
                  <IconExampleSize icon="arrow alternate circle up outline" style={{ textAlign: 'center' }} />
                  <br></br>
                  <IconExampleSize icon="arrow alternate circle down outline" style={{ textAlign: 'center' }} />
                </div>

              </Grid.Column>
            </Grid.Row>
            <Grid.Row style={{ backgroundColor: "#e9e8d9", borderRadius: "12px", marginTop: "0px" }}>
              <Grid.Column >
                <Button primary onClick={handleClick_old} id='dataoff' hidden>Show Table</Button>
                <Button primary onClick={handleClick} id='dataon'>Show Table</Button>
              </Grid.Column>
              <Grid.Column >
                <Button primary onClick={handleClick_old_col} id='dataoffcol' hidden>Show Table</Button>
                <Button primary onClick={handleClick_col} id='dataoncol'>Show Table</Button>
              </Grid.Column>
              <Grid.Column >
                <Button primary onClick={handleClick_old_col_name} id='dataoffcolname' hidden>Show Table</Button>
                <Button primary onClick={handleClick_col_name} id='dataoncolname'>Show Table</Button>
              </Grid.Column>
            </Grid.Row>
            <Grid.Row style={{ backgroundColor: "#e9e8d9", borderRadius: "12px", marginTop: "10px" }}>
              <Grid.Column>
                <div style={{ paddingLeft: "91%" }}><ButtonExampleSocial buttonname="Excel" buttonicon="file excel" color="light green" /></div>
                {showColumnName && colSheet()}
                {/* <TabExampleCustomMenuItem/> */}
                <div style={{ paddingTop: "7px" }}><ButtonExampleSocial buttonname="Singel Sheet" buttonicon="file excel outline" color="light green" size='mini' /></div>
              </Grid.Column>
            </Grid.Row>

          </Grid>


        </div>

      )
      }
    </div>

  );
}


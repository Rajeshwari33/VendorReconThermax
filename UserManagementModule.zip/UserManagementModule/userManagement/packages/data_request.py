import logging
from . import send_request as sr

logger = logging.getLogger("user_modules")

request = sr.SendRequest()

class GetResponse:
    _url = ''
    _header = ''
    _data = ''
    _response_data = ''

    def __init__(self, properties):
        self._url = properties["url"]
        self._header = properties["header"]
        self._data = properties["data"]
        self.get_response()

    def get_response(self):
        try:
            self._response_data = request.get_response(post_url = self._url, headers = self._header, data = self._data)
        except Exception:
            logger.error("Error in Get Response Function in Data Request File!!!", exc_info=True)

    def get_response_data(self):
        return self._response_data

class PostResponse:
    _url = ''
    _header = ''
    _data = ''
    _response_data = ''

    def __init__(self, properties):
        self._url = properties["url"]
        self._header = properties["header"]
        self._data = properties["data"]
        self.post_response()

    def post_response(self):
        try:
            self._response_data = request.post_response(post_url = self._url, headers = self._header, data = self._data)
        except Exception:
            logger.error("Error in Post Response Function in Data Request File!!!", exc_info=True)

    def get_post_response_data(self):
        return self._response_data

class PostFileResponse:

    _url = ''
    _header = ''
    _data = ''
    _file = ''
    _response_data = ''

    def __init__(self, properties):
        self._url = properties["url"]
        self._header = properties["header"]
        self._data = properties["data"]
        self._file = properties["file"]
        self.post_file_response()

    def post_file_response(self):
        try:
            self._response_data = request.post_file_response(post_url = self._url, headers = self._header, data = self._data, post_file = self._file)
        except Exception:
            logger.error("Error in Post File Response Function in Data Request File!!!", exc_info=True)

    def get_post_file_response(self):
        return self._response_data

class PutResponse:
    _url = ''
    _header = ''
    _data = ''
    _response_data = ''

    def __init__(self, properties):
        self._url = properties["url"]
        self._header = properties["header"]
        self._data = properties["data"]
        self.put_response()

    def put_response(self):
        try:
            self._response_data = request.put_response(post_url = self._url, headers = self._header, data = self._data)
        except Exception:
            logger.error("Error in Put Response Function in Data Request File!!!", exc_info=True)

    def get_put_response_data(self):
        return self._response_data

class PatchResponse:
    _url = ''
    _header = ''
    _data = ''
    _response_data = ''

    def __init__(self, properties):
        self._url = properties["url"]
        self._header = properties["header"]
        self._data = properties["data"]
        self.patch_response()

    def patch_response(self):
        try:
            self._response_data = request.patch_response(post_url = self._url, headers = self._header, data = self._data)
        except Exception:
            logger.error("Error in Patch Response Function in Data Request File!!!", exc_info=True)

    def get_patch_response(self):
        return self._response_data
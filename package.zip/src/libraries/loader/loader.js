import Backdrop from '@mui/material/Backdrop';
import CircularProgress from '@mui/material/CircularProgress';

function LoaderComponent({loaderOpen})
{
    return (
        <>
            <Backdrop
                    sx={{ color: "orange", zIndex: (theme) => theme.zIndex.drawer + 1 }}
                    open={loaderOpen}
                >
                    <CircularProgress color="inherit" />
            </Backdrop>
        </>
    );
}

export default LoaderComponent;
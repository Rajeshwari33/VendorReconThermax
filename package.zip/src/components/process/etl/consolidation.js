import React, { useState, useEffect } from 'react';

import axios from 'axios';
import "./etl.css";
import './consolidation.css';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import { Form } from 'semantic-ui-react';
import { Icon, Input, Dropdown, Grid, Popup, Segment, Select, Tab, Table, Menu, TextArea, Label } from 'semantic-ui-react';


const options1 = [
  { key: 1, text: 'Job1', value: 1 },
  { key: 2, text: 'Job2', value: 2 },
  { key: 3, text: 'Job3', value: 3 },
  { key: 4, text: 'Job4', value: 4 },
]

const FilesConsolidation = () => {
  const [taskData, setTaskData] = useState([]);
  const [selectedOptions, setSelectedOptions] = useState('Job');
  const [job, setJob] = useState([]);
  const [actionData, setActionData] = useState([]);
  const [conditionData, setConditionData] = useState([]);
  const [selectedJob, setSelectedJob] = useState('');
  const [name, setName] = useState('name');
  const [description, setDescription] = useState('description');
  const [category, setCategory] = useState('category');



  useEffect(() => {
    axios.get('http://localhost:8000/api/v2/user_modules/job_details/')
      .then(response => {
        let data = response.data;
        let obj1 = [];
        Object.keys(data).map((key, index) => (
          obj1.push({ key: data[key]['job_id'], text: data[key]['job_name'], value: data[key]['job_id'] })
        ))
        setJob(obj1);
        console.log(obj1);
      })
      .catch(error => {
        console.error(error);
      });
  }, []);

  const dropdownSelectedVal = (parse_value) => {
    console.log('parse_value' + parse_value)
    axios.get(`http://localhost:8000/api/v2/user_modules/fetch_job_details/${parse_value}`)
      .then(response => {
        console.log("jon1" + JSON.stringify(response.data));

        Object.keys(response.data).map((key, index) => {
          setName(response.data[key]['job_name'])
          setDescription(response.data[key]['job_description'])
          setCategory(response.data[key]['job_category'])
        })
      })
      .catch(error => {
        console.error(error);
      });
  }

  const InputExampleIconPosition5 = () => (
    <Input placeholder='Description' type='text' value={description} />
  )
  const InputExampleIconPosition6 = () => (
    <Input placeholder='Category' type='text' value={category} />
  )
  const InputExampleIconPosition3 = () => (
    <Input placeholder='Name' type='text' value={name} />
  )
  const handleOnChangeJobSelect = (e, data) => {
    let parse_value = parseInt(data.value);
    setSelectedOptions(data);
    dropdownSelectedVal(parse_value);

    axios.get(`http://localhost:8000/api/v2/user_modules/task/${parse_value}`)
      .then(response => {
        setTaskData(response.data);
        setActionData([]);
        setConditionData([]);
        console.log(response.data);
      })
      .catch(error => {
        console.error(error);
      });
  }
  const DropdownExampleClearable = () => (
    <Dropdown options={job} selection iconPosition='left' placeholder='Job' size='mini' onChange={handleOnChangeJobSelect}
      value={selectedOptions}
    />
  )
  const clickTaskRow = (id) => {

    console.log('task id' + id);
    axios.get(`http://localhost:8000/api/v2/user_modules/action/${id}`)
      .then(response => {
        setActionData(response.data);
        console.log(response.data);
      })
      .catch(error => {
        console.error(error);
      });
  }

  const clickActionRow = (id) => {
    axios.get(`http://localhost:8000/api/v2/user_modules/condition/${id}`)
      .then(response => {
        setConditionData(response.data);
        console.log(response.data);
      })
      .catch(error => {
        console.error(error);
      });
  }


  const TableExampleBasic = () => {
    const [show, setShow] = useState(false);
    const [formValues, setFormValues] = useState({ task_id: "", task_name: "", task_category: "", task_description: "", job: "" });
    const EditTask = ({ row }) => {
      setShow(true);
      setFormValues({ task_id: row.task_id, task_name: row.task_name, task_category: row.task_category, task_description: row.task_description, job: row.job });
    };
    let handleChange = (e) => {
      setFormValues({
        ...formValues,
        [e.target.name]: e.target.value
      })
    }
    const handleClose = () => {
      setFormValues({ task_id: "", task_name: "", task_category: "", task_description: "", job: "" });
      setShow(false);
    };


    let handleSubmit = (event) => {
      event.preventDefault();
      let url;
      url = `http://127.0.0.1:8000/api/v2/user_modules/updatetask/${formValues.task_id}/`;
      fetch(url, {
        method: 'POST',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(formValues)
      }).then((result) => {
        result.json().then((resp) => {
          console.log(resp);
          if (resp == 'updated successfully' || resp == 'created successfully') {
            setFormValues({ task_id: "", task_name: "", task_category: "", task_description: "", job: "" });
            setShow(false);
          }
        })
      })
    }

    return (
      <>
        <table className="table1">
          <thead>
            <tr>
              <th>Task id</th>
              <th>Task name</th>
              <th>category</th>
              <th>startcond/endcond</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {taskData.map(row => (
              <tr key={row.task_id}>
                <td onClick={() => clickTaskRow(row.job)}>{row.task_id}</td>
                <td>{row.task_name}</td>
                <td>{row.task_category}</td>
                <td></td>
                <td> <span onClick={e => EditTask({ row })}><i class='fa-solid fa-pen-to-square' ></i></span> </td>
              </tr>
            ))
            }
          </tbody>
        </table>

        <Modal
          show={show}
          onHide={handleClose}
          backdrop="static"
          keyboard={false}
        >
          <Modal.Header closeButton>
            <Modal.Title>Edit Task</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <Form>
              <Form.Field>
                <label>Task Id</label>
                <input type="text" name="task_id" value={formValues && formValues.task_id || ""} disabled={true} /><br /> <br />
              </Form.Field>
              <Form.Field>
                <label>Task Name</label>
                <input type="text" name="task_name" value={formValues && formValues.task_name || ""} onChange={e => handleChange(e)} /><br /> <br />
              </Form.Field>
              <Form.Field>
                <label>Task desc</label>
                <input type="text" name="task_description" value={formValues && formValues.task_description || ""} onChange={e => handleChange(e)} /><br /><br />
              </Form.Field>
              <Form.Field>
                <label>Task category</label>
                <input type="text" name="task_category" value={formValues && formValues.task_category || ""} onChange={e => handleChange(e)} /><br /><br />
              </Form.Field>
              <Form.Field>
                <label>Job</label>
                <input type="text" name="job" value={formValues && formValues.job || ""} onChange={e => handleChange(e)} /><br /><br />
              </Form.Field>

            </Form>
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={handleClose}>
              Close
            </Button>
            <Button type='submit' onClick={handleSubmit}>Save</Button>
          </Modal.Footer>
        </Modal>
      </>
    );
  }


  const TableExampleBasics = () => {
    const [show, setShow] = useState(false);
    const [formValues, setFormValues] = useState({ action_id: "", action_name: "", action_category: "", action_description: "", action_details: "", restapi_address: "", task: "" });
    const EditActions = ({ row }) => {
      setShow(true);
      setFormValues({ action_id: row.action_id, action_name: row.action_name, action_category: row.action_category, action_description: row.action_description, action_details: row.action_details, restapi_address: row.restapi_address, task: row.task });
    };
    let handleChange = (e) => {
      setFormValues({
        ...formValues,
        [e.target.name]: e.target.value
      })
    }
    const handleClose = () => {
      setFormValues({ action_id: "", action_name: "", action_category: "", action_description: "", action_details: "", restapi_address: "", task: "" });
      setShow(false);
    };


    let handleSubmit = (event) => {
      event.preventDefault();
      let url;
      url = `http://127.0.0.1:8000/api/v2/user_modules/update_action/${formValues.action_id}/`;
      fetch(url, {
        method: 'POST',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(formValues)
      }).then((result) => {
        result.json().then((resp) => {
          console.log(resp);
          if (resp == 'updated successfully' || resp == 'created successfully') {
            setFormValues({ action_id: "", action_name: "", action_category: "", action_description: "", action_details: "", restapi_address: "", task: "" });
            setShow(false);
          }
        })
      })
    }
    return (
      <>
        <table className="table1">
          <thead>
            <tr>
              <th>action id</th>
              <th>action name</th>
              <th>category</th>
              <th>startcond/endcond</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {actionData.map(row => (
              <tr key={row.action_id}>
                <td onClick={() => clickActionRow(row.task)}>{row.action_id}</td>
                <td>{row.action_name}</td>
                <td>{row.action_category}</td>
                <td></td>
                <td> <span onClick={e => EditActions({ row })}><i class='fa-solid fa-pen-to-square' ></i></span> </td>
              </tr>
            ))
            }

          </tbody>
        </table>

        <Modal
          show={show}
          onHide={handleClose}
          backdrop="static"
          keyboard={false}
        >
          <Modal.Header closeButton>
            <Modal.Title>Edit Actions</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <Form>
              <Form.Field>
                <label>Action Id</label>
                <input type="text" name="action_id" value={formValues && formValues.action_id || ""} disabled={true} /><br /> <br />
              </Form.Field>
              <Form.Field>
                <label>Action Name</label>
                <input type="text" name="action_name" value={formValues && formValues.action_name || ""} onChange={e => handleChange(e)} /><br /> <br />
              </Form.Field>
              <Form.Field>
                <label>action desc</label>
                <input type="text" name="action_description" value={formValues && formValues.action_description || ""} onChange={e => handleChange(e)} /><br /><br />
              </Form.Field>
              <Form.Field>
                <label>action details</label>
                <input type="text" name="action_details" value={formValues && formValues.action_details || ""} onChange={e => handleChange(e)} /><br /><br />
              </Form.Field>
              <Form.Field>
                <label>restapi address</label>
                <input type="text" name="restapi_address" value={formValues && formValues.restapi_address || ""} onChange={e => handleChange(e)} /><br /><br />
              </Form.Field>
              <Form.Field>
                <label>Action Category</label>
                <input type="text" name="action_category" value={formValues && formValues.action_category || ""} onChange={e => handleChange(e)} /><br /><br />
              </Form.Field>
              <Form.Field>
                <label>task</label>
                <input type="text" name="task" value={formValues && formValues.task || ""} onChange={e => handleChange(e)} /><br /><br />
              </Form.Field>

            </Form>
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={handleClose}>
              Close
            </Button>
            <Button type='submit' onClick={handleSubmit}>Save</Button>
          </Modal.Footer>
        </Modal>
      </>
    );
  }

  const TableExampleConditions = () => {
    const [show, setShow] = useState(false);
    const [formValues, setFormValues] = useState({ condition_id: "", condition_name: "", condition_category: "", condition_description: "", api_link: "", action: "" });
    const EditCondition = ({ row }) => {
      setShow(true);
      setFormValues({ condition_id: row.condition_id, condition_name: row.condition_name, condition_category: row.condition_category, condition_description: row.condition_description, api_link: row.api_link, action: row.action });
    };
    let handleChange = (e) => {
      setFormValues({
        ...formValues,
        [e.target.name]: e.target.value
      })
    }
    const handleClose = () => {
      setFormValues({ condition_id: "", condition_name: "", condition_category: "", condition_description: "", api_link: "", action: "" });
      setShow(false);
    };


    let handleSubmit = (event) => {
      event.preventDefault();
      let url;
      url = `http://127.0.0.1:8000/api/v2/user_modules/updatecondition/${formValues.condition_id}/`;
      fetch(url, {
        method: 'POST',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(formValues)
      }).then((result) => {
        result.json().then((resp) => {
          console.log(resp);
          if (resp == 'updated successfully' || resp == 'created successfully') {
            setFormValues({ condition_id: "", condition_name: "", condition_category: "", condition_description: "", api_link: "", action: "" });
            setShow(false);
          }
        })
      })
    }

    return (
      <>
        <table className="table1">
          <thead>
            <tr>
              <th>Condition id</th>
              <th>Condition name</th>
              <th>Condition category</th>
              <th>Condition description</th>
              <th>Api link</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {conditionData.map(row => (
              <tr key={row.condition_id}>
                <td>{row.condition_id}</td>
                <td>{row.condition_name}</td>
                <td>{row.condition_category}</td>
                <td>{row.condition_description}</td>
                <td>{row.api_link}</td>
                <td> <span onClick={e => EditCondition({ row })}><i class='fa-solid fa-pen-to-square' ></i></span> </td>
              </tr>
            ))
            }
          </tbody>
        </table>


        <Modal
          show={show}
          onHide={handleClose}
          backdrop="static"
          keyboard={false}
        >
          <Modal.Header closeButton>
            <Modal.Title>Edit Condition</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <Form>
              <Form.Field>
                <label>Condition id</label>
                <input type="text" name="condition_id" value={formValues && formValues.condition_id || ""} disabled={true} /><br /> <br />
              </Form.Field>
              <Form.Field>
                <label>Condition Name</label>
                <input type="text" name="condition_name" value={formValues && formValues.condition_name || ""} onChange={e => handleChange(e)} /><br /> <br />
              </Form.Field>
              <Form.Field>
                <label>Condition Category</label>
                <input type="text" name="condition_category" value={formValues && formValues.condition_category || ""} onChange={e => handleChange(e)} /><br /><br />
              </Form.Field>
              <Form.Field>
                <label>Condition Description</label>
                <input type="text" name="condition_description" value={formValues && formValues.condition_description || ""} onChange={e => handleChange(e)} /><br /><br />
              </Form.Field>
              <Form.Field>
                <label>api_link</label>
                <input type="text" name="api_link" value={formValues && formValues.api_link || ""} onChange={e => handleChange(e)} /><br /><br />
              </Form.Field>
              <Form.Field>
                <label>Action</label>
                <input type="text" name="action" value={formValues && formValues.action || ""} onChange={e => handleChange(e)} /><br /><br />
              </Form.Field>

            </Form>
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={handleClose}>
              Close
            </Button>
            <Button type='submit' onClick={handleSubmit}>Save</Button>
          </Modal.Footer>
        </Modal>
      </>
    );
  }


  return (
    <div>
      <div className="side" style={{ padding: "10px" }}>
        <Grid columns='equal'>
          <Grid.Row style={{ backgroundColor: "#e9e8d9" }} className="radius">
            <Grid.Column width={3}>
              <DropdownExampleClearable />
            </Grid.Column>

            <Grid.Column width={3}>
              <InputExampleIconPosition3 />
            </Grid.Column>

            <Grid.Column width={3}>
              <InputExampleIconPosition5 />
            </Grid.Column>

            <Grid.Column width={5}>
              <InputExampleIconPosition6 />
            </Grid.Column>
          </Grid.Row>
          <Grid.Row style={{ backgroundColor: "#e9e8d9", borderRadius: "12px", marginTop: "10px" }}>
            <Grid.Column className="overflow table_consolidation">
              <TableExampleBasic width={6} />
            </Grid.Column>
            <Grid.Column className="overflow table_consolidation">
              <TableExampleBasics width={6} />
            </Grid.Column>
          </Grid.Row>

          <Grid.Row style={{ backgroundColor: "#e9e8d9", borderRadius: "12px", marginTop: "10px" }}>
            <Grid.Column>
              <TableExampleConditions />
            </Grid.Column>
          </Grid.Row>
        </Grid>
      </div>
    </div>
  );
};

export default FilesConsolidation;

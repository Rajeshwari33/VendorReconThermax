import React, { useCallback, useMemo, useRef, useState, useEffect } from "react";
import "./reconSummary.css";
import LoaderComponent from "../../../../libraries/loader/loader";
import { getProcessingLayerListFromServer, getBalanceFromServer, getProcessingLayerDataFromServer, getProcessingLayerDataWithStatusFromServer, getUpdateMatchRecordsFromServer, getUpdateUnMatchRecordsFromServer, getUpdateDuplicateRecordsFromServer, getUpdateContraRecordsFromServer, getProcessingLayerDataReturnFromServer, getUpdateGlBalFromServer, getUpdateBankBalFromServer } from '../../../../services/process/VRS/vrsService';
import axios from "axios";
import ReactApexChart from "react-apexcharts";
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-alpine.css';
import Modal from 'react-modal';
import Select from "react-select";

function reconSummary() {
  const [loaderOpen, setLoaderOpen] = useState(false);
  const [userCredentials] = useState(JSON.parse(sessionStorage.getItem("userCredentials")));
  const [options, setOptions] = useState([]);
  const [selectedOption, setSelectedOption] = useState('');
  const [layerId, setLayerId] = useState('');
  const [glBalance, setGlBalance] = useState(0.00);
  const [vendorBalance, setVendorBalance] = useState(0.00);
  const [chartHidden, setChartHidden] = useState(true);
  const [doughnutLabel, setDoughnutLabel] = useState([]);
  const [doughnutdata, setDoughnutData] = useState([]);
  const [label, setLabel] = useState('');
  const [unMatchedHidden, setUnMatchedHidden] = useState(true);
  const [searchHidden, setSearchHidden] = useState(true);
  const [intGridData, setIntGridData] = useState([]);
  const [extGridData, setExtGridData] = useState([]);
  const [intDebit, setIntDebit] = useState(0.00);
  const [intCredit, setIntCredit] = useState(0.00);
  const [extDebit, setExtDebit] = useState(0.00);
  const [extCredit, setExtCredit] = useState(0.00);
  const [intDate, setIntDate] = useState(undefined);
  const [extDate, setExtDate] = useState(undefined);
  const [amountTolerance, setAmountTolerance] = useState(0.00);
  const [openGridHidden, setOpenGridHidden] = useState(true);
  const [openIntGridData, setOpenIntGridData] = useState([]);
  const [openExtGridData, setOpenExtGridData] = useState([]);
  const [selectedId, setSelectedId] = useState(null);
  const agIntGridRef = useRef(null);
  const agExtGridRef = useRef(null);
  const intMatchingRows = [];
  const extMatchingRows = [];
  const [internalAmount, setInternalAmount] = useState(0.00);
  const [externalAmount, setExternalAmount] = useState(0.00);
  const [matchHidden, setMatchHidden] = useState(true);
  const [contraHidden, setContraHidden] = useState(true);
  const [duplicateHidden, setDuplicateHidden] = useState(true);
  const [unMatchHidden, setUnMatchHidden] = useState(true);
  const [intId, setIntId] = useState('');
  const [intName, setIntName] = useState("");
  const [extName, setExtName] = useState("");
  const [modalIsOpen, setModalIsOpen] = useState(false);
  const [selectedMonth, setSelectedMonth] = useState('');
  const [unMatchStyles, setUnMatchStyles] = useState(undefined);
  const [selectCheckBox, setSelectCheckBox] = useState(undefined);
  const [searchText, setSearchText] = useState('');
  const [hideLabels, setHideLabels] = useState(false);
  const chartRef = useRef(null);

  const [selectedOptions, setSelectedOptions] = useState();

  const handleOpenModal = () => {
    setModalIsOpen(true);
  };

  const handleCloseModal = () => {
    setModalIsOpen(false);
  };

  useEffect(() => {
    BrsTypeList();
  }, []);

  console.log("intName", intName);
  function handleSelection(event) {
    const selectedValue = event.label;
    const selectedOption = options.find(option => option.processing_layer_name === selectedValue); // Find the option with the selected value
    const layerId = selectedOption ? selectedOption.processing_layer_id : null;
    console.log("layerId", layerId);
    setSelectedOption(event);
    setLayerId(layerId);
    getBalances(layerId);
    processingLayerData(selectedValue, layerId);
    setUnMatchedHidden(true);
    setOpenGridHidden(true);
    setChartHidden(true);
    setExternalAmount(0.00);
    setInternalAmount(0.00);
    setMatchHidden(true);
    setDuplicateHidden(true);
    setUnMatchHidden(true);
    setSearchHidden(true);
    setContraHidden(true);
    setLabel('');

  }

  function BrsTypeList() {
    setLoaderOpen(true);
    let payload = {
      "tenantId": userCredentials["tenants_id"],
      "groupId": userCredentials["groups_id"],
      "entityId": userCredentials["entities_id"],
      "mProcessingLayerId": userCredentials["m_processing_layer_id"],
      "mProcessingSubLayerId": userCredentials["m_processing_sub_layer_id"],
      "typeId": userCredentials["processing_layer_id"]
    }

    var getProcessingLayerList = getProcessingLayerListFromServer();
    console.log("brs", getProcessingLayerList[0])

    axios.post(getProcessingLayerList[1], { params: payload }, getProcessingLayerList[0])
      .then(
        response => {
          console.log("Processing Layer List!!!", response)
          let data = response["data"];
          if (data["Status"] === "Success") {
            let options = data["processing_layer_list"]
            setOptions(options);

            let names = []
            options.map((data) => {

              let obj = {
                value: data.processing_layer_id,
                label: data.processing_layer_name
              }
              names.push(obj);
            })
            setSelectedOptions(names);
            setLoaderOpen(false);
          }
        }
      ).catch(
        error => {
          console.log("Error in Processing Layer List!!!", error);
          setLoaderOpen(false);
        }
      );

  }

  function processingLayerData(selectedValue, layerId) {
    setIntDebit('');
    setIntCredit('');
    setExtDebit('');
    setExtCredit('');
    setAmountTolerance('');
    setIntName('');
    setExtName('');
    setIntDate('');
    setExtDate('');
    setLoaderOpen(true);
    let payload = {
      "processing_layer": selectedValue,
      "tenants_id": userCredentials["tenants_id"],
      "groups_id": userCredentials["groups_id"],
      "entities_id": userCredentials["entities_id"],
      "processing_layer_id": layerId
    }

    var getProcessingLayerData = getProcessingLayerDataFromServer();
    console.log("url", getProcessingLayerData[0])

    return axios.post(getProcessingLayerData[1], { params: payload }, getProcessingLayerData[0])
      .then(
        response => {
          console.log("Processing Layer Data!!!", response)
          let data = response["data"];
          if (data["Status"] === "Success") {
            console.log("data", data);
            setDoughnutLabel(data["Label"]);
            setDoughnutData(data["Values"]);
            setIntDebit(data["int_dr"]);
            setIntCredit(data["int_cr"]);
            setExtDebit(data["ext_dr"]);
            setExtCredit(data["ext_cr"]);
            setAmountTolerance(data["amount_tolerance"]);
            setIntName(data["m_source_name_int"]);
            setExtName(data["m_source_name_ext"]);
            setChartHidden(false);
            setUnMatchHidden(true);
            setContraHidden(true);
            setIntDate(data["int_date"]);
            setExtDate(data["ext_date"]);
          }
          setLoaderOpen(false);
          return response;
        }
      ).catch(
        error => {
          console.log("Error in Processing Layer Data!!!", error);
          setLoaderOpen(false);
        }
      );

  }

  function getBalances(layerId) {
    setLoaderOpen(true);
    let payload = {
      "tenantsId": userCredentials["tenants_id"],
      "groupsId": userCredentials["groups_id"],
      "entityId": userCredentials["entities_id"],
      "mProcessingLayerId": userCredentials["m_processing_layer_id"],
      "mProcessingSubLayerId": userCredentials["m_processing_sub_layer_id"],
      "processingLayerId": layerId
    }

    var getBalance = getBalanceFromServer();

    axios.post(getBalance[1], { params: payload }, getBalance[0])
      .then(
        response => {
          console.log("Get Balance Response!!!", response)
          let data = response["data"];
          if (data["Status"] === "Success") {
            console.log("bal", data["data"]["vendor_balance"])
            setVendorBalance(data["data"]["vendor_balance"]);
            setGlBalance(data["data"]["gl_balance"]);
            // setLoaderOpen(false);
          }
        }
      ).catch(
        error => {
          console.log("Error in Get Balance!!!", error);
          // setLoaderOpen(false);
        }
      );

  }

  function processingLayerDataReturn() {
    let payload = {
      "int_name": intName,
      "ext_name": extName,
      "processing_layer_id": layerId
    }

    var getProcessingLayerData = getProcessingLayerDataReturnFromServer();
    console.log("url", getProcessingLayerData[0])

    return axios.post(getProcessingLayerData[1], { params: payload }, getProcessingLayerData[0])
      .then(
        response => {
          console.log("Processing Layer Data!!!", response)
          let data = response["data"];
          if (data["Status"] === "Success") {
            console.log("data", data);
            setDoughnutLabel(data["Label"]);
            setDoughnutData(data["Values"]);
            setChartHidden(false);
            setUnMatchHidden(true);
            setContraHidden(true);
          }
          return response;
        }
      ).catch(
        error => {
          console.log("Error in Processing Layer Data!!!", error);
        }
      );

  }

  const handleDataPointSelection = (event, chartContext, config) => {
    const selectedLabel = config.w.config.labels[config.dataPointIndex];
    console.log("selectedLabel", selectedLabel);
    console.log("intNameClicked", intName);
    setLabel(selectedLabel);
    // getChartClickedData(selectedLabel);
    setOpenIntGridData([]);
    setOpenExtGridData([]);
    setExternalAmount(0.00);
    setInternalAmount(0.00);
    setMatchHidden(true);
    setDuplicateHidden(true);
    setUnMatchHidden(true);
    setContraHidden(true);
  };

  // const handleLegendClick = () => {
  //   setChartData((prevChartData) => ({
  //     ...prevChartData,
  //     options: {
  //       ...prevChartData.options,
  //       dataLabels: {
  //         enabled: !prevChartData.options.dataLabels.enabled,
  //       },
  //     },
  //   }));
  // };

  // const [chartData, setChartData] = useState({
  //   series: doughnutdata,
  //   options: {
  //     labels: doughnutLabel,
  //     colors: ["#66cc66", "#ff4d4d", "#1a75ff", "#b84dff", "#ff944d", "#00cccc"],
  //     legend: {
  //       onItemClick: {
  //         toggleDataSeries: false,
  //         onClick: handleLegendClick,
  //       },
  //     },
  //     chart: {
  //       width: 380,
  //       type: "donut",
  //     },
  //     plotOptions: {
  //       pie: {
  //         startAngle: -90,
  //         endAngle: 270,
  //       },
  //     },
  //     dataLabels: {
  //       enabled: true, // Show labels by default
  //     },
  //     fill: {
  //       type: "gradient",
  //     },
  //     title: {
  //       text: "",
  //     },
  //     responsive: [
  //       {
  //         breakpoint: 480,
  //         options: {
  //           chart: {
  //             width: 200,
  //           },
  //           legend: {
  //             position: "bottom",
  //           },
  //         },
  //       },
  //     ],
  //   },
  // });



  const chartData = {
    series: doughnutdata,
    options: {
      labels: doughnutLabel,
      colors: ['#66cc66', '#ff4d4d', '#1a75ff', '#b84dff', '#ff944d', '#00cccc'],
      legend: {
        onItemClick: {
          toggleDataSeries: false,
        }
      },
      chart: {
        width: 380,
        type: 'donut'
      },
      plotOptions: {
        pie: {
          startAngle: -90,
          endAngle: 270
        },
      },
      dataLabels: {
        enabled: false
      },
      fill: {
        type: 'gradient',
      },
      // legend: doughnutLabel,
      title: {
        text: ''
      },

      responsive: [{
        breakpoint: 480,
        options: {
          chart: {
            width: 200
          },
          legend: {
            position: 'bottom'
          }
        }
      }],
      chart: {
        events: {
          dataPointSelection: handleDataPointSelection
        }
      }
    },
  };

  useEffect(() => {
    setUnMatchedHidden(true);
    setOpenGridHidden(true);
    setMatchHidden(true);
    setDuplicateHidden(true);
    setUnMatchHidden(true);
    setSearchHidden(true);
    setSelectedId(null);
    setContraHidden(true);
    if (label) {
      setLoaderOpen(true); // Show loader while the API call is in progress
      getChartClickedData(label);
    }
  }, [intName, extName, label]);
  // useEffect(() => {
  //   setUnMatchedHidden(true);
  //   setOpenGridHidden(true);
  //   setMatchHidden(true);
  //   setDuplicateHidden(true);
  //   setUnMatchHidden(true);
  //   setSelectedId(null);
  //   setContraHidden(true);
  //   getChartClickedData(label);

  // }, [intName, extName, label]);

  const getChartClickedData = async (selectedLabel) => {
    try {
      console.log("intNameinside", intName);
      setLoaderOpen(true); // Use the passed setLoaderOpen function
      let payload = {
        "status": selectedLabel,
        "int_name": intName,
        "ext_name": extName,
        "processing_layer_id": layerId
      }

      var getProcessingLayerDataWithStatus = getProcessingLayerDataWithStatusFromServer();

      const response = await axios.post(getProcessingLayerDataWithStatus[1], { params: payload }, getProcessingLayerDataWithStatus[0]);
      console.log("Processing Layer Data With Status!!!", response);
      let data = response["data"];
      if (data["Status"] === "Success") {
        console.log("data", data);
        setIntGridData(data["internal_data"]);
        setExtGridData(data["external_data"]);
        setUnMatchedHidden(false);
        setSearchHidden(false);
        setOpenGridHidden(true);
        setMatchHidden(true);
        setDuplicateHidden(true);
        setUnMatchHidden(true);
        setSelectedId(null);
        setContraHidden(true);
      }
      setLoaderOpen(false); // Use the passed setLoaderOpen function to update the state

      return response;
    } catch (error) {
      console.log("Error in Processing Layer Data With Status!!!", error);
      setLoaderOpen(false); // Use the passed setLoaderOpen function to update the state
    }
  };


  // const getChartClickedData = async (selectedLabel) => {
  //   try {
  //     console.log("intNameinside", intName);
  //     setLoaderOpen(true); // Use the passed setLoaderOpen function
  //     let payload = {
  //       "status": selectedLabel,
  //       "int_name": intName,
  //       "ext_name": extName,
  //     }

  //     var getProcessingLayerDataWithStatus = getProcessingLayerDataWithStatusFromServer();

  //     const response = await axios.post(getProcessingLayerDataWithStatus[1], { params: payload }, getProcessingLayerDataWithStatus[0]);
  //     console.log("Processing Layer Data With Status!!!", response);
  //     let data = response["data"];
  //     if (data["Status"] === "Success") {
  //       console.log("data", data);
  //       setIntGridData(data["internal_data"]);
  //       setExtGridData(data["external_data"]);
  //       setUnMatchedHidden(false);
  //       setOpenGridHidden(true);
  //       setMatchHidden(true);
  //       setDuplicateHidden(true);
  //       setUnMatchHidden(true);
  //       setSelectedId(null);
  //       setContraHidden(true);
  //     }
  //     setLoaderOpen(false); // Use the passed setLoaderOpen function to update the state

  //     return response;
  //   } catch (error) {
  //     console.log("Error in Processing Layer Data With Status!!!", error);
  //     setLoaderOpen(false); // Use the passed setLoaderOpen function to update the state
  //   }
  // };


  // function getChartClickedData(selectedLabel)
  // {
  //     console.log("intNameChart", intName);
  //     setLoaderOpen(true);
  //     let payload = {
  //       "status": selectedLabel,
  //       "int_name" : intName,
  //       "ext_name" : extName,
  //     }

  //     var getProcessingLayerDataWithStatus = getProcessingLayerDataWithStatusFromServer();

  //     return axios.post(getProcessingLayerDataWithStatus[1], {params : payload}, getProcessingLayerDataWithStatus[0])
  //     .then(
  //         response => {
  //             console.log("Processing Layer Data With Status!!!", response)
  //             let data = response["data"];
  //             if (data["Status"] === "Success") {
  //               console.log("data", data);
  //               setIntGridData(data["internal_data"]);
  //               setExtGridData(data["external_data"]);
  //               setUnMatchedHidden(false);
  //               setOpenGridHidden(true);
  //               setMatchHidden(true);
  //               setDuplicateHidden(true);
  //               setUnMatchHidden(true);
  //               setSelectedId(null);
  //               setContraHidden(true);
  //             }
  //             setLoaderOpen(false);
  //             return response;
  //         }
  //     ).catch(
  //         error => {
  //             console.log("Error in Processing Layer Data WIth Status!!!", error);
  //             setLoaderOpen(false);
  //         }
  //     );

  // }

  function getChartClickedDataReturn(selectedLabel) {
    let payload = {
      "status": selectedLabel,
      "int_name": intName,
      "ext_name": extName,
      "processing_layer_id": layerId
    }

    var getProcessingLayerDataWithStatus = getProcessingLayerDataWithStatusFromServer();

    return axios.post(getProcessingLayerDataWithStatus[1], { params: payload }, getProcessingLayerDataWithStatus[0])
      .then(
        response => {
          console.log("Processing Layer Data With Status!!!", response)
          let data = response["data"];
          if (data["Status"] === "Success") {
            console.log("data", data);
            setIntGridData(data["internal_data"]);
            setExtGridData(data["external_data"]);
            setUnMatchedHidden(false);
            setSearchHidden(false);
            setOpenGridHidden(true);
            setMatchHidden(true);
            setDuplicateHidden(true);
            setUnMatchHidden(true);
            setSelectedId(null);
            setContraHidden(true);
          }
          return response;
        }
      ).catch(
        error => {
          console.log("Error in Processing Layer Data WIth Status!!!", error);
        }
      );

  }

  // const intColumnDefs = React.useMemo(() => {
  //   if (intGridData.length > 0) {
  //     // Get the column names from the first row of the JSON data
  //     const keys = Object.keys(intGridData[0]);

  //     // Create column definitions with the checkbox as the first column
  //     const intColumnDefs = [
  //       {
  //         headerName: '',
  //         checkboxSelection: true,
  //         width: 50,
  //       },
  //       ...keys
  //       .filter((key) => key !== 'id') // Filter out the "id" column
  //       .map((key) => {
  //         // Calculate the maximum content width for the current column
  //         const maxWidth = intGridData.reduce(
  //           (max, data) => {
  //             const cellContent = data[key] ? data[key].toString() : '';
  //             return Math.max(max, cellContent.length * 5); // Adjust the constant factor (10) as needed
  //           },
  //           100 // Set a minimum width of 100 to avoid very narrow columns
  //         );

  //         return {
  //           headerName: key,
  //           field: key.replace(/\./g, '[""]'),
  //           sortable: true, 
  //           filter: true, 
  //           resizable: true,
  //           width: maxWidth,
  //         };
  //       }),
  //   ];

  //     return intColumnDefs;
  //   }
  //   return [];
  // }, [intGridData]);

  const intColumnDefs = React.useMemo(() => {
    if (intGridData.length > 0) {
      const keys = Object.keys(intGridData[0]);

      const dynamicColumnDefs = [
        {
          headerCheckboxSelection: true,
          checkboxSelection: true,
          width: 50,
          headerCheckboxSelectionFilteredOnly: true,
          headerCheckboxSelectionMultiple: false,
        },
        ...keys
          .filter((key) => key !== 'id')
          .map((key) => {
            // Column definition setup
            const maxWidth = intGridData.reduce(
              (max, data) => {
                const cellContent = data[key] ? data[key].toString() : '';
                return Math.max(max, cellContent.length * 5); // Adjust the constant factor (10) as needed
              },
              100 // Set a minimum width of 100 to avoid very narrow columns
            );
            return {
              headerName: key,
              field: key.replace(/\./g, '[""]'),
              sortable: true,
              filter: true,
              resizable: true,
              width: maxWidth,
              editable: true,
              cellEditor: 'agTextCellEditor',
            };
          }),
      ];

      return dynamicColumnDefs;
    }
    return [];
  }, [intGridData]);

  let gridApi;
  let gridApiInt;

  const extColumnDefs = React.useMemo(() => {
    if (extGridData.length > 0) {
      const keys = Object.keys(extGridData[0]);

      const dynamicColumnDefs = [
        {
          headerCheckboxSelection: true,
          checkboxSelection: true,
          width: 50,
          headerCheckboxSelectionFilteredOnly: true,
          headerCheckboxSelectionMultiple: false,
        },
        ...keys
          .filter((key) => key !== 'id')
          .map((key) => {
            // Column definition setup
            const maxWidth = extGridData.reduce(
              (max, data) => {
                const cellContent = data[key] ? data[key].toString() : '';
                return Math.max(max, cellContent.length * 5); // Adjust the constant factor (10) as needed
              },
              100 // Set a minimum width of 100 to avoid very narrow columns
            );
            return {
              headerName: key,
              field: key.replace(/\./g, '[""]'),
              sortable: true,
              filter: true,
              resizable: true,
              width: maxWidth,
              editable: true,
              cellEditor: 'agTextCellEditor',
            };
          }),
      ];

      return dynamicColumnDefs;
    }
    return [];
  }, [extGridData]);

  const onGridReady = (params) => {
    const { api } = params;
    gridApi = api;
  };


  // const extColumnDefs = React.useMemo(() => {
  //   if (extGridData.length > 0) {
  //     // Get the column names from the first row of the JSON data
  //     const keys = Object.keys(extGridData[0]);

  //     // Create column definitions with the checkbox as the first column
  //     const extColumnDefs = [ 
  //       {
  //         headerName: '',
  //         checkboxSelection: true,
  //         width: 50,
  //       },
  //       ...keys
  //       .filter((key) => key !== 'id') // Filter out the "id" column
  //       .map((key) => {
  //         // Calculate the maximum content width for the current column
  //         const maxWidth = extGridData.reduce(
  //           (max, data) => {
  //             const cellContent = data[key] ? data[key].toString() : '';
  //             return Math.max(max, cellContent.length * 10); // Adjust the constant factor (10) as needed
  //           },
  //           100 // Set a minimum width of 100 to avoid very narrow columns
  //         );

  //         return {
  //           headerName: key,
  //           field: key.replace(/\./g, '[""]'),
  //           sortable: true, 
  //           filter: true, 
  //           resizable: true,
  //           width: maxWidth,
  //         };
  //       }),
  //   ];

  //     return extColumnDefs;
  //   }
  //   return [];
  // }, [extGridData]);

  const handleCheckboxChangeInt = (event) => {
    const selectedRow = event.api.getSelectedRows();
    console.log("label inside", label);
    if (label === 'UnMatched') {
      let intAmount = 0;
      selectedRow.forEach((row) => {
        const debit = parseFloat(row[intDebit]);
        const credit = parseFloat(row[intCredit]);
        if (!isNaN(debit) && !isNaN(credit) && isFinite(debit) && isFinite(credit)) {
          intAmount += debit - credit;
        }
      });
      console.log("int id", selectedRow[0].id);
      setIntId(selectedRow[0].id);
      setInternalAmount(intAmount);
      setOpenIntGridData(selectedRow);
      setMatchHidden(false);
      setContraHidden(false);
      setSelectCheckBox('multiple');
    }
    else if (label === 'Matched' || label === 'GroupMatched' || label === 'Contra' || label === 'ALL') {
      if (selectedRow.length > 0) {
        setSelectedId(selectedRow[0].matched_id);
      } else {
        setSelectedId(null);
      }
      setUnMatchHidden(false);
      const unMatchStyles = { height: "35px", width: "92px", marginTop: "-49px", marginLeft: "0px", marginRight: "-9%", backgroundColor: "#e60000", color: "rgb(248 252 248)" }
      setUnMatchStyles(unMatchStyles);
      setSelectCheckBox('single');
    }

    else if (label === 'GroupUnMatched') {
      if (selectedRow.length > 0) {
        setSelectedId(selectedRow[0].matched_id);
      } else {
        setSelectedId(null);
      }
      setMatchHidden(false);
      setUnMatchHidden(false);
      const unMatchStyles = { height: "35px", width: "92px", marginTop: "-83px", marginLeft: "0px", marginRight: "-9%", backgroundColor: "#e60000", color: "rgb(248 252 248)" }
      setUnMatchStyles(unMatchStyles);
      setSelectCheckBox('single');
    }

    // Perform any actions with the selected row
    setOpenGridHidden(false);
    setDuplicateHidden(false);
    // setInternalAmount(0.00);
  };

  const onGridReadyInt = (params) => {
    const { api } = params;
    gridApiInt = api;
  };

  const handleCheckboxChangeExt = (event) => {
    const selectedRow = event.api.getSelectedRows();
    if (label === 'UnMatched') {
      let extAmount = 0;
      selectedRow.forEach((row) => {
        const debit = parseFloat(row[extDebit]);
        const credit = parseFloat(row[extCredit]);
        if (!isNaN(debit) && !isNaN(credit) && isFinite(debit) && isFinite(credit)) {
          extAmount += credit - debit;
        }
      });

      setExternalAmount(extAmount);
      setOpenExtGridData(selectedRow);
      setMatchHidden(false);
      setContraHidden(false);
      setSelectCheckBox('multiple');
    }
    else if (label === 'Matched' || label === 'GroupMatched' || label === 'Contra' || label === 'ALL') {
      if (selectedRow.length > 0) {
        setSelectedId(selectedRow[0].matched_id);
      } else {
        setSelectedId(null);
      }
      setUnMatchHidden(false);
      const unMatchStyles = { height: "35px", width: "92px", marginTop: "-49px", marginLeft: "0px", marginRight: "-9%", backgroundColor: "#e60000", color: "rgb(248 252 248)" }
      setUnMatchStyles(unMatchStyles);
      setSelectCheckBox('single');
    }

    else if (label === 'GroupUnMatched') {
      if (selectedRow.length > 0) {
        setSelectedId(selectedRow[0].matched_id);
      } else {
        setSelectedId(null);
      }
      setMatchHidden(false);
      setUnMatchHidden(false);
      const unMatchStyles = { height: "35px", width: "92px", marginTop: "-83px", marginLeft: "0px", marginRight: "-9%", backgroundColor: "#e60000", color: "rgb(248 252 248)" }
      setUnMatchStyles(unMatchStyles);
      setSelectCheckBox('single');
    }
    // setOpenExtGridData([]);
    // Perform any actions with the selected row
    setOpenGridHidden(false);
    setDuplicateHidden(false);
    // setExternalAmount(0.00);
    console.log('ext', selectedRow);
  };
  // console.log("openExtGridDataout", openExtGridData);
  // console.log("openEIntGridDataout", openIntGridData.map(row => row.id));

  useEffect(() => {
    filterRowData();
  }, [selectedId]);

  const filterRowData = () => {
    console.log("hi", selectedId)
    if (selectedId) {
      const apiInt = agIntGridRef.current.api;
      const apiExt = agExtGridRef.current.api;

      let indexInt = 0;
      apiInt.forEachNodeAfterFilterAndSort((rowNode) => {
        const rowData = rowNode.data;
        // if (rowNode.data.matched_id === selectedId) {
        if (rowData && rowData.hasOwnProperty('matched_id') && rowData.matched_id === selectedId) {

          intMatchingRows[indexInt] = rowData;
          indexInt++;
        }
      });

      let idsum = 0;
      let icsum = 0;
      Object.values(intMatchingRows).forEach((rowData) => {
        // Check if the rowData has the 'amount' field
        if (rowData && rowData.hasOwnProperty(intDebit)) {
          // Add the amount to the sum
          idsum += rowData[intDebit];
          icsum += rowData[intCredit];
          let intAmount = idsum - icsum
          setInternalAmount(intAmount);
        }
      });

      let indexExt = 0;
      apiExt.forEachNodeAfterFilterAndSort((rowNode) => {
        const rowData = rowNode.data;
        // if (rowNode.data.matched_id === selectedId) {
        if (rowData && rowData.hasOwnProperty('matched_id') && rowData.matched_id === selectedId) {

          extMatchingRows[indexExt] = rowData;
          indexExt++;
        }
      });

      let edsum = 0;
      let ecsum = 0;
      Object.values(extMatchingRows).forEach((rowData) => {
        // Check if the rowData has the 'amount' field
        if (rowData && rowData.hasOwnProperty(extDebit)) {
          // Add the amount to the sum
          edsum += rowData[extDebit];
          ecsum += rowData[extCredit];
          let extAmount = ecsum - edsum
          setExternalAmount(extAmount);
        }
      });

      if (intMatchingRows) {
        setOpenIntGridData(intMatchingRows);
      }
      if (extMatchingRows) {
        setOpenExtGridData(extMatchingRows);
      }
    } else {
      setOpenIntGridData([]);
      setOpenExtGridData([]);
    }
  };

  const OpenExtColumnDefs = React.useMemo(() => {
    if (openExtGridData.length > 0) {
      console.log("openExtGridData", openExtGridData);
      // Get the column names from the first row of the JSON data
      const keys = Object.keys(openExtGridData[0]);

      // Create column definitions with the checkbox as the first column
      const OpenExtColumnDefs = [
        // {
        //   headerName: '',
        //   checkboxSelection: true,
        //   width: 50,
        // },
        ...keys
          .filter((key) => key !== 'id') // Filter out the "id" column
          .map((key) => {
            // Calculate the maximum content width for the current column
            const maxWidth = openExtGridData.reduce(
              (max, data) => {
                const cellContent = data[key] ? data[key].toString() : '';
                return Math.max(max, cellContent.length * 5); // Adjust the constant factor (10) as needed
              },
              100 // Set a minimum width of 100 to avoid very narrow columns
            );

            return {
              headerName: key,
              field: key.replace(/\./g, '[""]'),
              sortable: true,
              filter: true,
              resizable: true,
              width: maxWidth,
            };
          }),
      ];

      return OpenExtColumnDefs;
    }
    return [];
  }, [openExtGridData]);

  const OpenIntColumnDefs = React.useMemo(() => {
    if (openIntGridData.length > 0) {
      // Get the column names from the first row of the JSON data
      const keys = Object.keys(openIntGridData[0]);

      // Create column definitions with the checkbox as the first column
      const OpenIntColumnDefs = [
        // {
        //   headerName: '',
        //   checkboxSelection: true,
        //   width: 50,
        // },
        ...keys
          .filter((key) => key !== 'id') // Filter out the "id" column
          .map((key) => {
            // Calculate the maximum content width for the current column
            const maxWidth = openIntGridData.reduce(
              (max, data) => {
                const cellContent = data[key] ? data[key].toString() : '';
                return Math.max(max, cellContent.length * 5); // Adjust the constant factor (10) as needed
              },
              100 // Set a minimum width of 100 to avoid very narrow columns
            );

            return {
              headerName: key,
              field: key.replace(/\./g, '[""]'),
              sortable: true,
              filter: true,
              resizable: true,
              width: maxWidth,
            };
          }),
      ];

      return OpenIntColumnDefs;
    }
    return [];
  }, [openIntGridData]);

  function matchClick() {
    console.log("idss", openIntGridData.map(row => row.id))
    setLoaderOpen(true);
    let payload = {
      "int_name": intName,
      "ext_name": extName,
      "int_id": openIntGridData.map(row => row.id),
      "ext_id": openExtGridData.map(row => row.id),
      "user_id": userCredentials["user_id"],
      "processingLayerId": layerId
    }

    const amountInt = internalAmount.toString().replace(/-/g, "");
    const amountExt = externalAmount.toString().replace(/-/g, "");
    const total = (amountInt - amountExt).toString().replace(/-/g, "");
    console.log("total", total);

    if (total <= amountTolerance) {

      var getMatchRecords = getUpdateMatchRecordsFromServer();

      axios.post(getMatchRecords[1], { params: payload }, getMatchRecords[0])
        .then(
          response => {
            console.log("Matched the selected Records!!!", response)
            let data = response["data"];
            if (data["Status"] === "Success") {
              console.log("data", data);
              setDoughnutLabel([]);
              setDoughnutData([]);
              setIntGridData([]);
              setExtGridData([]);
              setUnMatchedHidden(true);
              setOpenGridHidden(true);
              setOpenIntGridData([]);
              setOpenExtGridData([]);
              setUnMatchHidden(true);
              Promise.all([
                processingLayerDataReturn(),
                getChartClickedDataReturn(label)
              ]).then(() => {
                alert("Records Matched Successfully!!!");
                setLoaderOpen(false);
              });
            }
            else {
              alert("Error In Matching!!!");
              setLoaderOpen(false);
            }
          }
        ).catch(
          error => {
            console.log("Error in Matching Records!!!", error);
            setLoaderOpen(false);
          }
        );
    }
    else {
      alert("Amounts Are Not Matching!!!");
      setLoaderOpen(false);
    }

  }

  function duplicateClick() {
    setLoaderOpen(true);
    let payload = {
      "int_name": intName,
      "ext_name": extName,
      "int_id": openIntGridData.map(row => row.id),
      "ext_id": openExtGridData.map(row => row.id),
      "user_id": userCredentials["user_id"],
      "processingLayerId": layerId
    }

    var getDuplicateRecords = getUpdateDuplicateRecordsFromServer();

    axios.post(getDuplicateRecords[1], { params: payload }, getDuplicateRecords[0])
      .then(
        response => {
          console.log("Duplicated the selected Records!!!", response)
          let data = response["data"];
          if (data["Status"] === "Success") {
            console.log("data", data);
            setDoughnutLabel([]);
            setDoughnutData([]);
            setIntGridData([]);
            setExtGridData([]);
            setUnMatchedHidden(true);
            setOpenGridHidden(true);
            setOpenIntGridData([]);
            setOpenExtGridData([]);
            setUnMatchHidden(true);
            Promise.all([
              processingLayerDataReturn(),
              getChartClickedDataReturn(label)
            ]).then(() => {
              alert("Records Updated As Duplicate Successfully!!!");
              setLoaderOpen(false);
            });

          }
          else {
            alert("Error In Duplicating!!!");
            setLoaderOpen(false);
          }
        }
      ).catch(
        error => {
          console.log("Error in Updating Records Duplicate!!!", error);
          setLoaderOpen(false);
        }
      );


  }

  function UnMatchClick() {
    setLoaderOpen(true);
    let payload = {
      "int_name": intName,
      "ext_name": extName,
      "int_id": openIntGridData.map(row => row.id),
      "ext_id": openExtGridData.map(row => row.id),
      "user_id": userCredentials["user_id"],
      "processingLayerId": layerId
    }

    var getUnMatchRecords = getUpdateUnMatchRecordsFromServer();

    axios.post(getUnMatchRecords[1], { params: payload }, getUnMatchRecords[0])
      .then(
        response => {
          console.log("UMatched the selected Records!!!", response)
          let data = response["data"];
          if (data["Status"] === "Success") {
            console.log("data", data);
            setDoughnutLabel([]);
            setDoughnutData([]);
            setIntGridData([]);
            setExtGridData([]);
            setUnMatchedHidden(true);
            setOpenGridHidden(true);
            setOpenIntGridData([]);
            setOpenExtGridData([]);
            setUnMatchHidden(true);
            Promise.all([
              processingLayerDataReturn(),
              getChartClickedDataReturn(label)
            ]).then(() => {
              alert("Records UnMatched Successfully!!!");
              setLoaderOpen(false);
            });
          }
          else {
            alert("Error In UnMatching!!!");
            setLoaderOpen(false);
          }
        }
      ).catch(
        error => {
          console.log("Error in Updating Records UnMatched!!!", error);
          setLoaderOpen(false);
        }
      );


  }

  function contraClick() {
    setLoaderOpen(true);
    let payload = {
      "int_name": intName,
      "ext_name": extName,
      "int_id": openIntGridData.map(row => row.id),
      "ext_id": openExtGridData.map(row => row.id),
      "user_id": userCredentials["user_id"],
      "processingLayerId": layerId
    }

    const amountInt = internalAmount.toString().replace(/-/g, "");
    const amountExt = externalAmount.toString().replace(/-/g, "");
    const total = (amountInt - amountExt).toString().replace(/-/g, "");
    console.log("total", total);

    // if (total === '0'){

    var getContraRecords = getUpdateContraRecordsFromServer();

    axios.post(getContraRecords[1], { params: payload }, getContraRecords[0])
      .then(
        response => {
          console.log("Match the selected Records As Contra!!!", response)
          let data = response["data"];
          if (data["Status"] === "Success") {
            console.log("data", data);
            setDoughnutLabel([]);
            setDoughnutData([]);
            setIntGridData([]);
            setExtGridData([]);
            setUnMatchedHidden(true);
            setOpenGridHidden(true);
            setOpenIntGridData([]);
            setOpenExtGridData([]);
            setUnMatchHidden(true);
            Promise.all([
              processingLayerDataReturn(),
              getChartClickedDataReturn(label)
            ]).then(() => {
              alert("Records Updated As Contra Successfully!!!");
              setLoaderOpen(false);
            });
          }
          else {
            alert("Error In Contra Matching!!!");
            setLoaderOpen(false);
          }
        }
      ).catch(
        error => {
          console.log("Error in Contra Matching Records!!!", error);
          setLoaderOpen(false);
        }
      );
    // }
    // else{
    //   alert("Amounts Are Not Matching!!!");
    //   setLoaderOpen(false);
    // }

  }

  function glBalClick() {
    setLoaderOpen(true);
    let payload = {
      "int_name": intName,
      "ext_name": extName,
      "int_cr": intCredit,
      "int_dr": intDebit,
      "processing_layer_id": layerId,
      "intDate": intDate
    }

    if (selectedOption.length > 0) {
      var getGlBal = getUpdateGlBalFromServer();

      axios.post(getGlBal[1], { params: payload }, getGlBal[0])
        .then(
          response => {
            console.log("GL Balances Update Response!!!", response)
            let data = response["data"];
            if (data["Status"] === "Success") {
              alert("GL Balance Updated Successfully!!!");
              setLoaderOpen(false);
            }
            else {
              // alert("Error In Matching!!!");
              setLoaderOpen(false);
            }
          }
        ).catch(
          error => {
            console.log("Error in Updating Balances!!!", error);
            setLoaderOpen(false);
          }
        );
    }
    else {
      alert("Please Select The Reconciliation Type!!!");
      setLoaderOpen(false);
    }
  }

  function BankBalClick() {
    setLoaderOpen(true);
    let payload = {
      "ext_name": extName,
      "ext_cr": extCredit,
      "ext_dr": extDebit,
      "processing_layer_id": layerId,
      "extDate": extDate
    }

    if (selectedOption.length > 0) {
      var getBankBal = getUpdateBankBalFromServer();

      axios.post(getBankBal[1], { params: payload }, getBankBal[0])
        .then(
          response => {
            console.log("Bank Balances Update Response!!!", response)
            let data = response["data"];
            if (data["Status"] === "Success") {
              alert("Bank Balance Updated Successfully!!!");
              setLoaderOpen(false);
            }
            else {
              // alert("Error In Matching!!!");
              setLoaderOpen(false);
            }
          }
        ).catch(
          error => {
            console.log("Error in Updating Bank Balances!!!", error);
            setLoaderOpen(false);
          }
        );
    }
    else {
      alert("Please Select The Reconciliation Type!!!");
      setLoaderOpen(false);
    }
  }

  const onFilterTextChange = (event) => {
    const { value } = event.target;
    setSearchText(value);
  };

  const handleCellValueChanged = (params) => {
    // This function will be called when a cell's value changes
    // You can capture the edited data and send it to the server for saving
    const editedData = params.data; // Updated row data
    console.log("editedData", editedData);

    setLoaderOpen(true);
    let payload = {
      "ext_name": extName,
      "editedData": editedData,
    }

    if (selectedOption.length > 0) {
      var editStatement = getUpdateEditedBankStatementToServer();

      axios.post(editStatement[1], { params: payload }, editStatement[0])
        .then(
          response => {
            console.log("Bank Balances Update Response!!!", response)
            let data = response["data"];
            if (data["Status"] === "Success") {
              alert("Date Updated Successfully!!!");
              setLoaderOpen(false);
            }
            else {
              // alert("Error In Matching!!!");
              setLoaderOpen(false);
            }
          }
        ).catch(
          error => {
            console.log("Error in Updating Date!!!", error);
            setLoaderOpen(false);
          }
        );
    }
    else {
      alert("Please Select The Reconciliation Type!!!");
      setLoaderOpen(false);
    }
  };

  return (
    <div>

      <div className=" row">
        <div className='col-md-1' style={{ paddingLeft: '1.5em', paddingTop: '2em' }}>
          <label htmlFor="underline_select " style={{ fontSize: '15px', padding: '0.5em' }}><h4>Vendor</h4></label>
        </div>
        <div className='col-md-3' style={{ paddingLeft: '0.5em', paddingTop: '2em' }}>

          <div className="cardName1">
            <div className="dropdown-container1">
              <Select
                clearable
                options={selectedOptions}
                selection
                placeholder='ChooseVendor'

                onChange={handleSelection}
                value={selectedOption}
              />

            </div>
          </div>
        </div>
        <div className="balance-containerVRS col-md-6" style={{ paddingTop: '4em' }}>
          <h4>GL Balance : {glBalance}</h4>
          <h4 className="bankBalance">Vendor Balance : {vendorBalance}</h4>
        </div>
      </div>

      <div className="detailsVrs">


        <div hidden={chartHidden}>
          <div>
            <div id="chart">
              <ReactApexChart options={chartData.options} series={chartData.series} type="donut" width={380} />
            </div>
          </div>
        </div>
        <div hidden={openGridHidden}>
          <div className="buttonClass" hidden={duplicateHidden}>
            <button className="btn" style={{ height: "35px", width: "92px", marginTop: "48px", marginRight: "-10%", marginLeft: "0px", backgroundColor: "#e60000", color: "rgb(248 252 248)" }} onClick={(e) => { duplicateClick(e) }}>Duplicate</button>
          </div>
          <div className="grid-container">
            <div className="ag-theme-alpine" style={{ height: '400px', width: '100%' }}>
              <h4 className="heading">External Total : {externalAmount}</h4>
              <AgGridReact columnDefs={OpenExtColumnDefs} rowData={openExtGridData} animateRows={true}
                // rowSelection={'multiple'}
                pagination={true}
                paginationPageSize={10}
                groupSelectsChildren={true}
                suppressAggAtRootLevel={true}
                suppressRowClickSelection={true} />
            </div>
            <div className="ag-theme-alpine" style={{ height: '400px', width: '100%' }}>
              <h4 className="heading">Internal Total : {internalAmount}</h4>
              <AgGridReact columnDefs={OpenIntColumnDefs} rowData={openIntGridData} animateRows={true}
                // rowSelection={'multiple'}
                pagination={true}
                paginationPageSize={10}
                groupSelectsChildren={true}
                suppressAggAtRootLevel={true}
                suppressRowClickSelection={true} />
            </div>
          </div>
        </div>
        <div hidden={searchHidden}>
          <input className="search-input" type="text" placeholder="Search..." value={searchText} onChange={onFilterTextChange} />
        </div>
        <div className="buttonClass" hidden={matchHidden}>
          <button className="btn" style={{ height: "35px", width: "92px", marginTop: "-45px", marginLeft: "0px", backgroundColor: "rgb(24 160 17)", color: "rgb(248 252 248)", marginRight: "2%" }} onClick={(e) => { matchClick(e) }}>Match</button>
          {/* <button className="btn" style={{height:"35px", width: "92px", marginTop: "48px", marginLeft:"0px", backgroundColor:"rgb(24 160 17)", color:"rgb(248 252 248)"}} onClick={(e) => {contraClick(e)}}>Contra</button> */}
        </div>
        <div className="buttonClass" hidden={contraHidden}>
          {/* <button className="btn" style={{height:"35px", width: "92px", marginTop: "48px", marginLeft:"0px", backgroundColor:"rgb(24 160 17)", color:"rgb(248 252 248)", marginRight: "2%"}} onClick={(e) => {matchClick(e)}}>Match</button> */}
          <button className="btn" style={{ height: "35px", width: "92px", marginTop: "-84px", marginRight: "-8%", backgroundColor: "rgb(24 160 17)", color: "rgb(248 252 248)" }} onClick={(e) => { contraClick(e) }}>Contra</button>
        </div>
        <div className="buttonClass" hidden={unMatchHidden}>
          <button className="btn" style={unMatchStyles} onClick={(e) => { UnMatchClick(e) }}>UnMatch</button>
        </div>
        <div hidden={unMatchedHidden}>
          <div className="grid-container2">
            <div className="ag-theme-alpine" style={{ height: '400px', width: '100%' }}>
              <h3 className="heading">Vendor Statement</h3>
              <AgGridReact columnDefs={extColumnDefs} rowData={extGridData} animateRows={true}
                ref={agExtGridRef}
                rowSelection={selectCheckBox}
                pagination={true}
                paginationPageSize={10}
                groupSelectsChildren={true}
                suppressAggAtRootLevel={true}
                onRowSelected={handleCheckboxChangeExt}
                // suppressRowClickSelection={false}
                quickFilterText={searchText}
                enableRangeSelection={true}
                enableRangeCopy={true}
                onGridReady={onGridReady}
                onCellValueChanged={handleCellValueChanged} />
            </div>
            <div className="ag-theme-alpine" style={{ height: '400px', width: '100%' }}>
              <h3 className="heading">GL Statement</h3>
              <AgGridReact columnDefs={intColumnDefs} rowData={intGridData} animateRows={true}
                ref={agIntGridRef}
                rowSelection={selectCheckBox}
                pagination={true}
                paginationPageSize={10}
                groupSelectsChildren={true}
                suppressAggAtRootLevel={true}
                onRowSelected={handleCheckboxChangeInt}
                suppressRowClickSelection={true}
                quickFilterText={searchText}
                onGridReady={onGridReadyInt} />
            </div>
          </div>
        </div>
        <LoaderComponent loaderOpen={loaderOpen} />
      </div>
    </div>
  );
}

export default reconSummary;
import React, { useState, useEffect, useRef } from "react";
import * as XLSX from 'xlsx';
import axios from 'axios';
import "./etl.css";
import { Accordion } from "https://cdn.skypack.dev/semantic-ui-react@2.1.4";
import { Icon, Input, Button, Dropdown, Grid, Popup, Segment, Tab, Table, Menu, Form, TextArea, Label, Header, Checkbox } from 'semantic-ui-react'
import { FileUploadToServer } from '../../../services/auth-service/authService.js'
import { SheetDataUpload } from '../../../services/auth-service/authService.js'
import { SheetData, FileUploadToServernew } from '../../../services/auth-service/authService.js'
import Select from "react-select";
import { render } from "@testing-library/react";
// import Modal from 'react-modal';
import Modal from 'react-bootstrap/Modal';

// this.column_name_val;
// temp
var col_name = [];
var sht_name = [];
var file_drp_value;
var file_src_name;
var file_src_description;
var sht_upd_data;
var json_data;
var source_id;
const TableExampleStructured = (data) => (
  <Table celled structured>
    <Table.Header>
      <Table.Row>
        <Table.HeaderCell rowSpan='2'>Name</Table.HeaderCell>
        <Table.HeaderCell rowSpan='2'>Type</Table.HeaderCell>
        <Table.HeaderCell rowSpan='2'>Files</Table.HeaderCell>
      </Table.Row>
    </Table.Header>

    <Table.Body>
      {data.map(item => (
        <Table.Row key={item.id}>
          <Table.Cell>{item.col_name}</Table.Cell>
          <Table.Cell>Project 1</Table.Cell>
          <Table.Cell textAlign='right'>2</Table.Cell>
        </Table.Row>
      ))}
    </Table.Body>
  </Table>
)

const Record = () => (
  <Select placeholder='Selecte DB Record' options={lookup} />
)
const Record1 = () => (
  <Select placeholder='Selecte Sheet' options={lookup1} />
)
const Sheet1 = () => (
  <Select placeholder='Selecte Column' options={lookup2} />
)
const Column1 = () => (
  <Select placeholder='Selecte ' options={lookup3} />
)


const TableExampleError = () => (
  <Table celled>
    <Table.Header>
      <Table.Row>
        <Table.HeaderCell>Name</Table.HeaderCell>
        <Table.HeaderCell>Status</Table.HeaderCell>
        <Table.HeaderCell>Notes</Table.HeaderCell>
      </Table.Row>
    </Table.Header>

    <Table.Body>
      <Table.Row>
        <Table.Cell>No Name Specified</Table.Cell>
        <Table.Cell>Approved</Table.Cell>
        <Table.Cell>None</Table.Cell>
      </Table.Row>
      <Table.Row error>
        <Table.Cell>Jimmy</Table.Cell>
        <Table.Cell>Cannot pull data</Table.Cell>
        <Table.Cell>None</Table.Cell>
      </Table.Row>
      <Table.Row>
        <Table.Cell>Jamie</Table.Cell>
        <Table.Cell>Approved</Table.Cell>
        <Table.Cell error>
          <Icon name='attention' />
          Classified
        </Table.Cell>
      </Table.Row>
      <Table.Row>
        <Table.Cell>Jill</Table.Cell>
        <Table.Cell>Approved</Table.Cell>
        <Table.Cell>None</Table.Cell>
      </Table.Row>
    </Table.Body>
  </Table>
)

// end tem
// File Upload
function handleFileUpload_old(id) {
  const file = document.getElementById(id).files[0];
  const reader = new FileReader();

  reader.onload = (event) => {
    const data = event.target.result;
    const workbook = XLSX.read(data, { type: 'binary' });
    const sheetName = workbook.SheetNames[0];
    const sheet = workbook.Sheets[sheetName];
    const json = XLSX.utils.sheet_to_json(sheet);
    console.log(json); // or do something else with the JSON data



    let payload = {
      File_data: json,
    }

    var FileUploadCredentials = FileUploadToServer();

    axios.post(FileUploadCredentials[1], payload, FileUploadCredentials[0])
      .then(
        response => {
          console.log("Validate Credentials Response!!!", response);
          let responseData = response["data"];
          if (responseData["Status"] === "Success") {
            let userCredentials = responseData["user_credentials"];
            sessionStorage.setItem("userCredentials", JSON.stringify(userCredentials));
            // navigate(userCredentials["config"]["default_page"]);
          }
        }
      ).catch(
        error => {
          console.log("Error", error);
          alert("Error in Login User!!!");
        }
      );
  };
  reader.readAsBinaryString(file);
}
function handleFileUpload(id) {
  const file = document.getElementById(id).files[0];
  sendFileToAPI(file);
}
function sendFileToAPI(file) {
  // const [data, setData] = useState([]);
  const formData = new FormData();
  formData.append('file', file);
  var FileUploadCredentials = FileUploadToServer();
  // console.log(payload);
  var hello = this;
  fetch(FileUploadCredentials[1], {
    method: 'POST',
    body: formData
  })
    .then(response => response.json())
    .then(data => {
      console.log(data);
      const myObj = data.employee_records[0][0];
      console.log(myObj)
      let text = [];
      for (const x in myObj) {
        text.push(x);
        // text += x + ", ";
      }
      col_name = text;
      console.log(col_name);
      // TableExampleBasic(col_name);
    })
    .catch(error => {
      console.error(error);
    });
  return (
    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Age</th>
        </tr>
      </thead>
    </table>
  );


}
// End File Upload
///////////////
const InputExampleIconPositionColNme = (Props) => (
  <input placeholder={'dummy'} size='mini' />

)
const InputExampleIconPosition = (Props) => (
  <Input placeholder={'dummy'} size='mini' />
)

const options = [
  { key: 1, text: 'Excel', value: 'Excel' },
  { key: 2, text: 'CSV', value: 'CSV' },
  { key: 3, text: 'Text', value: 'Text' },
  { key: 4, text: 'Staging DB', value: 'Staging DB' },
  { key: 5, text: 'Binary', value: 'Binary' },

]
const options2 = [
  { key: 1, text: 'Is Null', value: 1 },
  { key: 2, text: 'Yes or NO', value: 2 },
  { key: 3, text: 'Data Format', value: 3 },
  { key: 4, text: 'length', value: 4 },

]
const optionsclick = [
  // { key: 1, text: 'Fill character', value: 1 },
   { key: 2, text: 'Change date formate', value: 2 },
  // { key: 3, text: 'Add decimals', value: 3 },
  // { key: 4, text: 'Remove decimal', value: 4 },
  // { key: 5, text: 'Round of', value: 5 },
  // { key: 6, text: 'Clear Values', value: 6 },
  { key: 7, text: 'Field Extraction', value: 7 },
  { key: 7, text: 'Position', value: 7 },


]

// lookup
const lookup = [
  { key: 'af', value: 'af', text: 'Record 1' },
  { key: 'ax', value: 'ax', text: 'Record 2' },
  { key: 'al', value: 'al', text: 'Record 3' },
  { key: 'dz', value: 'dz', text: 'Record 4' },

]
const lookup1 = [
  { key: 'af', value: 'af', text: 'Sheet 1' },
  { key: 'ax', value: 'ax', text: 'Sheet 2' },
  { key: 'al', value: 'al', text: 'Sheet 3' },
  { key: 'dz', value: 'dz', text: 'Sheet 4' },

]


const lookup2 = [
  { key: 'af', value: 'af', text: 'Column 1' },
  { key: 'ax', value: 'ax', text: 'Column 2' },
  { key: 'al', value: 'al', text: 'Column 3' },
  { key: 'dz', value: 'dz', text: 'Column 4' },


]
const lookup3 = [
  { key: 'af', value: 'af', text: 'Primary Key' },

]
// const DropdownExampleUpwardSelection = () => (
//   <Dropdown
//     upward
//     search
//     selection
//     options={optionsclick}
//     placeholder='Choose an option'
//   />
// )
// const DropdownExampleClearable_old = () => (
//   <Dropdown clearable options={options} value={selectedOption} selection placeholder='Choose an option' size='mini' onChange={handleDropdownChange} />
// )
function onSelectVar(data) {
  return (
    <input id='input_var_val'></input>
  );
  console.log(data);
  // setModalIsOpen(false);
}
function ScreenPopup() {
  const [modalIsOpen, setModalIsOpen] = useState(false);

  const openModal = () => {
    setModalIsOpen(true);
  };

  const closeModal = () => {
    setModalIsOpen(false);
  };

  return (
    <div>
      <Button onClick={openModal}>choose</Button>
      <Modal isOpen={modalIsOpen} onRequestClose={closeModal} ariaHideApp={false} style={{ overlay: { backgroundColor: 'rgba(0, 0, 0, 0.5)' }, content: { width: '30%', height: '30%', top: '30%', left: '30%', transform: 'translate(-30%, -30%)' } }}>
        <div>
          <input type="radio" id="datatype1" name="datatype" value="Int" onClick={() => onSelectVar('int')}></input>
          <label for="datatype1"> Int </label>
          <input type='text'></input><br></br>
          <input type="radio" id="datatype1" name="datatype" value="Long_Int" onClick={() => onSelectVar('Long_Int')}></input>
          <label for="datatype1"> Long Int </label><br></br>
          <input type="radio" id="datatype2" name="datatype" value="Float" onClick={() => onSelectVar('Float')}></input>
          <label for="datatype2"> Float </label><br></br>
          <input type="radio" id="datatype3" name="datatype" value="DateTime" onClick={() => onSelectVar('DateTime')}></input>
          <label for="datatype3"> DateTime </label><br></br>
          <input type="radio" id="datatype4" name="datatype" value="Text" onClick={() => onSelectVar('Text')}></input>
          <label for="datatype4"> Text </label><br></br>
          <button onClick={closeModal}>Close</button>
        </div>
      </Modal>
    </div>
  );
}
const DropdownExampleClearableValitation = () => (
  <Menu compact>
    <ScreenPopup />
    {/* <Popup trigger=
                {<Button> Select </Button>}
                position="right center">
                <input type="checkbox" id="vehicle1" name="vehicle1" value="Bike"></input>
                <label for="vehicle1"> I have a bike</label><br></br>
                <input type="checkbox" id="vehicle2" name="vehicle2" value="Car"></input>
                <label for="vehicle2"> I have a car</label><br></br>
                <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat"></input>
                <label for="vehicle3"> I have a boat</label><br></br>
    </Popup> */}
  </Menu>
)


const Transform = () => {
  const [prevValue, setPrevValue] = useState(undefined);
  const [newValue, setNewValue] = useState(undefined);
  return (
    <Grid columns='equal' divided style={{ backgroundColor: "#e9e8d9", paddingLeft: "10px", borderRadius: "15px" }}>
      <Grid.Row>
        <Input type="text" value={prevValue} placeholder="previous value" onChange={e => setPrevValue(e.target.value)} />
      </Grid.Row>
      <Grid.Row>
        <Input type="text" value={newValue} placeholder="new value" onChange={e => setNewValue(e.target.value)} />
      </Grid.Row>
      <Grid.Row>
        <Grid.Column>
          <div>
            <Button color='red'>Cancel</Button>
            <Button color='green'>Save</Button>
          </div>
        </Grid.Column>
      </Grid.Row>
    </Grid>
  )
}

const DropdownExampleClearableValitationClick = () => {
  const [show, setShow] = useState(false);

  const displayTransformation = (e) => {
    console.log('hj');
    setShow(true);
  }
  const handleClose = () => {
    setShow(false);
  }
  return (
    <div>
      <div className="popup-link">
        <Menu compact>
          <Dropdown size='mini' text='Dropdown' options={optionsclick} simple item onChange={e => displayTransformation(e)} />
        </Menu>
      </div>

      <Modal
        show={show}
        onHide={handleClose}
        backdrop="static"
        keyboard={false}
      >
        <Modal.Header closeButton>
          <Modal.Title>Transformation</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Transform />
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Cancel
          </Button>
        </Modal.Footer>
      </Modal>

      {/* <div id="popup11" class="popup-container">
    <div class="popup-content">
      <a href="#" class="close">&times;</a>
      <h3>Tranformation</h3>
      <br></br>
      <Transform />
    </div>
  </div> */}
    </div>
  )
}


const InputExampleIconPositionNumber = () => (
  <Input icon='numbered list' iconPosition='left' placeholder='No Of Sheets' type='number' />
)

const InputExampleIconPositionchk = () => (
  <><Checkbox label='YES' /><Checkbox label='NO' /></>
  // <label>
  //   <input type="checkbox"/>
  //   Checkbox Label
  // </label>

)
const InputExampleIconPosition4 = () => (
  <Input icon='sort content ascending' iconPosition="left" placeholder='End Cloumn' type='number' />
)



const ButtonExampleSocial = () => (
  <div>
    {/* <Button onClick={App_file}>
        <Icon name='filter' /> Fetch Confic
      </Button> */}
    <Button onClick={() => handleFileUpload('myFileInput')}>
      <Icon name='filter' /> Fetch Confic
    </Button>

  </div>
)

// const TableExampleBasic = (props) => (
//   <Table basic>
//     <Table.Header>
//       <Table.Row>
//         <Table.HeaderCell>S.No</Table.HeaderCell>
//         <Table.HeaderCell>Column Name</Table.HeaderCell>
//         <Table.HeaderCell>Data type</Table.HeaderCell>
//         <Table.HeaderCell>Property</Table.HeaderCell>
//         <Table.HeaderCell>Validation</Table.HeaderCell>
//         <Table.HeaderCell>Tranform 1</Table.HeaderCell>
//         <Table.HeaderCell>Look Up</Table.HeaderCell>
//         <Table.HeaderCell>Math</Table.HeaderCell>
//         <Table.HeaderCell>Comments</Table.HeaderCell>
//         <Table.HeaderCell>Primary Key</Table.HeaderCell>
//       </Table.Row>
//     </Table.Header>

//     <Table.Body>
//       <Table.Row>
//         <Table.Cell>1</Table.Cell>
//         <Table.Cell>{props.col_name}</Table.Cell>
//         <Table.Cell><DataTypeDropdownList name="Data Type" /></Table.Cell>
//         <Table.Cell><InputExampleIconPosition name="Property" /></Table.Cell>
//         <Table.Cell>< DropdownExampleClearableValitation /></Table.Cell>
//         <Table.Cell><DropdownExampleClearableValitationClick /></Table.Cell>
//         <Table.Cell><DropdownExampleClearableValitationClick /></Table.Cell>
//         <Table.Cell><DropdownExampleClearableValitationClick /></Table.Cell>
//         <Table.Cell><InputExampleIconPosition /></Table.Cell>
//         <Table.Cell><InputExampleIconPositionchk /></Table.Cell>
//       </Table.Row>
//     </Table.Body>
//   </Table>

// )


function datamodify(data_num) {
  // alert(data_num);
  document.getElementById('dataoff').click();
  if (data_num != 0) {
    // alert('inRRRRRR');
    const file = document.getElementById('myFileInput').files[0];
    const formData = new FormData();
    formData.append('file', file);
    var FileUploadCredentials = FileUploadToServer();
    fetch(FileUploadCredentials[1], {
      method: 'POST',
      body: formData
    })
      .then(response => response.json())
      .then(data => {
        console.log(data);
        let data_val = Number(data_num)
        // const myObj = data[data_val];
        // console.log(myObj);
        const myObj = data[data_val].column_names;
        // const data_myObj = data[data_val].data_type;
        console.log(myObj);
        // console.log(data_myObj)
        let text = [];
        for (let j = 0; j <= Number(myObj.length) - 1; j++) {
          const newObj = {};
          newObj['id'] = Number(j) + 1
          newObj['col_name'] = myObj[j]
          // newObj['data_type'] = data_myObj[j]
          text.push(newObj);
        }
        console.log(text);
        col_name = text;

        document.getElementById('dataon').click();
      })
  } else {
    document.getElementById('dataon').click();
  }
}

function colSheet() {
  const data = col_name;

  // const panes = [
  //   {
  //     menuItem: { key: 'users', icon: 'file alternate outline', content: 'Sheet 1' },
  //     render: () => <Tab.Pane></Tab.Pane>,
  //   },
  // ]
  const panes = sht_name.map(data => ({
    menuItem: {
      key: 'users',
      icon: 'file alternate outline',
      content: data.sht_name
    },
    render: () => <Tab.Pane onClick={datamodify(data.id)}></Tab.Pane>
  }));
  return (
    <><Tab panes={panes} /><Table celled structured>
      <Table.Header>
        <Table.Row>
          <Table.HeaderCell rowSpan='2'>Name</Table.HeaderCell>
          <Table.HeaderCell rowSpan='2'>Type</Table.HeaderCell>
          <Table.HeaderCell rowSpan='2'>Files</Table.HeaderCell>
        </Table.Row>
      </Table.Header>

      <Table.Body>
        {data.map(item => (
          <Table.Row key={item.id}>
            <Table.Cell>{item.col_name}</Table.Cell>
            <Table.Cell>Project 1</Table.Cell>
            <Table.Cell textAlign='right'>2</Table.Cell>
          </Table.Row>
        ))}
      </Table.Body>
    </Table></>
  );

}
function componentDidMount() {
  const table = document.getElementById("my-table");
  const cells = table.querySelectorAll("td");
  const data = [];
  const name_data = [];
  // cells.forEach((cell, index) => {
  //   if (index % 9 === 0) {
  //     data.push({
  //       name: cell.textContent,
  //       age: cells[index + 1].textContent,
  //       // city: cells[index + 2].querySelector("input") ? cells[index + 2].querySelector("input").value : cells[index + 2].textContent,
  //     });
  //     name_data.push(cells[index].textContent)
  //   }
  // });
  // let text = [];
  // for (let z = 0; z <= Number(name_data.length) - 1; z++) {
  //   const newObj = {};
  //   newObj['id'] = Number(z) + 1
  //   newObj['text'] = name_data[z]
  //   text.push(newObj);
  // }
  let sheet_name = [];
  let obj;
  let process_name1 = "etl_consolidation";
  console.log(json_data);
  json_data.map(data => {
    obj = {
      "id": data.id,
      "text": data.sheet_name
    }
    sheet_name.push(obj);
    console.log('data', data.id)
  })
  let payload = {
    File_data: json_data,
    sheet_data: sheet_name,
    source_type: file_drp_value,
    source_name: file_src_name, 
    source_description: file_src_description,
    source_identifier: document.getElementById("identifier").value,
    process_name : process_name1,
    file_name: document.getElementById("myFileInput").value,
  }

  var FileUploadCredentials = SheetDataUpload();

  axios.post(FileUploadCredentials[1], payload, FileUploadCredentials[0])
    .then(
      response => {
        console.log("Validate Credentials Response!!!", response);
        // let responseData = response["data"];
        // if (responseData["Status"] === "Success")
        // {
        //     let userCredentials = responseData["user_credentials"]; 
        //     sessionStorage.setItem("userCredentials", JSON.stringify(userCredentials));
        //     // navigate(userCredentials["config"]["default_page"]);
        // }
      }
    ).catch(
      error => {
        console.log("Error", error);
        alert("Error in etl file upload User!!!");
      }
    );
}

function getTableData(id) {
  document.getElementById('dataoff').click();

  const file = document.getElementById(id).files[0];
  const formData = new FormData();
  console.log('datavcbv bv bv bv v' + source_id);
  var payload = {
    File_data: source_id,
  }
  var FileUploadCredentials = FileUploadToServer();
  var FileUploadCredentialsNew = FileUploadToServernew();
  if (source_id) {
    console.log('jhkjbkmjk,jh,knnm,m');

    axios.post(FileUploadCredentialsNew[1], payload, FileUploadCredentialsNew[0])
      .then(
        response => {
          console.log("Validate Credentials Response!!!", response);
          console.log(JSON.stringify(response.data));
          const len_data = response.data;
          source_id = null;
          let sheet = [];
          let sheet_upd = [];
          let j = 1
          console.log(len_data.length)
          for (let j = 0; j <= Number(len_data.length) - 1; j++) {
            console.log(j);
            const newObj_sht = {};
            newObj_sht['id'] = j
            newObj_sht['sht_name'] = len_data[j].sheet_name
            sheet_upd.push(len_data[j].sheet_name)
            sheet.push(newObj_sht);
          }
          sht_upd_data = sheet_upd;
          json_data = response.data
          console.log('sht_upd_data' + JSON.stringify(sht_upd_data));
          console.log(sheet);
          sht_name = sheet;
          const myObj = len_data[0].column_names;
          // const data_myObj = data[0].data_type;
          console.log(myObj);
          // console.log(data_myObj);
          let text = [];
          for (let j = 0; j <= Number(myObj.length) - 1; j++) {
            const newObj = {};
            newObj['id'] = Number(j) + 1
            newObj['col_name'] = myObj[j]
            // newObj['data_type'] = data_myObj[j]
            text.push(newObj);
          }
          console.log(text);
          col_name = text;
          document.getElementById('dataon').click();

        }
      ).catch(
        error => {
          console.log("Error", error);
        }
      );
  } else {
    formData.append('file', file);

    console.log('jhmn')

    fetch(FileUploadCredentials[1], {
      method: 'POST',
      body: formData
    })
      .then(response => response.json())
      .then(data => {
        console.log(JSON.stringify(data));
        const len_data = data;
        let sheet = [];
        let sheet_upd = [];
        let j = 1
        console.log(len_data.length)
        for (let j = 0; j <= Number(len_data.length) - 1; j++) {
          console.log(j);
          const newObj_sht = {};
          newObj_sht['id'] = j
          newObj_sht['sht_name'] = len_data[j].sheet_name
          sheet_upd.push(len_data[j].sheet_name)
          sheet.push(newObj_sht);
        }
        sht_upd_data = sheet_upd;
        json_data = data
        console.log('sht_upd_data' + JSON.stringify(sht_upd_data));
        console.log(sheet);
        sht_name = sheet;
        const myObj = data[0].column_names;
        // const data_myObj = data[0].data_type;
        console.log(myObj);
        // console.log(data_myObj);
        let text = [];
        for (let j = 0; j <= Number(myObj.length) - 1; j++) {
          const newObj = {};
          newObj['id'] = Number(j) + 1
          newObj['col_name'] = myObj[j]
          // newObj['data_type'] = data_myObj[j]
          text.push(newObj);
        }
        console.log(text);
        col_name = text;
        document.getElementById('dataon').click();
        // afterapirunsCol();
        // console.log(col_name);
      })
  }
}

function NullPopup() {
  return (
    <div>
      <div className="popup-link">
        <a href="#popup4"> Validation</a>
      </div>

      <div id="popup4" className="popup-container">
        <div className="popup-content">
          <a href="#" className="close">
            &times;
          </a>
          <ValidationPopup />
        </div>
      </div>
    </div>
  );
}

const LookUpSegment = () => (
  <Grid columns='equal' divided style={{ backgroundColor: "#e9e8d9", paddingLeft: "10px", borderRadius: "15px" }}>
    <Grid.Row>
      <Grid.Column>

        <Record />
      </Grid.Column>

    </Grid.Row>
    <Grid.Row>
      <Grid.Column>
        <Record1 />
      </Grid.Column>
      <Grid.Column>
        <Sheet1 />
      </Grid.Column>
      <Grid.Column>
        <Column1 />
      </Grid.Column>
    </Grid.Row>
    <Grid.Row>

      <Grid.Column>
        <div>
          <Button color='red'>Cancel</Button>
          <Button color='green'>Save</Button>
        </div>
      </Grid.Column>
    </Grid.Row>
  </Grid>
)

const operatoremath = [
  { key: 'af', value: 'af', text: '+' },
  { key: 'ax', value: 'ax', text: '-' },
  { key: 'al', value: 'al', text: '*' },
  { key: 'dz', value: 'dz', text: '%' },

]
const MathOperator = () => (
  <Select placeholder='Selecte Operator' options={operatoremath} />
)
const mathColoumn = [
  { key: 'af', value: 'af', text: 'Column 1' },
  { key: 'ax', value: 'ax', text: 'Column 2' },
  { key: 'al', value: 'al', text: 'Column 3' },
  { key: 'dz', value: 'dz', text: 'Column 4' },


]

const MathColoumn = () => (
  <Select placeholder='Selecte Column' options={mathColoumn} />
)

const MathTranformtable = () => (
  <Table style={{ borderRadius: "15px" }}>
    <Table.Header>
      <Table.Row>
        <Table.HeaderCell>Sheet 1</Table.HeaderCell>
        <Table.HeaderCell>Operator</Table.HeaderCell>
        <Table.HeaderCell>Sheet 2</Table.HeaderCell>
        <Table.HeaderCell>Value</Table.HeaderCell>
        <Table.HeaderCell>Target column</Table.HeaderCell>
        <Table.HeaderCell></Table.HeaderCell>

      </Table.Row>
    </Table.Header>

    <Table.Body>
      <Table.Row>
        <Table.Cell><MathColoumn /></Table.Cell>
        <Table.Cell><MathOperator /></Table.Cell>
        <Table.Cell ><MathColoumn /></Table.Cell>
        <Table.Cell ><InputExampleIconPosition name="Value" /></Table.Cell>
        <Table.Cell ><Record1 /></Table.Cell>
        <Table.Cell ><MathColoumn /></Table.Cell>


      </Table.Row>

    </Table.Body>
  </Table>
)

const ValidationPopup = () => {
  const [showlength, setShowLength] = useState(true);
  const [showdate, setShowdate] = useState(true);
  
  const isEnableLength = () =>{
    setShowLength(!showlength);
  }

  const isEnableDateFormate = () =>{
    setShowdate(!showdate);
  }


  return (
    <div className="col-md-12" style={{ display: "flex" }}>
      <div className="col-md-6">
        <Table style={{ width: '100%' }}>
          <Table.Header>
            <Table.Row>
              <Table.HeaderCell singleLine>Validation</Table.HeaderCell>
              <Table.HeaderCell>position</Table.HeaderCell>
              <Table.HeaderCell>Error</Table.HeaderCell>

            </Table.Row>
          </Table.Header>

          <Table.Body>
            {/* <Table.Row>
        <Table.Cell singleLine>
          <Header as='h2' >
            <Checkbox label='Integer' />
          </Header>
        </Table.Cell>
        <Table.Cell singleLine></Table.Cell>
        <Table.Cell singleLine></Table.Cell>
      </Table.Row> */}

            <Table.Row>
              <Table.Cell singleLine>
                <Header as='h2'>
                  <Checkbox label='Yes / No' />
                </Header>
              </Table.Cell>
              <Table.Cell singleLine></Table.Cell>
              <Table.Cell singleLine></Table.Cell>
            </Table.Row>

            {/* <Table.Row>
        <Table.Cell singleLine>
          <Header as='h2'>
            <Checkbox label='Decimal' />
          </Header>
        </Table.Cell>
        <Table.Cell singleLine></Table.Cell>
        <Table.Cell singleLine></Table.Cell>
      </Table.Row> */}

            <Table.Row>
              <Table.Cell singleLine>
                <Header as='h2'>
                  <Checkbox label='True / False' />
                </Header>
              </Table.Cell>
              <Table.Cell singleLine></Table.Cell>
              <Table.Cell singleLine></Table.Cell>
            </Table.Row>

            <Table.Row>
              <Table.Cell singleLine>
                <Header as='h2'>
                  <Checkbox label='Length' onClick={isEnableLength} />
                </Header>
              </Table.Cell>
              <Table.Cell singleLine></Table.Cell>
              <Table.Cell singleLine></Table.Cell>
            </Table.Row>

            <Table.Row>
              <Table.Cell singleLine>
                <Header as='h2' >
                  <Checkbox label='Date Formate' onClick={isEnableDateFormate} />
                </Header>
              </Table.Cell>
              <Table.Cell singleLine></Table.Cell>
              <Table.Cell singleLine></Table.Cell>
            </Table.Row>

            <Table.Row>
              <Table.Cell singleLine>
                <Header as='h2' >
                  <Checkbox label='Unique' />
                </Header>
              </Table.Cell>
              <Table.Cell singleLine></Table.Cell>
              <Table.Cell singleLine></Table.Cell>
            </Table.Row>

          </Table.Body>
        </Table>
      </div>
      <div className="col-md-5" style={{ backgroundColor: "rgb(233, 232, 217)" }}>
        <div style={{ marginLeft: "1em" }}>
          <Input disabled={showlength} type="text" placeholder="enter min-length" style={{ marginBottom: '1em', marginTop: "1em" }} />
          <Input disabled={showlength} type="text" placeholder="enter max-length" style={{ marginBottom: '1em' }} />
          <Input disabled={showdate} type="text" placeholder="enter date formate" />
        </div>
      </div>
    </div>
  )
}

function LookUp() {

  return (
    <div>
      <div className="popup-link">
        <a href="#popup18"> LookUp</a>
      </div>
      <div id="popup18" className="popup-container">
        <div className="popup-content">
          <a href="#" className="close">&times;</a>
          <h3>Look Up Tranformation</h3>
          <br></br>
          <LookUpSegment />
        </div>
      </div>
    </div>

  )
}

function MathTranform() {

  return (
    <div>
      <div className="popup-link">
        <a href="#popup11"> Tranform</a>
      </div>

      <div id="popup11" className="popup-container">
        <div className="popup-contentmath">
          <a href="#" className="close">&times;</a>
          <h3>Math Tranformation</h3>
          <br></br>
          <Grid style={{ backgroundColor: "#e9e8d9", borderRadius: "15px", paddingLeft: "20px" }}>
            <Grid.Row >
              <Grid.Column>
                <MathTranformtable />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row>
              <Grid.Column>
                <div>
                  <Button color='red' className="close">Cancel</Button>
                  <Button color='green'>Save</Button>
                </div>
              </Grid.Column>
            </Grid.Row>
          </Grid>
        </div>
      </div>
    </div>

  )
}

const datatype_optionslist = [
  { key: 1, text: '', value: 1 },
  { key: 2, text: 'Date', value: 2 },
  { key: 3, text: 'Decimal', value: 3 },
  { key: 4, text: 'Integer', value: 4 },
  { key: 5, text: 'Text', value: 5 },

]
const DataTypeDropdownList = () => {
  const displayTransformation1 = (e) => {
    console.log('datatype', e.target.value);
  }

  return (
    // <Select options={options} style={{width:"9em", backgroundColor:'#fff'}}/>

    <Dropdown options={datatype_optionslist} id="datatype_optionlist" onChange={e => displayTransformation1(e)} style={{ width: "9em", backgroundColor: '#fff', float: 'right', height: '2.3em' }} />
  )
}

function afterapirunsCol() {
  // const data = [
  //   { id: 1, name: 'Alice', age: 25 },
  //   { id: 2, name: 'Bob', age: 30 },
  //   { id: 3, name: 'Charlie', age: 35 },
  // ];
  const data = col_name;
  console.log(data);
  // TableExampleStructured(data);

  return (
    // <table>
    //   <thead>
    //     <tr>
    //       <th>ID</th>
    //       <th>Name</th>
    //       <th>Age</th>
    //     </tr>
    //   </thead>
    //   <tbody>
    //   {data.map(item => (
    //       <tr key={item.id}>
    //         <td>{item.id}</td>
    //         <td>{item.name}</td>
    //         <td>{item.age}</td>
    //       </tr>
    //     ))}
    //   </tbody>
    // </table>
    <Grid.Row style={{ backgroundColor: "#e9e8d9", borderRadius: "12px", marginTop: "10px", width: "100%" }}>
      <Grid.Column className="overflow">
        <Table basic id="my-table">
          <Table.Header>
            <Table.Row>
              <Table.HeaderCell>S.No</Table.HeaderCell>
              <Table.HeaderCell>Column Name</Table.HeaderCell>
              <Table.HeaderCell>Data type</Table.HeaderCell>
              <Table.HeaderCell>Property</Table.HeaderCell>
              <Table.HeaderCell>Validation</Table.HeaderCell>
              <Table.HeaderCell>Tranform 1</Table.HeaderCell>
              {/* <Table.HeaderCell>Look Up</Table.HeaderCell>
              <Table.HeaderCell>Math</Table.HeaderCell> */}
              <Table.HeaderCell>Comments</Table.HeaderCell>
              <Table.HeaderCell>Primary Key</Table.HeaderCell>
            </Table.Row>
          </Table.Header>

          <Table.Body>
            {data.map(item => (
              <Table.Row key={item.id}>
                <Table.Cell>{item.id}</Table.Cell>
                <Table.Cell>{item.col_name}</Table.Cell>
                <Table.Cell><DataTypeDropdownList name="datatype" /></Table.Cell>
                <Table.Cell><InputExampleIconPosition name="Property" /></Table.Cell>
                <Table.Cell><NullPopup /></Table.Cell>
                <Table.Cell><DropdownExampleClearableValitationClick /></Table.Cell>
                {/* <Table.Cell> <LookUp /></Table.Cell>
                <Table.Cell>   <MathTranform /></Table.Cell> */}
                <Table.Cell><InputExampleIconPosition /></Table.Cell>
                <Table.Cell><InputExampleIconPositionchk /></Table.Cell>
              </Table.Row>
            ))}
          </Table.Body>
        </Table>

      </Grid.Column>
    </Grid.Row>
  );
}



export default function SourceDefinition() {

  const [showTable, setShowTable] = useState(false);
  const [showdropdown, setShowdropdown] = useState(false);
  const [showInput, setShowInput] = useState(false);
  const [selectedOption, setSelectedOption] = useState(null);
  const [fileSrcName, setFileSrcName] = useState(null);


  // let showTable = true;
  const handleClick = () => {
    setShowTable(true);
    setTimeout(() => {
      console.log('_---------data');
      // handleClick();
    }, 100);
    // handleClick();
    // setShowTable(true);
  };

  const handleClick_old = () => {
    console.log(col_name);
    setShowTable(false);
    // setTimeout(() => {
    //   console.log('_---------data');
    //   data();
    // }, 100);
  };


  const DropdownSourcenames = () => {

    const [sourceNames, setSourcenames] = useState([{ value: "", label: "Select Source" },]);

    const handleDropdownChange = (event, data) => {
      setSelectedOption(event);
      console.log('data.value' + event.value);
      source_id = event.value;
      setShowInput(true);
    };
    useEffect(() => {
      let payload = {
        File_data: 'hi',
      }

      var FileUploadCredentials = SheetData();

      axios.post(FileUploadCredentials[1], payload, FileUploadCredentials[0])
        .then(
          response => {
            console.log("Validate Credentials Response!!!", response);
            let table_data = response.data;
            let names = [{ value: "", label: "Select Source" },]
            table_data.map((data) => {
              console.log('data' + data.source_name);

              let obj = {
                value: data.source_id,
                label: data.source_name
              }
              names.push(obj);
            })
            setSourcenames(names);
          }
        )
    }, [])

    return (
      <Select
        clearable
        isDisabled={showdropdown}
        options={sourceNames}
        selection
        placeholder='Choose Source name'
        size='mini'
        onChange={handleDropdownChange}
        value={selectedOption}
      />
    );
  };

  const DropdownExampleClearable = () => {
    const [selectedOption, setSelectedOption] = useState(null);

    const handleDropdownChange = (event, data) => {
      setSelectedOption(data.value);
      // console.log(data.value);
      file_drp_value = data.value;
    };

    return (
      <Dropdown
        clearable
        options={options}
        disabled={showInput}
        selection
        placeholder='Choose an option'
        size='mini'
        onChange={handleDropdownChange}
        value={selectedOption}
      />
    );
  };

  const InputExampleIconPosition5 = () => {
    const [value, newvalue] = useState(undefined)
    function handleChange(event) {
      const value = event.target.value;
      //setFileSrcName(value);
      newvalue(value);
      file_src_name = value;
      if (showdropdown != true) {
        console.log('show');
        setShowdropdown(true);
      }

      // console.log(value)
    }

    // file_src_name = inputRef.current.value;
    return (
      <>
        {showInput ? (<Input disabled icon='folder open outline' iconPosition='left' id='src_name_file' placeholder='Enter Source Name' value={value} onChange={handleChange} />) :
          (<Input icon='folder open outline' iconPosition='left' id='src_name_file' placeholder='Enter Source Name' value={value} onChange={handleChange} />)
        }</>

    )
  }
  const InputExampleIconPosition3 = () => {
    const [fileSrcName, setFileSrcName] = useState('');

    function handleChange(event) {
      const { value } = event.target;
      setFileSrcName(value);
      file_src_description = value;
      // console.log(value)
    }
    // const file_src_description = inputRef.current.value;
    return (
      <>
        {showInput ? (<Input disabled icon='sticky note outline' id='src_description_file' placeholder='Enter the Descriptions' type='text' value={fileSrcName} onChange={handleChange} />) :
          (<Input icon='sticky note outline' id='src_description_file' placeholder='Enter the Descriptions' type='text' value={fileSrcName} onChange={handleChange} />)
        }</>

    )

  }

  const InputIdentifier = () => {
    const [fileSrcName1, setFileSrcName1] = useState('');

    function handleChange(event) {
      const { value } = event.target;
      setFileSrcName1(value);
      file_src_description = value;
      // console.log(value)
    }
    // const file_src_description = inputRef.current.value;
    return (
      <>
        {showInput ? (<Input disabled icon='sticky note outline' id='identifier' placeholder='Enter the identifier' type='text' value={fileSrcName1} onChange={handleChange} />) :
          (<Input icon='sticky note outline' id='identifier' placeholder='Enter the identifier' type='text' value={fileSrcName1} onChange={handleChange} />)
        }
      </>

    )

  }

  const InputExampleIconPosition2 = () => (
    <>
      {showInput ? (<Input disabled type="file" id="myFileInput" accept=".xlsx" icon='upload' style={{ width: '-webkit-fill-available' }} />) :
        (<Input type="file" id="myFileInput" accept=".xlsx" icon='upload' style={{ width: '-webkit-fill-available' }} />)
      }</>

  )

  return (
    <div>
      {/* <h1>hi</h1> */}
      <div className="side" style={{ padding: "10px" }}>
        <Grid columns='equal'>
          <Grid.Row style={{ backgroundColor: "#e9e8d9" }} className="radius">
            <Grid.Column width={3}>
              <InputExampleIconPosition5 />
            </Grid.Column>
            <Grid.Column width={3}>
              <InputIdentifier />
            </Grid.Column>
            <Grid.Column width={3} >
              <InputExampleIconPosition3 />
            </Grid.Column>

            <Grid.Column width={3}>
              <DropdownExampleClearable />
            </Grid.Column>

            <Grid.Column width={3}>
              <InputExampleIconPosition2 />
            </Grid.Column>


          </Grid.Row>
          <Grid.Row style={{ backgroundColor: "#e9e8d9", padding: '0px' }}>
            <Grid.Column width={3}><DropdownSourcenames /></Grid.Column>
            <Grid.Column width={4}></Grid.Column>
            <Grid.Column width={4}></Grid.Column>
            <Grid.Column width={3}>

              <Button onClick={() => getTableData('myFileInput')}>
                <Icon name='filter' /> Fetch Confic
              </Button>
            </Grid.Column>
            <Grid.Column width={2}><Button onClick={() => componentDidMount()}>
              <Icon /> Save
            </Button></Grid.Column>
          </Grid.Row>
          {/* <Grid.Row style={{ backgroundColor:"#e9e8d9" , marginTop:"-10px"}} className="radiusbottom">
                <Grid.Column width={3}>

                    <InputExampleIconPositionNumber/>
                </Grid.Column>
                <Grid.Column width={3}>
                   
                    <InputExampleIconPositionNumber/>
                </Grid.Column>
                <Grid.Column width={3}>
               
                    <InputExampleIconPosition4/>
                </Grid.Column>
                
           </Grid.Row> */}
          <Grid.Row style={{ backgroundColor: "#e9e8d9", borderRadius: "12px", marginTop: "10px" }}>
            <Grid.Column className="overflow">
              <button onClick={handleClick_old} id='dataoff' hidden>Show Table</button>
              <button onClick={handleClick} id='dataon' hidden>Show Table</button>
              {showTable && afterapirunsCol()}
            </Grid.Column>
          </Grid.Row>

          <Grid.Row style={{ backgroundColor: "#e9e8d9", borderRadius: "12px", marginTop: "10px" }}>
            <Grid.Column>
              {showTable && colSheet()}

            </Grid.Column>
          </Grid.Row>
        </Grid>


      </div>
    </div>
  );
}
// App.js
import { useEffect, useState } from "react";
// import "./App.css";
import "./etlsecound.css";
import hdfcs from './../../../assets/images/banks/thermax.png';
function VendorDr() 
{
  

  return (
  <div>
    <table className="table" style={{overFlowX: "scroll !important"}}>
    <tr >
        <td colspan="15" className="bold"><img src={hdfcs} alt="" height="70px" width="90px" />THERMAX LIMITED </td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
   <br></br>
    <tr className="bold">
        <td colspan="4">VRS AS ON 31 MARCH 2022</td>
        <td></td>
        <td></td>
        <td></td>
        <td colspan="3"> VENDOR DR AMT </td>
        <td colspan="3"> VENDOR CR AMT </td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr className="bold">
        <td colspan="4">VENDOR DEBITS AND CREDITS NOT MATCHED</td>
        
        <td></td>
        <td></td>
        <td> TOTAL </td>
        <td colspan="3"> 7,148,289.38 </td>
        <td colspan="3"> 1,384,590.07 </td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <br></br>
    <tr className="fontcolor">
        <td>DATE</td>
        <td>PARTICULARS</td>
        <td>VCH TYPE</td>
        <td>VCH NO.</td>
        <td>Cr/Dr</td>
        <td>DEBIT</td>
        <td>CREDIT</td>
        <td>BALANCE</td>
        <td>INVOICE/ PO NO.</td>
        <td>GRN NO</td>
        <td>GST AMT</td>
        <td>TDS AMT</td>
        <td>RETENTION</td>
        <td>UTR NO</td>
        <td>REFERENCE TEXT</td>
        <td>Ref</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td>17-04-21</td>
        <td>Fabrication Machining</td>
        <td>Journal</td>
        <td>47</td>
        <td>Dr</td>
        <td>181960.78</td>
        <td>0</td>
        <td>181960.78</td>
        <td></td>
        <td></td>
        <td>0.00</td>
        <td>0.00</td>
        <td></td>
        <td></td>
        <td>ERS-5000013267-1826995</td>
        <td>181492.44</td>
        <td>-468.34</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td>21-05-21</td>
        <td>Fabrication Machining</td>
        <td>Journal</td>
        <td>225</td>
        <td>Dr</td>
        <td>121307.19</td>
        <td>0</td>
        <td>121307.19</td>
        <td></td>
        <td></td>
        <td>0.00</td>
        <td>0.00</td>
        <td></td>
        <td></td>
        <td>ERS-5000012994-1812142</td>
        <td>121189</td>
        <td>-118.19</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td>11-01-22</td>
        <td>Tax Deducted at Source (F.Y 2021-22)-NSDL</td>
        <td>Journal</td>
        <td>2139</td>
        <td>Cr</td>
        <td>0</td>
        <td>5499</td>
        <td>5499.00</td>
        <td></td>
        <td></td>
        <td>0.00</td>
        <td>0.00</td>
        <td></td>
        <td></td>
        <td>Unmatched TDS</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td>11-01-22</td>
        <td>Tax Deducted at Source (F.Y 2021-22)-NSDL</td>
        <td>Journal</td>
        <td>2140</td>
        <td>Dr</td>
        <td>3850</td>
        <td>0</td>
        <td>3850.00</td>
        <td></td>
        <td></td>
        <td>0.00</td>
        <td>0.00</td>
        <td></td>
        <td></td>
        <td>Unmatched TDS</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td>21-01-22</td>
        <td>Canara Bank-CC( 4163261000013)/8019777.73/-</td>
        <td>Receipt</td>
        <td>130</td>
        <td>Cr</td>
        <td>0</td>
        <td>125801.1</td>
        <td>125801.10</td>
        <td></td>
        <td></td>
        <td>0.00</td>
        <td>0.00</td>
        <td></td>
        <td></td>
        <td>Matched with payment</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td>24-01-22</td>
        <td>Fabrication Machining</td>
        <td>Journal</td>
        <td>2249</td>
        <td>Dr</td>
        <td>1599391.47</td>
        <td>0</td>
        <td>1599391.47</td>
        <td></td>
        <td></td>
        <td>0.00</td>
        <td>0.00</td>
        <td></td>
        <td></td>
        <td>Unmatched invoice</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td>25-01-22</td>
        <td>Canara Bank-CC( 4163261000013)/8019777.73/-</td>
        <td>Receipt</td>
        <td>131</td>
        <td>Cr</td>
        <td>0</td>
        <td>75480.66</td>
        <td>75480.66</td>
        <td></td>
        <td></td>
        <td>0.00</td>
        <td>0.00</td>
        <td></td>
        <td></td>
        <td>Matched with payment</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td>12-02-22</td>
        <td>Fabrication Machining</td>
        <td>Journal</td>
        <td>2475</td>
        <td>Dr</td>
        <td>204847.76</td>
        <td>0</td>
        <td>204847.76</td>
        <td></td>
        <td></td>
        <td>0.00</td>
        <td>0.00</td>
        <td></td>
        <td></td>
        <td>Unmatched invoice</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td>16-02-22</td>
        <td>Tax Deducted at Source (F.Y 2021-22)-NSDL</td>
        <td>Journal</td>
        <td>2507</td>
        <td>Dr</td>
        <td>2264</td>
        <td>0</td>
        <td>2264.00</td>
        <td></td>
        <td></td>
        <td>0.00</td>
        <td>0.00</td>
        <td></td>
        <td></td>
        <td>Unmatched TDS</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td>07-03-22</td>
        <td>Canara Bank-CC( 4163261000013)/8019777.73/-</td>
        <td>Receipt</td>
        <td>150</td>
        <td>Cr</td>
        <td>0</td>
        <td>1177809.31</td>
        <td>1177809.31</td>
        <td></td>
        <td></td>
        <td>0.00</td>
        <td>0.00</td>
        <td></td>
        <td></td>
        <td>Matched with payment</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td>25-03-22</td>
        <td>Fabrication Machining</td>
        <td>Journal</td>
        <td>2810</td>
        <td>Dr</td>
        <td>1786495.16</td>
        <td>0</td>
        <td>1786495.16</td>
        <td></td>
        <td></td>
        <td>0.00</td>
        <td>0.00</td>
        <td></td>
        <td></td>
        <td>Unmatched invoice</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td>31-03-22</td>
        <td>Fabrication Machining</td>
        <td>Journal</td>
        <td>2857</td>
        <td>Dr</td>
        <td>3248173.02</td>
        <td>0</td>
        <td>3248173.02</td>
        <td></td>
        <td></td>
        <td>0.00</td>
        <td>0.00</td>
        <td></td>
        <td></td>
        <td>Unmatched invoice</td>
    </tr>
</table>
  </div>
  )
}



export default VendorDr;
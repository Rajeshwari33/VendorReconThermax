// App.js
import { useEffect, useState } from "react";
// import "./App.css";
import "./etlsecound.css";
import hdfcs from './../../../assets/images/banks/thermax.png';
function ThermaxDr() 
{
  

  return (
  <div className="scroll">
    <table className="table">
    <tr>
        <td colspan="15" className="bold"><img src={hdfcs} alt="" height="70px" width="90px" /> THERMAX LIMITED </td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <br></br>
    <tr  className="bold">
        <td colspan="5">VRS AS ON 31 MARCH 2022</td>
        <td></td>
        <td></td>
        <td></td>
    
        <td colspan="3"> TMX CR AMOUNT </td>
        <td colspan="3"> TMX DR AMOUNT </td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr  className="bold">
        <td colspan="5">THERMAX DEBITS AND CREDITS NOT MATCHED</td>
        <td></td>
        <td></td>
        
        <td>TOTAL</td>
        <td colspan="3"> 5,372,337.79 </td>
        <td colspan="3"> 5,567,230.11 </td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <br></br>
    <tr className="fontcolor">
        <td>DIV</td>
        <td>GL CODE</td>
        <td>GL DESC</td>
        <td>VENDOR CODE</td>
        <td >VENDOR NAME</td>
        <td>VENDOR SITE</td>
        <td>DOC CATEGORY</td>
        <td>DOC NUMBER</td>
        <td>DOC DATE</td>
        <td>INVOICE NO</td>
        <td>SUPPLIER BILL NO</td>
        <td>GL DATE</td>
        <td>DEBIT AMOUNT</td>
        <td>CREDIT AMOUNT</td>
        <td>INVOICE NUM1</td>
        <td>INVOICE PAYMENT AMT</td>
        <td>NEWGEN WFID</td>
        <td>NARRATION</td>
        <td>TRAN TYPE</td>
        <td>OPENING PERIOD</td>
        <td>CLOSING PERIOD</td>
        <td>CLOSING BALANCE</td>
        <td>SOURCE1</td>
        <td>INVOICE TYPE LOOKUP CODE</td>
        <td>CHECK ID</td>
        <td>SR NO</td>
        <td>Event Type Code</td>
        <td></td>
        <td>Reason</td>
        <td>Ref no.</td>
    </tr>
    <tr>
        <td>08</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td >SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>3703005</td>
        <td>23-03-21</td>
        <td>ERS-4000025495-1771142</td>
        <td>SFE/IN/223/20-21</td>
        <td>20-04-21</td>
        <td>0</td>
        <td>1182440.82</td>
        <td>ERS-4000025495-1771142</td>
        <td>0.00</td>
        <td>PO-0000087992-Invoice</td>
        <td>Receipt Invoice automatically created on 23-MAR-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td></td>
        <td>Unmatched invoice due to Previous year invocie</td>
        <td></td>
    </tr>
    <tr>
        <td>08</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>3703006</td>
        <td>23-03-21</td>
        <td>ERS-4000025496-1771143</td>
        <td>SFE/IN/224/20-21</td>
        <td>20-04-21</td>
        <td>0</td>
        <td>71414.03</td>
        <td>ERS-4000025496-1771143</td>
        <td>0.00</td>
        <td>PO-0000087993-Invoice</td>
        <td>Receipt Invoice automatically created on 23-MAR-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td></td>
        <td>Unmatched invoice due to Previous year invocie</td>
        <td></td>
    </tr>
    <tr>
        <td>08</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>3755154</td>
        <td>21-06-21</td>
        <td>ERS-5000012813-1804272</td>
        <td>SFE/IN/226/20-21</td>
        <td>24-06-21</td>
        <td>0</td>
        <td>3675623</td>
        <td>ERS-5000012813-1804272</td>
        <td>0.00</td>
        <td>PO-0000111720-Invoice</td>
        <td>Receipt Invoice automatically created on 21-JUN-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td></td>
        <td>Unmatched invoice due to Previous year invocie</td>
        <td></td>
    </tr>
    <tr>
        <td>08</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CRM INV</td>
        <td>2869882</td>
        <td>30-08-21</td>
        <td>ERS-4000026866-1836033-TDS-CM-805281</td>
        <td>SFE/IN/049/21-22-TDS</td>
        <td>07-09-21</td>
        <td>1680</td>
        <td>0</td>
        <td>ERS-4000026866-1836033-TDS-CM-805281</td>
        <td>0.00</td>
        <td>PO-0000144918-Invoice</td>
        <td>ERS-4000026866-1836033-TDS-CM-805281</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td></td>
        <td>2</td>
        <td>CREDIT MEMO VALIDATED</td>
        <td></td>
        <td>Unmatched due to TDS</td>
        <td></td>
    </tr>
    <tr>
        <td>08</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>3836701</td>
        <td>06-10-21</td>
        <td>ERS-4000027228-1850402-RTN-TDS-SI-816554</td>
        <td>SFE/IN/075/21-22-TDS-SI-RTN-1</td>
        <td>06-10-21</td>
        <td>0</td>
        <td>1925</td>
        <td>ERS-4000027228-1850402-RTN-TDS-SI-816554</td>
        <td>0.00</td>
        <td>PO-0000157982-Invoice</td>
        <td>ERS-4000027228-1850402-RTN-TDS-SI-816554</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td></td>
        <td>RTN TDS difference</td>
        <td></td>
    </tr>
    <tr>
        <td>08</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>3836747</td>
        <td>06-10-21</td>
        <td>ERS-4000027226-1850401-RTN-TDS-SI-816594</td>
        <td>SFE/IN/076/21-22-TDS-SI-RTN-1</td>
        <td>06-10-21</td>
        <td>0</td>
        <td>1925</td>
        <td>ERS-4000027226-1850401-RTN-TDS-SI-816594</td>
        <td>0.00</td>
        <td>PO-0000157954-Invoice</td>
        <td>ERS-4000027226-1850401-RTN-TDS-SI-816594</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td></td>
        <td>RTN TDS difference</td>
        <td></td>
    </tr>
    <tr>
        <td>08</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CRM INV</td>
        <td>2881810</td>
        <td>30-09-21</td>
        <td>ERS-4000027228-1850402-TDS-CM-816553</td>
        <td>SFE/IN/075/21-22-TDS</td>
        <td>06-10-21</td>
        <td>2750</td>
        <td>0</td>
        <td>ERS-4000027228-1850402-TDS-CM-816553</td>
        <td>0.00</td>
        <td>PO-0000157982-Invoice</td>
        <td>ERS-4000027228-1850402-TDS-CM-816553</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td></td>
        <td>2</td>
        <td>CREDIT MEMO VALIDATED</td>
        <td></td>
        <td>Unmatched due to TDS</td>
        <td></td>
    </tr>
    <tr>
        <td>08</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CRM INV</td>
        <td>2881856</td>
        <td>30-09-21</td>
        <td>ERS-4000027226-1850401-TDS-CM-816593</td>
        <td>SFE/IN/076/21-22-TDS</td>
        <td>06-10-21</td>
        <td>2750</td>
        <td>0</td>
        <td>ERS-4000027226-1850401-TDS-CM-816593</td>
        <td>0.00</td>
        <td>PO-0000157954-Invoice</td>
        <td>ERS-4000027226-1850401-TDS-CM-816593</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td></td>
        <td>2</td>
        <td>CREDIT MEMO VALIDATED</td>
        <td></td>
        <td>Unmatched due to TDS</td>
        <td></td>
    </tr>
    <tr>
        <td>08</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CRM INV</td>
        <td>2890770</td>
        <td>28-10-21</td>
        <td>ERS-5000013928-1860518-TDS-CM-824952</td>
        <td>SFE/IN/081/21-22-TDS</td>
        <td>31-10-21</td>
        <td>9</td>
        <td>0</td>
        <td>ERS-5000013928-1860518-TDS-CM-824952</td>
        <td>0.00</td>
        <td>PO-0000169935-Invoice</td>
        <td>ERS-5000013928-1860518-TDS-CM-824952</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td></td>
        <td>2</td>
        <td>CREDIT MEMO VALIDATED</td>
        <td></td>
        <td>Unmatched due to TDS</td>
        <td></td>
    </tr>
    <tr>
        <td>08</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CRM INV</td>
        <td>2898223</td>
        <td>27-09-21</td>
        <td>ERS-4000027141-1847382-TDS-CM-831908</td>
        <td></td>
        <td>01-11-21</td>
        <td>342</td>
        <td>0</td>
        <td>ERS-4000027141-1847382-TDS-CM-831908</td>
        <td>0.00</td>
        <td></td>
        <td>ERS-4000027141-1847382-TDS-CM-831908</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td></td>
        <td>2</td>
        <td>CREDIT MEMO VALIDATED</td>
        <td></td>
        <td>Unmatched due to TDS</td>
        <td></td>
    </tr>
    <tr>
        <td>08</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>3902779</td>
        <td>31-12-21</td>
        <td>ERS-4000027487-1862443-RTN-TDS-SI-842899</td>
        <td>SFE/IN/090/21-22-TDS-SI-RTN-1</td>
        <td>31-12-21</td>
        <td>0</td>
        <td>963</td>
        <td>ERS-4000027487-1862443-RTN-TDS-SI-842899</td>
        <td>0.00</td>
        <td>PO-0000194296-Invoice</td>
        <td>ERS-4000027487-1862443-RTN-TDS-SI-842899</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td></td>
        <td>RTN TDS difference</td>
        <td></td>
    </tr>
    <tr>
        <td>08</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>3907405</td>
        <td>31-12-21</td>
        <td>ERS-4000027486-1862442-RTN-TDS-SI-846978</td>
        <td></td>
        <td>31-12-21</td>
        <td>0</td>
        <td>567</td>
        <td>ERS-4000027486-1862442-RTN-TDS-SI-846978</td>
        <td>0.00</td>
        <td></td>
        <td>ERS-4000027486-1862442-RTN-TDS-SI-846978</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td></td>
        <td>RTN TDS difference</td>
        <td></td>
    </tr>
    <tr>
        <td>08</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>3905486</td>
        <td>31-12-21</td>
        <td>ERS-4000027488-1862444-RTN-TDS-SI-845285</td>
        <td></td>
        <td>31-12-21</td>
        <td>0</td>
        <td>481</td>
        <td>ERS-4000027488-1862444-RTN-TDS-SI-845285</td>
        <td>0.00</td>
        <td></td>
        <td>ERS-4000027488-1862444-RTN-TDS-SI-845285</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td></td>
        <td>RTN TDS difference</td>
        <td></td>
    </tr>
    <tr>
        <td>08</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CRM INV</td>
        <td>2914191</td>
        <td>30-11-21</td>
        <td>ERS-4000027673-1872382-TDS-CM-846971</td>
        <td>SFE/IN/095/21-22-TDS</td>
        <td>31-12-21</td>
        <td>93</td>
        <td>0</td>
        <td>ERS-4000027673-1872382-TDS-CM-846971</td>
        <td>0.00</td>
        <td>PO-0000194294-Invoice</td>
        <td>ERS-4000027673-1872382-TDS-CM-846971</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td></td>
        <td>2</td>
        <td>CREDIT MEMO VALIDATED</td>
        <td></td>
        <td>Unmatched due to TDS</td>
        <td></td>
    </tr>
    <tr>
        <td>08</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CRM INV</td>
        <td>2911820</td>
        <td>30-11-21</td>
        <td>ERS-4000027675-1872383-TDS-CM-844793</td>
        <td>SFE/IN/103/21-22-TDS</td>
        <td>31-12-21</td>
        <td>93</td>
        <td>0</td>
        <td>ERS-4000027675-1872383-TDS-CM-844793</td>
        <td>0.00</td>
        <td>PO-0000194285-Invoice</td>
        <td>ERS-4000027675-1872383-TDS-CM-844793</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td></td>
        <td>2</td>
        <td>CREDIT MEMO VALIDATED</td>
        <td></td>
        <td>Unmatched due to TDS</td>
        <td></td>
    </tr>
    <tr>
        <td>08</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>3904219</td>
        <td>31-12-21</td>
        <td>ERS-4000027439-1860517-RTN-TDS-SI-844263</td>
        <td>SFE/IN/086/21-22-TDS-SI-RTN-1</td>
        <td>31-12-21</td>
        <td>0</td>
        <td>1443</td>
        <td>ERS-4000027439-1860517-RTN-TDS-SI-844263</td>
        <td>0.00</td>
        <td>PO-0000194286-Invoice</td>
        <td>ERS-4000027439-1860517-RTN-TDS-SI-844263</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td></td>
        <td>RTN TDS difference</td>
        <td></td>
    </tr>
    <tr>
        <td>08</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CRM INV</td>
        <td>2909857</td>
        <td>31-10-21</td>
        <td>ERS-4000027487-1862443-TDS-CM-842898</td>
        <td>SFE/IN/090/21-22-TDS</td>
        <td>31-12-21</td>
        <td>1375</td>
        <td>0</td>
        <td>ERS-4000027487-1862443-TDS-CM-842898</td>
        <td>0.00</td>
        <td>PO-0000194296-Invoice</td>
        <td>ERS-4000027487-1862443-TDS-CM-842898</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td></td>
        <td>2</td>
        <td>CREDIT MEMO VALIDATED</td>
        <td></td>
        <td>Unmatched due to TDS</td>
        <td></td>
    </tr>
    <tr>
        <td>08</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CRM INV</td>
        <td>2911259</td>
        <td>28-10-21</td>
        <td>ERS-4000027439-1860517-TDS-CM-844262</td>
        <td>SFE/IN/086/21-22-TDS</td>
        <td>31-12-21</td>
        <td>2062</td>
        <td>0</td>
        <td>ERS-4000027439-1860517-TDS-CM-844262</td>
        <td>0.00</td>
        <td>PO-0000194286-Invoice</td>
        <td>ERS-4000027439-1860517-TDS-CM-844262</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td></td>
        <td>2</td>
        <td>CREDIT MEMO VALIDATED</td>
        <td></td>
        <td>Unmatched due to TDS</td>
        <td></td>
    </tr>
    <tr>
        <td>08</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CRM INV</td>
        <td>2914202</td>
        <td>31-10-21</td>
        <td>ERS-4000027486-1862442-TDS-CM-846977</td>
        <td>SFE/IN/089/21-22-TDS</td>
        <td>31-12-21</td>
        <td>1375</td>
        <td>0</td>
        <td>ERS-4000027486-1862442-TDS-CM-846977</td>
        <td>0.00</td>
        <td>PO-0000194293-Invoice</td>
        <td>ERS-4000027486-1862442-TDS-CM-846977</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td></td>
        <td>2</td>
        <td>CREDIT MEMO VALIDATED</td>
        <td></td>
        <td>Unmatched due to TDS</td>
        <td></td>
    </tr>
    <tr>
        <td>08</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CRM INV</td>
        <td>2907968</td>
        <td>30-11-21</td>
        <td>ERS-4000027672-1872381-TDS-CM-841110</td>
        <td>SFE/IN/094/21-22-TDS</td>
        <td>31-12-21</td>
        <td>93</td>
        <td>0</td>
        <td>ERS-4000027672-1872381-TDS-CM-841110</td>
        <td>0.00</td>
        <td>PO-0000194297-Invoice</td>
        <td>ERS-4000027672-1872381-TDS-CM-841110</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td></td>
        <td>2</td>
        <td>CREDIT MEMO VALIDATED</td>
        <td></td>
        <td>Unmatched due to TDS</td>
        <td></td>
    </tr>
    <tr>
        <td>08</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CRM INV</td>
        <td>2912330</td>
        <td>31-10-21</td>
        <td>ERS-4000027488-1862444-TDS-CM-845282</td>
        <td>SFE/lN/091/21-22-TDS</td>
        <td>31-12-21</td>
        <td>687</td>
        <td>0</td>
        <td>ERS-4000027488-1862444-TDS-CM-845282</td>
        <td>0.00</td>
        <td>PO-0000194295-Invoice</td>
        <td>ERS-4000027488-1862444-TDS-CM-845282</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td></td>
        <td>2</td>
        <td>CREDIT MEMO VALIDATED</td>
        <td></td>
        <td>Unmatched due to TDS</td>
        <td></td>
    </tr>
    <tr>
        <td>08</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>3907600</td>
        <td>09-01-22</td>
        <td>ERS-4000027486-1862442-RTN-TDS-SI-846992</td>
        <td></td>
        <td>09-01-22</td>
        <td>0</td>
        <td>396</td>
        <td>ERS-4000027486-1862442-RTN-TDS-SI-846992</td>
        <td>0.00</td>
        <td></td>
        <td>ERS-4000027486-1862442-RTN-TDS-SI-846992</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td></td>
        <td>RTN TDS difference</td>
        <td></td>
    </tr>
    <tr>
        <td>08</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CRM INV</td>
        <td>2919174</td>
        <td>30-12-21</td>
        <td>ERS-4000028002-1887105-TDS-CM-851725</td>
        <td>SFE/IN/126/21-22-TDS</td>
        <td>14-01-22</td>
        <td>1152</td>
        <td>0</td>
        <td>ERS-4000028002-1887105-TDS-CM-851725</td>
        <td>0.00</td>
        <td>PO-0000202840-Invoice</td>
        <td>ERS-4000028002-1887105-TDS-CM-851725</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td></td>
        <td>2</td>
        <td>CREDIT MEMO VALIDATED</td>
        <td></td>
        <td>Unmatched due to TDS</td>
        <td></td>
    </tr>
    <tr>
        <td>08</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CRM INV</td>
        <td>2919151</td>
        <td>30-12-21</td>
        <td>ERS-4000027985-1887104-TDS-CM-851713</td>
        <td>SFE/IN/138/21-22-TDS</td>
        <td>14-01-22</td>
        <td>1302</td>
        <td>0</td>
        <td>ERS-4000027985-1887104-TDS-CM-851713</td>
        <td>0.00</td>
        <td>PO-0000202839-Invoice</td>
        <td>ERS-4000027985-1887104-TDS-CM-851713</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td></td>
        <td>2</td>
        <td>CREDIT MEMO VALIDATED</td>
        <td></td>
        <td>Unmatched due to TDS</td>
        <td></td>
    </tr>
    <tr>
        <td>08</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>3914962</td>
        <td>14-01-22</td>
        <td>ERS-4000027668-1872378-RTN-TDS-SI-851640</td>
        <td></td>
        <td>14-01-22</td>
        <td>0</td>
        <td>967</td>
        <td>ERS-4000027668-1872378-RTN-TDS-SI-851640</td>
        <td>0.00</td>
        <td></td>
        <td>ERS-4000027668-1872378-RTN-TDS-SI-851640</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td></td>
        <td>RTN TDS difference</td>
        <td></td>
    </tr>
    <tr>
        <td>08</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>3915031</td>
        <td>14-01-22</td>
        <td>ERS-4000027985-1887104-RTN-TDS-SI-851714</td>
        <td></td>
        <td>14-01-22</td>
        <td>0</td>
        <td>911</td>
        <td>ERS-4000027985-1887104-RTN-TDS-SI-851714</td>
        <td>0.00</td>
        <td></td>
        <td>ERS-4000027985-1887104-RTN-TDS-SI-851714</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td></td>
        <td>RTN TDS difference</td>
        <td></td>
    </tr>
    <tr>
        <td>08</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>3915048</td>
        <td>14-01-22</td>
        <td>ERS-4000028002-1887105-RTN-TDS-SI-851726</td>
        <td></td>
        <td>14-01-22</td>
        <td>0</td>
        <td>806</td>
        <td>ERS-4000028002-1887105-RTN-TDS-SI-851726</td>
        <td>0.00</td>
        <td></td>
        <td>ERS-4000028002-1887105-RTN-TDS-SI-851726</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td></td>
        <td>RTN TDS difference</td>
        <td></td>
    </tr>
    <tr>
        <td>08</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CRM INV</td>
        <td>2919059</td>
        <td>30-11-21</td>
        <td>ERS-4000027668-1872378-TDS-CM-851638</td>
        <td>SFE/IN/116/21-22-TDS</td>
        <td>14-01-22</td>
        <td>1382</td>
        <td>0</td>
        <td>ERS-4000027668-1872378-TDS-CM-851638</td>
        <td>0.00</td>
        <td>PO-0000202837-Invoice</td>
        <td>ERS-4000027668-1872378-TDS-CM-851638</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td></td>
        <td>2</td>
        <td>CREDIT MEMO VALIDATED</td>
        <td></td>
        <td>Unmatched due to TDS</td>
        <td></td>
    </tr>
    <tr>
        <td>08</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI LABOUR EPAY</td>
        <td>51406615</td>
        <td>20-01-22</td>
        <td>51306615</td>
        <td>SFE/IN/115/21-22</td>
        <td>20-01-22</td>
        <td>125801.1</td>
        <td>0</td>
        <td>ERS-4000027670-1872379</td>
        <td>97845.3</td>
        <td>PO-0000202853-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3744750</td>
        <td>2</td>
        <td></td>
        <td></td>
        <td>To be matched with vendors receipt</td>
        <td>130</td>
    </tr>
    <tr>
        <td>08</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI LABOUR EPAY</td>
        <td>51406615</td>
        <td>20-01-22</td>
        <td>51306615</td>
        <td>SFE/IN/095/21-22</td>
        <td>20-01-22</td>
        <td>125801.1</td>
        <td>0</td>
        <td>ERS-4000027673-1872382</td>
        <td>27955.8</td>
        <td>PO-0000194294-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3744750</td>
        <td>2</td>
        <td></td>
        <td></td>
        <td>To be matched with vendors receipt</td>
        <td>130</td>
    </tr>
    <tr>
        <td>08</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI LABOUR EPAY</td>
        <td>51406665</td>
        <td>24-01-22</td>
        <td>51306665</td>
        <td>SFE/IN/095/21-22</td>
        <td>24-01-22</td>
        <td>75480.66</td>
        <td>0</td>
        <td>ERS-4000027673-1872382</td>
        <td>16773.48</td>
        <td>PO-0000194294-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3745991</td>
        <td>2</td>
        <td></td>
        <td></td>
        <td>To be matched with vendors receipt</td>
        <td>131</td>
    </tr>
    <tr>
        <td>08</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI LABOUR EPAY</td>
        <td>51406665</td>
        <td>24-01-22</td>
        <td>51306665</td>
        <td>SFE/IN/115/21-22</td>
        <td>24-01-22</td>
        <td>75480.66</td>
        <td>0</td>
        <td>ERS-4000027670-1872379</td>
        <td>58707.18</td>
        <td>PO-0000202853-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3745991</td>
        <td>2</td>
        <td></td>
        <td></td>
        <td>To be matched with vendors receipt</td>
        <td>131</td>
    </tr>
    <tr>
        <td>08</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>3934383</td>
        <td>05-02-22</td>
        <td>ERS-4000028069-1888025-RTN-TDS-SI-862209</td>
        <td></td>
        <td>05-02-22</td>
        <td>0</td>
        <td>547</td>
        <td>ERS-4000028069-1888025-RTN-TDS-SI-862209</td>
        <td>0</td>
        <td></td>
        <td>ERS-4000028069-1888025-RTN-TDS-SI-862209</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td></td>
        <td>RTN TDS difference</td>
        <td></td>
    </tr>
    <tr>
        <td>08</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CRM INV</td>
        <td>2930139</td>
        <td>31-12-21</td>
        <td>ERS-4000028069-1888025-TDS-CM-862208</td>
        <td>SFE/IN/140/21-22-TDS</td>
        <td>05-02-22</td>
        <td>781</td>
        <td>0</td>
        <td>ERS-4000028069-1888025-TDS-CM-862208</td>
        <td>0</td>
        <td>PO-0000207842-Invoice</td>
        <td>ERS-4000028069-1888025-TDS-CM-862208</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td></td>
        <td>2</td>
        <td>CREDIT MEMO VALIDATED</td>
        <td></td>
        <td>Unmatched due to TDS</td>
        <td></td>
    </tr>
    <tr>
        <td>08</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>3766195</td>
        <td>10-07-21</td>
        <td>ERS-5000012994-1812142</td>
        <td>SFE/IN/013/21-22</td>
        <td>15-02-22</td>
        <td>0</td>
        <td>121189</td>
        <td>ERS-5000012994-1812142</td>
        <td>0</td>
        <td>PO-0000120351-Invoice</td>
        <td>Receipt Invoice automatically created on 10-JUL-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td></td>
        <td>Unmatched invoice due to Rs.118.19 diff</td>
        <td>225</td>
    </tr>
    <tr>
        <td>08</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>51233185</td>
        <td>16-02-22</td>
        <td>511033203</td>
        <td>SFE/IN/054/21-22</td>
        <td>16-02-22</td>
        <td>274117.5</td>
        <td>0</td>
        <td>ERS-5000013480-1837461</td>
        <td>171396.5</td>
        <td>PO-0000144747-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3755929</td>
        <td>2</td>
        <td></td>
        <td></td>
        <td>To be check since no pendency in vendor</td>
        <td>240</td>
    </tr>
    <tr>
        <td>08</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI LABOUR EPAY</td>
        <td>51407076</td>
        <td>03-03-22</td>
        <td>51307076</td>
        <td>SFE/IN/138/21-22</td>
        <td>03-03-22</td>
        <td>1177809.31</td>
        <td>0</td>
        <td>ERS-4000027985-1887104</td>
        <td>234359.73</td>
        <td>PO-0000202839-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3761297</td>
        <td>2</td>
        <td></td>
        <td></td>
        <td>To be matched with vendors receipt</td>
        <td>150</td>
    </tr>
    <tr>
        <td>08</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI LABOUR EPAY</td>
        <td>51407076</td>
        <td>03-03-22</td>
        <td>51307076</td>
        <td>SFE/IN/138/21-22</td>
        <td>03-03-22</td>
        <td>1177809.31</td>
        <td>0</td>
        <td>ERS-4000027985-1887104</td>
        <td>390599.2</td>
        <td>PO-0000202839-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3761297</td>
        <td>2</td>
        <td></td>
        <td></td>
        <td>To be matched with vendors receipt</td>
        <td>150</td>
    </tr>
    <tr>
        <td>08</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI LABOUR EPAY</td>
        <td>51407076</td>
        <td>03-03-22</td>
        <td>51307076</td>
        <td>SFE/IN/126/21-22</td>
        <td>03-03-22</td>
        <td>1177809.31</td>
        <td>0</td>
        <td>ERS-4000028002-1887105</td>
        <td>345531.55</td>
        <td>PO-0000202840-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3761297</td>
        <td>2</td>
        <td></td>
        <td></td>
        <td>To be matched with vendors receipt</td>
        <td>150</td>
    </tr>
    <tr>
        <td>08</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI LABOUR EPAY</td>
        <td>51407076</td>
        <td>03-03-22</td>
        <td>51307076</td>
        <td>SFE/IN/126/21-22</td>
        <td>03-03-22</td>
        <td>1177809.31</td>
        <td>0</td>
        <td>ERS-4000028002-1887105</td>
        <td>207318.83</td>
        <td>PO-0000202840-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3761297</td>
        <td>2</td>
        <td></td>
        <td></td>
        <td>To be matched with vendors receipt</td>
        <td>150</td>
    </tr>
    <tr>
        <td>08</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CRM INV</td>
        <td>2946071</td>
        <td>31-01-22</td>
        <td>ERS-4000028325-1899878-TDS-CM-877309</td>
        <td>SFE/IN/155/21-22-TDS</td>
        <td>04-03-22</td>
        <td>1215</td>
        <td>0</td>
        <td>ERS-4000028325-1899878-TDS-CM-877309</td>
        <td>0</td>
        <td>PO-0000223675-Invoice</td>
        <td>ERS-4000028325-1899878-TDS-CM-877309</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td></td>
        <td>2</td>
        <td>CREDIT MEMO VALIDATED</td>
        <td></td>
        <td>Unmatched due to TDS</td>
        <td></td>
    </tr>
    <tr>
        <td>08</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>3963814</td>
        <td>04-03-22</td>
        <td>ERS-4000028325-1899878-RTN-TDS-SI-877311</td>
        <td></td>
        <td>04-03-22</td>
        <td>0</td>
        <td>851</td>
        <td>ERS-4000028325-1899878-RTN-TDS-SI-877311</td>
        <td>0</td>
        <td></td>
        <td>ERS-4000028325-1899878-RTN-TDS-SI-877311</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td></td>
        <td>RTN TDS difference</td>
        <td></td>
    </tr>
    <tr>
        <td>08</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>3982532</td>
        <td>21-03-22</td>
        <td>ERS-4000028647-1913517-RTN-TDS-SI-887044</td>
        <td></td>
        <td>21-03-22</td>
        <td>0</td>
        <td>1349</td>
        <td>ERS-4000028647-1913517-RTN-TDS-SI-887044</td>
        <td>0</td>
        <td></td>
        <td>ERS-4000028647-1913517-RTN-TDS-SI-887044</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td></td>
        <td>RTN TDS difference</td>
        <td></td>
    </tr>
    <tr>
        <td>08</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CRM INV</td>
        <td>2956202</td>
        <td>28-02-22</td>
        <td>ERS-4000028646-1913516-TDS-CM-887050</td>
        <td>SFE/IN/175/21-22-TDS</td>
        <td>21-03-22</td>
        <td>1927</td>
        <td>0</td>
        <td>ERS-4000028646-1913516-TDS-CM-887050</td>
        <td>0</td>
        <td>PO-0000233459-Invoice</td>
        <td>ERS-4000028646-1913516-TDS-CM-887050</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td></td>
        <td>2</td>
        <td>CREDIT MEMO VALIDATED</td>
        <td></td>
        <td>Unmatched due to TDS</td>
        <td></td>
    </tr>
    <tr>
        <td>08</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>3982544</td>
        <td>21-03-22</td>
        <td>ERS-4000028646-1913516-RTN-TDS-SI-887051</td>
        <td></td>
        <td>21-03-22</td>
        <td>0</td>
        <td>1349</td>
        <td>ERS-4000028646-1913516-RTN-TDS-SI-887051</td>
        <td>0</td>
        <td></td>
        <td>ERS-4000028646-1913516-RTN-TDS-SI-887051</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td></td>
        <td>RTN TDS difference</td>
        <td></td>
    </tr>
    <tr>
        <td>08</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CRM INV</td>
        <td>2956195</td>
        <td>28-02-22</td>
        <td>ERS-4000028647-1913517-TDS-CM-887043</td>
        <td>SFE/IN/176/21-22-TDS</td>
        <td>21-03-22</td>
        <td>1927</td>
        <td>0</td>
        <td>ERS-4000028647-1913517-TDS-CM-887043</td>
        <td>0</td>
        <td>PO-0000233372-Invoice</td>
        <td>ERS-4000028647-1913517-TDS-CM-887043</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td></td>
        <td>2</td>
        <td>CREDIT MEMO VALIDATED</td>
        <td></td>
        <td>Unmatched due to TDS</td>
        <td></td>
    </tr>
    <tr>
        <td>08</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CRM INV</td>
        <td>2958572</td>
        <td>28-02-22</td>
        <td>ERS-4000028648-1913518-TDS-CM-889303</td>
        <td>SFE/IN/177/21-22-TDS</td>
        <td>24-03-22</td>
        <td>1927</td>
        <td>0</td>
        <td>ERS-4000028648-1913518-TDS-CM-889303</td>
        <td>0</td>
        <td>PO-0000233373-Invoice</td>
        <td>ERS-4000028648-1913518-TDS-CM-889303</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td></td>
        <td>2</td>
        <td>CREDIT MEMO VALIDATED</td>
        <td></td>
        <td>Unmatched due to TDS</td>
        <td></td>
    </tr>
    <tr>
        <td>08</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>3987090</td>
        <td>24-03-22</td>
        <td>ERS-4000028648-1913518-RTN-TDS-SI-889304</td>
        <td></td>
        <td>24-03-22</td>
        <td>0</td>
        <td>1349</td>
        <td>ERS-4000028648-1913518-RTN-TDS-SI-889304</td>
        <td>0</td>
        <td></td>
        <td>ERS-4000028648-1913518-RTN-TDS-SI-889304</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td></td>
        <td>RTN TDS difference</td>
        <td></td>
    </tr>
    <tr>
        <td>08</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CRM INV</td>
        <td>2962049</td>
        <td>22-03-22</td>
        <td>ERS-5000014989-1925419-TDS-CM-892671</td>
        <td>SFE/IN/065/21-22-TDS</td>
        <td>28-03-22</td>
        <td>9</td>
        <td>0</td>
        <td>ERS-5000014989-1925419-TDS-CM-892671</td>
        <td>0</td>
        <td>PO-0000239022-Invoice</td>
        <td>ERS-5000014989-1925419-TDS-CM-892671</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td></td>
        <td>2</td>
        <td>CREDIT MEMO VALIDATED</td>
        <td></td>
        <td>Unmatched due to TDS</td>
        <td></td>
    </tr>
    <tr>
        <td>08</td>
        <td>20330</td>
        <td>Creditors For Expenses</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI EPAY</td>
        <td>551820</td>
        <td>31-03-22</td>
        <td>95114497</td>
        <td></td>
        <td>31-03-22</td>
        <td>31034</td>
        <td>3103</td>
        <td>91 MSME Interest 2020-2021-TDS-CM-895608</td>
        <td>0</td>
        <td></td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td>3773703</td>
        <td>2</td>
        <td></td>
        <td></td>
        <td>Unmatched payment</td>
        <td></td>
    </tr>
    <tr>
        <td>08</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CRM INV</td>
        <td>2970768</td>
        <td>31-03-22</td>
        <td>ERS-5000015144-1933076-TDS-CM-901028</td>
        <td></td>
        <td>31-03-22</td>
        <td>22</td>
        <td>0</td>
        <td>ERS-5000015144-1933076-TDS-CM-901028</td>
        <td>0</td>
        <td></td>
        <td>ERS-5000015144-1933076-TDS-CM-901028</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td></td>
        <td>2</td>
        <td>CREDIT MEMO VALIDATED</td>
        <td></td>
        <td>Unmatched due to TDS</td>
        <td></td>
    </tr>
    <tr>
        <td>08</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>4011626</td>
        <td>31-03-22</td>
        <td>Q4 94Q CORRECTION</td>
        <td>Q4 94Q CORRECTION</td>
        <td>31-03-22</td>
        <td>87109.5</td>
        <td>87109.5</td>
        <td>Q4 94Q CORRECTION</td>
        <td>0</td>
        <td></td>
        <td>Q4 94Q CORRECTION</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>Manual Invoice Entry</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td></td>
        <td>Contra</td>
        <td></td>
    </tr>
    <tr>
        <td>08</td>
        <td>20330</td>
        <td>Creditors For Expenses</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CGN PV DN</td>
        <td>618323</td>
        <td>31-03-22</td>
        <td>08-PROV-21.22_PO_29</td>
        <td>08-PROV-21.22_PO_29</td>
        <td>31-03-22</td>
        <td>1786.5</td>
        <td>0</td>
        <td>08-PROV-21.22_PO_29</td>
        <td>0</td>
        <td></td>
        <td>Tds on AP accrual as on 31st March 2022</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>MANUAL INVOICE ENTRY</td>
        <td>DEBIT</td>
        <td></td>
        <td>2</td>
        <td>DEBIT MEMO VALIDATED</td>
        <td></td>
        <td>Unmatched due to prov</td>
        <td></td>
    </tr>
    <tr>
        <td>08</td>
        <td>20330</td>
        <td>Creditors For Expenses</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI EPAY</td>
        <td>551820</td>
        <td>31-03-22</td>
        <td>95114497</td>
        <td>91 MSME Interest 2020-2021</td>
        <td>31-03-22</td>
        <td>31034</td>
        <td>3103</td>
        <td>91 MSME Interest 2020-2021</td>
        <td>31034</td>
        <td></td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>MANUAL INVOICE ENTRY</td>
        <td>STANDARD</td>
        <td>3773703</td>
        <td>2</td>
        <td></td>
        <td></td>
        <td>Unmatched payment</td>
        <td></td>
    </tr>
    <tr>
        <td>08</td>
        <td>20330</td>
        <td>Creditors For Expenses</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CGN PV DN</td>
        <td>618321</td>
        <td>31-03-22</td>
        <td>08-PROV-21.22_PO_254</td>
        <td>08-PROV-21.22_PO_254</td>
        <td>31-03-22</td>
        <td>204.85</td>
        <td>0</td>
        <td>08-PROV-21.22_PO_254</td>
        <td>0.00</td>
        <td></td>
        <td>Tds on AP accrual as on 31st March 2022</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>MANUAL INVOICE ENTRY</td>
        <td>DEBIT</td>
        <td></td>
        <td>2</td>
        <td>DEBIT MEMO VALIDATED</td>
        <td></td>
        <td>Unmatched due to prov</td>
        <td></td>
    </tr>
    <tr>
        <td>08</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CRM INV</td>
        <td>2975340</td>
        <td>31-03-22</td>
        <td>Q4 94Q CORRECTION-TDS-CM-905493</td>
        <td></td>
        <td>31-03-22</td>
        <td>87</td>
        <td>0</td>
        <td>Q4 94Q CORRECTION-TDS-CM-905493</td>
        <td>0.00</td>
        <td></td>
        <td>Q4 94Q CORRECTION-TDS-CM-905493</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td></td>
        <td>2</td>
        <td>CREDIT MEMO VALIDATED</td>
        <td></td>
        <td>Unmatched due to TDS</td>
        <td></td>
    </tr>
    <tr>
        <td>08</td>
        <td>20330</td>
        <td>Creditors For Expenses</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CGN EPV</td>
        <td>411559</td>
        <td>30-03-22</td>
        <td>91 MSME Interest 2020-2021</td>
        <td>91 MSME Interest 2020-2021</td>
        <td>31-03-22</td>
        <td>0</td>
        <td>31034</td>
        <td>91 MSME Interest 2020-2021</td>
        <td>0.00</td>
        <td></td>
        <td>MSME Interest for F.Y. 2020-2021</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>MANUAL INVOICE ENTRY</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td></td>
        <td>Unmatched due to MSME interest</td>
        <td></td>
    </tr>
    <tr>
        <td>08</td>
        <td>20330</td>
        <td>Creditors For Expenses</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CRM INV</td>
        <td>2965079</td>
        <td>30-03-22</td>
        <td>91 MSME Interest 2020-2021-TDS-CM-895608</td>
        <td></td>
        <td>31-03-22</td>
        <td>3103</td>
        <td>0</td>
        <td>91 MSME Interest 2020-2021-TDS-CM-895608</td>
        <td>0.00</td>
        <td></td>
        <td>91 MSME Interest 2020-2021-TDS-CM-895608</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td></td>
        <td>2</td>
        <td>CREDIT MEMO VALIDATED</td>
        <td></td>
        <td>Unmatched due to TDS</td>
        <td></td>
    </tr>
    <tr>
        <td>08</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>3790881</td>
        <td>10-08-21</td>
        <td>ERS-5000013267-1826995</td>
        <td>SFE/IN/004/21-22</td>
        <td>31-03-22</td>
        <td>0</td>
        <td>181492.44</td>
        <td>ERS-5000013267-1826995</td>
        <td>0.00</td>
        <td>PO-0000133698-Invoice</td>
        <td>Receipt Invoice automatically created on 10-AUG-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td></td>
        <td>Unmatched invoice due to Rs.468.34 diff</td>
        <td>47</td>
    </tr>
</table>
  </div>
  )
}



export default ThermaxDr;
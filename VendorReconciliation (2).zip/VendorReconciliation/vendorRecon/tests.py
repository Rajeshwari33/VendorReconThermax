import pandas as pd


df = pd.read_excel("C:/Users/admin/Downloads/Report (66).xlsx")
df.to_json("C:/Users/admin/Downloads/utr.json", orient="records")
import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import "./etlsecound.css";
import { SheetData, SheetNames, TargetSheet, GetAllTarget, GetTarget } from '../../../services/auth-service/authService.js'
import { Icon, Input, Button, Dropdown, Grid, Table, Menu, Form, TextArea, Label, Checkbox, GridColumn } from 'semantic-ui-react'

import loader from "../../../assets/images/1476.gif";
import DialogTitle from "@mui/material/DialogTitle";
import Dialog from "@mui/material/Dialog";
import Select from 'react-select';
import 'bootstrap/dist/css/bootstrap.min.css';
import Box from "@mui/material/Box";
import Tab from "@mui/material/Tab";
import TabContext from '@material-ui/lab/TabContext';
import TabList from '@material-ui/lab/TabList';
import TabPanel from '@material-ui/lab/TabPanel';
import Tabs from '@mui/material/Tabs';
import Modal from 'react-bootstrap/Modal';

var table_data_val;
// var sheet_drp_val;
// var col_id;
// var col_name_val;
// var source_name;
// var pagedata;


const ButtonExampleLabeledIcon = () => (
  <div>
    <Button icon labelPosition='left'>
      <Icon name='pause' color="red" />
      Add Sheets
    </Button>

  </div>
)
const ButtonExampleSocial = (props) => (
  <div>
    <Button color={props.color}  >
      <Icon name={props.buttonicon} />{props.buttonname}
    </Button>
  </div>
)

const IconExampleSize = (props) => (
  <div>

    <Icon name={props.icon} size='big' />
  </div>
)
const InputExampleIconPosition2 = () => (

  <Input placeholder='' type='file' icon='upload' />
)



export default function MyComponent() {
  const [showTable, setShowTable] = useState(false);
  const [showColumn, setShowColumn] = useState(false);
  const [showColumnName, setShowColumnName] = useState(false);
  const [isLoading, setLoading] = useState(false);
  const [selectedOptions, setSelectedOptions] = useState(undefined);
  const [selectedValues, setSelectedValues] = useState();
  const [selectedValues1, setSelectedValues1] = useState({});
  const [sheetnames, SetSheetNames] = useState([]);
  const [sheetval, SetSheetVal] = useState([]);
  const [openDialog, handleDisplay] = useState(false);
  const [inputValue, setInputValue] = useState('');
  const [tabs, setTabs] = useState([]);
  const [isButtonDisabled, SetisButtonDisabled] = useState(true);
  const [showDialogMsg, setshowDialogMsg] = useState(false);

  const [showTabs, setShowTabs] = useState(false);
  const [slectedSheet, setSelectedSheet] = useState('');
  const [sourcename, setSourcename] = useState('');
  const [slectedColumns, setSelectedColumns] = useState({});
  const [slectedColumns1, setSelectedColumns1] = useState({});
  const [removecolumns, setRemovecolumns] = useState([]);
  const [removecolumns1, setRemovecolumns1] = useState([]);
  const [columnids, setColumnids] = useState([]);
  const [add, setAdd] = useState({});
  const ref = useRef([]);
  // const [list, setList] = useState([]);
  const [tabIndex, setTabIndex] = useState(0);
  const [checkbox, setCheckbox] = useState(false);
  const [finalColumns, setFinalColumns] = useState({});
  const [targetOption, setTargetOption] = useState({});
  const [targetId, setTargetid] = useState();
  const [showTarget, setShowtarget] = useState(false);
  const [showSource, setShowSource] = useState(false);

  const [targetNames, setTargetnames] = useState([]);

  const [target_name, settarget_name] = useState();
  const [target_description, settarget_description] = useState();
  const [target_placeholder, settarget_placeholder] = useState();
  const [target_location, settarget_location] = useState();



  function column_name() {

    // console.log('cliccccc123456', JSON.stringify(slectedColumns1));

    const data_val = table_data_val;

    let a;
    data_val.map((data) => {
      a = data.columns
      // console.log('iterare a' + JSON.stringify(a[0]));
    })

    a.map(data => {
      // console.log('slectedSheet', slectedSheet);
      // console.log("data['sheet_name']", data['sheet_name']);
      if (data['sheet_name']) {
        a = data['column_names']
      }
    });
    // if(selectfilecolumns.length > 0){
    //   a = selectfilecolumns;
    // }else{
    //   setSelectfilecolumns(a);
    // }
    console.log('a', a);
    // console.log('add' + JSON.stringify(add));

    // let columns = finalColumns[sourcename + '--' + slectedSheet];
    // columns && columns.map(data => {
    //   var index = a.indexOf(data);
    //   a.splice(index, 1);
    //   console.log('finalColumns' + JSON.stringify(finalColumns[sourcename + '--' + slectedSheet]));
    // });

    let json_data = {};
    json_data = slectedColumns1[tabIndex];
    // console.log('data_val1' + JSON.stringify(json_data));
    if(json_data){
      for (const [key, value] of Object.entries(json_data)) {
        var index = a.indexOf(value);
        console.log(index, value);
        if(index >= 0){
          a.splice(index, 1); 
        }
      };
    }

    console.log('a', a);

    // let add1 = add[sourcename + '--' + slectedSheet];
    // add1 && add1.map(data=>{
    //   a.unshift(data);
    // })
    var col_data = new Array();

    function handleDropdownChange(event, item) {
      
      col_data.push(item);
      
      // col_name_val = col_data
      if (item == 'All' && event.target.checked) {
        setCheckbox(true);

        {
          a && a.map((item, index) => (
            setSelectedColumns((prevState) => ({
              ...prevState,
              [sourcename + '--' + slectedSheet + '&' + item]: item
            }))
          ))
        }
      }
      else if (item == 'All' && event.target.checked == false) {
        setCheckbox(false);
        setSelectedColumns({});
      }
      else if (event.target.checked) {
        setSelectedColumns((prevState) => ({
          ...prevState,
          [sourcename + '--' + slectedSheet + '&' + item]: item
        }));
        setTimeout(
          () => setFinalColumns((prevState) => ({
            ...prevState,
            [sourcename + '--' + slectedSheet]: [...(prevState[sourcename + '--' + slectedSheet] || []), item]
          })),
          3000
        );

      }
      // }else{
      //   let values = slectedColumns;  
      //   values.splice(event.target.id, 1);
      // }
      // console.log('slectedColumns' + JSON.stringify(slectedColumns));
    }

    return (
      <table id="customers">
        {a.length > 0 ? (<><tr>
          <th>
            <input
              type="checkbox"
              onChange={(event) => handleDropdownChange(event, 'All')}
              value='All'
              name='All'
              id="All"
            />
            All
          </th>
        </tr></>):(<></>)}
        
        {a && a.map((item, index) =>

        (checkbox ? (<>
          <tr key={index}>
            <th>
              <input
                type="checkbox"
                onChange={(event) => handleDropdownChange(event, item)}
                value={item}
                checked={checkbox}
                name={item}
                id={index}
              />
              {item}
            </th>
          </tr></>) : (
          <>
            <tr key={index}>
              <th>
                <input
                  type="checkbox"
                  onChange={(event) => handleDropdownChange(event, item)}
                  value={item}
                  name={item}
                  ref={(element) => { ref.current[index] = element }}
                  id={index}
                />
                {item}
              </th>
            </tr>
          </>)
        ))
        }
      </table>
    )
  }

  function datavalue() {
    const data_val = slectedColumns1 && slectedColumns1[tabIndex];
    // console.log('slectedColumns12' + JSON.stringify(slectedColumns1[tabIndex]));
    // console.log("slectedColumns1" + JSON.stringify(data_val));
    var carArray = new Array();
    for (var c in data_val) {
      var jsonObj = new Object();
      jsonObj.text = data_val[c];
      carArray.push(jsonObj);
    }

    function handleDropdownChange(event, data) {
      console.log('data1 id' + event.target.name);
      if (event.target.checked) {
        console.log('checked');
        setColumnids((prevState) => ([
          ...prevState,
          event.target.id
        ]))

        setRemovecolumns((prevState) => ([
          ...prevState,
          event.target.id
        ]))

        setRemovecolumns1((prevState) => ([
          ...prevState,
          event.target.name
        ]))
      } else {
        let values = removecolumns;
        values.splice(event.target.id, 1);
        let values1 = columnids;
        values1.splice(event.target.id, 1);
      }
      console.log('columnids' + columnids);
    }
    return (
      <table id="customers">
        {data_val && Object.entries(data_val).map(([key, value], index) => (
          <tr key={key}>
            <th>
              <label htmlFor={value}>
                <input
                  type="checkbox"
                  onChange={(event) => handleDropdownChange(event, value)}
                  value={value}
                  name={key}
                  id={index}
                />
                {value}
              </label>

            </th>
          </tr>
        ))}
      </table>
    )
  }

  function SourceNames() {
    
    const handleChange1 = (event) => {
      const newValue = event.target.value;
      setShowtarget(true);
      console.log('selected val' + newValue);
      let selectedval = selectedValues1 && selectedValues1[tabIndex];
      console.log('selectedval', selectedval);
      if (selectedval && selectedval.includes(newValue)) {
        console.log('selected source name is already present');
      } else {
        let array = [];
        if(selectedval){
          array = selectedval;
          array.push(newValue);
        }else{
          array.push(newValue);
        
        }
        setSelectedValues1((prevState) => ({
          ...prevState,
          [tabIndex]:array
        }
        ));
        setSelectedValues(newValue);
        displayDropdowns(newValue);
      }
      // onChange(id, newValue);
    };


    return (

      <div>
        {showSource ? (<select disabled class="sheet_names" value={selectedValues} onChange={handleChange1}>
          {selectedOptions?.map((option) => (
            <option class="sheet_names" key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>) : (<select class="sheet_names" value={selectedValues} onChange={handleChange1}>
          {selectedOptions?.map((option) => (
            <option class="sheet_names" key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>)}

      </div>
    );
  }


  function fetchColumnData(sheetVal) {

    let payload = {
      File_data: sheetVal,
    }
    var table_data;
    var FileUploadCredentials = SheetNames();

    axios.post(FileUploadCredentials[1], payload, FileUploadCredentials[0])
      .then(
        response => {
          console.log("responce", response);
          table_data = response.data;
          console.log('sheetval' + table_data)
          table_data_val = table_data;
        }
      )
  }

  function Dropdown1({ id, options, onChange, placeholder }) {
    const [selectedValue, setSelectedValue] = useState(options?.value);

    const handleChange = (event) => {
      setShowColumn(false);
      const newValue = event.target.value;
      let index = event.nativeEvent.target.selectedIndex;
      let selected_sheet = event.nativeEvent.target[index].text;
      console.log('event' + selected_sheet);
      // setShowColumn(false);
      // setShowTabs(false);
      setSelectedValue(newValue);
      // onChange(id, newValue);
      SetSheetVal(newValue);
      fetchColumnData(newValue);
      setSelectedSheet(selected_sheet);
      setSourcename(placeholder);
      setTimeout(
        () => setShowColumn(true),
        1000
      );

    };

    return (
      <select class="sheet_names" onChange={handleChange}>
        <option class="sheet_names">
          {placeholder}
        </option>
        {options?.map((option) => (
          <option class="sheet_names" key={option.label} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
    );
  }

  function ListOfDropdowns() {
    const [selectedValues, setSelectedValues] = useState({});

    const handleDropdownChange = (dropdownId, selectedValue) => {
      setSelectedValues((prevState) => ({
        ...prevState,
        [dropdownId]: selectedValue
      }));
    };


    return (
      <div>
        <table id="customers">
          {sheetnames?.map((dropdown) => (
            <tr key={dropdown.id}>
              <th>
                <Dropdown1
                  key={dropdown.id}
                  id={dropdown.id}
                  options={dropdown.options}
                  onChange={handleDropdownChange}
                  placeholder={dropdown.source_name}

                /></th>
            </tr>
          ))}
        </table>
      </div>
    );
  }


  const colSheet = () => {

    const data_val = slectedColumns1 && slectedColumns1[tabIndex];
    // console.log('data_val' + data_val)

    var carArray = new Array();
    for (var c in data_val) {
      var jsonObj = new Object();
      jsonObj.text = data_val[c];
      carArray.push(jsonObj);
    }

    // console.log('carArray' + JSON.stringify(carArray));

    const handleChange = (event, newValue) => {
      console.log('newValue' + newValue);
      setTabIndex(newValue);
      setSelectedColumns([]);
    };
    return (
      <>

        <Box>
          <TabContext value={tabIndex}>
            <Box sx={{ borderBottom: 1, borderColor: "divider" }}>
              
              <Tabs
              value={tabIndex}
              onChange={handleChange}
              aria-label="basic tabs example"
            >
              {tabs?.map(item => (<Tab label={item.text} />))}
            </Tabs>
              
            </Box>
            {/* {tabs.map((item,index) => ( */}
            <TabPanel value={tabIndex} index={tabIndex} style={{ backgroundColor: 'white' }}>
              <Table celled structured>
                <Table.Header>
                  <Table.Row>
                    <Table.HeaderCell rowSpan='2'>Name</Table.HeaderCell>

                  </Table.Row>
                </Table.Header>

                <Table.Body>
                  {carArray.map(item => (
                    <Table.Row key={item.text}>
                      <Table.Cell>{item.text}</Table.Cell>

                    </Table.Row>
                  ))}
                </Table.Body>
              </Table>
            </TabPanel>
            {/* ))} */}
          </TabContext>
        </Box>

      </>
    );

  }

  const makeLoading = () => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setShowTable(true);
    }, 2500)
  }

  

  const handleClick = () => {
    setShowTabs(true);
  };

  const handleClick_col = () => {
    setShowColumn(true);
  };


  const Unchecked = () => {
    console.log('ref' + ref.current.length);
    for (let i = 0; i < ref.current.length -1; i++) {
      if (ref.current[i] !== null) {
        ref.current[i].checked = false;
      }
    }
  }


  const handleClick_col_name = () => {
    console.log('slectedColumns', slectedColumns);
    setSelectedColumns1((prevState) => ({
      ...prevState,
      [tabIndex]: slectedColumns
    })
    );

    setShowColumnName(true);
    setShowTabs(true);
    Unchecked();
  };

  const displayDialogbox = () => {
    handleDisplay(true);
  }

  const displayDropdowns = (newValue) => {
    console.log('clicked');
    console.log('selectedValues' + newValue);

    let payload = {
      File_data: newValue,
    }
    var table_data;
    var FileUploadCredentials = SheetNames();

    axios.post(FileUploadCredentials[1], payload, FileUploadCredentials[0])
      .then(
        response => {
          console.log("Validate Response!!!", response);
          table_data = response.data;
          console.log(table_data);
          table_data.map((data) => {
            console.log('map' + data.sheets)
          })
          var names;
          var options = [];
          var column;
          var id;

          table_data.map((data) => {
            console.log('data' + data.source_name);

            id = data.source_id;
            let obj = {
              id: data.source_id,
              source_name: data.source_name,
              options: []
            }
            column = data.sheets;
            names = obj;
          })

          column.map((data) => {
            if (data.text != '' || data.text != null) {
              let obj = {
                value: id,
                label: data.text
              }
              options.push(obj);
            }
          })

          names.options = options;
          setShowColumn(false);
          setShowColumnName(false);
          setShowTabs(false);
          console.log('names' + JSON.stringify(names));

          SetSheetNames((prevState) => ([
            ...prevState,
            names]
          ));
        }
      )
  };


  function getReportType(data) {
    setSelectedOptions(data);
    console.log(data);
  }

    

    const handleDropdownChange = (event) => {
      setTargetOption(event);
      setShowSource(true);
      console.log('data.value' + event.value);
      setTargetid(event.value);
    };

    const getAllTargetData = () => {
      let payload = {
        File_data: 'hi',
      }

      var FileUploadCredentials = GetAllTarget();

      axios.post(FileUploadCredentials[1], payload, FileUploadCredentials[0])
        .then(
          response => {
            console.log("fetch all target config data!!!", response);
            let table_data = response.data;
            let names = [{ value: "", label: "Select Source" },]
            table_data.map((data) => {
              console.log('data' + data.target_name);

              let obj = {
                value: data.target_id,
                label: data.target_name
              }
              names.push(obj);
            })
            setTargetnames(names);
          }
        )
    };

  useEffect(() => {
    let payload = {
      File_data: 'hi',
    }

    var FileUploadCredentials = SheetData();

    axios.post(FileUploadCredentials[1], payload, FileUploadCredentials[0])
      .then(
        response => {
          console.log("Validate Credentials Response!!!", response);
          let table_data = response.data;
          console.log(table_data)
          table_data_val = table_data;
          let names = [{ value: "", label: "Select Source" },]
          table_data.map((data) => {
            console.log('data' + data.source_name);

            let obj = {
              value: data.source_id,
              label: data.source_name
            }
            names.push(obj);
          })
          setSelectedOptions(names);
        }
      )
  }, [])


  useEffect(() => {
    getAllTargetData();
    makeLoading();
  }, [])


  const handleClose = () => {
    SetisButtonDisabled(true);
    setshowDialogMsg(false);
    handleDisplay(false);
    setShowColumn(false);
    setSelectedColumns([]);
  };

  // const openDialogBox = () => {
  //   handleDisplay(true);
  // };

  const handleInputChange = (event) => {
    setInputValue(event.target.value);
  };

  const removeColumnnames = () => {
    let slectedCol = slectedColumns1[tabIndex];
    let slectedCol1 = Object.entries(slectedCol);
    let selcol = Object.entries(slectedColumns);
    console.log('removecolumns' + removecolumns);
    console.log('slectedColumns' + JSON.stringify(slectedColumns));
    removecolumns.map((data) => {
      console.log('data', data);
      slectedCol1.splice(data, 1);
      selcol.splice(data, 1);
      // let index = slectedColumns.indexOf(data)
      // slectedColumns.splice(index, 1);
    });
    let data1 = Object.fromEntries(slectedCol1)
    let selcol1 = Object.fromEntries(selcol)
    console.log('data1' + JSON.stringify(data1));
    setSelectedColumns1((prevState) => ({
      ...prevState,
      [tabIndex]: data1
    }));
    setSelectedColumns(selcol1);

    let final;
    let name;
    removecolumns1.map(data => {
      let split = data.split('&');
      // setAdd((prevState) => ({
      //   ...prevState,
      //   [split[0]]:[...(prevState[split[0]] || []),split[1]]
      // }))
      name = split[0];
      final = finalColumns[split[0]];
      let index = final.indexOf(data);
      final.splice(index, 1);
      console.log('final' + final);
      // let index1 = slectedCol.indexOf(data);
      // slectedCol.splice(index1, 1); 
    }
    )
    // setSelectedColumns1((prevState) => ({
    //   ...prevState,
    //   [tabIndex]: slectedCol
    // }));
    setFinalColumns((prevState) => ({
      ...prevState,
      [name]: final
    }));

    setRemovecolumns([]);
    setRemovecolumns1([]);
  }

  const addDialoginput = () => {
    SetisButtonDisabled(false);
    setshowDialogMsg(true);
    setTabs((prevState) => ([
      ...prevState,
      { 'text': inputValue }
    ]));
  }


  function swapArrayElements(arr, indexA, indexB) {
    console.log('arr' + arr);
    var temp = arr[indexA];
    arr[indexA] = arr[indexB];
    arr[indexB] = temp;
    return (arr)
  };

  const ChangePositiontoTop = () => {
    let selectedCol = slectedColumns1[tabIndex];
    let columnid = columnids;
    let data1 = {};
    swapArrayElements = swapArrayElements(Object.entries(selectedCol), columnid - 1, columnid)
    // setSelectedColumns1({});
    console.log('arr' + JSON.stringify(Object.fromEntries(swapArrayElements)));
    // swapArrayElements.map(data =>{
    //   data1.push(data);
    // })
    data1 = Object.fromEntries(swapArrayElements)
    setSelectedColumns1((prevState) => ({
      ...prevState,
      [tabIndex]: data1
    }));
    setColumnids([parseInt(columnid) - 1]);
    setRemovecolumns([parseInt(columnid) - 1]);
  };

  const ChangePositiontoBottom = () => {
    let selectedCol = slectedColumns1[tabIndex];
    let columnid = columnids;
    let data1 = {};
    swapArrayElements = swapArrayElements(Object.entries(selectedCol), columnid, parseInt(columnid) + 1)
    // setSelectedColumns1([]);
    // swapArrayElements.map(data =>{
    //   data1.push(data);
    // })
    data1 = Object.fromEntries(swapArrayElements)
    setSelectedColumns1((prevState) => ({
      ...prevState,
      [tabIndex]: data1
    }));
    setColumnids([parseInt(columnid) + 1]);
    setRemovecolumns([parseInt(columnid) + 1]);
  };

  const uploadtargetdata = () => {

    let target_name = document.getElementById("target_name").value;
    let target_desc = document.getElementById("target_desc").value || null;
    let target_placeholder = document.getElementById("target_placeholder").value;
    let target_loc_path = document.getElementById("target_loc_path").value;
    // console.log("input field" + target_name, target_desc, target_placeholder, target_loc_path);
    // console.log(slectedColumns1);

  

    let payload = {
      target_name: target_name,
      target_desc: target_desc,
      target_placeholder: target_placeholder,
      target_loc_path: target_loc_path,
      target_configuration: {
        slectedColumns1: slectedColumns1,
        sheetNames: tabs,
        selectedValues1: selectedValues1,
      },
      
    }

    // console.log('clicked save button selectedValues1', selectedValues1);
    // console.log('clicked save button finalColumns', finalColumns);

    var FileUploadCredentials = TargetSheet();

    axios.post(FileUploadCredentials[1], payload, FileUploadCredentials[0])
      .then(
        response => {
          console.log("Validate Credentials Response!!!", response);
        }
      )
  }

  const dialogStyle = {
    padding: "20px",
  };

  const DropdownTargetnames = () => {
    const [targetNames, setTargetnames] = useState([]);

    const handleDropdownChange = (event) => {
      setTargetOption(event);
      setShowSource(true);
      console.log('data.value' + event.value);
      setTargetid(event.value);
    };

    useEffect(() => {
      let payload = {
        File_data: 'hi',
      }

      var FileUploadCredentials = GetAllTarget();

      axios.post(FileUploadCredentials[1], payload, FileUploadCredentials[0])
        .then(
          response => {
            console.log("fetch all target config data!!!", response);
            let table_data = response.data;
            let names = [{ value: "", label: "Select Source" },]
            table_data.map((data) => {
              console.log('data' + data.target_name);

              let obj = {
                value: data.target_id,
                label: data.target_name
              }
              names.push(obj);
            })
            setTargetnames(names);
          }
        )
    }, [])

    return (
      <Select
        clearable
        options={targetNames}
        isDisabled={showTarget}
        selection
        placeholder='Choose Target'
        size='mini'
        onChange={handleDropdownChange}
        value={targetOption}
      />
    );
  };

  const viewSavedFilesdata = () => {
    let payload = {
      id: targetId,
    }

    var FileUploadCredentials = GetTarget();

    axios.post(FileUploadCredentials[1], payload, FileUploadCredentials[0])
      .then(
        response => {
          console.log("fetch target config data!!!", response);
          let table_data = response.data;
          let target_configuration;
          
          const input_data = table_data[0];
          console.log('input_data', input_data.target_name);
          table_data.map((data) => {
            target_configuration = data.target_configuration
          })
          settarget_name(input_data.target_name);
          settarget_description(input_data.target_description);
          settarget_placeholder(input_data.target_placeholder);
          settarget_location(input_data.target_location);
          

          target_configuration = JSON.parse(target_configuration);

          let selectedColumnsss = target_configuration.slectedColumns1;
          let sheetNames = target_configuration.sheetNames;

          let targetValues = target_configuration.selectedValues1;

          console.log('targetValues', targetValues);
          setTabs(sheetNames);
          setSelectedColumns1(selectedColumnsss);

          // const values = Object.keys(selectedColumnsss[tabIndex]);
          // const uniqueValues = [...new Set(values.map(value => value.split('--')[0]))];

          // console.log('uniqueValues', uniqueValues);

          // const targetValues = uniqueValues.map(targetLabel => {
          //   const targetItem = selectedOptions.find(item => item.label === targetLabel);
          //   return targetItem ? targetItem.value : '';
          // });

          // console.log('targetValues', targetValues);

          // setFinalColumns(selectedColumns);
          // let source_list = target_configuration.source_list;
          // console.log('table_data' + JSON.stringify(target_configuration.source_list));
          // targetValues?.map((data, index) => {
            
          //   setSelectedValues1((prevState) => ({
          //     ...prevState,
          //     [index]:data
          //   }
          //   ));
          //   setSelectedValues(parseInt(data));
          //   displayDropdowns(parseInt(data));
          // })

          Object.keys(targetValues).forEach(key => {
            targetValues[key].forEach((data, index) => {
              setSelectedValues1(prevState => ({
                ...prevState,
                [index]: data
              }));
      
              setSelectedValues(parseInt(data));
              displayDropdowns(parseInt(data));
      
            });
          });

        }
      )
  }

  return (

    <div>

      {isLoading ? (<div class="center"><h4 style={{ fontSize: '2rem' }}>Loading...</h4>
        <img style={{ width: '150px', height: "150px" }} src={loader} /></div>
      ) : (


        <div className="side">
          
          <Modal
            show={openDialog}
            onHide={handleClose}
            backdrop="static"
            keyboard={false}
          >
            <Modal.Header closeButton>
              <Modal.Title>definetely enter the file name</Modal.Title>
            </Modal.Header>
            <Modal.Body>
              {showDialogMsg ? <p >Added file name sucessfully...</p> : ""}
              <Form>
                <Form.Field style={{ marginBottom: '0em' }}>
                  <div style={dialogStyle}>
                    <input
                      type="text"
                      value={inputValue}
                      onChange={handleInputChange}
                      placeholder='Enter file name'
                    />
                  </div>
                </Form.Field>
              </Form>
            </Modal.Body>
            <Modal.Footer>
              <Button variant="secondary" onClick={handleClose} style={{color: '#fff', backgroundColor:'#0A2352'}}>
                Cancel
              </Button>
              <Button  variant="primary" onClick={addDialoginput} disabled={!isButtonDisabled} style={{color: '#fff', backgroundColor:'#0A2352'}}>Add</Button>
              {/* <Button type='submit' onClick={sendemails}>Send</Button> */}
            </Modal.Footer>
          </Modal>
          
          <Grid columns='equal' style={{ padding: "10px" }}>
            <Grid.Row style={{ backgroundColor: "#e9e8d9", borderRadius: "12px" }}>
              <Grid.Column >
                <label>Source</label>
                <SourceNames />

              </Grid.Column>
              <Grid.Column>
                <label>Name</label>
                <div>
                  {showSource ? (<Input disabled type="text" value={target_name} placeholder="target name" required/>) : (<Input type="text" value={target_name} id="target_name" placeholder="target name" required />)}

                </div>
              </Grid.Column>
              <Grid.Column>
                <label>Description</label>
                <div>
                  {showSource ? (<Input disabled type="text" value={target_description} placeholder="target desc" required />) : (<Input type="text" value={target_description} id="target_desc" placeholder="target desc" required/>)}
                </div>
              </Grid.Column>
              <Grid.Column>
                <label>Placeholder</label>
                <div>
                  {showSource ? (<Input disabled type="text" value={target_placeholder} placeholder="target placeholder" required/>) : (<Input type="text" value={target_placeholder} id="target_placeholder" placeholder="target placeholder" required />)}

                </div>
              </Grid.Column>
              <Grid.Column>
                <label>Location</label>
                <div>
                  {showSource ? (<Input disabled type="text" value={target_location} placeholder="target location path" required/>) : (<Input type="text" value={target_location} id="target_loc_path" placeholder="target location path" required />)}

                </div>
              </Grid.Column>

              <Grid.Column>
                <label>Target</label>
                <div onClick={displayDialogbox}>
                  {showSource ? (<Button disabled color='instagram' >
                    <Icon name='add' />Add Sheets
                  </Button>) : (<Button color='instagram' >
                    <Icon name='add' />Add Sheets
                  </Button>)}

                </div>

              </Grid.Column>

            </Grid.Row>
            <Grid.Row style={{ backgroundColor: "#e9e8d9", padding: '0px' }}>
              <Grid.Column width={3}>
                {/* <DropdownTargetnames /> */}

                <Select
                  clearable
                  options={targetNames}
                  isDisabled={showTarget}
                  selection
                  placeholder='Choose Target'
                  size='mini'
                  onChange={handleDropdownChange}
                  value={targetOption}
                />

              </Grid.Column>
              <Grid.Column width={4}></Grid.Column>
              <Grid.Column width={3}></Grid.Column>
              <Grid.Column width={3}></Grid.Column>
              <Grid.Column width={3}>
                <div onClick={viewSavedFilesdata}>
                  {showTarget ? (<Button disabled color='instagram'>
                    <Icon name="save" /> View
                  </Button>) : (<Button color='instagram'>
                    <Icon name="save" /> View
                  </Button>)}

                </div>
              </Grid.Column>
            </Grid.Row>
            <Grid.Row style={{ backgroundColor: "#e9e8d9", borderRadius: "12px", marginTop: "10px" }}>
              <Grid.Column style={{ width: "400px", height: "200px", overflowY: "scroll" }}>

                <ListOfDropdowns />


              </Grid.Column>
              <Grid.Column style={{ width: "300px", height: "200px", overflowY: "scroll" }} >
                {showColumn && <p style={{ marginBottom: '0px' }}><span style={{ marginRight: '1em' }}>{sourcename}</span><span>{slectedSheet}</span></p>}
                {showColumn && column_name()}

              </Grid.Column>
              <Grid.Column style={{ textAlign: 'center' }}>
                <div style={{ paddingTop: "75px" }}>
                  <p onClick={handleClick_col_name}><IconExampleSize icon="arrow circle right" style={{ textAlign: 'center' }} /></p>
                  <br></br>
                  <p onClick={removeColumnnames}><IconExampleSize icon="arrow circle left" style={{ textAlign: 'center' }} /></p>
                </div>

              </Grid.Column>
              <Grid.Column style={{ width: "250px", height: "200px", overflowY: "scroll" }}>

                {true && datavalue()}

              </Grid.Column>
              <Grid.Column >
                <div style={{ paddingTop: "75px" }}>
                  <p onClick={ChangePositiontoTop}> <IconExampleSize icon="arrow alternate circle up outline" style={{ textAlign: 'center' }} /> </p>
                  <br></br>
                  <p onClick={ChangePositiontoBottom}><IconExampleSize icon="arrow alternate circle down outline" style={{ textAlign: 'center' }} /></p>
                </div>

              </Grid.Column>
            </Grid.Row>

            <Grid.Row style={{ backgroundColor: "#e9e8d9", borderRadius: "12px", marginTop: "10px" }}>
              <Grid.Column>

                {true && colSheet()}
                {/* <TabExampleCustomMenuItem/> */}

              </Grid.Column>
            </Grid.Row>
            <Grid.Row style={{ backgroundColor: "#e9e8d9" }}>
              <Grid.Column>
                <div onClick={uploadtargetdata}>
                  {showSource ? (<Button disabled color='instagram' >
                    <Icon name='save' />Save
                  </Button>) : (<Button color='instagram' >
                    <Icon name='save' />Save
                  </Button>)}
                </div>
              </Grid.Column>
            </Grid.Row>

          </Grid>


        </div>

      )
      }
    </div>

  );
}


from rest_framework.views import APIView
from rest_framework.decorators import authentication_classes, permission_classes
from rest_framework.response import Response
from rest_framework import status
from datetime import datetime
from .models import UserAuthToken
import logging, json
from django.db import connection
import pandas as pd

logger = logging.getLogger("user_modules")

def execute_sql_query(query, object_type):
    try:
        with connection.cursor() as cursor:
            cursor.execute(query)
            if object_type == "table":
                column_names = [col[0] for col in cursor.description]
                rows = dict_fetch_all(cursor)
                table_output = {"headers":column_names, "data":rows}
                # print(table_output)
                output = json.dumps(table_output)
                return output
            elif object_type == "Normal":
                return "Success"
            elif object_type in["update", "create"]:
                return None
            else:
                rows = cursor.fetchall()
                column_header = [col[0] for col in cursor.description]
                df = pd.DataFrame(rows)
                return [df, column_header]
    except Exception as e:
        logger.info(query)
        logger.error(str(e))
        logger.error("Error in Executing SQL Query", exc_info=True)
        return None

def dict_fetch_all(cursor):
    "Return all rows from cursor as a dictionary"
    try:
        column_header = [col[0] for col in cursor.description]
        return [dict(zip(column_header, row)) for row in cursor.fetchall()]
    except Exception as e:
        logger.error("Error in converting cursor data to dictionary", exc_info=True)

def get_date_time_compare(past_time):
    try:

        present_time = str(datetime.today())
        if str(past_time) < present_time:
            return True
        return False

    except Exception:
        logger.error("Error in Get Date Time Compare Function!!!", exc_info=True)
        return False


@authentication_classes([])
@permission_classes([])
class ExpireToken(APIView):

    def post(self, request):

        user_auth_token = UserAuthToken.objects.all()

        for user in user_auth_token:
            compare_date = get_date_time_compare(past_time = user.expiry_dt)
            if compare_date:
                user_id = user.user_id
                query = "DELETE FROM user_management.authtoken_token WHERE user_id = {user_id};"
                query_proper = query.replace("{user_id}", str(user_id))
                query_output = execute_sql_query(query = query_proper, object_type="Normal")
                if query_output == "Success":
                    user.delete()
                    continue
                else:
                    return Response({"Status": "Error"}, status=status.HTTP_400_BAD_REQUEST)

        return Response({"Status": "Success"}, status=status.HTTP_200_OK)

expire_token = ExpireToken.as_view()
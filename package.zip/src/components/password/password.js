import React from 'react';

function Password()
{
    return (
        <div>
            <h2>Reset Password!!!</h2>
        </div>
    );
}

export default Password;
import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Login from '../components/login/login';
import ForgotPassword from '../components/forgot-password/forgotPassword';
import NotFound from '../components/not-found/notFound';
import Password from '../components/password/password';
import Main from '../components/main/main';
import SideMenu from '../components/side-menu/sideMenu';
import DashBoard from '../components/process/migrations/dashboard/dashboard';
import ComplainceCertificateFileUpload from '../components/process/complaince-certficate/file-upload/file-upload';
import ComplainceCertificateDashboard from '../components/process/complaince-certficate/dashboard/dashboard';
import ComplainceCertificateReport from '../components/process/complaince-certficate/reports/reports';
import MedicalInsuranceFileUpload from '../components/process/medical-insurance/file-upload/file-upload';
import MedicalInsuranceReport from '../components/process/medical-insurance/reports/reports';
import MigrationDashboard from '../components/process/migrations/dashboard/dashboard';


import DonutChart from '../components/process/etl/donutchart';

import Header from '../components/header/header';
import Etl from '../components/process/etl/etl';
import Etlsecound from '../components/process/etl/etlsecoud';

import Etlsecound1 from '../components/process/etl/etlsecoud1.js';
import Etlsecound2 from '../components/process/etl/etlsecoud2';

import Etlrelation from '../components/process/etl/etlrealations';
import P2p from '../components/process/etl/p2p';
import Kpi from '../components/process/etl/kpi';
import Kpi2 from '../components/process/etl/kpi2';
import Kpi3 from '../components/process/etl/kpi3';
import Trip from '../components/process/etl/trip';
import Report from '../components/process/etl/report';
import ApexChart from '../components/process/etl/apexdontchart';
import Table from '../components/process/etl/table';
import Home from '../components/process/etl/home';
import Details from '../components/process/etl/detail';
import Vendorcrdr from '../components/process/etl/SAGARBHANGA/vendorcddr';
import SagarbhaReport from '../components/process/etl/SAGARBHANGA/sagarbhareport';
import Consolidation from '../components/process/etl/consolidation';
import ProcessMaster from '../components/process/etl/resource_master';
import Etl1 from '../components/process/etl/etl1';
import AlcsFileUpload from '../components/process/alcs/file-upload/file-upload';
import AlcsFileUpload1 from '../components/process/alcs/file-upload-new/file-upload';
import AlcsReport from '../components/process/alcs/reports/reports';
import EmailsList from '../components/process/alcs/EmailsList';
import Consolidation_file_upload from '../components/process/etl/consolidation_upload/file-upload/file-upload';
import Consolidation_report from '../components/process/etl/consolidation_upload/reports/reports';

import VRSEmailsList from '../components/process/alcs/VrsEmailsList';
import ReconSummary from '../components/process/BRS/ReconSummary/reconSummary';
import BRSFileUpload from '../components/process/BRS/file-upload/file-upload';
import BRSReport from '../components/process/BRS/Report/report';
import BRSMonthEndClose from '../components/process/BRS/MonthEndClose/monthEndClose';
import VRSReconSummary from '../components/process/VRS/ReconSummary/reconSummary';
import VRSReport from '../components/process/VRS/Report/report';
import TestGrid from '../components/process/test/test';
import VRSBalanceConfirmation from '../components/process/VRS/Mail/VrsEmailsList';
import VRSFileUpload from '../components/process/VRS/file-upload/file-upload';
// import P2pDashboard from '../p2p/components/dashboard/dashboard';
// import Porequirement from '../p2p/components/porequirement/porequirement';
// import Podeptheadtracker from '../p2p/components/podeptheadtracker/podeptheadtracker';
// import Poapprovaltracker from '../p2p/components/poapprovaltracker/poapprovaltracker';
// import Pofinancetracker from '../p2p/components/pofinancetracker/pofinancetracker';
// import P2ptracker from '../p2p/components/p2ptracker/p2ptracker';
// import Consolidationdocupload from '../p2p/components/consolidationdocupload/consolidationdocupload';
// import Consolidationprocess from '../p2p/components/consolidationprocess/consolidationprocess';
// import Consolidationreport from '../p2p/components/consolidationreport/consolidationreport';
// import Sourcedefinition from '../p2p/components/sourcedefinition/sourcedefinition';
// import SourceComponent from '../p2p/components/source/source';
// import OverallprfComponent from '../p2p/components/overallprf/overallprf';
// import UsermasterComponent from '../p2p/components/usermaster/usermaster';
// import P2preportComponent from '../p2p/components/p2preport/p2preport';
// import DepartmentMasterComponent from '../p2p/components/departmentmaster/departmentmaster';
// import VendorMasterComponent from '../p2p/components/vendormaster/vendormaster';
// import MaterialMasterComponent from '../p2p/components/materialmaster/materialmaster';

// import Porequirement1 from '../p2p/components/porequirement/porequirment1';


// import AlcsExcelFileUpload from '../components/process/alcs/upload_excel_file/file-upload';

class Routing extends React.Component
{
    render()
    {
        return(
            <BrowserRouter>
                <div>
                    <Routes>
                        <Route path="/" element = {<Login />} />
                        <Route path="/ForgotPassword" element = {<ForgotPassword />} />
                      

                        <Route path="/ResetPassword" element = {<Password />} />
                        <Route path="/SideMenu" element = {<SideMenu />} />
                        <Route path="/Header" element = {<Header />} />
                        <Route path="/" element = {<Main />}>
                            <Route path="DashBoard" element={<DashBoard />} />
                            <Route path="CCFileUpload" element = {<ComplainceCertificateFileUpload />} />
                            <Route path="CCDashboard" element = {<ComplainceCertificateDashboard />} />
                            <Route path="CCReports" element = {<ComplainceCertificateReport />} />
                            <Route path="MIFileUpload" element = {<MedicalInsuranceFileUpload />} />
                            <Route path="MIReports" element = {<MedicalInsuranceReport />} />
                            <Route path="MigrationDashboard" element = {<MigrationDashboard />} />
                            <Route path="/etl" element = {<Etl/>} />
                            <Route path="/etlsecound" element ={< Etlsecound/> }/>
                            <Route path="/etlrelation" element ={< Etlrelation/> }/>
                            <Route path="/p2p" element ={< P2p/> }/>
                            <Route path="/kpi" element ={< Kpi/> }/>
                            <Route path="/kpi2" element ={< Kpi2/> }/>
                            <Route path="/kpi3" element ={< Kpi3/> }/>
                            <Route path="/trip" element ={< Trip/> }/>
                            <Route path="/report" element ={< Report/> }/>
                            <Route path="/apex" element ={< ApexChart/> }/>
                            <Route path="/donutChart" element ={< DonutChart/> }/>
                            <Route path="/table" element ={< Table/> }/>
                            <Route path="/home" element ={< Home/> }/>
                            <Route path="/details" element ={< Details/> }/>
                            <Route path="/sagar" element ={< SagarbhaReport/> }/>
                            <Route path="/consolidation" element ={< Consolidation/> }/>
                            <Route path="/processmaster" element ={< ProcessMaster/> }/>
                            <Route path="/etl1" element ={< Etl1/> }/>
                            <Route path="/alcs" element ={< AlcsFileUpload/> }/>
                            <Route path="/alcs_new_file_upload" element ={< AlcsFileUpload1/> }/>

                            <Route path="/alcsreport" element ={< AlcsReport/> }/>
                            <Route path="/emailsList" element ={< EmailsList/> }/>

                            <Route path="/vrsemailsList" element ={< VRSEmailsList/> }/>

                            <Route path="/consolidation_file_upload" element ={< Consolidation_file_upload/> }/>
                            <Route path="/consolidation_report" element ={< Consolidation_report/> }/>
                            <Route path="/VRSReconSummary" element ={< VRSReconSummary/> }/>
                            <Route path="/ReconSummary" element ={< ReconSummary/> }/>
                            <Route path="/BRSFileUpload" element ={< BRSFileUpload/> }/>
                            <Route path="/BRSReport" element ={< BRSReport/> }/>
                            <Route path="/BRSMonthEndClose" element ={< BRSMonthEndClose/> }/>
                            <Route path="/VRSReport" element ={< VRSReport/> }/>
                            <Route path="/TestGrid" element ={< TestGrid/> }/>
                            <Route path="/VRSBalanceConfirmation" element ={< VRSBalanceConfirmation/> }/>
                            <Route path="/VRSFileUpload" element ={< VRSFileUpload/> }/>


                            {/* <Route path="/p2pDashboard" element ={< P2pDashboard/> }/>
                            <Route path="/porequirement" element ={< Porequirement/> }/>


                            <Route path="/podeptheadtracker" element ={< Podeptheadtracker/> }/>
                            <Route path="/poapprovaltracker" element ={< Poapprovaltracker/> }/> 
                            <Route path="/poapprovaltracker1" element ={< Porequirement1/> }/> 
                            <Route path="/pofinancetracker" element ={< Pofinancetracker/> }/>
                            <Route path="/p2ptracker" element ={< P2ptracker/> }/> */}
                            {/*<Route path="/consolidationdocupload" element ={< Consolidationdocupload/> }/>
                            <Route path="/consolidationprocess" element ={< Consolidationprocess/> }/>
                            <Route path="/consolidationreport" element ={< Consolidationreport/> }/>
                            <Route path="/sourcedefinition" element ={< Sourcedefinition/> }/>
                            <Route path="/source" element ={< SourceComponent/> }/>*/}
                            {/* <Route path="/overallprf" element ={< OverallprfComponent/> }/>
                            <Route path="/user" element ={< UsermasterComponent/> }/>  */}
                            {/* <Route path="/p2preport" element ={< P2preportComponent/> }/> */}
                            {/* <Route path="/departmentMaster" element ={< DepartmentMasterComponent/> }/>
                            <Route path="/vendorMaster" element ={< VendorMasterComponent/> }/>
                            <Route path="/materialMaster" element ={< MaterialMasterComponent/> }/> */}



                            {/* <Route path="/excelFileUpload" element ={< AlcsExcelFileUpload/> }/>  */}

                            <Route path="/etlsecound1" element ={< Etlsecound1/> }/>
                            <Route path="/etlsecound2" element ={< Etlsecound2/> }/>


                            

                        </Route>
                        <Route path="*" element = {<NotFound />} />
                    </Routes>
                </div>
            </BrowserRouter>
        );
    }
}

export default Routing;
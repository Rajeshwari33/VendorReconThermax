// App.js
import { useEffect, useState } from "react";
// import "./App.css";
import "../etlsecound.css";
import hdfcs from '../../../../assets/images/banks/thermax.png';


function VRS() 
{
  

  return (
  <div>
    <table className="table">
    <tr className="bold">
        <td colspan="2"> VENDOR CODE : 150350</td>
        <td></td>
    </tr>
    <tr className="bold">
        <td></td>
        <td>HEIN LEHMANN INDIA PRIVATE LIMITED</td>
        <td></td>
    </tr>
   
    <tr className="fontcolor">
        <td>Si. No</td>
        <td>Particulars</td>
        <td> Amount </td>
    </tr>
    
    <tr>
        <td></td>
        <td>Balance as per Thermax</td>
        <td> 2,583,975.01 </td>
    </tr>
    
    <tr>
        <td></td>
        <td>Balance as per Vendor</td>
        <td> -   </td>
    </tr>
    
    <tr>
        <td></td>
        <td>Variance</td>
        <td> 2,583,975.01 </td>
    </tr>
    
    <tr>
        <td></td>
        <td>Reasons for Variance</td>
        <td></td>
    </tr>
   
    <tr>
        <td>1</td>
        <td>Purchase Invoices booked by Thermax not accounted by vendor</td>
        <td> 116,036,421.13 </td>
    </tr>
    
    <tr>
        <td>2</td>
        <td>Payment received by vendor but not accounted by Thermax</td>
        <td> 34,794,839.67 </td>
    </tr>
   
    <tr>
        <td>3</td>
        <td>Sales considered by vendor but not accounted by Thermax</td>
        <td> -37,819,000.00 </td>
    </tr>
    
    <tr>
        <td>4</td>
        <td>Payment made by Thermax not accounted by vendor</td>
        <td> -180,957,350.49 </td>
    </tr>
    
    <tr>
        <td>5</td>
        <td>Difference in Opening balance of Thermax &amp; Vendor statement</td>
        <td> 23,938,679.74 </td>
    </tr>
   
    <tr>
        <td></td>
        <td>Sum total of variance</td>
        <td> -44,006,409.95 </td>
    </tr>
    
    <tr>
        <td></td>
        <td>Check</td>
        <td>-46590384.96</td>
    </tr>
   
    <tr>
        <td></td>
        <td>Reconciliation done till</td>
        <td>30-Nov-2022</td>
    </tr>
   
    <tr className="fontcolor">
        <td></td>
        <td colspan="2">Vendor Reconciliation Statement as on 30 NOVEMBER 2022</td>
        {/* <td></td> */}
    </tr>
</table>
  </div>
  )
}



export default VRS;
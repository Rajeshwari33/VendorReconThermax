import React, { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import './report.css';
import Select from "react-select";
import { getProcessingLayerListFromServer, getVRSReportFromServer } from '../../../../services/process/VRS/vrsService';
import axios from "axios";
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-balham.css';
import { AgGridReact } from 'ag-grid-react';
import LoaderComponent from "../../../../libraries/loader/loader";
import refreshIcon from "../../../../assets/images/refresh.png";
import { Grid, Button, Input } from 'semantic-ui-react';




function VRSReport() {
    const [userCredentials] = useState(JSON.parse(sessionStorage.getItem("userCredentials")));
    const [fromDate, setFromDate] = useState(undefined);
    const [toDate, setToDate] = useState(undefined);
    const { register, handleSubmit } = useForm();
    const [rowData, setRowData] = useState([]);
    const [paginationSize] = useState(15);
    const [loaderOpen, setLoaderOpen] = useState(false);
    const [options, setOptions] = useState([]);
    const [selectedOption, setSelectedOption] = useState('');
    const [layerId, setLayerId] = useState('');
    const [fileUploaded, setFileUploaded] = useState('');
    const [link, setLink] = useState('');
    const [downloadHidden, setDownloadHidden] = useState(true);
    const [selectedOptions, setSelectedOptions] = useState();

    console.log("fromDate", fromDate);
    useEffect(() => {
        BrsTypeList();
    }, []);

    function handleSelection(event) {
        const selectedValue = event.label;
        console.log('selectedValue', selectedValue)
        const selectedOption = options.find(option => option.processing_layer_name === selectedValue); // Find the option with the selected value
        const layerId = selectedOption ? selectedOption.processing_layer_id : null;
        console.log("layerId", layerId);
        setSelectedOption(event);
        setLayerId(layerId);
        setLink('');
        setDownloadHidden(true);

    }

    function BrsTypeList() {
        setLoaderOpen(true);
        let payload = {
            "tenantId": userCredentials["tenants_id"],
            "groupId": userCredentials["groups_id"],
            "entityId": userCredentials["entities_id"],
            "mProcessingLayerId": userCredentials["m_processing_layer_id"],
            "mProcessingSubLayerId": userCredentials["m_processing_sub_layer_id"],
            "typeId": userCredentials["processing_layer_id"]
        }

        var getProcessingLayerList = getProcessingLayerListFromServer();
        console.log("brs", getProcessingLayerList[0])

        axios.post(getProcessingLayerList[1], { params: payload }, getProcessingLayerList[0])
            .then(
                response => {
                    console.log("Processing Layer List!!!", response)
                    let data = response["data"];
                    if (data["Status"] === "Success") {
                        let options = data["processing_layer_list"]
                        setOptions(options);

                        let names = []
                        options.map((data) => {

                            let obj = {
                                value: data.processing_layer_id,
                                label: data.processing_layer_name
                            }
                            names.push(obj);
                        })
                        setSelectedOptions(names);
                        setLoaderOpen(false);
                    }
                }
            ).catch(
                error => {
                    console.log("Error in Processing Layer List!!!", error);
                    setLoaderOpen(false);
                }
            );

    }


    function reportClick() {
        setDownloadHidden(true);
        setLoaderOpen(true);
        let payload = {
            "tenantId": userCredentials["tenants_id"],
            "groupId": userCredentials["groups_id"],
            "entityId": userCredentials["entities_id"],
            "processing_layer_id": layerId,
            "reportFromDate": fromDate,
            "reportToDate": toDate,
            "processing_layer": selectedOption
        }

        var getVrsReport = getVRSReportFromServer();

        axios.post(getVrsReport[1], { params: payload }, getVrsReport[0])
            .then(
                response => {
                    console.log("Report Generated Response!!!", response)
                    let data = response["data"];
                    if (data["Status"] === "Success") {
                        console.log("data", data);
                        setLink(data["file_generated"]);
                        setLoaderOpen(false);
                        setDownloadHidden(false);
                    }
                    else {
                        setDownloadHidden(true);
                        setLoaderOpen(false);
                    }
                }
            ).catch(
                error => {
                    console.log("Error in File Generated!!!", error);
                    setLoaderOpen(false);
                }
            );

    }

    return (
        <>
            <div className="report-cardBox-vrs row" style={{padding:'1em'}}>
                <div className='col-md-3' >

                    <label htmlFor="underline_select " style={{ fontSize: '15px', paddingBottom:'0.5em' }}>Vendor</label><br />
                    <div className="cardName1">
                        <div className="dropdown-container1">
                            <Select
                                clearable
                                options={selectedOptions}
                                selection
                                placeholder='ChooseVendor'

                                onChange={handleSelection}
                                value={selectedOption}
                            />

                        </div>
                    </div>


                </div>
                <div className=" col-md-2">
                    <div>
                        <label id="underline_select" htmlFor="underline_select " style={{ fontSize: '15px',  paddingBottom:'0.5em' }}>From</label><br />
                        <Input type="date" className="cardName filetype" style={{ paddingLeft: "0px" }} onChange={(e) => { setFromDate(e.target.value), setLink(''), setDownloadHidden(true) }} />
                    </div>
                </div>
                <div className=" col-md-2">
                    <div>
                        <label id="underline_select" htmlFor="underline_select " style={{ fontSize: '15px',  paddingBottom:'0.5em' }}>To</label><br />
                        <Input type="date" className="cardName filetype" style={{ paddingLeft: "0px" }} onChange={(e) => { setToDate(e.target.value), setLink(''), setDownloadHidden(true) }} />
                    </div>
                </div>
                <div className="col-md-2" style={{paddingTop:'2em'}}>
                    <Button className="btn" style={{ backgroundColor: "#000055", color: "rgb(248 252 248)", marginRight: "2%" }} onClick={(e) => { reportClick(e) }}>Generate BRS</Button>
                </div>

                <div hidden={downloadHidden} style={{ paddingTop:'2.5em' }} className="col-md-2">
                    <a href={link} style={{ textDecoration: 'underline', color: "green", fontSize: "130%", cursor: 'pointer' }} download>Download Report</a>
                </div>
                {/* <div>
                    <div> <a href={link} style={{ textDecoration: 'underline', color:"green", fontSize:"130%", cursor: 'pointer'}}><p>Download Report</p></a>
                        <button className="btn" style={{height:"35px", width: "125px", marginTop: "38px", marginLeft:"-72%", backgroundColor:"#000055", color:"rgb(248 252 248)", marginRight: "2%"}} onClick={(e) => {reportClick(e)}}>Generate BRS</button>
                    </div>
                </div> */}
                {/* <div hidden={downloadHidden}  style={{marginTop:"36%", marginLeft:"-192%"}}>
                    <a href={link} style={{ textDecoration: 'underline', color:"green", fontSize:"130%" }}>Download Report</a>
                </div> */}
            </div>
            <LoaderComponent loaderOpen={loaderOpen} />
        </>
    )
}


export default VRSReport;



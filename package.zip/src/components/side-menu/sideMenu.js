import React from 'react';
import './sideMenu.css';
import {NavLink} from 'react-router-dom';

class SideMenu extends React.Component {
    constructor()
    {
        super();
        this.state = {};
    }

    getSideMenuList()
    {
        const userCredentials = JSON.parse(sessionStorage.getItem("userCredentials"));
        const sideMenuList = userCredentials["side_menu"];

        return (
            <div>  
                {sideMenuList.map(item => (
                    <NavLink
                        to = {item.sideMenu}
                        style={({ isActive }) =>
                        isActive
                            ? {
                                color: '#ffffff',
                                background: '#ff0000',
                            }
                            : { textDecoration: "none" }
                        }
                        key = {item.id}
                    >
                        <li>
                            <div>
                                <span className="icon">
                                    <ion-icon name={item.iconName}></ion-icon>
                                </span>
                                <span className="title">{item.name}</span>
                            </div>
                        </li>

                    </NavLink>  
                ))}
            </div>
        );
    }

    render()
    {
        return (
            <div>
                <div className="side-menu-navigation">
                    <ul>
                        <nav>
                            <li>
                                <div className="icona">
                                    <span className="icon">
                                        <ion-icon name="logo-electron"></ion-icon>
                                    </span>
                                    <span className="title">TeamLease</span>
                                </div>
                            </li>
                            
                            {this.getSideMenuList()}
                            
                            <NavLink to="Settings"
                                style={({ isActive }) =>
                                isActive
                                ? {
                                    color: '#ffffff',
                                    background: '#ff0000',
                                  }
                                : { textDecoration: "none" }
                              }
                            >
                                <li>
                                    <div>
                                        <span className="icon">
                                            <ion-icon name="settings-outline"></ion-icon>
                                        </span>
                                        <span className="title">Setting</span>
                                    </div>
                                </li>
                            </NavLink>

                            <NavLink to="Help"
                                style={({ isActive }) =>
                                isActive
                                ? {
                                    color: '#ffffff',
                                    background: '#ff0000',
                                  }
                                : { textDecoration: "none" }
                              }
                            >
                                <li>
                                    <div>
                                        <span className="icon">
                                            <ion-icon name="help-outline"></ion-icon>
                                        </span>
                                        <span className="title">Help</span>
                                    </div>
                                </li>
                            </NavLink>

                            <NavLink to="/"
                                style={({ isActive }) =>
                                isActive
                                ? {
                                    color: '#ffffff',
                                    background: '#ff0000',
                                  }
                                : { textDecoration: "none" }
                              }
                            >
                                <li>
                                    <div>
                                        <span className="icon">
                                            <ion-icon name="log-out-outline"></ion-icon>
                                        </span>
                                        <span className="title signout">Sign Out</span>
                                    </div>
                                </li>
                            </NavLink>
                        </nav>
                    </ul>
                </div>

                {/* <Helmet>
                    <script src='script.js' type="text/javascript" />
                </Helmet> */}
            </div>
        );
    }
}

export default SideMenu;
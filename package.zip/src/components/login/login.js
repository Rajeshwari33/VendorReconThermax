import React, {useState} from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.css';
import lock from '../../assets/images/lock.png';
import key from '../../assets/images/key.png';
import sandhi from '../../assets/images/sandhi.png';
import passwordIcon from '../../assets/images/passwordIcon.svg';
import emailIcon from '../../assets/images/emailIcon.svg';
import './login.css';
import {LoginUserToServer} from  '../../services/auth-service/authService.js'

function Login()
{
    const navigate = useNavigate();
    const [image, changeBackGround] = useState(lock);
    const [emailAddress, setEmailAddress] = useState("");
    const [password, setPassword] = useState("");
    // const headers = {
    //     'Authorization': 'Bearer my-token',
    //     'My-Custom-Header': 'foobar'
    // }

    const validateEmailAddress = (inputData) => {
        var validRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
        if (inputData.match(validRegex))
        {
            return true;
        }
        else
        {
            return false;
        }
    };

    function navigateToForgotPassword() {
        navigate('/ForgotPassword');
    };

    function signIn() {
        if (!validateEmailAddress(emailAddress))
        {
            alert("Email Address is not Valid. Please Enter a Valid Email Address!!!");
        }
        else
        {
            validateCredentials();
        }
    };

    function validateCredentials()
    {
        let payload = {
            emailAddress: emailAddress,
            password: password
        }

        var loginUserCredentials = LoginUserToServer();

        axios.post(loginUserCredentials[1], payload, loginUserCredentials[0])
        .then(
            response => {
                console.log("Validate Credentials Response!!!", response);
                let responseData = response["data"];
                if (responseData["Status"] === "Success")
                {
                    let userCredentials = responseData["user_credentials"]; 
                    sessionStorage.setItem("userCredentials", JSON.stringify(userCredentials));
                    navigate(userCredentials["config"]["default_page"]);
                }
            }
        ).catch(
            error => {
                console.log("Error", error);
                alert("Error in Login User!!!");
            }
        );
    }

    return (
        <div className="containers">
            <img src={image} alt="No Images" style={{width: '1536px', height: '761px'}}  />
            <div className="box"></div>
            <div>
                <img src={sandhi} width="153px" height="36px" className="imgsandhi" alt="sandhi"/>
                <form className="main-form">
                    <label htmlFor="email" className="emailid">Email ID</label>
                    <input type="email" id="email" name="emailAddress" className="emailidinput" value={emailAddress} onClick={() => changeBackGround(lock)} onChange={(e) => {setEmailAddress(e.target.value)}} />
                    <div className="emailicon">
                        <img src={emailIcon} alt="email"/>
                    </div>
                    <label htmlFor="Pwd" className="password">Password</label>
                    <input type="password" id="Pwd" name="password" className="passwordinput" value={password} onClick={() => changeBackGround(key)} onChange={(e) => {setPassword(e.target.value)}}/>
                    <div className="passwordicon">
                        <img src={passwordIcon} alt="password"/>
                    </div>
                    <div className="topnav">
                        <input type="checkbox" name="" className="checkbox-1 " />
                        <span className="top-left">Remember Me</span>
                        <p id="forgot-password-id" className="top-right" onClick={navigateToForgotPassword}>Forgot Password?</p>
                    </div>
                    <input type="button" value="Login" className="loginbtn" onClick={signIn}/>
                </form>
            </div>
        </div>
    )
}

export default Login;
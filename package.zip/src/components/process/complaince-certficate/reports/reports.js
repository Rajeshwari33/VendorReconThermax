import React, { useState, useEffect } from "react";
import Select from "react-select";
import './reports.css';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-balham.css';
import { AgGridReact } from 'ag-grid-react';
import LoaderComponent from "../../../../libraries/loader/loader";
import { getExcelReportFromServer, getCCPdfFromServer, getSendEmail } from "../../../../services/process/compliance-certificate/compCertificateReportService.js";
import axios from "axios";
import excelIcon from '../../../../assets/images/excel.png';
import pdfIcon from '../../../../assets/images/pdf.png';
import * as XLSX from 'xlsx';

function ComplainceCertificateReport()
{

    const gridColumnDefsExcelESIC = [    
        {field: 'reference_text_1', headerName: 'Client ID', sortable: false, filter: true, resizable: true},
        {field: 'reference_text_2', headerName: 'Client Name', sortable: false, filter: true, resizable: true},
        {field: 'reference_text_3', headerName: 'Employee No', sortable: false, filter: true, resizable: true},
        // {field: 'reference_dec_1', headerName: 'No of Working Days Main', sortable: false, filter: true, resizable: true},
        {field: 'reference_dec_2', headerName: 'EMPESI(CTC  IT )', sortable: false, filter: true, resizable: true},
        {field: 'reference_dec_3', headerName: 'AEMPESI( IT )', sortable: false, filter: true, resizable: true},
        {field: 'reference_dec_4', headerName: 'Gross ESIC Main', sortable: false, filter: true, resizable: true},
        {field: 'reference_dec_5', headerName: 'EMPLESI( IT )', sortable: false, filter: true, resizable: true},
        {field: 'reference_dec_6', headerName: 'AEMPLESI( IT )', sortable: false, filter: true, resizable: true},
        {field: 'reference_dec_7', headerName: 'SR3.25%', sortable: false, filter: true, resizable: true},
        {field: 'reference_dec_8', headerName: 'SR0.75%', sortable: false, filter: true, resizable: true},
        {field: 'reference_dec_9', headerName: 'SR4%', sortable: false, filter: true, resizable: true},
        // {field: 'reference_dec_10', headerName: 'No of Working Days OPP', sortable: false, filter: true, resizable: true},
        {field: 'reference_dec_11', headerName: 'EMPESI', sortable: false, filter: true, resizable: true},
        {field: 'reference_dec_12', headerName: 'AEMPESI', sortable: false, filter: true, resizable: true},
        {field: 'reference_dec_13', headerName: 'Gross ESIC OPP', sortable: false, filter: true, resizable: true},
        {field: 'reference_dec_14', headerName: 'EMPLESI', sortable: false, filter: true, resizable: true},
        {field: 'reference_dec_15', headerName: 'AEMPLESI', sortable: false, filter: true, resizable: true},
        {field: 'reference_dec_16', headerName: 'OR3.25%', sortable: false, filter: true, resizable: true},
        {field: 'reference_dec_17', headerName: 'OR0.75%', sortable: false, filter: true, resizable: true},
        {field: 'reference_dec_18', headerName: 'OR4%', sortable: false, filter: true, resizable: true},
        {field: 'reference_dec_19', headerName: 'No of Working Days', sortable: false, filter: true, resizable: true},
        {field: 'reference_dec_20', headerName: 'Total Salary', sortable: false, filter: true, resizable: true},
        {field: 'reference_dec_21', headerName: 'Per Day Wages', sortable: false, filter: true, resizable: true},
        {field: 'reference_dec_22', headerName: 'Total 3.25%', sortable: false, filter: true, resizable: true},
        {field: 'reference_dec_23', headerName: 'Total 0.75%', sortable: false, filter: true, resizable: true},
        {field: 'reference_dec_24', headerName: 'Total 4%', sortable: false, filter: true, resizable: true},
        {field: 'reference_dec_25', headerName: 'Arrived 0.75%', sortable: false, filter: true, resizable: true},
        {field: 'reference_dec_26', headerName: 'Arrived 3.25%', sortable: false, filter: true, resizable: true},
        {field: 'reference_dec_27', headerName: 'Arrived 4%', sortable: false, filter: true, resizable: true},
        {field: 'reference_dec_28', headerName: 'Diff in 3.25%', sortable: false, filter: true, resizable: true},
        {field: 'reference_dec_29', headerName: 'Diff in 0.75%', sortable: false, filter: true, resizable: true},
        {field: 'reference_dec_30', headerName: 'Diff in 4%', sortable: false, filter: true, resizable: true},
        {field: 'reference_dec_4', headerName: 'Remarks', sortable: false, filter: true, resizable: true},
        {field: 'reference_dec_31', headerName: 'Arrived gross', sortable: false, filter: true, resizable: true}
      ];

      const gridColumnDefsExcelPT = [
        {field: 'reference_text_1', headerName: 'Client ID', sortable: false, filter: true, resizable: true},
        {field: 'reference_text_2', headerName: 'Employee No', sortable: false, filter: true, resizable: true},
        {field: 'reference_dec_1', headerName: 'PT Data', sortable: false, filter: true, resizable: true}
      ]

    const gridColumnDefsPDF = [
        {field: '', headerName: '', checkboxSelection: true, headerCheckboxSelection: true, maxWidth: 40, pinned: 'left', sortable: true, filter: false, resizable: false, suppressAutoSize: true, suppressSizeToFit: true, lockPosition: true},
        {field: 'client_id', headerName: 'Client ID', sortable: false, filter: true, resizable: true},
        {field: 'esic_no_of_ass', headerName: 'ESIC No. of Associates', sortable: false, filter: true, resizable: true},
        {field: 'esic_daily_wages', headerName: 'ESIC Daily Wages', sortable: false, filter: true, resizable: true},
        {field: 'esic_emo_contr_075_percent', headerName: 'ESIC Emp Contrib 0.75%', sortable: false, filter: true, resizable: true},
        {field: 'esic_emo_contr_325_percent', headerName: 'ESIC Emp Contrib 3.25%', sortable: false, filter: true, resizable: true},
        {field: 'total_esic_contr', headerName: 'ESIC Total', sortable: false, filter: true, resizable: true},
        {field: 'pt_no_of_ass', headerName: 'PT No.of Associates', sortable: false, filter: true, resizable: true},
        {field: 'pt_total_data', headerName: 'PT Total', sortable: false, filter: true, resizable: true}
    ]

    const [selectedOptions, setSelectedOptions] = useState();
    const [selectedOptionsFileType, setSelectedOptionsFileType] = useState();
    const [inputMonth, setInputMonth] = useState(undefined);
    // const [userCredentials] = useState(JSON.parse(sessionStorage.getItem("userCredentials")));
    const [hideResultGrid, setHideResultGrid] = useState(true);
    const [hideExcelGrid, setHideExcelGrid] = useState(true);
    const [hideSelectFileType, setHideSelectFileType] = useState(true);
    const [loaderOpen, setLoaderOpen] = useState(true);
    const [columnDefsExcel, setColumnDefsExcel] = useState([]);
    const [columnDefsPDF] = useState(gridColumnDefsPDF);
    const [rowDataExcel, setRowDataExcel] = useState(undefined);
    const [rowDataPDF, setRowDataPDF] = useState(undefined);
    const [paginationSize] = useState(15);
    const [fileName] = useState("download");
    const [clickedDataPDF, setClickedDataPDF] = useState(undefined);
    const [certificateButtonDisable, setCertificateButtonDisable] = useState(true);

    var getExcelExportApi = getExcelReportFromServer();
    var getPdfFileApi = getCCPdfFromServer();
    var sendEmail = getSendEmail();
 
    useEffect(() => {
        setLoaderOpen(false);
    }, []);

    function handleSelect(data) {
        // console.log(data);
        setSelectedOptions(data);
        if (data["value"] === "excel")
        {
            setHideSelectFileType(false);
        }
        else
        {
            setHideSelectFileType(true);
        }
        setHideResultGrid(true);
        setHideExcelGrid(true);
    }

    function handleSelectFileType(data) {
        setSelectedOptionsFileType(data);
        setHideResultGrid(true);
        setHideExcelGrid(true);
        setRowDataExcel(undefined);
        if (data["value"] === "esic")
        {
            setColumnDefsExcel(gridColumnDefsExcelESIC);
        }
        else if (data["value"] === "pt")
        {
            setColumnDefsExcel(gridColumnDefsExcelPT);
        }
        else
        {
            setColumnDefsExcel([]);
        }
    }

    const customStyles = {
        control: base => ({
          ...base,
          height: 35,
          minHeight: 35,
          marginTop: 0,
          paddingTop: -5,
          fontSize: 14,
          left: -31
        })
    };

    const optionList = [
        { value: "cc", label: "Compliance Certificate"},
        { value: "excel", label: "Excel Files"}
    ];

    const fileTypeOptionsList = [
        { value: "esic", label: "ESIC"},
        { value: "epf", label: "EPF"},
        { value: "pt", label: "Professional Tax"}
    ]

    const onSelectionChangedGridPDF = (event) => {
        let clickedData = event.api.getSelectedRows();
        // console.log("clicked Data", clickedData);
        setClickedDataPDF(clickedData);
        if (clickedData.length > 0)
        {
            setCertificateButtonDisable(false);
        }
        else
        {
            setCertificateButtonDisable(true);
        };
    };

    function searchClick(event)
    {
        if (selectedOptions === undefined)
        {
            alert("Please Select Download Type!!!");
        }
        else if (inputMonth === undefined)
        {
            alert("Please Choose the Month!!!");
        }
        else if (selectedOptions !== undefined && inputMonth !== undefined)
        {
            if (selectedOptions["value"] === "cc")
            {
                pdfReportGridData();
            }
            else if (selectedOptions["value"] === "excel")
            {
                if (selectedOptionsFileType === undefined)
                {
                    alert("Please Choose File Type!!!");
                }
                else if (selectedOptionsFileType !== undefined)
                {
                    excelReportGridData();
                }
            }
            else
            {
                setHideResultGrid(true);
            };
        }
    }

    function excelReportGridData()
    {
        setLoaderOpen(true);
        setHideExcelGrid(false);
        setHideResultGrid(true);

        let payload = {
            "type": selectedOptionsFileType["value"],
            "upload_month": inputMonth
        }
        console.log("payload", payload);

        axios.get(getExcelExportApi[1], {params : payload}, getExcelExportApi[0])
        .then(
            response => {
                console.log("Get Excel Export Grid Data Response !!!", response);
                let data = response["data"];
                if (data["Status"] === "Success")
                {
                    setRowDataExcel(data["response_data"]);
                };

                setLoaderOpen(false);
            }
        ).catch(
            error => {
                console.log("Error in File Upload List!!!", error);
                setLoaderOpen(false);
            }
        );

    }

    function pdfReportGridData()
    {
        setLoaderOpen(true);
        setHideExcelGrid(true);
        setHideResultGrid(false);

        let payload = {
            "type": "cc",
            "upload_month": inputMonth
        };

        console.log("payload", payload);

        axios.get(getExcelExportApi[1], {params : payload}, getExcelExportApi[0])
        .then(
            response => {
                console.log("Get Excel Export Grid Data Response !!!", response);
                let data = response["data"];
                if (data["Status"] === "Success")
                {
                    setRowDataPDF(data["response_data"]);
                };

                setLoaderOpen(false);
            }
        ).catch(
            error => {
                console.log("Error in File Upload List!!!", error);
                setLoaderOpen(false);
            }
        );

    }

    function exportJsonToXLSX(data, sheetName, excelFileName)
    {
        try
        {
            var workBook = XLSX.utils.book_new();
            var workSheet = XLSX.utils.json_to_sheet(data, {
                skipHeader : false,
            });
            XLSX.utils.book_append_sheet(workBook, workSheet, sheetName);
            XLSX.writeFile(workBook, excelFileName);
            return true;
        }
        catch
        {
            return false;
        }
    }

    function excelExportClick()
    {
        let fileNameChange = fileName + "_" + selectedOptionsFileType["value"] + ".xlsx";
        let sheetName = selectedOptionsFileType["value"];
        // console.log("rowDataExcel", rowDataExcel);

        let excelExportData = [];

        for (let i=0; i<rowDataExcel.length; i++)
        {
            
            let data = {};
            for (let key in rowDataExcel[i])
            {
                for (let j=0; j<columnDefsExcel.length; j++)
                {
                    if (key === columnDefsExcel[j]["field"])
                    {
                        data[columnDefsExcel[j]["headerName"]] = rowDataExcel[i][key]
                    }
                }
            }

            excelExportData.push(data);
        };

        // console.log(excelExportData);

        exportJsonToXLSX(excelExportData, sheetName, fileNameChange);
    }

    function certificateClick(event)
    {
        // console.log(clickedDataPDF);

        setLoaderOpen(true);

        let payload = {
            "clientId": clickedDataPDF[0]["client_id"],
            "uploadMonth": clickedDataPDF[0]["upload_month"]
        };

        axios.get(getPdfFileApi[1], {params : payload}, getPdfFileApi[0])
        .then(
            response => {
                // console.log("Get CC PDF Response ", response);
                let data = response["data"];
                if (data["Status"] === "Success")
                {
                    window.open(data["response_data"]);
                };
                setLoaderOpen(false);
            }
        ).catch(
            error => {
                console.log("Error in Get CC PDF Response!!!", error);
                setLoaderOpen(false);
            }
        );

    };

    function sendEmailToClient(event)
    {
        setLoaderOpen(true);

        let payload = {
            "clientId": clickedDataPDF[0]["client_id"],
            "uploadMonth": clickedDataPDF[0]["upload_month"]
        };

        axios.get(sendEmail[1], {params : payload}, sendEmail[0])
        .then(
            response => {
                console.log("Get Send Email To Client Response ", response);
                let data = response["data"];
                if (data["Status"] === "Success")
                {
                    let message = "Email Sent to the Client - " + clickedDataPDF[0]["client_id"] + " Successfully!!!";
                    
                    alert(message);
                };
                setLoaderOpen(false);
            }
        ).catch(
            error => {
                console.log("Error in Get Send Email To Client Response!!!", error);
                setLoaderOpen(false);
            }
        );
    }

    return(
        <>
            <div className="report-cardBox">
                <div className="report-card">
                    <div>
                        <label htmlFor="underline_select " className="sr-only numbers" style={{fontSize: '15px', left: '-30px'}}>Download Type</label><br />
                        <div className="cardName">
                            <div className="dropdown-container">
                                <Select
                                    options={optionList}
                                    placeholder="Select Type"
                                    value={selectedOptions}
                                    onChange={handleSelect}
                                    isSearchable={true}
                                    styles = {customStyles}
                                //   isMulti
                                />
                            </div>
                        </div>
                    </div>
                </div>

                <div className="report-card" hidden={hideSelectFileType}>
                    <div>
                        <label htmlFor="underline_select " className="sr-only numbers " style={{fontSize: '15px', left: '-30px'}}>File Type</label><br />
                        <div className="cardName">
                            <div className="dropdown-container">
                                <Select 
                                    options={fileTypeOptionsList}
                                    placeholder="Select Type"
                                    value={selectedOptionsFileType}
                                    onChange={handleSelectFileType}
                                    isSearchable={true}
                                    styles = {customStyles}
                                />
                            </div>
                        </div>
                    </div>
                </div>

                <div className="report-card">
                    <div>
                        <label  id="underline_select" htmlFor="underline_select " className="sr-only numbers" style={{fontSize: '15px'}}>Month</label><br />
                        <input type="month" className="cardName filetype" style={{paddingLeft: "10px"}} onChange={(e) => {setInputMonth(e.target.value)}} />
                    </div>
                </div>

                <button className="btn" style={{height:"35px", width: "92px", marginTop: "48px", marginLeft:"0px", backgroundColor:"#000055", color:"#ffffff"}} onClick={(e) => {searchClick(e)}}>Search</button> 

            </div>

            <div className="report" hidden={hideResultGrid}>
                <img src={pdfIcon} alt="No Images" style={{width: '40px', height: '37px'}}  className="excel-icon-class" title="Export All" />
                <div className="ag-theme-balham report-layer">
                    <AgGridReact
                        columnDefs = {columnDefsPDF}
                        rowData = {rowDataPDF}
                        paginationPageSize = {paginationSize}
                        pagination = {true}
                        animateRow = {true}
                        rowSelection = {'single'}
                        onSelectionChanged = {onSelectionChangedGridPDF}
                    ></AgGridReact>
                </div>
                <button className="btn" style={{height:"35px", width: "92px", marginTop: "5px", marginLeft:"0px", backgroundColor:"#000055", color:"#ffffff"}} onClick={(e) => {certificateClick(e)}} disabled={certificateButtonDisable}>Certificate</button>
                <button className="btn" style={{height:"34px", width: "64px", marginTop: "-45px", marginLeft:"110px", backgroundColor:"#000055", color:"#ffffff"}} onClick={(e) => {sendEmailToClient(e)}} disabled={certificateButtonDisable}>Email</button>
            </div>

            <div className="report" hidden={hideExcelGrid}>
                <img src={excelIcon} alt="No Images" style={{width: '40px', height: '37px'}}  className="excel-icon-class" onClick={() => {excelExportClick()}} title="Export" />
                <div className="ag-theme-balham report-layer">
                    <AgGridReact
                        columnDefs = {columnDefsExcel}
                        rowData = {rowDataExcel}
                        paginationPageSize = {paginationSize}
                        pagination = {true}
                        animateRows = {true}
                    >
                    </AgGridReact>
                </div>
            </div>

            <LoaderComponent loaderOpen={loaderOpen} />
        </>
    );
}

export default ComplainceCertificateReport;



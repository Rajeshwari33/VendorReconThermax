import logging
import json
import re
from datetime import datetime
from django.views.decorators.csrf import csrf_exempt
from .models import *
from django.http import JsonResponse
import requests
from django.db import connection
import pandas as pd
import os
from pathlib import Path
import shutil
from rest_framework import viewsets
from .serializers import *
import warnings
from .packages import read_file, send_email, write_vrs, send_request, database_connect, write_brs
from .packages import closing_balance as cb
from sqlalchemy import create_engine, URL, update, text
from sqlalchemy.orm import sessionmaker
import mysql.connector
from sqlalchemy.sql import text as sa_text
import sqlalchemy as sa

def get_write_vrs_report(data):
    try:
        write_brs_output = write_vrs.write_vrs_file(data)
        if write_brs_output["Status"] == "Success":
            return {"Status": "Success", "file_generated": write_brs_output["file_generated"]}
        elif write_brs_output["Status"] == "Error":
            logger.info("Error in Getting Write BRS Report!!!")
            logger.info(write_brs_output["Message"])
            return {"Status": "Error"}
    except Exception:
        logger.error("Error in Writing BRS Report!!!", exc_info=True)
        return {"Status": "Error"}

@csrf_exempt
def get_vrs_report(request, *args, **kwargs):
    try:
        if request.method == "POST":
            report_generation = ReportGeneration.objects.filter(is_report_generating=False)
            if report_generation:

                body = request.body.decode('utf-8')
                data = json.loads(body)

                for k, v in data.items():
                    if k == "tenantId":
                        tenant_id = v
                    if k == "groupId":
                        group_id = v
                    if k == "entityId":
                        entity_id = v
                    if k == "mProcessingLayerId":
                        m_processing_layer_id = v
                    if k == "mProcessingSubLayerId":
                        m_processing_sub_layer_id = v
                    if k == "processingLayerId":
                        processing_layer_id = v
                    if k == "reportFromDate":
                        report_from_date = v
                    if k == "reportToDate":
                        report_to_date = v

                processing_layer_id_rep = 1102
                vendor_matching_details = VendorMatchingDetails.objects.filter(
                    tenants_id=tenant_id,
                    groups_id=group_id,
                    entities_id=entity_id,
                    m_processing_layer_id=m_processing_layer_id,
                    m_processing_sub_layer_id=m_processing_sub_layer_id,
                    processing_layer_id=processing_layer_id
                )

                if vendor_matching_details:

                    report_generation_1 = ReportGeneration.objects.filter(id=1)

                    for report in report_generation_1:
                        report.is_report_generating = 1
                        report.save()

                    for vendor in vendor_matching_details:
                        vendor_code = vendor.vendor_code
                        vendor_name = vendor.vendor_name
                        vendor_site_code = vendor.vendor_site_code
                        vendor_category = vendor.vendor_category
                        liability_account = vendor.liability_account
                        division = vendor.division
                        pan_number = vendor.pan_number
                        gst_number = vendor.gst_number

                    reco_settings_rep_gen = RecoSettings.objects.filter(
                        tenants_id=tenant_id,
                        groups_id=group_id,
                        entities_id=entity_id,
                        m_processing_layer_id=m_processing_layer_id,
                        m_processing_sub_layer_id=m_processing_sub_layer_id,
                        processing_layer_id=processing_layer_id_rep,
                        setting_key='report_generation',
                        is_active=1
                    )

                    for setting in reco_settings_rep_gen:
                        report_generation_count = setting.setting_value

                    reco_settings_tmx_dr_cr = RecoSettings.objects.filter(
                        tenants_id=tenant_id,
                        groups_id=group_id,
                        entities_id=entity_id,
                        m_processing_layer_id=m_processing_layer_id,
                        m_processing_sub_layer_id=m_processing_sub_layer_id,
                        processing_layer_id=processing_layer_id_rep,
                        setting_key='vrs_rep_tmx_dr_cr',
                        is_active=1
                    )

                    for setting in reco_settings_tmx_dr_cr:
                        vrs_rep_tmx_dr_cr_query = setting.setting_value

                    reco_settings_vendor_dr_cr = RecoSettings.objects.filter(
                        tenants_id=tenant_id,
                        groups_id=group_id,
                        entities_id=entity_id,
                        m_processing_layer_id=m_processing_layer_id,
                        m_processing_sub_layer_id=m_processing_sub_layer_id,
                        processing_layer_id=processing_layer_id_rep,
                        setting_key='vrs_rep_vendor_dr_cr',
                        is_active=1
                    )

                    for setting in reco_settings_vendor_dr_cr:
                        vrs_rep_vendor_dr_cr_query = setting.setting_value

                    reco_settings_vrs_rep_vendor_all = RecoSettings.objects.filter(
                        tenants_id=tenant_id,
                        groups_id=group_id,
                        entities_id=entity_id,
                        m_processing_layer_id=m_processing_layer_id,
                        m_processing_sub_layer_id=m_processing_sub_layer_id,
                        processing_layer_id=processing_layer_id_rep,
                        setting_key='vrs_rep_vendor_all',
                        is_active=1
                    )

                    for setting in reco_settings_vrs_rep_vendor_all:
                        vrs_rep_vendor_all_query = setting.setting_value

                    reco_settings_vrs_rep_tmx_all = RecoSettings.objects.filter(
                        tenants_id=tenant_id,
                        groups_id=group_id,
                        entities_id=entity_id,
                        m_processing_layer_id=m_processing_layer_id,
                        m_processing_sub_layer_id=m_processing_sub_layer_id,
                        processing_layer_id=processing_layer_id_rep,
                        setting_key='vrs_rep_tmx_all',
                        is_active=1
                    )

                    for setting in reco_settings_vrs_rep_tmx_all:
                        vrs_rep_tmx_all_query = setting.setting_value

                    setting_queries_vrs_rep_tmx_closing_bal = SettingQueries.objects.filter(
                        tenants_id=tenant_id,
                        groups_id=group_id,
                        entities_id=entity_id,
                        m_processing_layer_id=m_processing_layer_id,
                        m_processing_sub_layer_id=m_processing_sub_layer_id,
                        setting_key='vrs_rep_tmx_closing_bal',
                        is_active=1
                    )

                    for setting in setting_queries_vrs_rep_tmx_closing_bal:
                        vrs_rep_tmx_closing_bal_query = setting.setting_value

                    setting_queries_vrs_rep_vendor_closing_bal = SettingQueries.objects.filter(
                        tenants_id=tenant_id,
                        groups_id=group_id,
                        entities_id=entity_id,
                        m_processing_layer_id=m_processing_layer_id,
                        m_processing_sub_layer_id=m_processing_sub_layer_id,
                        setting_key='vrs_rep_vendor_closing_bal',
                        is_active=1
                    )

                    for setting in setting_queries_vrs_rep_vendor_closing_bal:
                        vrs_rep_vendor_closing_bal_query = setting.setting_value

                    setting_queries_vrs_rep_ext_int_dr_cr = SettingQueries.objects.filter(
                        tenants_id=tenant_id,
                        groups_id=group_id,
                        entities_id=entity_id,
                        m_processing_layer_id=m_processing_layer_id,
                        m_processing_sub_layer_id=m_processing_sub_layer_id,
                        setting_key='vrs_rep_ext_int_dr_cr',
                        is_active=1
                    )

                    for setting in setting_queries_vrs_rep_ext_int_dr_cr:
                        vrs_rep_ext_int_dr_cr_query = setting.setting_value

                    vrs_rep_tmx_dr_cr_query_proper = vrs_rep_tmx_dr_cr_query.replace("{tenants_id}",
                                                                                     str(tenant_id)).replace(
                        "{groups_id}", str(group_id)). \
                        replace("{entities_id}", str(entity_id)).replace("{m_processing_layer_id}",
                                                                         str(m_processing_layer_id)). \
                        replace("{m_processing_sub_layer_id}", str(m_processing_sub_layer_id)).replace(
                        "{processing_layer_id}", str(processing_layer_id)). \
                        replace("{from_date}", report_from_date).replace("{to_date}", report_to_date)

                    vrs_rep_vendor_dr_cr_query_proper = vrs_rep_vendor_dr_cr_query.replace("{tenants_id}",
                                                                                           str(tenant_id)).replace(
                        "{groups_id}", str(group_id)). \
                        replace("{entities_id}", str(entity_id)).replace("{m_processing_layer_id}",
                                                                         str(m_processing_layer_id)). \
                        replace("{m_processing_sub_layer_id}", str(m_processing_sub_layer_id)).replace(
                        "{processing_layer_id}", str(processing_layer_id)). \
                        replace("{from_date}", report_from_date).replace("{to_date}", report_to_date)

                    vrs_rep_vendor_all_query_proper = vrs_rep_vendor_all_query.replace("{tenants_id}",
                                                                                       str(tenant_id)).replace(
                        "{groups_id}", str(group_id)). \
                        replace("{entities_id}", str(entity_id)).replace("{m_processing_layer_id}",
                                                                         str(m_processing_layer_id)). \
                        replace("{m_processing_sub_layer_id}", str(m_processing_sub_layer_id)).replace(
                        "{processing_layer_id}", str(processing_layer_id)). \
                        replace("{from_date}", report_from_date).replace("{to_date}", report_to_date)

                    vrs_rep_tmx_all_query_proper = vrs_rep_tmx_all_query.replace("{tenants_id}",
                                                                                 str(tenant_id)).replace("{groups_id}",
                                                                                                         str(group_id)). \
                        replace("{entities_id}", str(entity_id)).replace("{m_processing_layer_id}",
                                                                         str(m_processing_layer_id)). \
                        replace("{m_processing_sub_layer_id}", str(m_processing_sub_layer_id)).replace(
                        "{processing_layer_id}", str(processing_layer_id)). \
                        replace("{from_date}", report_from_date).replace("{to_date}", report_to_date)

                    vrs_rep_tmx_closing_bal_query_proper = vrs_rep_tmx_closing_bal_query.replace("{tenants_id}", str(tenant_id)).\
                        replace("{groups_id}", str(group_id)).replace("{entities_id}", str(entity_id)).replace("{m_processing_layer_id}", str(m_processing_layer_id)).\
                        replace("{m_processing_sub_layer_id}", str(m_processing_sub_layer_id)).replace("{processing_layer_id}", str(processing_layer_id))

                    vrs_rep_vendor_closing_bal_query_proper = vrs_rep_vendor_closing_bal_query.replace("{tenants_id}", str(tenant_id)). \
                        replace("{groups_id}", str(group_id)).replace("{entities_id}", str(entity_id)).replace("{m_processing_layer_id}", str(m_processing_layer_id)).\
                        replace("{m_processing_sub_layer_id}", str(m_processing_sub_layer_id)).replace("{processing_layer_id}", str(processing_layer_id))

                    vrs_rep_ext_int_dr_cr_query_proper = vrs_rep_ext_int_dr_cr_query.replace("{tenants_id}", str(tenant_id)).\
                        replace("{groups_id}", str(group_id)).replace("{entities_id}", str(entity_id)).replace("{m_processing_layer_id}", str(m_processing_layer_id)).\
                        replace("{m_processing_sub_layer_id}", str(m_processing_sub_layer_id)).replace("{processing_layer_id}", str(processing_layer_id)).\
                        replace("{from_date}", report_from_date).replace("{to_date}", report_to_date)

                    
                    vrs_rep_tmx_dr_cr_query_output = execute_sql_query(vrs_rep_tmx_dr_cr_query_proper, object_type="")[0]
                    vrs_rep_vendor_dr_cr_query_output = \
                    execute_sql_query(vrs_rep_vendor_dr_cr_query_proper, object_type="")[0]
                    vrs_rep_vendor_all_query_output = \
                    execute_sql_query(vrs_rep_vendor_all_query_proper, object_type="")[0]
                    vrs_rep_tmx_all_query_output = execute_sql_query(vrs_rep_tmx_all_query_proper, object_type="")[0]
                    vrs_rep_tmx_closing_bal_query_output = json.loads(execute_sql_query(vrs_rep_tmx_closing_bal_query_proper, object_type="table"))
                    vrs_rep_vendor_closing_bal_query_output = json.loads(execute_sql_query(vrs_rep_vendor_closing_bal_query_proper, object_type="table"))
                    vrs_rep_ext_int_dr_cr_query_output = json.loads(execute_sql_query(vrs_rep_ext_int_dr_cr_query_proper, object_type="table"))

                    print("vrs_rep_tmx_all_query_proper", vrs_rep_tmx_all_query_proper)

                    thermax_closing_balance = float(vrs_rep_tmx_closing_bal_query_output['data'][0]['internal_closing_balance'])
                    vendor_closing_balance = float(vrs_rep_vendor_closing_bal_query_output['data'][0]['external_closing_balance'])

                    external_debit_amount = float(vrs_rep_ext_int_dr_cr_query_output['data'][0]['ext_debit_amount'])
                    external_credit_amount = float(vrs_rep_ext_int_dr_cr_query_output['data'][0]['ext_credit_amount'])
                    internal_debit_amount = float(vrs_rep_ext_int_dr_cr_query_output['data'][0]['int_debit_amount'])
                    internal_credit_amount = float(vrs_rep_ext_int_dr_cr_query_output['data'][0]['int_credit_amount'])

                    opening_balance_difference_amount = ( thermax_closing_balance - vendor_closing_balance ) - (internal_credit_amount + external_credit_amount - internal_debit_amount - external_debit_amount)

                    # print("vrs_rep_ext_int_dr_cr_query_output")
                    # print(vrs_rep_ext_int_dr_cr_query_output)



                    # closing_balance_query = "select SUM(OPENING_BALANCE) AS CLOSING_BALANCE from XXTMX.XXTMX_AP_PARTY_LEDGER_T where SUPPLIER_CODE = '{supplier_code}' AND DIVISION_NAME = '{division_name}' AND NARRATION = 'Closing Balance'"
                    # closing_balance_query_proper = closing_balance_query.replace("{supplier_code}",
                    #                                                              str(vendor_code)).replace(
                    #     '{division_name}', division)
                    #
                    # oracle_connect = database_connect.OracleConnection(query=closing_balance_query_proper,
                    #                                                    object_type="table")
                    # closing_balance_query_output = json.loads(oracle_connect.get_query_output())
                    # thermax_closing_balance = closing_balance_query_output["data"][0]["CLOSING_BALANCE"]

                    data = {
                        "vendor_code": vendor_code,
                        "vendor_name": vendor_name,
                        "vendor_site_code": vendor_site_code,
                        "vendor_category": vendor_category,
                        "liability_account": liability_account,
                        "division": division,
                        "pan_number": pan_number,
                        "gst_number": gst_number,
                        "report_generation_date": str(datetime.today()),
                        "report_from_date": report_from_date,
                        "report_to_date": report_to_date,
                        "report_generation_count": report_generation_count,
                        "vrs_rep_tmx_dr_cr_query_output": vrs_rep_tmx_dr_cr_query_output,
                        "vrs_rep_vendor_dr_cr_query_output": vrs_rep_vendor_dr_cr_query_output,
                        "vrs_rep_vendor_all_query_output": vrs_rep_vendor_all_query_output,
                        "vrs_rep_tmx_all_query_output": vrs_rep_tmx_all_query_output,
                        "thermax_closing_balance": thermax_closing_balance,
                        "vendor_closing_balance": vendor_closing_balance,
                        "opening_balance_difference": opening_balance_difference_amount
                    }

                    vrs_report_output = get_write_brs_report(data)
                    print("vrs_report_output", vrs_report_output)

                    if vrs_report_output["Status"] == "Success":
                        for setting in reco_settings_rep_gen:
                            setting.setting_value = str(int(report_generation_count) + 1)
                            setting.save()

                        report_generation_1 = ReportGeneration.objects.filter(id=1)

                        for report in report_generation_1:
                            report.is_report_generating = 0
                            report.save()

                        return JsonResponse(
                            {"Status": "Success", "file_generated": vrs_report_output["file_generated"]})
                    else:
                        report_generation_1 = ReportGeneration.objects.filter(id=1)

                        for report in report_generation_1:
                            report.is_report_generating = 0
                            report.save()

                        return JsonResponse({"Status": "Error"})
                else:

                    report_generation_1 = ReportGeneration.objects.filter(id=1)

                    for report in report_generation_1:
                        report.is_report_generating = 0
                        report.save()

                    return JsonResponse({"Status": "VNR", "Message": "Vendor Not Registered!!!"})
            else:
                return JsonResponse(
                    {"Status": "Report Generating", "Message": "User is Currently Generating Report!!!"})

        else:
            return JsonResponse({"Status": "Error", "Message": "POST Method Not Received!!!"})

    except Exception:
        report_generation_1 = ReportGeneration.objects.filter(id=1)

        for report in report_generation_1:
            report.is_report_generating = 0
            report.save()

        logger.error("Error in Get VRS Report Function!!!", exc_info=True)
        return JsonResponse({"Status": "Error"})

import React from 'react';


function Insurance({hidden})
{
    return (
        <>
            <div hidden={hidden}>
            Insurance
            </div>
        </>
    );
}

export default  Insurance;
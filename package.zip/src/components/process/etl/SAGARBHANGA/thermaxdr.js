// App.js
import { useEffect, useState,useMemo,useCallback } from "react";
// import "./App.css";
import "../etlsecound.css";
import hdfcs from '../../../../assets/images/banks/thermax.png';

import record from './tharmaxdr.json';
import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
const GridExample2 = () => {
    const containerStyle = useMemo(() => ({ width: "100%", height: "100%" }), []);
    const gridStyle = useMemo(() => ({ height: "100%", width: "100%" }), []);
    const [rowData, setRowData] = useState();
    const [columnDefs, setColumnDefs] = useState([
      { field: "DIV", minWidth: 170 },
      { field: "GL CODE" },
      { field: "GL DESC" },
      { field: "VENDOR CODE" },
      { field: "VENDOR NAME" },
      { field: "VENDOR SITE" },
      { field: "DOC CATEGORY" },
      { field: "DOC NUMBER" },
      { field: "DOC DATE" },
      { field: "INVOICE NO" },
      { field: "SUPPLIER BILL NO" },
      { field: "NARRATION" },
      { field: "DOC STATUS" },
      { field: "GL DATE" },
      { field: " DEBIT AMOUNT " },
      { field: " CREDIT AMOUNT " },
      { field: "INVOICE/ PAYMENT" },
      { field: "EVENT TYPE" },
      { field: "Remarks" },

      

    ]);
    const defaultColDef = useMemo(() => {
      return {
        editable: true,
        sortable: true,
        filter: true,
        resizable: true,
      };
    }, []);
  
    const onGridReady = useCallback((params) => {
      fetch('./vendorstatement.json')
        .then((resp) => resp.json())
        .then((data) => setRowData(data));
    }, []);
  
   
    return (
      <div style={containerStyle}>
        <div style={gridStyle} className="ag-theme-alpine">
          <AgGridReact
            rowData={record}
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}
            sideBar={true}
            suppressMenuHide={true}
            onGridReady={onGridReady}
          ></AgGridReact>
         
        </div>
      </div>
    );
  };

function ThermaxDR() 
{
  

  return (
  <div className="scroll">
   <table className="table1">
    <tr>
        <td className="bold" colSpan={6}><img src={hdfcs} alt="" height="40px" width="60px" />THERMAX LIMITED</td>
       
    </tr>
    <br></br>
    <tr className="bold">
        <td colSpan={5}>VRS AS ON 30 NOVEMBER 2022</td>
        <td></td>
        <td></td>
        <td></td>
    
        <td> TMX CR AMOUNT </td>
        <td> TMX DR AMOUNT </td>
    </tr>
    <tr className="bold">
        <td colSpan={5}>THERMAX DEBITS AND CREDITS NOT MATCHED</td>
        <td></td>
        <td></td>
       
        <td>TOTAL</td>
        <td> 116,036,421.13 </td>
        <td> 180,957,350.49 </td>
    </tr>
    <br></br>
    
</table>
<div  style={{height:"400px"}}>
    <GridExample2/>
    </div>
  </div>
  )
}



export default ThermaxDR;
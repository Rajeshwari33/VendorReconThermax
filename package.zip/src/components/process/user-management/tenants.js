
import React,{useEffect, useState,} from "react";
import Box from "@mui/material/Box";
import Tab from "@mui/material/Tab";
import { Grid, Button } from 'semantic-ui-react';
import './tenants.css';
import TabContext from '@material-ui/lab/TabContext';
import TabList from '@material-ui/lab/TabList';
import TabPanel from '@material-ui/lab/TabPanel';
import axios from 'axios';  


import Paper from '@mui/material/Paper';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TablePagination from '@mui/material/TablePagination';
import TableRow from '@mui/material/TableRow';


const columns = [
  { id: 'name', label: 'Name', minWidth: 10},
  { id: 'address', label: 'Address',minWidth: 1 },
  {
    id: 'salutation',
    label: 'Salutation',
    minWidth: 10
  },
  {
    id: 'contact_person_name',
    label: 'Contact Person Name',
    minWidth: 10
  },
  {
    id: 'contact_person_number',
    label: 'Contact Person No',
    minWidth: 10
  },
  {
    id: 'contact_person_email_id',
    label: 'Contact Person Email',
    minWidth: 10
  },
  {
    id: 'pan',
    label: 'PAN',
    minWidth: 10
  },
  {
    id: 'gst',
    label: 'GST',
    minWidth: 10
  },
  {
    id: 'tan',
    label: 'TAN',
    minWidth: 10
  },
  {
    id: 'scrip_code',
    label: 'SCRIP Code',
    minWidth: 10
  },
  {
    id: 'actions',
    label: 'Actions',
    minWidth: 10
  },
];





const StickyHeadTable = ({data}) => {
  const [page, setPage] = useState(0);
  const [rowdata, setRowdata] = useState(data);
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const [formCreate, setFormCreate] = useState(true);
  const [formValues, setFormValues] = useState({
    tenants_id: "", name: "", address: "", salutation: "", contact_person_name: "", contact_person_number: "", contact_person_email_id: "", pan: "", gst: "", tan:"",  scrip_code:""})

  let handleChange = (e) => {
      setFormValues({
        ...formValues,
        [e.target.name]: e.target.value
        })
    }
  
    const makeapicall = async (url) => {
      try {
        const response = await fetch(url);
        const data = await response.json();
        console.log('data', data);
        setRowdata(data); 
        
      }
      catch (e) {
        console.log(e);
     
      }
    }
  
  let handleSubmit = (event) => {
      event.preventDefault();
      let url;
      if(formCreate == true){
        url = `http://127.0.0.1:8000/api/v2/user_modules/create_tenants/`;
      }else{
        console.log("formValues.tenants_id", formValues.tenants_id);
        url = `http://127.0.0.1:8000/api/v2/user_modules/update_tenants/${formValues.tenants_id}/`;
      }
      fetch(url, {method: 'POST',
      headers:{
        'Accept':'application/json',
        'Content-Type':'application/json'
      },
      body:JSON.stringify(formValues)
    }).then((result)=>{
      result.json().then((resp)=>{
        console.log("data", resp);
        if(resp.message === 'updated successfully.' || resp.message === 'created successfully.'){
          const url = `http://127.0.0.1:8000/api/v2/user_modules/all_tenants/`;
          makeapicall(url);
          setFormCreate(true);
          setFormValues({
            tenants_id: "", name: "", address: "", salutation: "", contact_person_name: "", contact_person_number: "", contact_person_email_id: "", pan: "", gst: "", tan:"",  scrip_code:""});
        }
      })
    })
  }


  useEffect(() => {
    const url = `http://127.0.0.1:8000/api/v2/user_modules/all_tenants/`;
    makeapicall(url);
  },[]);

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(+event.target.value);
    setPage(0);
  };

  const EditActions = ({row}) =>{
    console.log("row", row);
    setFormCreate(false);
    setFormValues({tenants_id:row.tenants_id, name:row.name, address: row.address, salutation:row.salutation, contact_person_name: row.contact_person_name, contact_person_number: row.contact_person_number, contact_person_email_id: row.contact_person_email_id, pan: row.pan, gst: row.gst, tan: row.tan, scrip_code:row.scrip_code});
  };

const DeleteActions = ({row}) =>{
  console.log('id'+row.tenants_id);
  axios.delete(`http://127.0.0.1:8000/api/v2/user_modules/delete_actions/${row.tenants_id}/`)  
      .then(res => {  
        console.log(res);  
        console.log(res.data);  
        const url = `http://127.0.0.1:8000/api/v2/user_modules/all_actions/`;
        makeapicall(url);
        
  });
};

  return (
    <>
    <form  onSubmit={handleSubmit} style={{justifyContent:'center', marginLeft:'25em', marginBottom:'2em'}}>
      
        <div className="form-inline">
          <label className="label">Tenant Name: </label>
          <input type="text" name="name" value={formValues && formValues.name || ""} onChange={e => handleChange(e)} /><br /> <br />
          <label className="label">Address: </label>
          <input type="text" name="address" value={formValues && formValues.address || ""} onChange={e => handleChange(e)} /><br /> <br />
          <label className="label">Salutation : </label>
          <input type="text" name="salutation" value={formValues && formValues.salutation || ""} onChange={e => handleChange(e)} /><br /><br/>
          <label className="label">Contact Person Name: </label>
          <input type="text" name="contact_person_name" value={formValues && formValues.contact_person_name || ""} onChange={e => handleChange(e)} /><br /><br/>
          <label className="label">Contact Person No: </label>
          <input type="text" name="contact_person_number" value={formValues && formValues.contact_person_number || ""} onChange={e => handleChange(e)} /><br /><br/>
          <label className="label">Contact Person Email: </label>
          <input type="text" name="contact_person_email_id" value={formValues && formValues.contact_person_email_id || ""} onChange={e => handleChange(e)} /><br /><br/>
          <label className="label">PAN No: </label>
          <input type="text" name="pan" value={formValues && formValues.pan || ""} onChange={e => handleChange(e)} /><br /><br/>
          <label className="label">GST No: </label>
          <input type="text" name="gst" value={formValues && formValues.gst || ""} onChange={e => handleChange(e)} /><br /><br/>
          <label className="label">TAN No: </label>
          <input type="text" name="tan" value={formValues && formValues.tan || ""} onChange={e => handleChange(e)} /><br /><br/>
          <label className="label">SCRIP Code: </label>
          <input type="text" name="scrip_code" value={formValues && formValues.scrip_code || ""} onChange={e => handleChange(e)} /><br /><br/>
        </div>
      
      <div className="button-section">  
      {formCreate ? <Button variant="contained" color="primary" type="submit">Create</Button>:
        <Button variant="contained" color="primary" type="submit">Save</Button>}
      </div>
  </form>

    <Paper sx={{ width: '100%', overflow: 'hidden' }}>
      <TableContainer sx={{ maxHeight: 240 }}>
        <Table stickyHeader aria-label="sticky table">
          <TableHead>
            <TableRow style={{backgroundColor: 'rgb(233, 232, 217)'}}>
              {columns.map((column) => (
                <TableCell
                  key={column.id}
                  align={column.align}
                  class="header_column"
                >
                  {column.label}
                </TableCell>
              ))}
            </TableRow>
          </TableHead>
          <TableBody>
                    
            {rowdata && rowdata
              .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
              .map((row, index) => {
                return (
                  <TableRow hover role="checkbox" tabIndex={-1} key={index}>
                    <TableCell className="cell_data"> {row.name}</TableCell>
                    <TableCell className="cell_data"> {row.address}</TableCell>
                    <TableCell className="cell_data"> {row.salutation}</TableCell>
                    <TableCell className="cell_data"> {row.contact_person_name}</TableCell>
                    <TableCell className="cell_data"> {row.contact_person_number}</TableCell>
                    <TableCell className="cell_data"> {row.contact_person_email_id}</TableCell>
                    <TableCell className="cell_data"> {row.pan}</TableCell>
                    <TableCell className="cell_data"> {row.gst}</TableCell>
                    <TableCell className="cell_data"> {row.tan}</TableCell>
                    <TableCell className="cell_data"> {row.scrip_code}</TableCell>
                    <TableCell className="cell_data">
                        <span onClick={e => EditActions({row})}><i class='fa-solid fa-pen-to-square' ></i></span> 
                        <span style={{marginLeft:'1em'}} onClick={e => DeleteActions({row})}><i class='fa fa-trash-o'></i></span>  
                    </TableCell>
                  </TableRow>
                );
              })}
                           
          </TableBody>
        </Table>
      </TableContainer>
      <TablePagination
        rowsPerPageOptions={[5, 10]}
        component="div"
        count={rowdata?.length}
        rowsPerPage={rowsPerPage}
        page={page}
        onPageChange={handleChangePage}
        onRowsPerPageChange={handleChangeRowsPerPage}
      />
    </Paper>
    </>
  );
}


const ResourceMasterTabs = () => {
  const [value, setValue] = useState("1");
  const [rowData, setRowData] = useState(undefined);
 
  const [hideResultGrid, setHideResultGrid] = useState(true);
  const [tab, setTab] = useState(null);
  
  const makeAPICall = async (url) => {
    try {
      const response = await fetch(url);
      const data = await response.json();
      console.log('data'+data);
      setRowData(data);
      setHideResultGrid(false);
      // setColumnData(gridColumnDefs);
      
    }
    catch (e) {
      console.log(e);
      setHideResultGrid(true);
    }
  }
 
  const handleChange = (event, newValue) => {
    console.log('newValue'+newValue);
    let url='';
    switch(newValue){
      case 0:
        url = `http://127.0.0.1:8000/api/v2/user_modules/action/${1}`;
        makeAPICall(url);
        break;
      case 1:
        url = `http://127.0.0.1:8000/api/v2/user_modules/action/${1}`;
        makeAPICall(url);
        break;
      case 2:
        url = `http://127.0.0.1:8000/api/v2/user_modules/action/${1}`;
        makeAPICall(url);
        break;
      default:
        break;
    }
    setValue(newValue);
  };

  return (
    
    <Box>
      <TabContext value={value}>
        <Box sx={{ borderBottom: 1, borderColor: "divider" }}>
          <TabList onChange={handleChange} aria-label="lab API tabs example">
            <Tab label="Action" value="1" />
            {/* <Tab label="Task" value="2" />
            <Tab label="Job" value="3" /> */}
          </TabList>
        </Box>
        <TabPanel value="1" style={{backgroundColor:'white'}}><StickyHeadTable data={rowData}/></TabPanel>
        <TabPanel value="2" style={{backgroundColor:'white'}}><StickyHeadTable data={rowData}/></TabPanel>
        <TabPanel value="3" style={{backgroundColor:'white'}}><StickyHeadTable data={rowData}/></TabPanel>
      </TabContext>
    </Box>
    
  );
}



const TenantsMaster = () => {
 
  return (
    
     <div className="side" style={{ padding:"10px"}}>
     <Grid columns='equal'>
          <Grid.Row style={{ backgroundColor:"#e9e8d9",borderRadius:"12px",marginTop:"10px"}}>
          <Grid.Column>
              <ResourceMasterTabs />
          </Grid.Column>
          </Grid.Row> 
      </Grid>
     </div>
    
  );
}


export default TenantsMaster;
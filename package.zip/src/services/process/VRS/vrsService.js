import { headers, baseUrl } from "../../common/credentials";

const sourcePort = "50003";
const reconPort = "50013";

export const getProcessingLayerListFromServer = () => {
    let url = baseUrl + sourcePort + "/source/get_processing_layer_list/";
    return ([headers, url]);
} 

export const getProcessingLayerDataFromServer = () => {
    let url = baseUrl + reconPort + "/api/v1/vendor_recon/get_processing_layer_data/";
    return ([headers, url]);
} 

export const getProcessingLayerDataReturnFromServer = () => {
    let url = baseUrl + reconPort + "/api/v1/vendor_recon/get_processing_layer_data_return/";
    return ([headers, url]);
} 

export const getProcessingLayerDataWithStatusFromServer = () => {
    let url = baseUrl + reconPort + "/api/v1/vendor_recon/get_data_with_status/";
    return ([headers, url]);
} 

export const getUpdateMatchRecordsFromServer = () => {
    let url = baseUrl + reconPort + "/api/v1/vendor_recon/get_update_matched_records/";
    return ([headers, url]);
} 

export const getUpdateUnMatchRecordsFromServer = () => {
    let url = baseUrl + reconPort + "/api/v1/vendor_recon/get_update_unmatched_records/";
    return ([headers, url]);
} 

export const getUpdateDuplicateRecordsFromServer = () => {
    let url = baseUrl + reconPort + "/api/v1/vendor_recon/get_update_duplicate_records/";
    return ([headers, url]);
} 

export const getUpdateContraRecordsFromServer = () => {
    let url = baseUrl + reconPort + "/api/v1/vendor_recon/get_update_contra_records/";
    return ([headers, url]);
} 

export const getFileUploadListFromServer = () => {
    let url = baseUrl + reconPort + "/api/v1/vendor_recon/get_recon_file_list/";
    return ([headers, url]);
} 

export const getVRSReportFromServer = () => {
    let url = baseUrl + reconPort + "/api/v1/vendor_recon/get_vrs_report/";
    return ([headers, url]);
} 

export const getUpdateGlBalFromServer = () => {
    let url = baseUrl + reconPort + "/api/v1/vendor_recon/get_update_gl_balances_revised/";
    return ([headers, url]);
}

export const getUpdateBankBalFromServer = () => {
    let url = baseUrl + reconPort + "/api/v1/vendor_recon/get_update_bank_balances_revised/";
    return ([headers, url]);
}

export const getBalanceFromServer = () => {
    let url = baseUrl + reconPort + "/api/v1/vendor_recon/get_balances/";
    return ([headers, url]);
}

export const getMonthEndBalanceFromServer = () => {
    let url = baseUrl + reconPort + "/api/v1/vendor_recon/get_month_end_balance/";
    return ([headers, url]);
}

export const getUpdateMonthEndBalanceToServer = () => {
    let url = baseUrl + reconPort + "/api/v1/vendor_recon/get_update_month_end_balance/";
    return ([headers, url]);
}

export const getSendMailFromServer = () => {
    let url = baseUrl + reconPort + "/api/v1/vendor_recon/get_send_mail/";
    return ([headers, url]);
}

export const getReadMailToServer = () => {
    let url = baseUrl + reconPort + "/api/v1/vendor_recon/get_read_mail/";
    return ([headers, url]);
}
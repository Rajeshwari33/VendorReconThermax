import React, { useState, useEffect, useRef } from "react";
import * as XLSX from 'xlsx';
import axios from 'axios';
import "./etl.css";
import { Accordion } from "https://cdn.skypack.dev/semantic-ui-react@2.1.4";
import { Icon, Input, Button, Dropdown, Grid, Popup, Segment, Tab, Table, Menu, Form, TextArea, Label, Header, Checkbox } from 'semantic-ui-react'
import { FileUploadToServer } from '../../../services/auth-service/authService.js'
import { SheetDataUpload } from '../../../services/auth-service/authService.js'
import { SheetData, FileUploadToServernew, UploadEditSheetData } from '../../../services/auth-service/authService.js'
import Select from "react-select";
import { render } from "@testing-library/react";
// import Modal from 'react-modal';
import Modal from 'react-bootstrap/Modal';

// this.column_name_val;
// temp
var col_name = [];
var sht_name = [];
var file_drp_value;
var file_src_name;
var file_src_description;
var sht_upd_data;
var json_data;
var source_id;


// File Upload
function handleFileUpload_old(id) {

  const file = document.getElementById(id).files[0];
  const reader = new FileReader();

  reader.onload = (event) => {
    const data = event.target.result;
    const workbook = XLSX.read(data, { type: 'binary' });
    const sheetName = workbook.SheetNames[0];
    const sheet = workbook.Sheets[sheetName];
    const json = XLSX.utils.sheet_to_json(sheet);
    console.log(json); // or do something else with the JSON data

    let payload = {
      File_data: json,
    }

    var FileUploadCredentials = FileUploadToServer();

    axios.post(FileUploadCredentials[1], payload, FileUploadCredentials[0])
      .then(
        response => {
          console.log("Validate Credentials Response!!!", response);
          let responseData = response["data"];
          if (responseData["Status"] === "Success") {
            let userCredentials = responseData["user_credentials"];
            sessionStorage.setItem("userCredentials", JSON.stringify(userCredentials));
            // navigate(userCredentials["config"]["default_page"]);
          }
        }
      ).catch(
        error => {
          console.log("Error", error);
          alert("Error in Login User!!!");
        }
      );
  };
  reader.readAsBinaryString(file);
}
function handleFileUpload(id) {
  const file = document.getElementById(id).files[0];
  sendFileToAPI(file);
}


function sendFileToAPI(file) {
  // const [data, setData] = useState([]);
  const formData = new FormData();
  formData.append('file', file);
  var FileUploadCredentials = FileUploadToServer();
  // console.log(payload);
  var hello = this;
  fetch(FileUploadCredentials[1], {
    method: 'POST',
    body: formData
  })
    .then(response => response.json())
    .then(data => {
      console.log(data);
      const myObj = data.employee_records[0][0];
      console.log(myObj)
      let text = [];
      for (const x in myObj) {
        text.push(x);
        // text += x + ", ";
      }
      col_name = text;
      console.log(col_name);
      // TableExampleBasic(col_name);
    })
    .catch(error => {
      console.error(error);
    });
  return (
    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Age</th>
        </tr>
      </thead>
    </table>
  );

}

// End File Upload
///////////////
// const InputExampleIconPositionColNme = (Props) => (
//   <input placeholder={'dummy'} size='mini' />

// )

const InputExampleIconPosition = (Props) => (
  <Input placeholder={'dummy'} size='mini' />
)

const options = [
  { key: 1, text: 'Excel', value: 'Excel' },
  { key: 2, text: 'CSV', value: 'CSV' },
  { key: 3, text: 'Text', value: 'Text' },
  { key: 4, text: 'Staging DB', value: 'Staging DB' },
  { key: 5, text: 'Binary', value: 'Binary' },

]
// const options2 = [
//   { key: 1, text: 'Is Null', value: 1 },
//   { key: 2, text: 'Yes or NO', value: 2 },
//   { key: 3, text: 'Data Format', value: 3 },
//   { key: 4, text: 'length', value: 4 },

// ]

const optionsclick = [
  // { key: 1, text: 'Fill character', value: 1 },
  { key: 1, text: 'Change date formate', value: 'Change date formate' },
  // { key: 3, text: 'Add decimals', value: 3 },
  // { key: 4, text: 'Remove decimal', value: 4 },
  // { key: 5, text: 'Round of', value: 5 },
  // { key: 6, text: 'Clear Values', value: 6 },
  { key: 2, text: 'Field Extraction', value: 'Field Extraction' },
  { key: 3, text: 'Position', value: 'Position' },
  { key: 4, text: 'Change Column Name', value: 'Change Column Name' },

]

const datatype_optionslist = [
  { key: 1, text: '', value: 1 },
  { key: 2, text: 'Date', value: '/api/v2/user_modules/date_validation/' },
  { key: 3, text: 'Decimal', value: '/api/v2/user_modules/decimal_validation/' },
  { key: 4, text: 'Integer', value: '/api/v2/user_modules/integer_validation/' },
  { key: 5, text: 'Text', value: '/api/v2/user_modules/string_validation/' },
  { key: 6, text: 'Time', value: '/api/v2/user_modules/time_validation/' },
]

var dataTypeDropdownList = [];
var validationList = [];
var mandataryList = [];






const getValidationForColumn = (value, validationDatatype) => {
    // const actions = validationDatatype; // Replace with your JSON data array
    //  // Filter records containing the search key
    //  console.log('actions', actions);
    // const filteredRecords = actions.filter(record => record.hasOwnProperty(value));
    // return filteredRecords ? filteredRecords : null;

    const invoiceDates = validationDatatype.flatMap(item => {
      const filteredRecords = item[value];
      return filteredRecords ? filteredRecords : [];
    });
    return invoiceDates;
    
  }; 

  const getValidationManadataryList = (value, mandataryList) => {

    const list = mandataryList.flatMap(item => {
      const filteredRecords = item[value];
      return filteredRecords ? filteredRecords : [];
    });
    return list;
    
  };
  

var transformList = [];

const Transform = ({ col_name, selectedval }) => {
  const [prevValue, setPrevValue] = useState(col_name.value);
  const [newValue, setNewValue] = useState(undefined);
  console.log('col_name.value', col_name.value);
  console.log('selectedval', selectedval);

  const issaveTransform = () => {
    let col_name1 = col_name.value;

    transformList && transformList.map((data, index) => {
      console.log('index main', index);
      let keys = Object.keys(data);
      keys.map((data1) => {
        if (col_name1 == data1) {
          console.log('true index sub');
          transformList.splice(index, 1);
        }
      })
    })

    if (prevValue && newValue) {
      let json = {};
      json[col_name1] = { [selectedval]: [prevValue, newValue] };
      transformList.push(json);
    }
    console.log('transformList', transformList);
  }

  return (
    <Grid columns='equal' divided style={{ backgroundColor: "#e9e8d9", paddingLeft: "10px", borderRadius: "15px" }}>
      <Grid.Row>
        <Input type="text" value={prevValue} placeholder="previous value" onChange={e => setPrevValue(e.target.value)} />
      </Grid.Row>
      <Grid.Row>
        <Input type="text" value={newValue} placeholder="new value" onChange={e => setNewValue(e.target.value)} />
      </Grid.Row>
      <Grid.Row>
        <button style={{ height: "35px", width: "92px", backgroundColor: "#000055", color: "#ffffff", marginLeft: '2em' }} onClick={issaveTransform} >Save</button>
      </Grid.Row>
    </Grid>
  )
}

const DropdownExampleClearableValitationClick = (col_name) => {
  const [show, setShow] = useState(false);
  const [selectedValue, setselectedValue] = useState(undefined);

  const displayTransformation = (event, data) => {
    console.log('hj', data.value);
    console.log('hj', col_name);
    setselectedValue(data.value);
    setShow(true);
  }
  const handleClose = () => {
    setShow(false);
  }
  return (
    <div>
      <div className="popup-link">
        <Menu compact>
          <Dropdown size='mini' text='Dropdown' options={optionsclick} simple item onChange={(event, data) => displayTransformation(event, data)} />
        </Menu>
      </div>

      <Modal
        show={show}
        onHide={handleClose}
        backdrop="static"
        keyboard={false}
      >
        <Modal.Header closeButton>
          <Modal.Title>Transformation</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Transform col_name={col_name} selectedval={selectedValue} />
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Cancel
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  )
}





const InputExampleIconPositionchk = () => (
  <>
    <Checkbox label='YES' />
    <Checkbox label='NO' />
  </>
)

export default function SourceDefinition() {

  const [showTable, setShowTable] = useState(false);
  const [showdropdown, setShowdropdown] = useState(false);
  const [showInput, setShowInput] = useState(false);
  const [selectedOption, setSelectedOption] = useState('');
  const [fileSrcName, setFileSrcName] = useState('');
  // const [datatypevalues, setDataTypeValues] = useState([]);

  const [actionsDatatype, setActionsDatatype] = useState([]);
  const [validationDatatype, setValidationDatatype] = useState([]);
  const [mandataryData, setmandataryData] = useState([]);

  const [userCredentials] = useState(JSON.parse(sessionStorage.getItem("userCredentials")));

  const [sourceid, setsourceid] = useState();



  const DataTypeDropdownList = ({value, value1}) => {

    const [isdefault, setisdefault] = useState(value1);
  
    const displayTransformation1 = (event, data) => {
      setisdefault(data.value);
      let item = { [value]: data.value };
      const updatedData = actionsDatatype.filter(entry => entry[value] === undefined);  
      updatedData.push(item);
      setActionsDatatype(updatedData);
    }
  
    return (
      <>
      {isdefault ? (<>
        <Dropdown options={datatype_optionslist} id="datatype_optionlist" value={isdefault} onChange={displayTransformation1} style={{ width: "9em", backgroundColor: '#fff', float: 'right', height: '2.3em' }} />
        </>):(
          <>
            <Dropdown options={datatype_optionslist} id="datatype_optionlist" onChange={displayTransformation1} style={{ width: "9em", backgroundColor: '#fff', float: 'right', height: '2.3em' }} />
          </>
        )}
        </>
      
    )
  }



  
const ValidationPopup = ({value}) => {

  const [showlength, setShowLength] = useState(true);
  const [showdate, setShowdate] = useState(true);
  const [minlength, setMinLength] = useState(undefined);
  const [maxlength, setMaxLength] = useState(undefined);
  const [date, setDate] = useState(undefined);

  const [isUnique, setisunique] = useState(false);
  const [isMandatary, setismandatary] = useState(false);

  const [isTrueorFalse, setTrueorFalse] = useState(false);

  const [isdate, setisdate] = useState(true);
  const [islength, setislength] = useState(true);

  // let ref = useRef([]);

  // ref.current[0].checked = false;
  // ref.current[1].checked = false;
  // ref.current[2].checked = false;
  // ref.current[3].checked = false;
  // ref.current[4].checked = false;

  // useEffect(()=>{
  //   console.log("first time");
  //   for (let i = 0; i < ref.current.length; i++) {

  //       ref.current[i].checked = false;
  //   }
  // },[]);

  // const Unchecked = () => {

  //   console.log(ref.current.length)
  //   for (let i = 0; i < ref.current.length; i++) {

  //       ref.current[i].checked = false;
  //   }

  // }

  const isEnableLength = () => {
    console.log('value', value);
    console.log('showlength', showlength);
    if(showlength == false){
      setMinLength('');
      setMaxLength('');
      const updatedData = validationDatatype.filter(entry => {
        if (typeof entry[value] === 'object' && 'Length' in entry[value]) {
          return false; // Remove entries with "Length" key
        }
        return true; // Keep other entries
      });
      console.log('updatedData', updatedData);
      setValidationDatatype(updatedData);
    }
    setShowLength(!showlength);
    
  }


  const isEnableDateFormate = () => {
    if(showdate == false){
      const updatedData = validationDatatype.filter(entry => {
        if (typeof entry[value] === 'string' && entry[value] !== 'Unique' && entry[value] !== 'True / False' && entry[value] !== 'Yes / No')
        {
          return false; // Remove entries with "Length" key
        }
        return true; // Keep other entries
      });
      console.log('updatedData', updatedData);
      setValidationDatatype(updatedData);
    }
    setShowdate(!showdate);
    setDate('');
  }

  const isChecked = (event, data, value, name) => {
    let name1 = {};
    name1[value] = name;
    if (data.checked) {
      validationList.push(name1);
      let validationList1 = validationDatatype;
      validationList1.push(name1);
      setValidationDatatype(validationList1);

    }else{
      const updatedData1 = validationDatatype.filter(entry => {
        if (typeof entry[value] === 'string' && entry[value] === name)
        {
          return false; // Remove entries with "Length" key
        }
        return true; // Keep other entries
      });
      setValidationDatatype(updatedData1);
    }
    console.log('validationList', validationList);
  }

  const isCheckedNew = (event, data, value, name) => {
    let name1 = {};
    name1[value] = name;
    console.log(data.checked);
    if (data.checked) {
      mandataryList.push(name1);
      let mandataryData1 = mandataryData;
      mandataryData1.push(name1);
      setmandataryData(mandataryData1);
    }else{
      console.log('mandataryData', mandataryData);
      console.log(value, name);
      const updatedData3 = mandataryData.filter(entry => {
        if (typeof entry[value] === 'string' && entry[value] === name)
        {
          console.log('entry[value]', entry[value]);
          return false; // Remove entries with "Length" key
        }
        
        return true; // Keep other entries
      });
      setmandataryData(updatedData3);
    }
   console.log('mandataryList', mandataryList);
  }

  const isSubmitData = () => {

    let col_name1 = value;
    
    if(islength){
    if (minlength && maxlength) {

      const updatedData = validationDatatype.filter(entry => {
        if (typeof entry[value] === 'object' && 'Length' in entry[value]) {
          return false; // Remove entries with "Length" key
        }
        return true; // Keep other entries
      });
      

      let json = {};
      json[col_name1] = { "Length": [minlength, maxlength] };
      console.log('col_name', col_name1, minlength, maxlength);
      validationList.push(json);
      updatedData.push(json);
      setValidationDatatype(updatedData);
      setMinLength('');
      setMaxLength('');
    }}

    if(isdate){
    if (date) {
      console.log('value', value);
      const updatedData = validationDatatype.filter(entry => {
        if (typeof entry[value] === 'string' && entry[value] != 'Unique' && entry[value] != 'True / False' && entry[value] != 'Yes / No')
        {
          console.log('entry[value]', entry[value]);
          return false; // Remove entries with "Length" key
        }
        // console.log('entry[value]', entry[value]);
        return true; // Keep other entries
      });
      
     
      let col_name1 = value;
      let name1 = {};
      name1[col_name1] = date;
      validationList.push(name1);
      updatedData.push(name1);
      console.log('updatedData', updatedData);
      setValidationDatatype(updatedData);
      console.log('validationDatatype', validationDatatype);
      setDate('');
      
    }}
  }

  const addDefaultValue = (type, value) =>{
    switch (type) {
      case "string":
        if(value == 'Unique'){
          setisunique(true);
        }else if(value == 'True / False'){
          setTrueorFalse(true);
        }else if(value == 'Mandatary'){
          setismandatary(true);
        }
        else{
          setDate(value);
          setShowdate(false);
        }
        break;
      case "object": 
        const minLength = value.Length[0];
        const maxLength = value.Length[1];
        setMinLength(minLength);
        setMaxLength(maxLength);
        setShowLength(false);
      
        break;
      
      default:
        console.log("Weekend!");
    }
  }

  useEffect(() => {
    let data = [];
    if(validationDatatype.length > 0){
     data = getValidationForColumn(value, validationDatatype);
    console.log('data', data[0]);
    }
    else if(validationList.length > 0){
      data = getValidationForColumn(value, validationList);
      console.log('data1', data[0]);
    }
    
    setMinLength('');
    setMaxLength('');
    setShowLength(true);
    setShowdate(true);
    setisunique(false);
    setTrueorFalse(false);


    let length = data.length;
    console.log('length', length);
    console.log('data',data);
    if (length == 3){
      let index1 = data[0];
      let index2 = data[1];
      let index3 = data[2];
      let type1 = typeof index1;
      let type2 = typeof index2;
      let type3 = typeof index3;
      addDefaultValue(type1, index1);
      addDefaultValue(type2, index2);
      addDefaultValue(type3, index3);

    }
    else if (length == 2){
      let index1 = data[0];
      let index2 = data[1];
      let type1 = typeof index1;
      let type2 = typeof index2;
      addDefaultValue(type1, index1);
      addDefaultValue(type2, index2);

    }

    else if (length == 1){
      let index1 = data[0];
      let type1 = typeof index1;
      addDefaultValue(type1, index1);
    }
    let mandatary_list = [];
    if(mandataryData.length > 0){
      mandatary_list = getValidationManadataryList(value, mandataryData);
    }
    else if(mandataryList.length > 0){
      mandatary_list = getValidationManadataryList(value, mandataryList);
    }

    let mandatary_length = mandatary_list.length;

    if(mandatary_length == 1){
      let index1 = mandatary_list[0];
      let type1 = typeof index1;
      addDefaultValue(type1, index1);
    }

  }, []);

  const maxlengthval = (event) =>{ 
    setMaxLength(event.target.value);
    setisdate(false);
    setislength(true);
  }

  const minlengthval = (event) =>{
    setMinLength(event.target.value);
    setisdate(false);
    setislength(true);
  }
  const dateval = (event) =>{
    setDate(event.target.value);
    setisdate(true);
    setislength(false);
  }
  return (
    <>
    <div className="col-md-12" style={{ display: "flex" }}>
      <div className="col-md-5">
        <Table >
          <Table.Header>
            <Table.Row>
              <Table.HeaderCell singleLine>Validation</Table.HeaderCell>
              <Table.HeaderCell>position</Table.HeaderCell>
              <Table.HeaderCell>Error</Table.HeaderCell>

            </Table.Row>
          </Table.Header>

          <Table.Body>

            <Table.Row>
              <Table.Cell singleLine>
                <Header as='h2'>
                  <Checkbox label='Yes / No' name="Yes / No" onClick={(event, data) => isChecked(event, data, value.value, 'Yes / No')} />
                </Header>
              </Table.Cell>
              <Table.Cell singleLine></Table.Cell>
              <Table.Cell singleLine></Table.Cell>
            </Table.Row>

            <Table.Row>
              <Table.Cell singleLine>
                <Header as='h2'>
                  {isTrueorFalse ? (<Checkbox label='True / False' checked={true} onClick={(event, data) => isChecked(event, data, value, 'True / False')} />):
                  (<Checkbox label='True / False' onClick={(event, data) => isChecked(event, data, value, 'True / False')} />)}
                  
                </Header>
              </Table.Cell>
              <Table.Cell singleLine></Table.Cell>
              <Table.Cell singleLine></Table.Cell>
            </Table.Row>

            <Table.Row>
              <Table.Cell singleLine>
                <Header as='h2'>
                  {maxlength ? (<Checkbox label='Length' checked={true} onClick={isEnableLength} />):(<Checkbox label='Length' onClick={isEnableLength} />)}
                  
                </Header>
              </Table.Cell>
              <Table.Cell singleLine></Table.Cell>
              <Table.Cell singleLine></Table.Cell>
            </Table.Row>

            <Table.Row>
              <Table.Cell singleLine>
                <Header as='h2' >
                  {date ? (<Checkbox label='Date Formate' checked={true} onClick={isEnableDateFormate} />):(<Checkbox label='Date Formate' onClick={isEnableDateFormate} />)}
                  
                </Header>
              </Table.Cell>
              <Table.Cell singleLine></Table.Cell>
              <Table.Cell singleLine></Table.Cell>
            </Table.Row>

            <Table.Row>
              <Table.Cell singleLine>
                <Header as='h2' >
                  {isUnique ? (<Checkbox label='Unique' checked={true} onClick={(event, data) => isChecked(event, data, value, 'Unique')} />):
                  (<Checkbox label='Unique' onClick={(event, data) => isChecked(event, data, value, 'Unique')} />)}
                  
                </Header>
              </Table.Cell>
              <Table.Cell singleLine></Table.Cell>
              <Table.Cell singleLine></Table.Cell>
            </Table.Row>
            <Table.Row>
              <Table.Cell singleLine>
                <Header as='h2' >
                {isMandatary ? (<Checkbox label='Mandatary' checked={true} onClick={(event, data) => isCheckedNew(event, data, value, 'Mandatary')} />):
                  (<Checkbox label='Mandatary' onClick={(event, data) => isCheckedNew(event, data, value, 'Mandatary')} />)}
                  
                </Header>
              </Table.Cell>
              <Table.Cell singleLine></Table.Cell>
              <Table.Cell singleLine></Table.Cell>
            </Table.Row>

          </Table.Body>
        </Table>
      </div>
      <div className="col-md-5" style={{ backgroundColor: "rgb(233, 232, 217)", marginLeft: "6em" }}>
        <div >
          <Input disabled={showlength} value={minlength} type="text" placeholder="enter min-length" style={{ marginBottom: '1em', marginTop: "1em" }} onChange={event => minlengthval(event) } />
          <Input disabled={showlength} value={maxlength} type="text" placeholder="enter max-length" style={{ marginBottom: '1em' }} onChange={event => maxlengthval(event)} />
          <Input disabled={showdate} value={date} type="text" placeholder="enter date formate" onChange={event =>dateval(event) } />

        </div>
      </div>

    </div>
    <Button style={{ height: "35px", width: "92px", marginTop: "28px", backgroundColor: "#000055", color: "#ffffff", marginLeft: '2em', float:'right' }} onClick={isSubmitData}>Save</Button>
    </>
  )
}










  function NullPopup({value}) {
    const [show, setSow] = useState(false);
  
    const isShow = () => {
      setSow(true);
      console.log('col_name', value);
    }
  
    const handleClose = () => {
      setSow(false);
      console.log('col_name', value);
    }
  
    return (
      <div>
        <Button onClick={isShow} variant="primary">Validation</Button>
  
        <Modal
          show={show}
          onHide={handleClose}
          backdrop="static"
          keyboard={false}
        >
          <Modal.Header closeButton>
                <Modal.Title></Modal.Title>
              </Modal.Header>
          <Modal.Body>
            <ValidationPopup value={value}/>
          </Modal.Body>
          
        </Modal>
      </div>
    );
  }






  const handleClick = () => {
    setShowTable(true);
    setTimeout(() => {
      console.log('_---------data');
    }, 100);
  };

  const handleClick_old = () => {
    console.log(col_name);
    setShowTable(false);

  };


  const DropdownSourcenames = () => {
    const [sourceNames, setSourcenames] = useState([]);

    const handleDropdownChange = (event, data) => {
      setSelectedOption(event);
      
      source_id = event.value;
      setsourceid(event.value);

      setShowInput(true);
    };

    useEffect(() => {
      let payload = {
        File_data: 'hi',
      }

      var FileUploadCredentials = SheetData();

      axios.post(FileUploadCredentials[1], payload, FileUploadCredentials[0])
        .then(
          response => {
            console.log("dropdown source names!!!", response);
            let table_data = response.data;
            let names = [{ value: "", label: "Select Source" },]
            table_data.map((data) => {
            
              let obj = {
                value: data.source_id,
                label: data.source_name
              }
              names.push(obj);
            })
            setSourcenames(names);
          }
        )
    }, [])

    return (
      <Select
        clearable
        isDisabled={showdropdown}
        options={sourceNames}
        selection
        placeholder='Choose Source name'
        size='mini'
        onChange={handleDropdownChange}
        value={selectedOption}
      />
    );
  };

  // const [selectedOption, setSelectedOption] = useState(null);

    const handleDropdownChange = (event, data) => {
      setSelectedOption(data.value);
      // console.log(data.value);
      file_drp_value = data.value;
    };

  // const DropdownExampleClearable = () => {
    

  //   return (
      
  //   );
  // };

  const [value, newvalue] = useState('');

    function handleChange(event) {
      const value = event.target.value;
      newvalue(value);
      file_src_name = value;
      if (showdropdown == false) {
        console.log('show');
        setShowdropdown(true);
      }

    }


  // const InputExampleIconPosition5 = () => {
    
  //   // file_src_name = inputRef.current.value;
  //   return (
     

  //   )
  // }

  // const [fileSrcName, setFileSrcName] = useState('');

    function handleChangeDescripion(event) {
      const { value } = event.target;
      setFileSrcName(value);
      file_src_description = value;
      // console.log(value)
    }

  // const InputExampleIconPosition3 = () => {
    
  //   // const file_src_description = inputRef.current.value;
  //   return (
      

  //   )

  // }

  const [fileSrcName1, setFileSrcName1] = useState('');

    function handleChangeIdentifier(event) {
      const { value } = event.target;
      setFileSrcName1(value);
      file_src_description = value;
      // console.log(value)
    }

  // const InputIdentifier = () => {
    
  //   // const file_src_description = inputRef.current.value;
  //   return (
    
  //   )

  // }

  const InputExampleIconPosition2 = () => (
    <>
      {showInput ? (<Input disabled type="file" id="myFileInput" accept=".xlsx, .xlsb, .csv" icon='upload' style={{ width: '-webkit-fill-available' }} />) :
        (<Input type="file" id="myFileInput" accept=".xlsx, .xlsb, .csv" icon='upload' style={{ width: '-webkit-fill-available' }} />)
      }</>

  )

  const getActionForColumn = (columnName) => {
    const actions = actionsDatatype; // Replace with your JSON data array
    const action = actions && actions.find(action => action.hasOwnProperty(columnName));
    return action ? action[columnName] : null;
  };
  

  function afterapirunsCol() {

    const data = col_name;
    console.log(data);

    return (

      <Grid.Row style={{ backgroundColor: "#e9e8d9", borderRadius: "12px", marginTop: "10px", width: "100%" }}>
        <Grid.Column className="overflow">
          <Table basic id="my-table">
            <Table.Header>
              <Table.Row>
                <Table.HeaderCell>S.No</Table.HeaderCell>
                <Table.HeaderCell>Column Name</Table.HeaderCell>
                <Table.HeaderCell>Data type</Table.HeaderCell>
                <Table.HeaderCell>Property</Table.HeaderCell>
                <Table.HeaderCell>Validation</Table.HeaderCell>
                <Table.HeaderCell>Tranform 1</Table.HeaderCell>
                {/* <Table.HeaderCell>Look Up</Table.HeaderCell>
                <Table.HeaderCell>Math</Table.HeaderCell> */}
                {/* <Table.HeaderCell>Comments</Table.HeaderCell> */}
                <Table.HeaderCell>Primary Key</Table.HeaderCell>
              </Table.Row>
            </Table.Header>

            <Table.Body>
              {data.map(item => (
                <Table.Row key={item.id}>
                  <Table.Cell>{item.id}</Table.Cell>
                  <Table.Cell>{item.col_name}</Table.Cell>
                  <Table.Cell><DataTypeDropdownList value={item.col_name} value1={getActionForColumn(item.col_name)}/></Table.Cell>
                  <Table.Cell><InputExampleIconPosition name="Property" /></Table.Cell>
                  <Table.Cell><NullPopup value={item.col_name}/></Table.Cell>
                  <Table.Cell><DropdownExampleClearableValitationClick value={item.col_name} /></Table.Cell>
                  {/* <Table.Cell> <LookUp /></Table.Cell>
                  <Table.Cell>   <MathTranform /></Table.Cell> */}
                  {/* <Table.Cell><InputExampleIconPosition /></Table.Cell> */}
                  <Table.Cell><InputExampleIconPositionchk /></Table.Cell>
                </Table.Row>
              ))}
            </Table.Body>
          </Table>

        </Grid.Column>
      </Grid.Row>
    );
  }


  function datamodify(data_num) {
    // alert(data_num);
    document.getElementById('dataoff').click();
    if (data_num != 0) {
      // alert('inRRRRRR');
      const file = document.getElementById('myFileInput').files[0];
      const formData = new FormData();
      formData.append('file', file);
      var FileUploadCredentials = FileUploadToServer();
      fetch(FileUploadCredentials[1], {
        method: 'POST',
        body: formData
      })
        .then(response => response.json())
        .then(data => {
          console.log(data);
          let data_val = Number(data_num);
          // const myObj = data[data_val];
          // console.log(myObj);
          const myObj = data[data_val].column_names;
          // const data_myObj = data[data_val].data_type;
          console.log(myObj);
          // console.log(data_myObj)
          let text = [];
          for (let j = 0; j <= Number(myObj.length) - 1; j++) {
            const newObj = {};
            newObj['id'] = Number(j) + 1
            newObj['col_name'] = myObj[j]
            // newObj['data_type'] = data_myObj[j]
            text.push(newObj);
          }
          console.log(text);
          col_name = text;

          document.getElementById('dataon').click();
        })
    } else {
      document.getElementById('dataon').click();
    }
  }

  function colSheet() {
    const data = col_name;
    // const panes = [
    //   {
    //     menuItem: { key: 'users', icon: 'file alternate outline', content: 'Sheet 1' },
    //     render: () => <Tab.Pane></Tab.Pane>,
    //   },
    // ]
    const panes = sht_name.map(data => ({
      menuItem: {
        key: 'users',
        icon: 'file alternate outline',
        content: data.sht_name
      },
      render: () => <Tab.Pane onClick={datamodify(data.id)}></Tab.Pane>
    }));

    return (
      <><Tab panes={panes} />
        <Table celled structured>
          <Table.Header>
            <Table.Row>
              <Table.HeaderCell rowSpan='2'>Name</Table.HeaderCell>
              <Table.HeaderCell rowSpan='2'>Type</Table.HeaderCell>
              <Table.HeaderCell rowSpan='2'>Files</Table.HeaderCell>
            </Table.Row>
          </Table.Header>

          <Table.Body>
            {data.map(item => (
              <Table.Row key={item.id}>
                <Table.Cell>{item.col_name}</Table.Cell>
                <Table.Cell>Project 1</Table.Cell>
                <Table.Cell textAlign='right'>2</Table.Cell>
              </Table.Row>
            ))}
          </Table.Body>
        </Table></>
    );

  }

  function componentDidMount() {

    // const table = document.getElementById("my-table");
    // const cells = table.querySelectorAll("td");
    // const data = [];
    // const name_data = [];
    let isproceed = true;
    if(sourceid){
      console.log('sourceid', sourceid);
      const actions = {
        1: [
          { "Data_type": actionsDatatype },
          { "Validation": validationDatatype },
          { "Transform": transformList },
          { "Mandatary": mandataryData }
        ]
      }

      let payload = {
        source_id: sourceid,
        actions: actions,
      }

      var FileUploadCredentials = UploadEditSheetData();
    
      axios.post(FileUploadCredentials[1], payload, FileUploadCredentials[0])
        .then(
          response => {
            console.log("Validate Credentials Response!!!", response);
            alert('source config file is successfully stored.');
            window.location.reload();
          }
        ).catch(
          error => {
            console.log("Error", error);
            alert("Error in save the edit source config file and source name or source identifier exists already!!!");
          }
      );
    

    }else{
      console.log('inside else');
    // const actions = {
    //   1: [
    //     { "Data_type": dataTypeDropdownList },
    //     { "Validation": validationList },
    //     { "Transform": transformList },
    //     { "Mandatary": mandataryList }
    //   ]
    // }

    const actions = {
      1: [
        { "Data_type": actionsDatatype },
        { "Validation": validationDatatype },
        { "Transform": transformList },
        { "Mandatary": mandataryData }
      ]
    }

    let sheet_name = [];
    let obj;
    let process_name1 = "etl_consolidation";

    json_data.map(data => {
      obj = {
        "id": data.id,
        "text": data.sheet_name
      }
      sheet_name.push(obj);
      
    })

    let payload = {
      File_data: json_data,
      sheet_data: sheet_name,
      source_type: selectedOption,
      source_name: value,
      source_description: fileSrcName,
      source_identifier: fileSrcName1,
      actions: actions,
      process_name: process_name1,
      file_name: document.getElementById("myFileInput").value,
      tenants_id: userCredentials["tenants_id"],
      groups_id: userCredentials["groups_id"],
      entities_id: userCredentials["entities_id"],
      user_id: userCredentials["user_id"],
      m_processing_layer_id: userCredentials["m_processing_layer_id"],
      m_processing_sub_layer_id: userCredentials["m_processing_sub_layer_id"],
      processing_layer_id: userCredentials["processing_layer_id"]
    }

    if(value.length == 0){
      alert('give source name input values!!');
      isproceed = false;
    } 
    if(fileSrcName.length == 0){
      alert('give identifier input values!!');
      isproceed = false;
    }

    if(fileSrcName1.length == 0){
      alert('give description input values!!');
      isproceed = false;
    }

    if(fileSrcName1.length == 0){
      alert('select dropdown values!!');
      isproceed = false;
    }


    var FileUploadCredentials = SheetDataUpload();
    if(isproceed){
      axios.post(FileUploadCredentials[1], payload, FileUploadCredentials[0])
        .then(
          response => {
            console.log("Validate Credentials Response!!!", response);
            alert('file config is successfully stored.');
            setSelectedOption('');
            newvalue('');
            setFileSrcName('');
            setFileSrcName1('');
            dataTypeDropdownList = [];
            validationList = [];
            transformList = [];
            window.location.reload();
          }
        ).catch(
          error => {
            console.log("Error", error);
            alert("Error in save the config file and source name or source identifier exists already!!!");
          }
      );
    }
  }
  }

  function getTableData(id) {
    document.getElementById('dataoff').click();

    const file = document.getElementById(id).files[0];
    const formData = new FormData();
    console.log('datavcbv bv bv bv v' + source_id);
    var payload = {
      id: source_id,
    }
    var FileUploadCredentials = FileUploadToServer();
    var FileUploadCredentialsNew = FileUploadToServernew();
    if (source_id) {
      console.log('jhkjbkmjk,jh,knnm,m');

      axios.post(FileUploadCredentialsNew[1], payload, FileUploadCredentialsNew[0])
        .then(
          response => {
            console.log("Validate Credentials Response!!!", response);
            console.log(JSON.stringify(response.data));
            let jsonData = response.data;
            const columns = jsonData.columns[0];
            const actions = jsonData.actions[0]['1'][0]['Data_type'];
            const validationData = jsonData.actions[0]['1'][1]['Validation'];
            const mandatarydata = jsonData.actions[0]['1'][3]['Mandatary'];
            setActionsDatatype(actions);
            setValidationDatatype(validationData);
            setmandataryData(mandatarydata);
            console.log('mandataryData', mandatarydata);
            const len_data = columns;
            source_id = null;
            let sheet = [];
            let sheet_upd = [];
            let j = 1;
            console.log('json', len_data);
            for (let j = 0; j <= Number(len_data.length) - 1; j++) {
              console.log(j);
              const newObj_sht = {};
              newObj_sht['id'] = j
              newObj_sht['sht_name'] = len_data[j].sheet_name
              sheet_upd.push(len_data[j].sheet_name);
              sheet.push(newObj_sht);
            }
            sht_upd_data = sheet_upd;
            json_data = response.data
            console.log('sht_upd_data' + JSON.stringify(sht_upd_data));
            console.log(sheet);
            sht_name = sheet;
            const myObj = len_data[0].column_names;
            // const data_myObj = data[0].data_type;
            console.log(myObj);

            let text = [];
            for (let j = 0; j <= Number(myObj.length) - 1; j++) {
              const newObj = {};
              newObj['id'] = Number(j) + 1
              newObj['col_name'] = myObj[j]

              text.push(newObj);
            }
            console.log(text);
            col_name = text;
            document.getElementById('dataon').click();

          }
        ).catch(
          error => {
            console.log("Error", error);
          }
        );
    } else {

      formData.append('file', file);

      console.log('jhmn')

      fetch(FileUploadCredentials[1], {
        method: 'POST',
        body: formData
      })
        .then(response => response.json())
        .then(data => {
          console.log(JSON.stringify(data));
          const columnDatatypes = data[0].datatype;
          const columnvalidation  = data[0].validation;
          if(columnDatatypes){
            setActionsDatatype(columnDatatypes);
          }
          if(columnvalidation){
            setValidationDatatype(columnvalidation);
          }
          
          const len_data = data;
          let sheet = [];
          let sheet_upd = [];
          let j = 1
          console.log(len_data.length)
          for (let j = 0; j <= Number(len_data.length) - 1; j++) {
            console.log(j);
            const newObj_sht = {};
            newObj_sht['id'] = j
            newObj_sht['sht_name'] = len_data[j].sheet_name
            sheet_upd.push(len_data[j].sheet_name)
            sheet.push(newObj_sht);
          }
          sht_upd_data = sheet_upd;
          json_data = data
          console.log('sht_upd_data' + JSON.stringify(sht_upd_data));
          console.log(sheet);
          sht_name = sheet;
          const myObj = data[0].column_names;
          // const data_myObj = data[0].data_type;
          console.log(myObj);
          // console.log(data_myObj);
          let text = [];
          for (let j = 0; j <= Number(myObj.length) - 1; j++) {
            const newObj = {};
            newObj['id'] = Number(j) + 1
            newObj['col_name'] = myObj[j]
            // newObj['data_type'] = data_myObj[j]
            text.push(newObj);
          }
          console.log(text);
          col_name = text;
          document.getElementById('dataon').click();
        })
    }
  }


  return (
    <div>
      {/* <h1>hi</h1> */}
      <div className="side" style={{ padding: "10px" }}>
        <Grid columns='equal'>
          <Grid.Row style={{ backgroundColor: "#e9e8d9" }} className="radius">
            <Grid.Column width={3}>
              {/* <InputExampleIconPosition5 /> */}

              <>
                {showInput ? (<Input disabled icon='folder open outline' iconPosition='left' id='src_name_file' placeholder='Enter Source Name' value={value} onChange={handleChange} />) :
                  (<Input icon='folder open outline' iconPosition='left' id='src_name_file' placeholder='Enter Source Name' value={value} onChange={handleChange} />)
                }
              </>
            </Grid.Column>
            <Grid.Column width={3}>
              {/* <InputIdentifier /> */}
              <>
                {showInput ? (<Input disabled icon='sticky note outline' id='identifier' placeholder='Enter the identifier' type='text' value={fileSrcName1} onChange={handleChangeIdentifier} />) :
                  (<Input icon='sticky note outline' id='identifier' placeholder='Enter the identifier' type='text' value={fileSrcName1} onChange={handleChangeIdentifier} />)
                }
              </>
            </Grid.Column>
            <Grid.Column width={3} >
              {/* <InputExampleIconPosition3 /> */}

              <>
              {showInput ? (<Input disabled icon='sticky note outline' id='src_description_file' placeholder='Enter the Descriptions' type='text' value={fileSrcName} onChange={handleChangeDescripion} />) :
                (<Input icon='sticky note outline' id='src_description_file' placeholder='Enter the Descriptions' type='text' value={fileSrcName} onChange={handleChangeDescripion} />)
              }</>
            </Grid.Column>

            <Grid.Column width={3}>
              {/* <DropdownExampleClearable /> */}

              <Dropdown
                clearable
                options={options}
                disabled={showInput}
                selection
                placeholder='Choose an option'
                size='mini'
                onChange={handleDropdownChange}
                value={selectedOption}
              />
            </Grid.Column>

            <Grid.Column width={3}>
              <InputExampleIconPosition2 />
            </Grid.Column>


          </Grid.Row>
          <Grid.Row style={{ backgroundColor: "#e9e8d9", padding: '0px' }}>
            <Grid.Column width={3}><DropdownSourcenames /></Grid.Column>
            <Grid.Column width={4}></Grid.Column>
            <Grid.Column width={4}></Grid.Column>
            <Grid.Column width={3}>

              <Button color='#0A2352' onClick={() => getTableData('myFileInput')}>
                <Icon name='filter' /> Fetch Confic
              </Button>
            </Grid.Column>
            <Grid.Column width={2}><Button color='#0A2352' onClick={() => componentDidMount()}>
              <Icon /> Save
            </Button></Grid.Column>
          </Grid.Row>
          <Grid.Row style={{ backgroundColor: "#e9e8d9", borderRadius: "12px", marginTop: "10px" }}>
            <Grid.Column className="overflow">
              <button onClick={handleClick_old} id='dataoff' hidden>Show Table</button>
              <button onClick={handleClick} id='dataon' hidden>Show Table</button>
              {showTable && afterapirunsCol()}
            </Grid.Column>
          </Grid.Row>

          <Grid.Row style={{ backgroundColor: "#e9e8d9", borderRadius: "12px", marginTop: "10px" }}>
            <Grid.Column>
              {showTable && colSheet()}

            </Grid.Column>
          </Grid.Row>
        </Grid>


      </div>
    </div>
  );
}




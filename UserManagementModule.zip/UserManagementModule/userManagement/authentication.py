# import datetime
#
# import pytz
# from django.conf import settings
# from django.utils import timezone
# from rest_framework.authentication import TokenAuthentication
# from rest_framework.exceptions import AuthenticationFailed
# from .models import Token
#
#
# class ExpiringTokenAuthentication(TokenAuthentication):
#     """
#     Expiring Token.
#
#     It expires every {n} hours requiring client to supply valid username
#     and password for new one to be created
#     """
#
#     model = Token
#     print("Inside")
#
#     def authenticate_credentials(self, key):
#         print("Check")
#         models = self.get_model()
#
#         try:
#             token = models.objects.select_related("User").get(key=key)
#         except models.DoesNotExist:
#             raise AuthenticationFailed(
#                 {"error": "Invalid or Inactive Token", "is_authenticated": False}
#             )
#
#         if not token.user.is_active:
#             raise AuthenticationFailed(
#                 {"error": "Invalid User", "is_authenticated": False}
#             )
#
#         utc_now = timezone.now()
#         utc_now = utc_now.replace(tzinfo=pytz.utc)
#
#         if token.created < utc_now - settings.TOKEN_TTL:
#             raise AuthenticationFailed(
#                 {"error": "Token has expired", "is_authenticated": False}
#             )
#
#         return token.user, token
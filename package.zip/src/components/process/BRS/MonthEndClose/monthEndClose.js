import React, { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import './monthEndClose.css';
import Select from "react-select";
import { getProcessingLayerListFromServer, getMonthEndBalanceFromServer, getUpdateMonthEndBalanceToServer } from '../../../../services/process/BRS/brsService.js';
import axios from "axios";
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-balham.css';
import { AgGridReact } from 'ag-grid-react';
import LoaderComponent from "../../../../libraries/loader/loader";
import refreshIcon from "../../../../assets/images/refresh.png";




function BRSFileUpload()
{
    const [userCredentials] = useState(JSON.parse(sessionStorage.getItem("userCredentials")));
    const { register, handleSubmit } = useForm();
    const [rowData, setRowData] = useState([]);
    const [paginationSize] = useState(15);
    const [loaderOpen, setLoaderOpen] = useState(false);
    const [options, setOptions] = useState([]);
    const [selectedOption, setSelectedOption] = useState('');
    const [layerId, setLayerId] = useState('');
    const [intId, setIntId] = useState('');
    const [extId, setExtId] = useState('');
    const [inputMonth, setInputMonth] = useState(undefined);
    const [monthValue, setMonthValue] = useState('');
    const [balanceHidden, setBalanceHidden] = useState(true);
    const [monthHidden, setMonthHidden] = useState(true);
    const [glBalance, setGlBalance] = useState('');
    const [bankBalance, setBankBalance] = useState('');

    useEffect(() => {
        BrsTypeList();
        // fileUploadsList();
    }, []);

    function handleSelection(event) {
    const selectedValue = event.target.value;
    const selectedOption = options.find(option => option.processing_layer_name === selectedValue); // Find the option with the selected value
    const layerId = selectedOption ? selectedOption.processing_layer_id : null; 
    console.log("layerId", layerId);
    setSelectedOption(selectedValue);
    setLayerId(layerId);
    getBalances(layerId);
    setMonthHidden(true);
    setBalanceHidden(true);
    }

    function BrsTypeList()
    {
        setLoaderOpen(true);
        let payload = {
            "tenantId": userCredentials["tenants_id"],
            "groupId": userCredentials["groups_id"],
            "entityId": userCredentials["entities_id"],
            "mProcessingLayerId": userCredentials["m_processing_layer_id"],
            "mProcessingSubLayerId": userCredentials["m_processing_sub_layer_id"],
            "typeId": userCredentials["processing_layer_id"]
        }

        var getProcessingLayerList = getProcessingLayerListFromServer();
        console.log("brs", getProcessingLayerList[0])

        axios.post(getProcessingLayerList[1], {params : payload}, getProcessingLayerList[0])
        .then(
            response => {
                console.log("Processing Layer List!!!", response)
                let data = response["data"];
                if (data["Status"] === "Success")
                {
                let options = data["processing_layer_list"]
                setOptions(options);
                setLoaderOpen(false);
                }
            }
        ).catch(
            error => {
                console.log("Error in Processing Layer List!!!", error);
                setLoaderOpen(false);
            }
        );

    }

    function getBalances(layerId)
    {
        setLoaderOpen(true);
        let payload = {
            "processingLayerId": layerId
        }

        var getBalance = getMonthEndBalanceFromServer();

        axios.post(getBalance[1], {params : payload}, getBalance[0])
        .then(
            response => {
                console.log("Get Balance Response!!!", response)
                let data = response["data"];
                if (data["Status"] === "Success")
                {
                  console.log("bal", data["data"]);
                  setMonthValue(data["data"]["closing_month"]);
                  setGlBalance(data["data"]["gl_closing_balance"]);
                  setBankBalance(data["data"]["bank_closing_balance"]);
                  setIntId(data["data"]["int_id"]);
                  setExtId(data["data"]["ext_id"]);
                  setMonthHidden(false);
                  setLoaderOpen(false);
                }
                else if (data["Status"] === "No Month")
                {
                    alert("No Month For Closing!!!");
                    setLoaderOpen(false);
                }
            }
        ).catch(
            error => {
                console.log("Error in Get Balance!!!", error);
                setLoaderOpen(false);
            }
        );

    }

    function balClick()
    {
        setBalanceHidden(false);
    }

    function balUpdateClick()
    {
        setLoaderOpen(true);
        let payload = {
            "processingLayerId": layerId,
            "intId" : intId,
            "extId" : extId,
            "userId" : userCredentials["user_id"]
        }

        var updateBalance = getUpdateMonthEndBalanceToServer();

        axios.post(updateBalance[1], {params : payload}, updateBalance[0])
        .then(
            response => {
                console.log("Get Update Balance Response!!!", response)
                let data = response["data"];
                if (data["Status"] === "Success")
                {
                    
                    setMonthHidden(true);
                    setBalanceHidden(true);
                    alert("Month Closed Successfully!!!");
                    setLoaderOpen(false);
                }
            }
        ).catch(
            error => {
                console.log("Error in Get Balance!!!", error);
                setLoaderOpen(false);
            }
        );

    }


    return (
        <>
            <div className="file-upload-cardBox">
                <div className="typeSelectionm">
                    <div className="dropdown-container">
                        <h3>Reconciliation Type</h3>
                        <select className="selectOptions" onChange={handleSelection} value={selectedOption}>
                            <option value="Choose">Choose</option>
                            {options.map(option => (
                            <option key={option.processing_layer_id} value={option.processing_layer_name}>{option.processing_layer_name}</option>
                            ))}
                        </select>
                    </div>
                    <div className="monthFilterm" hidden={monthHidden}>
                        
                        <h3>Month</h3>
                        <input type="text" value={monthValue} className="cardName filetype" style={{paddingLeft: "10px", height:"34%", marginTop:"-3%"}} />
                        
                        
                        <a href="#popup3">
                        {/* <button className="btn" style={{height:"35px", width: "92px", marginTop: "48px", marginLeft:"0px", backgroundColor:"rgb(24 160 17)", color:"rgb(248 252 248)", marginRight: "2%"}} onClick={(e) => {matchClick(e)}}>Match</button> */}
                        <button className="btn" style={{height:"39px", width: "132px", marginTop: "-2px", marginLeft:"71px", backgroundColor:"rgb(22 48 97)", color:"rgb(248 252 248)"}} onClick={(e) => {balClick(e)}}>Check Balance</button>
                        </a>
                        
                    </div>
                </div>

                <div>
                    
                </div>
            </div>

            <div className="file-upload">
            <div hidden={balanceHidden}>
                <div>
                    <div id="popup3" class="popup-container-3 popup-style-3">
                        <div class="popup-content-3">
                            <a href="#" class="close-3">&times;</a>
                            <div className="closingBalance">
                                <div className="glBalance">
                                    <h4>GL Balance :</h4>
                                    <input type="text" value={glBalance} className="cardName filetype" style={{paddingLeft: "10px", height:"115%", marginTop:"-2%", width:"234%", marginLeft:"-16%", fontSize:"117%"}} />
                                </div>
                                <div className="glBalance">
                                    <h4>Bank Balance :</h4>
                                    <input type="text" value={bankBalance} className="cardName filetype" style={{paddingLeft: "10px", height:"115%", marginTop:"-2%", width:"229%", marginLeft:"-18%", fontSize:"117%"}} />
                                </div>
                                <div>
                                    <button className="btn" style={{height:"39px", width: "132px", marginTop: "20px", marginLeft:"423px", backgroundColor:"rgb(22 48 97)", color:"rgb(248 252 248)"}} onClick={(e) => {balUpdateClick(e)}}>Confirm</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
                
            </div>
            <LoaderComponent loaderOpen = {loaderOpen} />
        </>
    )
}


export default BRSFileUpload;



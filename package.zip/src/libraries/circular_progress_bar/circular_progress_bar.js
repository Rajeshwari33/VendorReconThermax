import Backdrop from '@mui/material/Backdrop';

import { CircularProgressbar } from "react-circular-progressbar";
import "react-circular-progressbar/dist/styles.css";

function CircularLoaderComponent({loaderOpen, percentage}){

    const needDominantBaselineFix = true;

    return (
        <>
            <Backdrop
                    sx={{ color: "orange", zIndex: (theme) => theme.zIndex.drawer + 1 }}
                    open={loaderOpen}
                >
                    <CircularProgressbar
                        value={percentage}
                        text={
                        <tspan dy={needDominantBaselineFix ? 0 : 0}>{percentage}%</tspan>
                        }
                    />
            </Backdrop>
        </>
    );
}

export default CircularLoaderComponent;
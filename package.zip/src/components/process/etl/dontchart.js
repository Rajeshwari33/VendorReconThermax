import React, { useCallback, useMemo, useRef, useState } from 'react';
import { render } from 'react-dom';

import "./etlsecound.css";
import { Icon, Input, Button,Dropdown, Grid, Popup,Segment,Select,Tab,Table,Menu , Form, TextArea, Label, Checkbox, GridColumn,Search,Pagination } from 'semantic-ui-react'
import { AgGridReact } from 'ag-grid-react';
import * as agCharts from 'ag-charts-community';
import { AgChartsReact } from 'ag-charts-react';

function tooltipRenderer(params) {
    const { yValue, xValue } = params;
    return {
      content: `${xValue}: ${yValue}%`,
    };
  }
  const WOMEN = {
    type: 'column',
    xKey: 'year',
    yKey: 'women',
    yName: 'Women',
    grouped: true,
    strokeWidth: 0,
    tooltip: {
      renderer: tooltipRenderer,
    },
  };
  const MEN = {
    type: 'column',
    xKey: 'year',
    yKey: 'men',
    yName: 'Men',
    grouped: true,
    strokeWidth: 0,
    tooltip: {
      renderer: tooltipRenderer,
    },
  };
  const PORTIONS = {
    type: 'line',
    xKey: 'year',
    yKey: 'portions',
    yName: 'Portions',
    strokeWidth: 3,
    marker: {
      enabled: false,
    },
    tooltip: {
      renderer: tooltipRenderer,
    },
  };
  const COLUMN_AND_LINE = [
    { ...WOMEN, type: 'column' },
    { ...MEN, type: 'column' },
    { ...PORTIONS, type: 'line' },
  ];
  const AREA_AND_COLUMN = [
    { ...PORTIONS, type: 'area' },
    { ...WOMEN, type: 'column' },
    { ...MEN, type: 'column' },
  ];
  function getData() {
    return [
      {
        year: '2001',
        adults: 24,
        men: 22,
        women: 25,
        children: 13,
        portions: 3.4,
      },
      {
        year: '2003',
        adults: 24,
        men: 22,
        women: 26,
        children: 11,
        portions: 3.4,
      },
      {
        year: '2005',
        adults: 28,
        men: 26,
        women: 30,
        children: 17,
        portions: 3.7,
      },
      {
        year: '2007',
        adults: 29,
        men: 25,
        women: 31,
        children: 21,
        portions: 3.8,
      },
      {
        year: '2009',
        adults: 26,
        men: 25,
        women: 28,
        children: 21,
        portions: 3.5,
      },
      {
        year: '2011',
        adults: 27,
        men: 24,
        women: 29,
        children: 18,
        portions: 3.6,
      },
      {
        year: '2013',
        adults: 26,
        men: 25,
        women: 28,
        children: 16,
        portions: 3.6,
      },
      {
        year: '2015',
        adults: 26,
        men: 24,
        women: 27,
        children: 20,
        portions: 3.5,
      },
      {
        year: '2017',
        adults: 29,
        men: 26,
        women: 32,
        children: 18,
        portions: 3.8,
      },
    ];
  }
class ChartDont extends React.Component {
    constructor(props) {
        super(props);
    
        this.state = {
          options: {
            data: [
              { os: 'Android', share: 56.9 },
              { os: 'iOS', share: 22.5 },
              { os: 'BlackBerry', share: 6.8 },
              { os: 'Symbian', share: 8.5 },
              { os: 'Bada', share: 2.6 },
              { os: 'Windows', share: 1.9 },
            ],
            series: [
              {
                type: 'pie',
                calloutLabelKey: 'os',
                angleKey: 'share',
                innerRadiusOffset: -70,
              },
            ],
          },
        };
      }
      componentDidMount() {}

    render() {
        
      return (
        <AgChartsReact options={this.state.options} />
      );
    }
  }
  
  export default ChartDont;
  
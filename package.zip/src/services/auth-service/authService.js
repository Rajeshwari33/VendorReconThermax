import { headers, baseUrl } from '../common/credentials.js';

export const port = "8000";

export const port1 = "8002";

export const LoginUserToServer = () => {
    let url = baseUrl + port + "/api/v2/user_modules/validate_user/";
    return ([headers, url]);
}

export const FileUploadToServer = () => {
    let url = baseUrl + port + "/api/v2/user_modules/file_upload/";
    return ([headers, url]);
}
export const FileUploadToServernew = () => {
    let url = baseUrl + port + "/api/v2/user_modules/file_upload_new/";
    return ([headers, url]);
}

export const SheetDataUpload = () => {
    let url = baseUrl + port + "/api/v2/user_modules/sheet_upload/";
    return ([headers, url]);
}

export const UploadEditSheetData = () => {
    let url = baseUrl + port + "/api/v2/user_modules/edit_sheet_data/";
    return ([headers, url]);
}

export const SheetData = () => {
    let url = baseUrl + port + "/api/v2/user_modules/sheet_data/";
    return ([headers, url]);
}

export const SheetNames = () => {
    let url = baseUrl + port + "/api/v2/user_modules/sheet_names/";
    return ([headers, url]);
}

export const TargetSheet = () => {
    let url = baseUrl + port + "/api/v2/user_modules/uploadtargetdata/";
    return ([headers, url]);
}

export const GetAllTarget = () => {
    let url = baseUrl + port + "/api/v2/user_modules/getalltenants/";
    return ([headers, url]);
}

export const GetTarget = () => {
    let url = baseUrl + port + "/api/v2/user_modules/gettenants/";
    return ([headers, url]);
}

export const CreateJob = () => {
    let url = baseUrl + port + "/api/v2/user_modules/createjob/";
    return ([headers, url]);
}

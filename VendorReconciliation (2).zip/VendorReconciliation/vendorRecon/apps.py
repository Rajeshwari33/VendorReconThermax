from django.apps import AppConfig


class VendorreconConfig(AppConfig):
    name = 'vendorRecon'

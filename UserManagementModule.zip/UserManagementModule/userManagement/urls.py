from django.urls import path, include

from .views import *
# from rest_framework.authtoken import views
from .auth_token import obtain_auth_token
from .expire_token import expire_token
from rest_framework.routers import DefaultRouter
from . import views
from .scripts.file_column_validations import *

# router = DefaultRouter()
# router.register('module_settings', ModuleSettingsViewSet, basename="module_settings_view")

urlpatterns = [
    path('validate_user/', ValidateUserView.as_view(), name="validate_user"),
    path('api-token-auth/', obtain_auth_token, name="api-token-auth"),
    path('api-token-expire/', expire_token, name="api-token-expire"),
    path('tenants/', TenantsView.as_view(), name="tenants"),
    path('groups/', GroupsView.as_view(), name="groups"),
    path('entities/', EntitiesView.as_view(), name="entities"),
    path('divisions/', DivisionsView.as_view(), name="divisions"),
    path('external_entities/', ExternalEntitiesView.as_view(), name="external_entities"),
    path('share_holding_header/', ShareHoldingHeaderView.as_view(), name="share_holding_header"),
    path('share_holding_details/', ShareHoldingDetailsView.as_view(), name="share_holding_details"),
    path('user_roles/', UserRolesView.as_view(), name="user_roles"),
    path('user_permission_groups/', UserPermissionGroupsView.as_view(), name="user_permission_groups"),
    path('register/', RegisterView.as_view(), name="register"),
    path('file_upload1/', FileUploadView.as_view(), name="file_upload"),
# path('register/', RegisterView.as_view(), name="register"),
    path('file_upload/', FileUpload.as_view(), name="file_upload"),
    path('file_upload_new/', GetFileUpload.as_view(), name="file_upload_new"),
    path('sheet_upload/', SheetDataUpload.as_view(), name="sheet_upload"),
    path('task/<int:id>', TaskDetailView.as_view(), name='task_detail'),
    path('action/<int:id>/', ActionDetailView.as_view(), name='action_detail'),
    path('update_action/<int:id>/', UpdateActionDetail.as_view(), name='update_action'),
    path('condition/<int:id>/', ConditionDetailView.as_view(), name='condition_detail'),
    path('job_details/', JobDetailView.as_view(), name='job_detail'),
    path('all_actions/', GetAllAction.as_view(), name='all_actions'),
    path('create_actions/', CreateActionView.as_view(), name='create_actions'),
    path('delete_actions/<int:id>/', DeleteTaskView.as_view(), name='delete_actions'),
    path('fetch_job_details/<int:id>', FetchJobDetailView.as_view(), name='fetch_job_detail'),
    path('validation/', ValidationView.as_view(), name="validation"),
    path('sheet_data/', EtlSecondUpload.as_view(), name="sheet_upload"),
    path('sheet_names/', FetchSheets.as_view(), name="sheet_names"),
    path('master/', FileMasterData.as_view(), name="master"),
    path('client_name/', FetchClientName.as_view(), name="client_name"),
    path('uploadtargetdata/', TargetSheetUpload.as_view(), name="uploadtargetdata"),
    path('fetchtargetdata/', FetchTargetData.as_view(), name="fetchtargetdata"),
    path('fetchsourcemasterdata/', FetchSourceMasterData.as_view(), name="fetchsourcemasterdata"),

    path('getalltenants/', GetAllTenants.as_view(), name="getalltenants"),
    path('gettenants/', GetTenants.as_view(), name="gettenants"),
    path('createjob/', CreateJob.as_view(), name="createjob"),
    path('updatejob/<int:id>/', UpdateJob.as_view(), name='updatejob'),
    path('deletejob/<int:id>/', DeleteJob.as_view(), name='updatejob'),
    path('updatetask/<int:id>/', UpdateTaskDetail.as_view(), name='updatetask'),
    path('updatecondition/<int:id>/', UpdateCondition.as_view(), name='updatecondition'),

    path('integer_validation/', IntegerValidationView.as_view(), name='integer_validation'),
    path('string_validation/', StringValidationView.as_view(), name='string_validation'),
    path('unique_validation/', UnqueValidationView.as_view(), name='unique_validation'),
    path('decimal_validation/', DecimalValidationView.as_view(), name='decimal_validation'),
    path('length_validation/', LengthValidationView.as_view(), name='length_validation'),
    path('date_validation/', DateValidationView.as_view(), name='date_validation'),
    path('yesorno_validation/', YesOrNoValidationView.as_view(), name='yesorno_validation'),
    path('trueorfalse_validation/', TrueOrFalseValidationView.as_view(), name='trueorfalse_validation'),
    path('change_date_formate_validation/', ChangeDateFormateValidationView.as_view(), name='change_date_formate_validation'),
    path('round_off/', RoundOffView.as_view(), name='round_off'),
    path('change_position/', ChangePositionsView.as_view(), name='change_position'),
    path('field_extraction/', FieldExtractionView.as_view(), name='field_extraction'),
    path('change_date_formate/', ChangeDateFormateView.as_view(), name='change_date_formate'),
    path('validate_source_same_min_length_etl/', ValidateSourceNameMinLengthEtl.as_view(), name='validate_source_same_min_length_etl'),
    path('validate_source_same_max_length_etl/', ValidateSourceNameMaxLengthEtl.as_view(), name='validate_source_same_max_length_etl'),
    path('validate_source_identifier_min_length_etl/', ValidateSourceIdentifierMinLengthEtl.as_view(), name='validate_source_identifier_min_length_etl'),
    path('validate_source_identifier_max_length_etl/', ValidateSourceIdentifierMaxLengthEtl.as_view(), name='validate_source_identifier_max_length_etl'),
    path('validate_source_description_min_length_etl/', ValidateSourceDescriptionMinLengthEtl.as_view(), name='validate_source_description_min_length_etl'),
    path('validate_source_description_max_length_etl/', ValidateSourceDescriptionMaxLengthEtl.as_view(), name='validate_source_description_max_length_etl'),
    path('validate_source_file_type_etl/', ValidateSourceFileTypeEtl.as_view(), name='validate_source_file_type_etl'),

    path('request/', RequestView.as_view(), name='request'),
    
]

# Process

# Compliance Certificate
urlpatterns += [
    path('compliance_certificate/file_uploads/', ComplianceCertificateFileUpload.as_view(), name="compliance_certificate_file_upload")
]

# Medical Insurance
urlpatterns += [
    path('medical_insurance/file_uploads/', MedicalInsuranceFileUpload.as_view(), name="medical_insurance_file_upload")
]

# Medical Insurance
urlpatterns += [
    path('consolidation/file_uploads/', ConsolidationFileUpload.as_view(), name="consolidation_file_upload")
]


# For View sets
# urlpatterns += [
#     path('', include(router.urls))
# ]


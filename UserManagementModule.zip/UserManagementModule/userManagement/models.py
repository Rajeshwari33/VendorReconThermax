from django.db import models
from django.contrib.auth.models import AbstractBaseUser, PermissionsMixin, BaseUserManager
# from django.conf import settings
# from rest_framework.authtoken.models import Token as AuthToken

from django.utils.translation import gettext_lazy as _

# Create your models here.


class ModuleSettings(models.Model):
    class Meta:
        db_table = "module_settings"

    module_settings_id = models.AutoField(verbose_name="Module Settings Id", null=False, primary_key = True)
    setting_key = models.CharField(max_length=64, verbose_name="Setting Key", null=False, unique=True)
    setting_value = models.JSONField(verbose_name="Setting Value", null=False)
    description = models.TextField(verbose_name="Description", null=False)
    is_active = models.BooleanField(default=True, verbose_name="Active ?")
    created_by_user_id = models.PositiveIntegerField(verbose_name="Created By User Id", null=True)
    created_date = models.CharField(max_length=32, verbose_name="Created Date", null=True)
    modified_by_user_id = models.PositiveIntegerField(verbose_name="Modified By User Id", null=True)
    modified_date = models.CharField(max_length=32, verbose_name="Modified Date", null=True)

class Tenants(models.Model):
    class Meta:
        db_table = "tenants"

    TYPE_SALUT = (
        ('Mr.', 'Mr.'),
        ('Miss', 'Miss'),
        ('Mrs.', 'Mrs.')
    )

    tenants_id = models.AutoField(verbose_name="Tenants Id", null=False, primary_key=True)
    name = models.CharField(max_length=64, verbose_name="Name", null=False)
    address = models.TextField(verbose_name="Address", null=False)
    salutation = models.CharField(max_length=8, choices=TYPE_SALUT, null=False)
    contact_person_name = models.CharField(max_length=64, verbose_name="Name", null=False)
    contact_person_number = models.CharField(max_length=15, verbose_name="Contact Number", null=True)
    contact_person_email_id = models.CharField(max_length=255, verbose_name="Contact Person Email Id", null=True, unique=True)
    pan = models.CharField(max_length=10, verbose_name="Pan Number", null=True)
    gst = models.CharField(max_length=15, verbose_name="GST Number", null=True)
    tan = models.CharField(max_length=10, verbose_name="Tan Number", null=True)
    scrip_code = models.PositiveIntegerField(verbose_name="Scrip Code", null=True)
    is_active = models.BooleanField(default=True, verbose_name="Active ?")
    created_by_user_id = models.PositiveIntegerField(verbose_name="Created By User Id", null=True)
    created_date = models.CharField(max_length=32, verbose_name="Created Date", null=True)
    modified_by_user_id = models.PositiveIntegerField(verbose_name="Modified By User Id", null=True)
    modified_date = models.CharField(max_length=32, verbose_name="Modified Date", null=True)

    def __str__(self):
        return self.name

class Groups(models.Model):
    class Meta:
        db_table = "groups"

    TYPE_SALUT = (
        ('Mr.', 'Mr.'),
        ('Miss', 'Miss'),
        ('Mrs.', 'Mrs.')
    )

    groups_id = models.AutoField(verbose_name="Group Id", null=False, primary_key=True)
    name = models.CharField(max_length=64, verbose_name="Name", null=False)
    address = models.TextField(verbose_name="Address", null=False)
    salutation = models.CharField(max_length=8, choices=TYPE_SALUT)
    contact_person_name = models.CharField(max_length=64, verbose_name="Name", null=False)
    contact_person_number = models.CharField(max_length=15, verbose_name="Contact Number", null=True)
    contact_person_email_id = models.CharField(max_length=255, verbose_name="Contact Person Email Id", null=True, unique=True)
    pan = models.CharField(max_length=10, verbose_name="Pan Number", null=True)
    gst = models.CharField(max_length=15, verbose_name="GST Number", null=True)
    tan = models.CharField(max_length=10, verbose_name="Tan Number", null=True)
    scrip_code = models.PositiveIntegerField(verbose_name="Scrip Code", null=True)
    tenants = models.ForeignKey(Tenants, verbose_name="Tenants Id (Tenants)", on_delete=models.CASCADE)
    is_active = models.BooleanField(default=True, verbose_name="Active ?")
    created_by_user_id = models.PositiveIntegerField(verbose_name="Created By User Id", null=True)
    created_date = models.CharField(max_length=32, verbose_name="Created Date", null=True)
    modified_by_user_id = models.PositiveIntegerField(verbose_name="Modified By User Id", null=True)
    modified_date = models.CharField(max_length=32, verbose_name="Modified Date", null=True)

    def __str__(self):
        return self.name

class Entities(models.Model):
    class Meta:
        db_table = "entities"

    TYPE_SALUT = (
        ('Mr.', 'Mr.'),
        ('Miss', 'Miss'),
        ('Mrs.', 'Mrs.')
    )

    entity_id = models.AutoField(verbose_name="Entity Id", null=False, primary_key=True)
    name = models.CharField(max_length=64, verbose_name="Name", null=False)
    address = models.TextField(verbose_name="Address", null=False)
    salutation = models.CharField(max_length=8, choices=TYPE_SALUT, null=True)
    contact_person_name = models.CharField(max_length=64, verbose_name="Name", null=False)
    contact_person_number = models.CharField(max_length=15, verbose_name="Contact Number", null=True)
    contact_person_email_id = models.CharField(max_length=255, verbose_name="Contact Person Email Id", null=True, unique=True)
    pan = models.CharField(max_length=10, verbose_name="Pan Number", null=True)
    gst = models.CharField(max_length=15, verbose_name="GST Number", null=True)
    tan = models.CharField(max_length=10, verbose_name="Tan Number", null=True)
    scrip_code = models.PositiveIntegerField(verbose_name="Scrip Code", null=True)
    groups = models.ForeignKey(Groups, verbose_name="Groups Id (Groups)", on_delete=models.CASCADE)
    is_active = models.BooleanField(default=True, verbose_name="Active ?")
    created_by_user_id = models.PositiveIntegerField(verbose_name="Created By User Id", null=True)
    created_date = models.CharField(max_length=32, verbose_name="Created Date", null=True)
    modified_by_user_id = models.PositiveIntegerField(verbose_name="Modified By User Id", null=True)
    modified_date = models.CharField(max_length=32, verbose_name="Modified Date", null=True)

    def __str__(self):
        return self.name

class Divisions(models.Model):
    class Meta:
        db_table = "divisions"

    division_id = models.AutoField(verbose_name="Division Id", null=False, primary_key=True)
    name = models.CharField(max_length=64, verbose_name="Name", null=False)
    description = models.CharField(max_length=64, verbose_name="Description", null=False)
    department_head_name = models.CharField(max_length=64, verbose_name="Department Head Name", null=False)
    department_head_designation = models.CharField(max_length=64, verbose_name="Department Head Designation", null=False)
    reporting_manager = models.CharField(max_length=64, verbose_name="Reporting Manager", null=False)
    entity = models.ForeignKey(Entities, verbose_name="Entities Id (Entities)", on_delete=models.CASCADE)
    is_active = models.BooleanField(default=True, verbose_name="Active ?")
    created_by_user_id = models.PositiveIntegerField(verbose_name="Created By User Id", null=True)
    created_date = models.CharField(max_length=32, verbose_name="Created Date", null=True)
    modified_by_user_id = models.PositiveIntegerField(verbose_name="Modified By User Id", null=True)
    modified_date = models.CharField(max_length=32, verbose_name="Modified Date", null=True)

    def __str__(self):
        return self.name

class ExternalEntities(models.Model):
    class Meta:
        db_table = "external_entities"

    TYPE_SALUT = (
        ('Mr.', 'Mr.'),
        ('Miss', 'Miss'),
        ('Mrs.', 'Mrs.')
    )

    external_entity_id = models.AutoField(verbose_name="External Entity Id", null=False, primary_key=True)
    name = models.CharField(max_length=64, verbose_name="Name", null=False)
    address = models.TextField(verbose_name="Address", null=False)
    salutation = models.CharField(max_length=8, choices=TYPE_SALUT, null=True)
    contact_person_name = models.CharField(max_length=64, verbose_name="Name", null=False)
    contact_person_number = models.CharField(max_length=15, verbose_name="Contact Number", null=True)
    contact_person_email_id = models.CharField(max_length=255, verbose_name="Contact Person Email Id", null=True, unique=True)
    pan = models.CharField(max_length=10, verbose_name="Pan Number", null=True)
    gst = models.CharField(max_length=15, verbose_name="GST Number", null=True)
    tan = models.CharField(max_length=10, verbose_name="Tan Number", null=True)
    scrip_code = models.PositiveIntegerField(verbose_name="Scrip Code", null=True)
    is_active = models.BooleanField(default=True, verbose_name="Active ?")
    created_by_user_id = models.PositiveIntegerField(verbose_name="Created By User Id", null=True)
    created_date = models.CharField(max_length=32, verbose_name="Created Date", null=True)
    modified_by_user_id = models.PositiveIntegerField(verbose_name="Modified By User Id", null=True)
    modified_date = models.CharField(max_length=32, verbose_name="Modified Date", null=True)

    def __str__(self):
        return self.name

class ShareHoldingHeader(models.Model):
    class Meta:
        db_table = "share_holding_header"

    share_hold_head_id = models.AutoField(verbose_name="Share Holding Head Id", null=False, primary_key=True)
    listed_stock_exchange = models.CharField(max_length=64, verbose_name="Listed Stock Exchange", null=False)
    listed_trade_value = models.CharField(max_length=64, verbose_name="Listed Trade Value", null=False)
    last_traded_date = models.CharField(max_length=64, verbose_name="Last trade Date", null=False)
    no_of_investors = models.CharField(max_length=64, verbose_name="No of Investors", null=False)
    entity = models.ForeignKey(Entities, verbose_name="Entity Id (Entities)", on_delete=models.CASCADE)
    is_active = models.BooleanField(default=True, verbose_name="Active ?")
    created_by_user_id = models.PositiveIntegerField(verbose_name="Created By User Id", null=True)
    created_date = models.CharField(max_length=32, verbose_name="Created Date", null=True)
    modified_by_user_id = models.PositiveIntegerField(verbose_name="Modified By User Id", null=True)
    modified_date = models.CharField(max_length=32, verbose_name="Modified Date", null=True)

class ShareHoldingDetails(models.Model):
    class Meta:
        db_table = "share_holding_details"

    share_hold_detail_id = models.AutoField(verbose_name="Shar holding Details Id", null=False, primary_key=True)
    share_holding_percentage = models.PositiveIntegerField(verbose_name="Share Holding Percentage", null=True)
    share_holding_value = models.PositiveIntegerField(verbose_name="Share Holding Value", null=True)
    external_entity = models.ForeignKey(ExternalEntities, verbose_name="External Entity Id (External Entity)", on_delete=models.CASCADE)
    entity = models.ForeignKey(Entities, verbose_name="Entity Id (Entities)", on_delete=models.CASCADE)
    share_hold_head = models.ForeignKey(ShareHoldingHeader, verbose_name="Share Holding Header Id (Share Holding Header)", on_delete=models.CASCADE)
    is_active = models.BooleanField(default=True, verbose_name="Active ?")
    created_by_user_id = models.PositiveIntegerField(verbose_name="Created By User Id", null=True)
    created_date = models.CharField(max_length=32, verbose_name="Created Date", null=True)
    modified_by_user_id = models.PositiveIntegerField(verbose_name="Modified By User Id", null=True)
    modified_date = models.CharField(max_length=32, verbose_name="Modified Date", null=True)

class UserRoles(models.Model):
    class Meta:
        db_table = "user_roles"

    user_role_id = models.AutoField(verbose_name="user Role Id", null=False, primary_key=True)
    name = models.CharField(max_length=64, verbose_name="User Role Name", null=False)
    role_note = models.CharField(max_length=64, verbose_name="Role Note", null=False)
    entity = models.ForeignKey(Entities, verbose_name="Entity Id (Entities)", on_delete=models.CASCADE)
    division = models.ForeignKey(Divisions, verbose_name="Division Id (Divisions)", on_delete=models.CASCADE)
    is_active = models.BooleanField(default=True, verbose_name="Active ?")
    created_by_user_id = models.PositiveIntegerField(verbose_name="Created By User Id", null=True)
    created_date = models.CharField(max_length=32, verbose_name="Created Date", null=True)
    modified_by_user_id = models.PositiveIntegerField(verbose_name="Modified By User Id", null=True)
    modified_date = models.CharField(max_length=32, verbose_name="Modified Date", null=True)

    def __str__(self):
        return self.name

class UserPermissionGroups(models.Model):
    class Meta:
        db_table = "user_permission_groups"

    user_permission_group_id = models.AutoField(verbose_name="User Group Id", null=False, primary_key = True)
    name = models.CharField(max_length=64, verbose_name="Name", null=False)
    description = models.TextField(verbose_name="Description", null=True)
    is_active = models.BooleanField(default=True, verbose_name="Active ?")
    created_by_user_id = models.PositiveIntegerField(verbose_name="Created By User Id", null=True)
    created_date = models.CharField(max_length=32, verbose_name="Created Date", null=True)
    modified_by_user_id = models.PositiveIntegerField(verbose_name="Modified By User Id", null=True)
    modified_date = models.CharField(max_length=32, verbose_name="Modified Date", null=True)

    def __str__(self):
        return self.name

class ProcessingLayerAPIS(models.Model):
    class Meta:
        db_table = "processing_layer_apis"

    processing_layer_apis_id = models.AutoField(primary_key = True, verbose_name = "Processing Layer APIS Id", null=False)
    name = models.CharField(max_length=64, verbose_name="Name", null=False)
    value = models.JSONField(verbose_name="Value", null=True)
    description = models.TextField(verbose_name="Description", null=True)
    is_active = models.BooleanField(default=True, verbose_name="Active ?")
    created_by = models.PositiveSmallIntegerField(verbose_name="User Id", null=True)
    created_date = models.CharField(max_length=32, verbose_name="Created Date", null=True)
    modified_by = models.PositiveSmallIntegerField(verbose_name="User Id", null=True)
    modified_date = models.CharField(max_length=32, verbose_name="Modified Date", null=True)

    def __str__(self):
        return self.name

class UserManager(BaseUserManager):
    def create_superuser(self, email, name, password):

        if email is None:
            raise TypeError('User Should have an email address')
        if name is None:
            raise TypeError('User Should have a Name')

        user = self.model(
            email = self.normalize_email(email),
            name = name
        )
        user.set_password(password)
        user.save(using=self._db)
        return user

class Users(AbstractBaseUser, PermissionsMixin):
    class Meta:
        db_table = "users"

    user_id = models.AutoField(verbose_name="user Id", null=False, primary_key=True)
    name = models.CharField(max_length=255, verbose_name="Name", null=False)
    mobile_number = models.CharField(max_length=15, verbose_name="Mobile Number", unique=True, null=True)
    email = models.CharField(max_length=255, verbose_name="Email", unique=True, null=False, db_index=True)
    username = models.CharField(max_length=64, verbose_name="Username", unique=True, null=True)
    password = models.CharField(max_length=255, verbose_name="Password", unique=True)
    security_question = models.CharField(max_length=255, verbose_name="Security Question", null=True)
    security_answer = models.CharField(max_length=255, verbose_name="Security Answer", null=True)
    is_verified = models.BooleanField(default=False, verbose_name="Verified ?")
    is_active = models.BooleanField(default=True, verbose_name="Active ?")
    created_by_user_id = models.PositiveIntegerField(verbose_name="Created By User Id", null=True)
    created_date = models.DateTimeField(auto_now_add=True, verbose_name="Created Date", null=False)
    modified_by_user_id = models.PositiveIntegerField(verbose_name="Modified By User Id", null=True)
    modified_date = models.DateTimeField(auto_now_add=True, verbose_name="Modified Date", null=False)

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['name', 'password']

    objects = UserManager()

    def __str__(self):
        return self.email

class UserMapping(models.Model):
    class Meta:
        db_table = "user_mapping"

    user_mapping_id = models.AutoField(verbose_name = "User Mapping Id", null=False, primary_key = True)
    user = models.ForeignKey(Users, verbose_name="User Id (Users)", on_delete=models.CASCADE)
    role = models.ForeignKey(UserRoles, verbose_name="Role Id (User Roles)", on_delete=models.CASCADE)
    entity = models.ForeignKey(Entities, verbose_name="Entity Id (Entities)", on_delete=models.CASCADE)
    user_permission_group = models.ForeignKey(UserPermissionGroups, verbose_name="User Permissions Group Id (User Permissions Group)", on_delete=models.CASCADE)
    is_active = models.BooleanField(default=True, verbose_name="Active ?")
    created_by_user_id = models.PositiveIntegerField(verbose_name="Created By User Id", null=True)
    created_date = models.DateTimeField(auto_now_add=True, verbose_name="Created Date", null=False)
    modified_by_user_id = models.PositiveIntegerField(verbose_name="Modified By User Id", null=True)
    modified_date = models.DateTimeField(auto_now_add=True, verbose_name="Modified Date", null=False)

class UserAuthToken(models.Model):
    class Meta:
        db_table = "user_auth_token"

    user = models.ForeignKey(Users, verbose_name="User Id (Users)", on_delete=models.CASCADE)
    created_dt = models.CharField(max_length=32, verbose_name="Created Date Time", null=False)
    expiry_dt = models.CharField(max_length=32, verbose_name="Expiry Date Time", null=False)

# class Token(AuthToken):
#     key = models.CharField("key", max_length=40, db_index=True, unique=True)
#     user = models.ForeignKey(settings.AUTH_USER_MODEL, related_name="auth_token", on_delete=models.CASCADE, verbose_name="User")

class Pages(models.Model):
    class Meta:
        db_table = "pages"

    pages_id = models.AutoField(verbose_name = "Pages Id", primary_key = True, null=False)
    name = models.CharField(max_length=128, verbose_name="Pages", null=True)
    description = models.TextField(verbose_name="Description", null=True)
    config = models.JSONField(verbose_name="Configuration", null=True)
    is_active = models.BooleanField(default=True, verbose_name="Active ?")
    created_by_user_id = models.PositiveIntegerField(verbose_name="Created By User Id", null=True)
    created_date = models.DateTimeField(auto_now_add=True, verbose_name="Created Date", null=False)
    modified_by_user_id = models.PositiveIntegerField(verbose_name="Modified By User Id", null=True)
    modified_date = models.DateTimeField(auto_now_add=True, verbose_name="Modified Date", null=False)

    def __str__(self):
        return self.name

class Permissions(models.Model):
    class Meta:
        db_table = "permissions"

    permissions_id = models.AutoField(verbose_name = "Permissions Id", primary_key = True, null=False)
    user_roles = models.ForeignKey(UserRoles, verbose_name="User Roles (User Role Id)", on_delete=models.CASCADE)
    user_permission_group = models.ForeignKey(UserPermissionGroups, verbose_name="User Permission Groups (User Permission Group Id)", on_delete=models.CASCADE)
    is_active = models.BooleanField(default=True, verbose_name="Active ?")
    created_by_user_id = models.PositiveIntegerField(verbose_name="Created By User Id", null=True)
    created_date = models.DateTimeField(auto_now_add=True, verbose_name="Created Date", null=False)
    modified_by_user_id = models.PositiveIntegerField(verbose_name="Modified By User Id", null=True)
    modified_date = models.DateTimeField(auto_now_add=True, verbose_name="Modified Date", null=False)

class PermissionGroupsMapping(models.Model):
    class Meta:
        db_table = "permission_groups_mapping"

    permission_groups_mapping_id = models.AutoField(verbose_name = "Permission Groups Mapping Id", primary_key = True, null=False)
    user_permission_groups = models.ForeignKey(UserPermissionGroups, verbose_name="User Permission Groups (User Permission Groups Id)", on_delete=models.CASCADE)
    pages = models.ForeignKey(Pages, verbose_name="Pages (Pages Id)", on_delete=models.CASCADE)
    is_active = models.BooleanField(default=True, verbose_name="Active ?")
    created_by_user_id = models.PositiveIntegerField(verbose_name="Created By User Id", null=True)
    created_date = models.DateTimeField(auto_now_add=True, verbose_name="Created Date", null=False)
    modified_by_user_id = models.PositiveIntegerField(verbose_name="Modified By User Id", null=True)
    modified_date = models.DateTimeField(auto_now_add=True, verbose_name="Modified Date", null=False)

class UserProcessMapping(models.Model):
    class Meta:
        db_table = "user_process_mapping"

    process_mapping_id = models.AutoField(verbose_name = "Process Mapping Id", primary_key = True, null=False)
    tenants = models.ForeignKey(Tenants, verbose_name="Tenants (Tenants Id)", on_delete=models.CASCADE)
    groups = models.ForeignKey(Groups, verbose_name="Groups (Groups Id)", on_delete=models.CASCADE)
    entities = models.ForeignKey(Entities, verbose_name="Entities (Entities Id)", on_delete=models.CASCADE)
    m_processing_layer_id = models.PositiveIntegerField(verbose_name="M Processing Layer Id", null=False)
    m_processing_sub_layer_id = models.PositiveIntegerField(verbose_name="M Processing Sub Layer Id", null=False)
    processing_layer_id = models.PositiveIntegerField(verbose_name="Processing Layer Id", null=False)
    processing_layer_name = models.CharField(max_length=128, verbose_name="Processing Layer Name", null=True)
    user = models.ForeignKey(Users, verbose_name="Users (User Id)", on_delete=models.CASCADE)
    config = models.JSONField(verbose_name="Config", null=True)
    is_active = models.BooleanField(default=True, verbose_name="Active ?")
    created_by_user_id = models.PositiveIntegerField(verbose_name="Created By User Id", null=True)
    created_date = models.DateTimeField(auto_now_add=True, verbose_name="Created Date", null=False)
    modified_by_user_id = models.PositiveIntegerField(verbose_name="Modified By User Id", null=True)
    modified_date = models.DateTimeField(auto_now_add=True, verbose_name="Modified Date", null=False)


class ActionCategory(models.Model):
    class Meta:
        db_table = "action_category"

    action_category_id = models.AutoField(verbose_name="ActionCategory Id", null=False, primary_key=True)
    action_category_name = models.CharField(max_length=100, null=False)
    action_category_description = models.CharField(max_length=100)
    action_category_code = models.CharField(max_length=100)

class Process(models.Model):
    class Meta:
        db_table = "process"

    process_id = models.AutoField(verbose_name="Job Id", null=False, primary_key=True)
    process_name = models.CharField(max_length=45)
    process_description = models.CharField(max_length=65)
    process_category = models.CharField(max_length=45)

    def __int__(self):
        return self.process_id

class Job(models.Model):
    class Meta:
        db_table = "job"

    job_id = models.AutoField(verbose_name="Job Id", null=False, primary_key=True)
    job_name = models.CharField(max_length=100)
    job_description = models.CharField(max_length=128)
    job_category = models.CharField(max_length=100)
    process = models.ForeignKey(Process, verbose_name="Process (Process Id)", on_delete=models.CASCADE)

    def __int__(self):
        return self.job_id


class Task(models.Model):
    class Meta:
        db_table = "task"

    task_id = models.AutoField(verbose_name="Task Id", null=False, primary_key=True)
    task_name = models.CharField(max_length=100, null=False)
    task_description = models.CharField(max_length=100)
    task_category = models.CharField(max_length=100)
    job = models.ForeignKey(Job, verbose_name="Job (Job Id)", on_delete=models.CASCADE)


class Action(models.Model):
    class Meta:
        db_table = "action"

    action_id = models.AutoField(verbose_name="Action Id", null=False, primary_key=True)
    action_name = models.CharField(max_length=100, null=False)
    action_description = models.CharField(max_length=100, null=False)
    action_details = models.CharField(max_length=100, null=False)
    restapi_address = models.CharField(max_length=100)
    action_category = models.ForeignKey(ActionCategory, verbose_name="ActionCategory (ActionCategory Id)", on_delete=models.CASCADE)
    task = models.ForeignKey(Task, verbose_name="Task (Task Id)", on_delete=models.CASCADE)

    def delete(self):       
       super(Action, self).delete()                            


class Condition(models.Model):
    class Meta:
        db_table = "condition"

    condition_id = models.AutoField(verbose_name="Condition Id", null=False, primary_key=True)
    condition_name = models.CharField(max_length=100, null=False)
    condition_description = models.CharField(max_length=100)
    condition_category = models.CharField(max_length=100)
    api_link = models.CharField(max_length=100)
    action = models.ForeignKey(Action, on_delete=models.CASCADE)

    def delete(self):       
       super(Condition, self).delete()


class JobMaster(models.Model):
    class Meta:
        db_table = "job_master"

    job_master_id = models.AutoField(verbose_name="JobMaster Id", null=False, primary_key=True)
    job_master_name = models.CharField(max_length=100)
    job_master_code = models.TextField()
    job_master_description = models.TextField()


class ProcessMaster(models.Model):
    class Meta:
        db_table = "process_master"

    process_master_id = models.AutoField(verbose_name="ProcessMaster Id", null=False, primary_key=True)
    process_master_name = models.CharField(max_length=100)
    process_master_description = models.TextField()
    jobs = models.ForeignKey(Job, verbose_name="Job (Job Id)",
                                        on_delete=models.CASCADE)


class SourceMaster(models.Model):
    class Meta:
        db_table = "source_master"

    source_id = models.AutoField(primary_key = True,null=False)
    source_name = models.CharField(max_length=100,null=False)
    source_type = models.CharField(max_length=100,null=False)
    source_description = models.CharField(max_length=100, null=False)
    source_identifier = models.CharField(max_length=160, null=False)
    sheets = models.JSONField(null=False)
    columns = models.JSONField(null=False)
    actions = models.JSONField(null=False)


class Target(models.Model):
    class Meta:
        db_table = "target"

    target_id = models.AutoField(primary_key = True,null=False)
    target_name = models.CharField(max_length=100,null=False)
    target_description = models.CharField(max_length=100)
    target_placeholder = models.CharField(max_length=100)
    target_location = models.CharField(max_length=100, null=False)
    target_configuration = models.JSONField(null=False)
    
class DjangoCeleryResultsTaskresult(models.Model):

    task_id = models.CharField(unique=True, max_length=255, blank=True, null=True)
    status = models.CharField(max_length=50, blank=True, null=True)
    content_type = models.CharField(max_length=128, blank=True, null=True)
    content_encoding = models.CharField(max_length=64, blank=True, null=True)
    result = models.TextField(blank=True, null=True)
    date_done = models.DateTimeField(blank=True, null=True)
    traceback = models.TextField(blank=True, null=True)
    meta = models.TextField(blank=True, null=True)
    task_args = models.TextField(blank=True, null=True)
    task_kwargs = models.TextField(blank=True, null=True)
    task_name = models.CharField(max_length=255, blank=True, null=True)
    worker = models.CharField(max_length=100, blank=True, null=True)
    date_created = models.DateTimeField(blank=True, null=True)
    periodic_task_name = models.CharField(max_length=255, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'django_celery_results_taskresult'

    
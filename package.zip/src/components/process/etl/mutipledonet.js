import React, { useCallback, useMemo, useRef, useState } from 'react';
import { render } from 'react-dom';

import "./etlsecound.css";
import { Icon, Input, Button,Dropdown, Grid, Popup,Segment,Select,Tab,Table,Menu , Form, TextArea, Label, Checkbox, GridColumn,Search,Pagination } from 'semantic-ui-react'
import { AgGridReact } from 'ag-grid-react';
import * as agCharts from 'ag-charts-community';
import { AgChartsReact } from 'ag-charts-react';


class MultiChartDont extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      options: {
        data: [
          { os: 'SBI', share: 56.9 },
          { os: 'ICICI', share: 22.5 },
          { os: 'HDFC', share: 6.8 },
          { os: 'AXIS', share: 8.5 },
          // { os: 'Bada', share: 2.6 },
          // { os: 'Windows', share: 1.9 },
        ],
        series: [
          {
            type: 'pie',
            calloutLabelKey: 'os',
            angleKey: 'share',
            innerRadiusOffset: -70,
          },
        ],
      },
    };
  }

  componentDidMount() {}

    render() {
        
      return (
        <AgChartsReact options={this.state.options} />
      );
    }
  }
  
  export default MultiChartDont;
  
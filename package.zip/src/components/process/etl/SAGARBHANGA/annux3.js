// App.js
import { useEffect, useState } from "react";
// import "./App.css";
import "../etlsecound.css";
import hdfcs from '../../../../assets/images/banks/thermax.png';


function Annux3() 
{
  

  return (
  <div>
    <table className="table">
    <tr className="bold">
        <td colSpan={7}>Payment received by vendor but not accounted by Thermax</td>
        
    </tr>
    <tr className="fontcolor">
        <td>DATE</td>
        <td>PARTICULARS</td>
        <td>VCH TYPE</td>
        <td>VCH NO.</td>
        <td>Cr/Dr</td>
        <td>DEBIT</td>
        <td>CREDIT</td>
    </tr>
</table>
  </div>
  )
}



export default Annux3;
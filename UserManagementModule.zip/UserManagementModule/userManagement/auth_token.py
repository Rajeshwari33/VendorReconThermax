from rest_framework import parsers, renderers
from rest_framework.authtoken.models import Token
from rest_framework.authtoken.serializers import AuthTokenSerializer
from rest_framework.compat import coreapi, coreschema
from rest_framework.response import Response
from rest_framework.schemas import ManualSchema
from rest_framework.schemas import coreapi as coreapi_schema
from rest_framework.views import APIView
from .models import UserAuthToken, Users, ModuleSettings
from datetime import datetime, timedelta
import logging

logger = logging.getLogger("user_modules")

def get_time(minutes_to_add):
    try:
        time_str = str(datetime.today())
        date_format_str = "%Y-%m-%d %H:%M:%S.%f"

        given_time = datetime.strptime(time_str, date_format_str)
        final_time = given_time + timedelta(minutes = minutes_to_add)

        final_time_str = final_time.strftime("%Y-%m-%d %H:%M:%S.%f")

        time = {
            "current_time": time_str,
            "expiry_time": final_time_str
        }

        return time

    except Exception:
        logger.error("Error in Get Time Function!!!", exc_info=True)
        return ""


class ObtainAuthToken(APIView):
    throttle_classes = ()
    permission_classes = ()
    parser_classes = (parsers.FormParser, parsers.MultiPartParser, parsers.JSONParser,)
    renderer_classes = (renderers.JSONRenderer,)
    serializer_class = AuthTokenSerializer

    if coreapi_schema.is_enabled():
        schema = ManualSchema(
            fields=[
                coreapi.Field(
                    name="username",
                    required=True,
                    location='form',
                    schema=coreschema.String(
                        title="Username",
                        description="Valid username for authentication",
                    ),
                ),
                coreapi.Field(
                    name="password",
                    required=True,
                    location='form',
                    schema=coreschema.String(
                        title="Password",
                        description="Valid password for authentication",
                    ),
                ),
            ],
            encoding="application/json",
        )

    def get_serializer_context(self):
        return {
            'request': self.request,
            'format': self.format_kwarg,
            'view': self
        }

    def get_serializer(self, *args, **kwargs):
        kwargs['context'] = self.get_serializer_context()
        return self.serializer_class(*args, **kwargs)

    def post(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.validated_data['user']
        token, created = Token.objects.get_or_create(user=user)

        module_settings = ModuleSettings.objects.filter(setting_key = 'token_timeout', is_active = 1)
        for setting in module_settings:
            setting_value = setting.setting_value

        time_to_live = setting_value["TTL"]["value"]

        date_time = get_time(minutes_to_add = time_to_live)
        users = Users.objects.filter(email = user)

        for user in users:
            user_id = user.user_id

        UserAuthToken.objects.create(
            created_dt = date_time["current_time"],
            expiry_dt = date_time["expiry_time"],
            user_id = user_id
        )

        return Response({'token': token.key})


obtain_auth_token = ObtainAuthToken.as_view()
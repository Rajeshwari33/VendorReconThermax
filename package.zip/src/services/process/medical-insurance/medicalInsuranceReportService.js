import { headers, baseUrl } from "../../common/credentials";

export const port = "8002";

export const getFileProcessFromServer = () => {
    let url = baseUrl + port + "/api/v2/medical_insurance/generic/reports/";
    return ([headers, url]);
} 

export const getFileProcessFromServer1 = () => {
    let url = baseUrl + port + "/api/v2/medical_insurance/alcs_reports/";
    return ([headers, url]);
} 

export const getFileProcessFromServer2 = () => {
    let url = baseUrl + port + "/api/v2/medical_insurance/generic/reports_new/";
    return ([headers, url]);
}

export const saveJsonfileToServer = () => {
    let url = baseUrl + port + "/api/v2/medical_insurance/save_utr_file/";
    return ([headers, url]);
} 


export const getSingleMailSentFromServer = () => {
    let url = baseUrl + port + "/api/v2/alcs/common/alcs_clent_mail_sent_revised/";
    return ([headers, url]);
}

export const getClientNameFromServer = () => {
    let url = baseUrl + port + "/api/v2/alcs/emails_list/";
    return ([headers, url]);
}

export const fetchProcessedEmailsList = () => {
    let url = baseUrl + port + "/api/v2/alcs/fetch_processed_emails_list/";
    return ([headers, url]);
}

export const deactivateemailid = () => {
    let url = baseUrl + port + "/api/v2/alcs/deactivate_email_id/";
    return ([headers, url]);
}

export const activateemailid = () => {
    let url = baseUrl + port + "/api/v2/alcs/activate_email_id/";
    return ([headers, url]);
}
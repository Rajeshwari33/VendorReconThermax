// App.js
import { useEffect, useState } from "react";
// import "./App.css";
import "./etlsecound.css";

function ThermaxStatement() 
{
  

  return (
  <div>
    <table className="table">
    <tr className="fontcolor">
        <td>DIV</td>
        <td>GL CODE</td>
        <td>GL DESC</td>
        <td>VENDOR CODE</td>
        <td>VENDOR NAME</td>
        <td>VENDOR SITE</td>
        <td>DOC CATEGORY</td>
        <td>DOC NUMBER</td>
        <td>DOC DATE</td>
        <td>INVOICE/ CHEQUE NO</td>
        <td>SUPPLIER BILL NO</td>
        <td>GL DATE</td>
        <td>DEBIT AMOUNT</td>
        <td>CREDIT AMOUNT</td>
        <td>INVOICE NUM1</td>
        <td>INVOICE PAYMENT AMT</td>
        <td>NEWGEN WFID</td>
        <td>NARRATION</td>
        <td>TRAN TYPE</td>
        <td>OPENING PERIOD</td>
        <td>CLOSING PERIOD</td>
        <td>CLOSING BALANCE</td>
        <td>SOURCE1</td>
        <td>INVOICE TYPE LOOKUP CODE</td>
        <td>CHECK ID</td>
        <td>SR No</td>
        <td>Event Type Code</td>
        <td>REMARKS</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI UTILITY EPAY</td>
        <td>12-04-21</td>
        <td>51302361</td>
        <td>514008124</td>
        <td>12-04-21</td>
        <td>1736433.57</td>
        <td>0</td>
        <td>ERS-4000025126-1756375</td>
        <td>734666.82</td>
        <td>PO-0000069411-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3633496</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI UTILITY EPAY</td>
        <td>12-04-21</td>
        <td>51302361</td>
        <td>514008124</td>
        <td>12-04-21</td>
        <td>1736433.57</td>
        <td>0</td>
        <td>ERS-4000025078-1753891</td>
        <td>1001766.75</td>
        <td>PO-0000069090-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3633496</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI EPAY</td>
        <td>19-04-21</td>
        <td>534172</td>
        <td>51213122</td>
        <td>19-04-21</td>
        <td>788172.58</td>
        <td>0</td>
        <td>ERS-4000025208-1759193</td>
        <td>788172.58</td>
        <td>PO-0000077861-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3637967</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>23-03-21</td>
        <td>3703005</td>
        <td>ERS-4000025495-1771142</td>
        <td>20-04-21</td>
        <td>544934.2</td>
        <td>0</td>
        <td>ERS-4000025495-1771142</td>
        <td>0.00</td>
        <td>PO-0000087992-Invoice</td>
        <td>Receipt Invoice automatically created on 23-MAR-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>23-03-21</td>
        <td>3703006</td>
        <td>ERS-4000025496-1771143</td>
        <td>20-04-21</td>
        <td>0</td>
        <td>71414.03</td>
        <td>ERS-4000025496-1771143</td>
        <td>0.00</td>
        <td>PO-0000087993-Invoice</td>
        <td>Receipt Invoice automatically created on 23-MAR-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>UNMATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>23-03-21</td>
        <td>3703005</td>
        <td>ERS-4000025495-1771142</td>
        <td>20-04-21</td>
        <td>0</td>
        <td>1182440.82</td>
        <td>ERS-4000025495-1771142</td>
        <td>0.00</td>
        <td>PO-0000087992-Invoice</td>
        <td>Receipt Invoice automatically created on 23-MAR-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>UNMATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>45030</td>
        <td>Advances to Suppliers - Goods</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>23-03-21</td>
        <td>3703005</td>
        <td>ERS-4000025495-1771142</td>
        <td>20-04-21</td>
        <td>0</td>
        <td>544934.2</td>
        <td>ERS-4000025495-1771142</td>
        <td>0.00</td>
        <td>PO-0000087992-Invoice</td>
        <td>Receipt Invoice automatically created on 23-MAR-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI EPAY</td>
        <td>14-05-21</td>
        <td>535747</td>
        <td>51214663</td>
        <td>14-05-21</td>
        <td>655671.1</td>
        <td>0</td>
        <td>ERS-4000025477-1770359</td>
        <td>18164.48</td>
        <td>PO-0000077862-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3646877</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI EPAY</td>
        <td>14-05-21</td>
        <td>535747</td>
        <td>51214663</td>
        <td>14-05-21</td>
        <td>655671.1</td>
        <td>0</td>
        <td>ERS-4000025495-1771142</td>
        <td>637506.62</td>
        <td>PO-0000087992-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3646877</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI EPAY</td>
        <td>27-05-21</td>
        <td>536405</td>
        <td>51215300</td>
        <td>27-05-21</td>
        <td>1854407</td>
        <td>0</td>
        <td>ERS-5000012152-1777220</td>
        <td>1854407.00</td>
        <td>PO-0000084097-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3652063</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CGN PV Adv</td>
        <td>17-05-21</td>
        <td>578567</td>
        <td>Po No 1000065712 C173</td>
        <td>31-05-21</td>
        <td>0</td>
        <td>8387400</td>
        <td>Po No 1000065712 C173</td>
        <td>0.00</td>
        <td>Advance_Pay-0000002801-Invoices</td>
        <td>70 Percent advance on basic amount against raw material inspection clearance Po No 1000065712 C173</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>MANUAL INVOICE ENTRY</td>
        <td>PREPAYMENT</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT VALIDATED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>45030</td>
        <td>Advances to Suppliers - Goods</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CGN PV Adv</td>
        <td>17-05-21</td>
        <td>578567</td>
        <td>Po No 1000065712 C173</td>
        <td>31-05-21</td>
        <td>8387400</td>
        <td>0</td>
        <td>Po No 1000065712 C173</td>
        <td>0.00</td>
        <td>Advance_Pay-0000002801-Invoices</td>
        <td>70 Percent advance on basic amount against raw material inspection clearance Po No 1000065712 C173</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>MANUAL INVOICE ENTRY</td>
        <td>PREPAYMENT</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT VALIDATED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>30-03-21</td>
        <td>3710848</td>
        <td>ERS-5000012055-1776097</td>
        <td>01-06-21</td>
        <td>0</td>
        <td>3672868</td>
        <td>ERS-5000012055-1776097</td>
        <td>0.00</td>
        <td>PO-0000084082-Invoice</td>
        <td>Receipt Invoice automatically created on 30-MAR-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI EPAY</td>
        <td>04-06-21</td>
        <td>536679</td>
        <td>51215574</td>
        <td>04-06-21</td>
        <td>1395991.03</td>
        <td>0</td>
        <td>ERS-5000012148-1777218</td>
        <td>529831.00</td>
        <td>PO-0000084087-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3654629</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI EPAY</td>
        <td>04-06-21</td>
        <td>536679</td>
        <td>51215574</td>
        <td>04-06-21</td>
        <td>1395991.03</td>
        <td>0</td>
        <td>ERS-5000012150-1777219</td>
        <td>794746.00</td>
        <td>PO-0000084093-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3654629</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI EPAY</td>
        <td>04-06-21</td>
        <td>536679</td>
        <td>51215574</td>
        <td>04-06-21</td>
        <td>1395991.03</td>
        <td>0</td>
        <td>ERS-4000025496-1771143</td>
        <td>71414.03</td>
        <td>PO-0000087993-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3654629</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI UTILITY EPAY</td>
        <td>08-06-21</td>
        <td>51303154</td>
        <td>851000142</td>
        <td>08-06-21</td>
        <td>8387400</td>
        <td>0</td>
        <td>Po No 1000065712 C173</td>
        <td>8387400.00</td>
        <td>Advance_Pay-0000002801-Invoices</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>MANUAL INVOICE ENTRY</td>
        <td>PREPAYMENT</td>
        <td>3655712</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>DBM INV</td>
        <td>08-06-21</td>
        <td>3099522</td>
        <td>5000012055-204362</td>
        <td>08-06-21</td>
        <td>3672868</td>
        <td>0</td>
        <td>5000012055-204362</td>
        <td>0.00</td>
        <td></td>
        <td>System Generated by 'Return to Supplier' Transaction</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>RTS</td>
        <td>DEBIT</td>
        <td></td>
        <td>2</td>
        <td>DEBIT MEMO VALIDATED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>45030</td>
        <td>Advances to Suppliers - Goods</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CGN PV Adv</td>
        <td>16-06-21</td>
        <td>578598</td>
        <td>1000065519DDC167</td>
        <td>18-06-21</td>
        <td>2120909</td>
        <td>0</td>
        <td>1000065519DDC167</td>
        <td>0.00</td>
        <td>Advance_Pay-0000003538-Invo</td>
        <td>50 PERCENT ADVANCE ON BASIC AMOUNT AGAINST PI</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>MANUAL INVOICE ENTRY</td>
        <td>PREPAYMENT</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT VALIDATED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CGN PV Adv</td>
        <td>16-06-21</td>
        <td>578598</td>
        <td>1000065519DDC167</td>
        <td>18-06-21</td>
        <td>0</td>
        <td>2120909</td>
        <td>1000065519DDC167</td>
        <td>0.00</td>
        <td>Advance_Pay-0000003538-Invo</td>
        <td>50 PERCENT ADVANCE ON BASIC AMOUNT AGAINST PI</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>MANUAL INVOICE ENTRY</td>
        <td>PREPAYMENT</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT VALIDATED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI UTILITY EPAY</td>
        <td>18-06-21</td>
        <td>51303263</td>
        <td>851000251</td>
        <td>18-06-21</td>
        <td>2120909</td>
        <td>0</td>
        <td>1000065519DDC167</td>
        <td>2120909.00</td>
        <td>Advance_Pay-0000003538-Invo</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>MANUAL INVOICE ENTRY</td>
        <td>PREPAYMENT</td>
        <td>3659087</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>45030</td>
        <td>Advances to Suppliers - Goods</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CGN PV Adv</td>
        <td>22-06-21</td>
        <td>578605</td>
        <td>1000066420EOE027</td>
        <td>23-06-21</td>
        <td>1436500</td>
        <td>0</td>
        <td>1000066420EOE027</td>
        <td>0.00</td>
        <td>Advance_Pay-0000003634-Invoices</td>
        <td>50 Percent advance on basic amount ADV AGAINST PI</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>MANUAL INVOICE ENTRY</td>
        <td>PREPAYMENT</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT VALIDATED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CGN PV Adv</td>
        <td>22-06-21</td>
        <td>578605</td>
        <td>1000066420EOE027</td>
        <td>23-06-21</td>
        <td>0</td>
        <td>1436500</td>
        <td>1000066420EOE027</td>
        <td>0.00</td>
        <td>Advance_Pay-0000003634-Invoices</td>
        <td>50 Percent advance on basic amount ADV AGAINST PI</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>MANUAL INVOICE ENTRY</td>
        <td>PREPAYMENT</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT VALIDATED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI UTILITY EPAY</td>
        <td>23-06-21</td>
        <td>51303290</td>
        <td>851000278</td>
        <td>23-06-21</td>
        <td>1436500</td>
        <td>0</td>
        <td>1000066420EOE027</td>
        <td>1436500.00</td>
        <td>Advance_Pay-0000003634-Invoices</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>MANUAL INVOICE ENTRY</td>
        <td>PREPAYMENT</td>
        <td>3661283</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>21-06-21</td>
        <td>3755154</td>
        <td>ERS-5000012813-1804272</td>
        <td>24-06-21</td>
        <td>0</td>
        <td>3675623</td>
        <td>ERS-5000012813-1804272</td>
        <td>0.00</td>
        <td>PO-0000111720-Invoice</td>
        <td>Receipt Invoice automatically created on 21-JUN-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>UNMATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>21-06-21</td>
        <td>3755154</td>
        <td>ERS-5000012813-1804272</td>
        <td>24-06-21</td>
        <td>1556300</td>
        <td>0</td>
        <td>ERS-5000012813-1804272</td>
        <td>0.00</td>
        <td>PO-0000111720-Invoice</td>
        <td>Receipt Invoice automatically created on 21-JUN-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>45030</td>
        <td>Advances to Suppliers - Goods</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>21-06-21</td>
        <td>3755154</td>
        <td>ERS-5000012813-1804272</td>
        <td>24-06-21</td>
        <td>0</td>
        <td>1556300</td>
        <td>ERS-5000012813-1804272</td>
        <td>0.00</td>
        <td>PO-0000111720-Invoice</td>
        <td>Receipt Invoice automatically created on 21-JUN-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI UTILITY EPAY</td>
        <td>28-06-21</td>
        <td>51303353</td>
        <td>851000341</td>
        <td>28-06-21</td>
        <td>3526460</td>
        <td>0</td>
        <td>Po No 1000066145 C173</td>
        <td>3526460.00</td>
        <td>Advance_Pay-0000003643-Invoices</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>MANUAL INVOICE ENTRY</td>
        <td>PREPAYMENT</td>
        <td>3662312</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>45030</td>
        <td>Advances to Suppliers - Goods</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CGN PV Adv</td>
        <td>22-06-21</td>
        <td>578617</td>
        <td>Po No 1000066145 C173</td>
        <td>28-06-21</td>
        <td>3526460</td>
        <td>0</td>
        <td>Po No 1000066145 C173</td>
        <td>0.00</td>
        <td>Advance_Pay-0000003643-Invoices</td>
        <td>70 Percent advance against raw material inspection clearance Po No 1000066145 C173</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>MANUAL INVOICE ENTRY</td>
        <td>PREPAYMENT</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT VALIDATED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CGN PV Adv</td>
        <td>22-06-21</td>
        <td>578617</td>
        <td>Po No 1000066145 C173</td>
        <td>28-06-21</td>
        <td>0</td>
        <td>3526460</td>
        <td>Po No 1000066145 C173</td>
        <td>0.00</td>
        <td>Advance_Pay-0000003643-Invoices</td>
        <td>70 Percent advance against raw material inspection clearance Po No 1000066145 C173</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>MANUAL INVOICE ENTRY</td>
        <td>PREPAYMENT</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT VALIDATED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CGN BV ZERO Payment</td>
        <td>30-06-21</td>
        <td>1006264</td>
        <td>16069</td>
        <td>30-06-21</td>
        <td>3672868</td>
        <td>3672868</td>
        <td>5000012055-204362</td>
        <td>0.00</td>
        <td></td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>RTS</td>
        <td>DEBIT</td>
        <td>3666589</td>
        <td>2</td>
        <td></td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CGN BV ZERO Payment</td>
        <td>30-06-21</td>
        <td>1006264</td>
        <td>16069</td>
        <td>30-06-21</td>
        <td>3672868</td>
        <td>3672868</td>
        <td>ERS-5000012055-1776097</td>
        <td>3672868.00</td>
        <td>PO-0000084082-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3666589</td>
        <td>2</td>
        <td></td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI EPAY</td>
        <td>10-07-21</td>
        <td>538627</td>
        <td>51217538</td>
        <td>10-07-21</td>
        <td>2119323</td>
        <td>0</td>
        <td>ERS-5000012813-1804272</td>
        <td>2119323.00</td>
        <td>PO-0000111720-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3667216</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>30-06-21</td>
        <td>3762170</td>
        <td>ERS-5000012935-1809613</td>
        <td>16-07-21</td>
        <td>0</td>
        <td>303263.56</td>
        <td>ERS-5000012935-1809613</td>
        <td>0.00</td>
        <td>PO-0000118061-Invoice</td>
        <td>Receipt Invoice automatically created on 30-JUN-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>30-06-21</td>
        <td>3762171</td>
        <td>ERS-5000012934-1809614</td>
        <td>16-07-21</td>
        <td>0</td>
        <td>2035247.05</td>
        <td>ERS-5000012934-1809614</td>
        <td>0.00</td>
        <td>PO-0000118055-Invoice</td>
        <td>Receipt Invoice automatically created on 30-JUN-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>30-06-21</td>
        <td>3762171</td>
        <td>ERS-5000012934-1809614</td>
        <td>21-07-21</td>
        <td>861531.5</td>
        <td>0</td>
        <td>ERS-5000012934-1809614</td>
        <td>0.00</td>
        <td>PO-0000118055-Invoice</td>
        <td>Receipt Invoice automatically created on 30-JUN-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>45030</td>
        <td>Advances to Suppliers - Goods</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>30-06-21</td>
        <td>3762171</td>
        <td>ERS-5000012934-1809614</td>
        <td>21-07-21</td>
        <td>0</td>
        <td>861531.5</td>
        <td>ERS-5000012934-1809614</td>
        <td>0.00</td>
        <td>PO-0000118055-Invoice</td>
        <td>Receipt Invoice automatically created on 30-JUN-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI UTILITY EPAY</td>
        <td>22-07-21</td>
        <td>51303561</td>
        <td>851000549</td>
        <td>22-07-21</td>
        <td>4726937</td>
        <td>4727</td>
        <td>Po No 1000066481 C170</td>
        <td>4726937.00</td>
        <td>Advance_Pay-0000004104-Invo</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>MANUAL INVOICE ENTRY</td>
        <td>PREPAYMENT</td>
        <td>3672207</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CGN PV Adv</td>
        <td>16-07-21</td>
        <td>578660</td>
        <td>Po No 1000066555 C170</td>
        <td>22-07-21</td>
        <td>0</td>
        <td>652304</td>
        <td>Po No 1000066555 C170</td>
        <td>0.00</td>
        <td>Advance_Pay-0000004077-Invo</td>
        <td>70 Percent advance on basic amount against raw material inspection clearance Po No 1000066555 C170</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>MANUAL INVOICE ENTRY</td>
        <td>PREPAYMENT</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT VALIDATED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CRM INV</td>
        <td>18-07-21</td>
        <td>2852312</td>
        <td>Po No 1000066481 C170-TDS-CM-788809</td>
        <td>22-07-21</td>
        <td>4727</td>
        <td>0</td>
        <td>Po No 1000066481 C170-TDS-CM-788809</td>
        <td>0.00</td>
        <td>Advance_Pay-0000004104-Invo</td>
        <td>Po No 1000066481 C170-TDS-CM-788809</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td></td>
        <td>2</td>
        <td>CREDIT MEMO VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI UTILITY EPAY</td>
        <td>22-07-21</td>
        <td>51303561</td>
        <td>851000549</td>
        <td>22-07-21</td>
        <td>4726937</td>
        <td>4727</td>
        <td>Po No 1000066481 C170-TDS-CM-788809</td>
        <td>0.00</td>
        <td>Advance_Pay-0000004104-Invo</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td>3672207</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI UTILITY EPAY</td>
        <td>22-07-21</td>
        <td>51303562</td>
        <td>851000550</td>
        <td>22-07-21</td>
        <td>652304</td>
        <td>0</td>
        <td>Po No 1000066555 C170</td>
        <td>652304.00</td>
        <td>Advance_Pay-0000004077-Invo</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>MANUAL INVOICE ENTRY</td>
        <td>PREPAYMENT</td>
        <td>3672217</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CGN PV Adv</td>
        <td>18-07-21</td>
        <td>578662</td>
        <td>Po No 1000066481 C170</td>
        <td>22-07-21</td>
        <td>0</td>
        <td>4726937</td>
        <td>Po No 1000066481 C170</td>
        <td>0.00</td>
        <td>Advance_Pay-0000004104-Invo</td>
        <td>70 Percent advance on basic amount against raw material inspection clearance Partial Payment Lot 1</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>MANUAL INVOICE ENTRY</td>
        <td>PREPAYMENT</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT VALIDATED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>45030</td>
        <td>Advances to Suppliers - Goods</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CGN PV Adv</td>
        <td>18-07-21</td>
        <td>578662</td>
        <td>Po No 1000066481 C170</td>
        <td>22-07-21</td>
        <td>4726937</td>
        <td>0</td>
        <td>Po No 1000066481 C170</td>
        <td>0.00</td>
        <td>Advance_Pay-0000004104-Invo</td>
        <td>70 Percent advance on basic amount against raw material inspection clearance Partial Payment Lot 1</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>MANUAL INVOICE ENTRY</td>
        <td>PREPAYMENT</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT VALIDATED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>45030</td>
        <td>Advances to Suppliers - Goods</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CGN PV Adv</td>
        <td>16-07-21</td>
        <td>578660</td>
        <td>Po No 1000066555 C170</td>
        <td>22-07-21</td>
        <td>652304</td>
        <td>0</td>
        <td>Po No 1000066555 C170</td>
        <td>0.00</td>
        <td>Advance_Pay-0000004077-Invo</td>
        <td>70 Percent advance on basic amount against raw material inspection clearance Po No 1000066555 C170</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>MANUAL INVOICE ENTRY</td>
        <td>PREPAYMENT</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT VALIDATED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CRM INV</td>
        <td>18-07-21</td>
        <td>2852584</td>
        <td>Po No 1000066553C170-TDS-CM-789051</td>
        <td>23-07-21</td>
        <td>6121</td>
        <td>0</td>
        <td>Po No 1000066553C170-TDS-CM-789051</td>
        <td>0.00</td>
        <td>Advance_Pay-0000004103-Invo</td>
        <td>Po No 1000066553C170-TDS-CM-789051</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td></td>
        <td>2</td>
        <td>CREDIT MEMO VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI UTILITY EPAY</td>
        <td>23-07-21</td>
        <td>51303569</td>
        <td>851000557</td>
        <td>23-07-21</td>
        <td>6120607</td>
        <td>6121</td>
        <td>Po No 1000066553C170-TDS-CM-789051</td>
        <td>0.00</td>
        <td>Advance_Pay-0000004103-Invo</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td>3672457</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI UTILITY EPAY</td>
        <td>23-07-21</td>
        <td>51303569</td>
        <td>851000557</td>
        <td>23-07-21</td>
        <td>6120607</td>
        <td>6121</td>
        <td>Po No 1000066553C170</td>
        <td>6120607.00</td>
        <td>Advance_Pay-0000004103-Invo</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>MANUAL INVOICE ENTRY</td>
        <td>PREPAYMENT</td>
        <td>3672457</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>45030</td>
        <td>Advances to Suppliers - Goods</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CGN PV Adv</td>
        <td>18-07-21</td>
        <td>578663</td>
        <td>Po No 1000066553C170</td>
        <td>23-07-21</td>
        <td>6120607</td>
        <td>0</td>
        <td>Po No 1000066553C170</td>
        <td>0.00</td>
        <td>Advance_Pay-0000004103-Invo</td>
        <td>70 Percent advance on basic amount against inspection clearance Po No 1000066553 C170 Partial payment Lot 1</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>MANUAL INVOICE ENTRY</td>
        <td>PREPAYMENT</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT VALIDATED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CGN PV Adv</td>
        <td>18-07-21</td>
        <td>578663</td>
        <td>Po No 1000066553C170</td>
        <td>23-07-21</td>
        <td>0</td>
        <td>6120607</td>
        <td>Po No 1000066553C170</td>
        <td>0.00</td>
        <td>Advance_Pay-0000004103-Invo</td>
        <td>70 Percent advance on basic amount against inspection clearance Po No 1000066553 C170 Partial payment Lot 1</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>MANUAL INVOICE ENTRY</td>
        <td>PREPAYMENT</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT VALIDATED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI LABOUR EPAY</td>
        <td>13-08-21</td>
        <td>51404787</td>
        <td>51304787</td>
        <td>13-08-21</td>
        <td>4897997</td>
        <td>4898</td>
        <td>Po No 1000066481 C170 A-TDS-CM-796235</td>
        <td>0.00</td>
        <td>Advance_Pay-0000004386-Invoices</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td>3681329</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CGN PV Adv</td>
        <td>03-08-21</td>
        <td>578701</td>
        <td>Po No 1000066481 C170 A</td>
        <td>13-08-21</td>
        <td>0</td>
        <td>4897997</td>
        <td>Po No 1000066481 C170 A</td>
        <td>0.00</td>
        <td>Advance_Pay-0000004386-Invoices</td>
        <td>70 Percent advance against raw material inspection clearance Po No 1000066481 C170 Lot 2</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>MANUAL INVOICE ENTRY</td>
        <td>PREPAYMENT</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT VALIDATED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>45030</td>
        <td>Advances to Suppliers - Goods</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CGN PV Adv</td>
        <td>03-08-21</td>
        <td>578701</td>
        <td>Po No 1000066481 C170 A</td>
        <td>13-08-21</td>
        <td>4897997</td>
        <td>0</td>
        <td>Po No 1000066481 C170 A</td>
        <td>0.00</td>
        <td>Advance_Pay-0000004386-Invoices</td>
        <td>70 Percent advance against raw material inspection clearance Po No 1000066481 C170 Lot 2</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>MANUAL INVOICE ENTRY</td>
        <td>PREPAYMENT</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT VALIDATED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI LABOUR EPAY</td>
        <td>13-08-21</td>
        <td>51404787</td>
        <td>51304787</td>
        <td>13-08-21</td>
        <td>4897997</td>
        <td>4898</td>
        <td>Po No 1000066481 C170 A</td>
        <td>4897997.00</td>
        <td>Advance_Pay-0000004386-Invoices</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>MANUAL INVOICE ENTRY</td>
        <td>PREPAYMENT</td>
        <td>3681329</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CRM INV</td>
        <td>03-08-21</td>
        <td>2860254</td>
        <td>Po No 1000066481 C170 A-TDS-CM-796235</td>
        <td>13-08-21</td>
        <td>4898</td>
        <td>0</td>
        <td>Po No 1000066481 C170 A-TDS-CM-796235</td>
        <td>0.00</td>
        <td>Advance_Pay-0000004386-Invoices</td>
        <td>Po No 1000066481 C170 A-TDS-CM-796235</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td></td>
        <td>2</td>
        <td>CREDIT MEMO VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>31-07-21</td>
        <td>3784733</td>
        <td>ERS-5000013219-1823608</td>
        <td>30-08-21</td>
        <td>0</td>
        <td>1313700.14</td>
        <td>ERS-5000013219-1823608</td>
        <td>0.00</td>
        <td>PO-0000130770-Invoice</td>
        <td>Receipt Invoice automatically created on 31-JUL-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>31-07-21</td>
        <td>3784732</td>
        <td>ERS-5000013208-1823607</td>
        <td>30-08-21</td>
        <td>0</td>
        <td>1156199.46</td>
        <td>ERS-5000013208-1823607</td>
        <td>0.00</td>
        <td>PO-0000131925-Invoice</td>
        <td>Receipt Invoice automatically created on 31-JUL-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>45030</td>
        <td>Advances to Suppliers - Goods</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>31-07-21</td>
        <td>3784732</td>
        <td>ERS-5000013208-1823607</td>
        <td>31-08-21</td>
        <td>0</td>
        <td>489915</td>
        <td>ERS-5000013208-1823607</td>
        <td>0.00</td>
        <td>PO-0000131925-Invoice</td>
        <td>Receipt Invoice automatically created on 31-JUL-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>31-07-21</td>
        <td>3784733</td>
        <td>ERS-5000013219-1823608</td>
        <td>31-08-21</td>
        <td>556652.5</td>
        <td>0</td>
        <td>ERS-5000013219-1823608</td>
        <td>0.00</td>
        <td>PO-0000130770-Invoice</td>
        <td>Receipt Invoice automatically created on 31-JUL-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>45030</td>
        <td>Advances to Suppliers - Goods</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>31-07-21</td>
        <td>3784733</td>
        <td>ERS-5000013219-1823608</td>
        <td>31-08-21</td>
        <td>0</td>
        <td>556652.5</td>
        <td>ERS-5000013219-1823608</td>
        <td>0.00</td>
        <td>PO-0000130770-Invoice</td>
        <td>Receipt Invoice automatically created on 31-JUL-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>31-07-21</td>
        <td>3784732</td>
        <td>ERS-5000013208-1823607</td>
        <td>31-08-21</td>
        <td>489915</td>
        <td>0</td>
        <td>ERS-5000013208-1823607</td>
        <td>0.00</td>
        <td>PO-0000131925-Invoice</td>
        <td>Receipt Invoice automatically created on 31-JUL-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>45030</td>
        <td>Advances to Suppliers - Goods</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>30-08-21</td>
        <td>3806692</td>
        <td>ERS-4000026866-1836033</td>
        <td>07-09-21</td>
        <td>0</td>
        <td>1176270.2</td>
        <td>ERS-4000026866-1836033</td>
        <td>0.00</td>
        <td>PO-0000144918-Invoice</td>
        <td>Receipt Invoice automatically created on 30-AUG-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>30-08-21</td>
        <td>3806692</td>
        <td>ERS-4000026866-1836033</td>
        <td>07-09-21</td>
        <td>1176270.2</td>
        <td>0</td>
        <td>ERS-4000026866-1836033</td>
        <td>0.00</td>
        <td>PO-0000144918-Invoice</td>
        <td>Receipt Invoice automatically created on 30-AUG-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>30-08-21</td>
        <td>3806692</td>
        <td>ERS-4000026866-1836033</td>
        <td>07-09-21</td>
        <td>0</td>
        <td>1982855.95</td>
        <td>ERS-4000026866-1836033</td>
        <td>0.00</td>
        <td>PO-0000144918-Invoice</td>
        <td>Receipt Invoice automatically created on 30-AUG-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CRM INV</td>
        <td>30-08-21</td>
        <td>2869882</td>
        <td>ERS-4000026866-1836033-TDS-CM-805281</td>
        <td>07-09-21</td>
        <td>1680</td>
        <td>0</td>
        <td>ERS-4000026866-1836033-TDS-CM-805281</td>
        <td>0.00</td>
        <td>PO-0000144918-Invoice</td>
        <td>ERS-4000026866-1836033-TDS-CM-805281</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td></td>
        <td>2</td>
        <td>CREDIT MEMO VALIDATED</td>
        <td>UNMATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>30-08-21</td>
        <td>3806693</td>
        <td>ERS-4000026869-1836034</td>
        <td>07-09-21</td>
        <td>0</td>
        <td>2150946.78</td>
        <td>ERS-4000026869-1836034</td>
        <td>0.00</td>
        <td>PO-0000144995-Invoice</td>
        <td>Receipt Invoice automatically created on 30-AUG-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>30-08-21</td>
        <td>3808161</td>
        <td>ERS-4000026874-1836793</td>
        <td>07-09-21</td>
        <td>0</td>
        <td>2987584.95</td>
        <td>ERS-4000026874-1836793</td>
        <td>0.00</td>
        <td>PO-0000145025-Invoice</td>
        <td>Receipt Invoice automatically created on 30-AUG-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>30-08-21</td>
        <td>3806694</td>
        <td>ERS-4000026870-1836035</td>
        <td>07-09-21</td>
        <td>0</td>
        <td>2040970.49</td>
        <td>ERS-4000026870-1836035</td>
        <td>0.00</td>
        <td>PO-0000145004-Invoice</td>
        <td>Receipt Invoice automatically created on 30-AUG-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>30-08-21</td>
        <td>3806694</td>
        <td>ERS-4000026870-1836035</td>
        <td>08-09-21</td>
        <td>1210745</td>
        <td>0</td>
        <td>ERS-4000026870-1836035</td>
        <td>0.00</td>
        <td>PO-0000145004-Invoice</td>
        <td>Receipt Invoice automatically created on 30-AUG-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>45030</td>
        <td>Advances to Suppliers - Goods</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>30-08-21</td>
        <td>3808161</td>
        <td>ERS-4000026874-1836793</td>
        <td>08-09-21</td>
        <td>0</td>
        <td>1772295.7</td>
        <td>ERS-4000026874-1836793</td>
        <td>0.00</td>
        <td>PO-0000145025-Invoice</td>
        <td>Receipt Invoice automatically created on 30-AUG-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>30-08-21</td>
        <td>3808161</td>
        <td>ERS-4000026874-1836793</td>
        <td>08-09-21</td>
        <td>1772295.7</td>
        <td>0</td>
        <td>ERS-4000026874-1836793</td>
        <td>0.00</td>
        <td>PO-0000145025-Invoice</td>
        <td>Receipt Invoice automatically created on 30-AUG-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>30-08-21</td>
        <td>3806693</td>
        <td>ERS-4000026869-1836034</td>
        <td>08-09-21</td>
        <td>1275985</td>
        <td>0</td>
        <td>ERS-4000026869-1836034</td>
        <td>0.00</td>
        <td>PO-0000144995-Invoice</td>
        <td>Receipt Invoice automatically created on 30-AUG-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>45030</td>
        <td>Advances to Suppliers - Goods</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>30-08-21</td>
        <td>3806693</td>
        <td>ERS-4000026869-1836034</td>
        <td>08-09-21</td>
        <td>0</td>
        <td>1275985</td>
        <td>ERS-4000026869-1836034</td>
        <td>0.00</td>
        <td>PO-0000144995-Invoice</td>
        <td>Receipt Invoice automatically created on 30-AUG-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>45030</td>
        <td>Advances to Suppliers - Goods</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>30-08-21</td>
        <td>3806694</td>
        <td>ERS-4000026870-1836035</td>
        <td>08-09-21</td>
        <td>0</td>
        <td>1210745</td>
        <td>ERS-4000026870-1836035</td>
        <td>0.00</td>
        <td>PO-0000145004-Invoice</td>
        <td>Receipt Invoice automatically created on 30-AUG-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI EPAY</td>
        <td>13-09-21</td>
        <td>542552</td>
        <td>51221468</td>
        <td>13-09-21</td>
        <td>2597047.65</td>
        <td>0</td>
        <td>ERS-5000013208-1823607</td>
        <td>666284.46</td>
        <td>PO-0000131925-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3694800</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI EPAY</td>
        <td>13-09-21</td>
        <td>542552</td>
        <td>51221468</td>
        <td>13-09-21</td>
        <td>2597047.65</td>
        <td>0</td>
        <td>ERS-5000013219-1823608</td>
        <td>757047.64</td>
        <td>PO-0000130770-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3694800</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI EPAY</td>
        <td>13-09-21</td>
        <td>542552</td>
        <td>51221468</td>
        <td>13-09-21</td>
        <td>2597047.65</td>
        <td>0</td>
        <td>ERS-5000012934-1809614</td>
        <td>1173715.55</td>
        <td>PO-0000118055-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3694800</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>29-09-21</td>
        <td>51218522</td>
        <td>511018530</td>
        <td>29-09-21</td>
        <td>303263.56</td>
        <td>0</td>
        <td>ERS-5000012935-1809613</td>
        <td>303263.56</td>
        <td>PO-0000118061-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3702058</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>45030</td>
        <td>Advances to Suppliers - Goods</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>27-09-21</td>
        <td>3827414</td>
        <td>ERS-4000027142-1847383</td>
        <td>30-09-21</td>
        <td>0</td>
        <td>962380.3</td>
        <td>ERS-4000027142-1847383</td>
        <td>0.00</td>
        <td>PO-0000157094-Invoice</td>
        <td>Receipt Invoice automatically created on 27-SEP-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>45030</td>
        <td>Advances to Suppliers - Goods</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>17-09-21</td>
        <td>3820699</td>
        <td>ERS-4000027042-1843473</td>
        <td>30-09-21</td>
        <td>0</td>
        <td>536182.22</td>
        <td>ERS-4000027042-1843473</td>
        <td>0.00</td>
        <td>PO-0000156013-Invoice</td>
        <td>Receipt Invoice automatically created on 17-SEP-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>45030</td>
        <td>Advances to Suppliers - Goods</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>14-09-21</td>
        <td>3817915</td>
        <td>ERS-4000027010-1842001</td>
        <td>30-09-21</td>
        <td>0</td>
        <td>345776.9</td>
        <td>ERS-4000027010-1842001</td>
        <td>0.00</td>
        <td>PO-0000153874-Invoice</td>
        <td>Receipt Invoice automatically created on 14-SEP-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>14-09-21</td>
        <td>3817915</td>
        <td>ERS-4000027010-1842001</td>
        <td>30-09-21</td>
        <td>0</td>
        <td>582880.94</td>
        <td>ERS-4000027010-1842001</td>
        <td>0.00</td>
        <td>PO-0000153874-Invoice</td>
        <td>Receipt Invoice automatically created on 14-SEP-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>17-09-21</td>
        <td>3820700</td>
        <td>ERS-4000027043-1843474</td>
        <td>30-09-21</td>
        <td>0</td>
        <td>451987.61</td>
        <td>ERS-4000027043-1843474</td>
        <td>0.00</td>
        <td>PO-0000156017-Invoice</td>
        <td>Receipt Invoice automatically created on 17-SEP-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>17-09-21</td>
        <td>3820699</td>
        <td>ERS-4000027042-1843473</td>
        <td>30-09-21</td>
        <td>536182.22</td>
        <td>0</td>
        <td>ERS-4000027042-1843473</td>
        <td>0.00</td>
        <td>PO-0000156013-Invoice</td>
        <td>Receipt Invoice automatically created on 17-SEP-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>14-09-21</td>
        <td>3817914</td>
        <td>ERS-4000027009-1842000</td>
        <td>30-09-21</td>
        <td>1013751.2</td>
        <td>0</td>
        <td>ERS-4000027009-1842000</td>
        <td>0.00</td>
        <td>PO-0000153873-Invoice</td>
        <td>Receipt Invoice automatically created on 14-SEP-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>17-09-21</td>
        <td>3820700</td>
        <td>ERS-4000027043-1843474</td>
        <td>30-09-21</td>
        <td>268128</td>
        <td>0</td>
        <td>ERS-4000027043-1843474</td>
        <td>0.00</td>
        <td>PO-0000156017-Invoice</td>
        <td>Receipt Invoice automatically created on 17-SEP-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>45030</td>
        <td>Advances to Suppliers - Goods</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>17-09-21</td>
        <td>3820700</td>
        <td>ERS-4000027043-1843474</td>
        <td>30-09-21</td>
        <td>0</td>
        <td>268128</td>
        <td>ERS-4000027043-1843474</td>
        <td>0.00</td>
        <td>PO-0000156017-Invoice</td>
        <td>Receipt Invoice automatically created on 17-SEP-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>14-09-21</td>
        <td>3817916</td>
        <td>ERS-4000027011-1842002</td>
        <td>30-09-21</td>
        <td>0</td>
        <td>1658066.44</td>
        <td>ERS-4000027011-1842002</td>
        <td>0.00</td>
        <td>PO-0000153877-Invoice</td>
        <td>Receipt Invoice automatically created on 14-SEP-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>14-09-21</td>
        <td>3817916</td>
        <td>ERS-4000027011-1842002</td>
        <td>30-09-21</td>
        <td>983598.7</td>
        <td>0</td>
        <td>ERS-4000027011-1842002</td>
        <td>0.00</td>
        <td>PO-0000153877-Invoice</td>
        <td>Receipt Invoice automatically created on 14-SEP-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>14-09-21</td>
        <td>3817914</td>
        <td>ERS-4000027009-1842000</td>
        <td>30-09-21</td>
        <td>0</td>
        <td>1708894.28</td>
        <td>ERS-4000027009-1842000</td>
        <td>0.00</td>
        <td>PO-0000153873-Invoice</td>
        <td>Receipt Invoice automatically created on 14-SEP-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>14-09-21</td>
        <td>3817915</td>
        <td>ERS-4000027010-1842001</td>
        <td>30-09-21</td>
        <td>345776.9</td>
        <td>0</td>
        <td>ERS-4000027010-1842001</td>
        <td>0.00</td>
        <td>PO-0000153874-Invoice</td>
        <td>Receipt Invoice automatically created on 14-SEP-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>27-09-21</td>
        <td>3827414</td>
        <td>ERS-4000027142-1847383</td>
        <td>30-09-21</td>
        <td>0</td>
        <td>1622298.64</td>
        <td>ERS-4000027142-1847383</td>
        <td>0.00</td>
        <td>PO-0000157094-Invoice</td>
        <td>Receipt Invoice automatically created on 27-SEP-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>27-09-21</td>
        <td>3827414</td>
        <td>ERS-4000027142-1847383</td>
        <td>30-09-21</td>
        <td>962380.3</td>
        <td>0</td>
        <td>ERS-4000027142-1847383</td>
        <td>0.00</td>
        <td>PO-0000157094-Invoice</td>
        <td>Receipt Invoice automatically created on 27-SEP-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>17-09-21</td>
        <td>3820699</td>
        <td>ERS-4000027042-1843473</td>
        <td>30-09-21</td>
        <td>0</td>
        <td>903850.03</td>
        <td>ERS-4000027042-1843473</td>
        <td>0.00</td>
        <td>PO-0000156013-Invoice</td>
        <td>Receipt Invoice automatically created on 17-SEP-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>45030</td>
        <td>Advances to Suppliers - Goods</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>14-09-21</td>
        <td>3817914</td>
        <td>ERS-4000027009-1842000</td>
        <td>30-09-21</td>
        <td>0</td>
        <td>1013751.2</td>
        <td>ERS-4000027009-1842000</td>
        <td>0.00</td>
        <td>PO-0000153873-Invoice</td>
        <td>Receipt Invoice automatically created on 14-SEP-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>45030</td>
        <td>Advances to Suppliers - Goods</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>14-09-21</td>
        <td>3817916</td>
        <td>ERS-4000027011-1842002</td>
        <td>30-09-21</td>
        <td>0</td>
        <td>983598.7</td>
        <td>ERS-4000027011-1842002</td>
        <td>0.00</td>
        <td>PO-0000153877-Invoice</td>
        <td>Receipt Invoice automatically created on 14-SEP-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>45030</td>
        <td>Advances to Suppliers - Goods</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>30-09-21</td>
        <td>3832421</td>
        <td>ERS-4000027226-1850401</td>
        <td>06-10-21</td>
        <td>0</td>
        <td>1924986</td>
        <td>ERS-4000027226-1850401</td>
        <td>0.00</td>
        <td>PO-0000157954-Invoice</td>
        <td>Receipt Invoice automatically created on 30-SEP-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>30-09-21</td>
        <td>3831243</td>
        <td>ERS-4000027207-1849516</td>
        <td>06-10-21</td>
        <td>0</td>
        <td>301451.59</td>
        <td>ERS-4000027207-1849516</td>
        <td>0.00</td>
        <td>PO-0000157957-Invoice</td>
        <td>Receipt Invoice automatically created on 30-SEP-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>30-09-21</td>
        <td>3832422</td>
        <td>ERS-4000027228-1850402</td>
        <td>06-10-21</td>
        <td>0</td>
        <td>3244976.4</td>
        <td>ERS-4000027228-1850402</td>
        <td>0.00</td>
        <td>PO-0000157982-Invoice</td>
        <td>Receipt Invoice automatically created on 30-SEP-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CRM INV</td>
        <td>30-09-21</td>
        <td>2881810</td>
        <td>ERS-4000027228-1850402-TDS-CM-816553</td>
        <td>06-10-21</td>
        <td>2750</td>
        <td>0</td>
        <td>ERS-4000027228-1850402-TDS-CM-816553</td>
        <td>0.00</td>
        <td>PO-0000157982-Invoice</td>
        <td>ERS-4000027228-1850402-TDS-CM-816553</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td></td>
        <td>2</td>
        <td>CREDIT MEMO VALIDATED</td>
        <td>UNMATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>06-10-21</td>
        <td>3836747</td>
        <td>ERS-4000027226-1850401-RTN-TDS-SI-816594</td>
        <td>06-10-21</td>
        <td>0</td>
        <td>1925</td>
        <td>ERS-4000027226-1850401-RTN-TDS-SI-816594</td>
        <td>0.00</td>
        <td>PO-0000157954-Invoice</td>
        <td>ERS-4000027226-1850401-RTN-TDS-SI-816594</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>UNMATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>30-09-21</td>
        <td>3832421</td>
        <td>ERS-4000027226-1850401</td>
        <td>06-10-21</td>
        <td>0</td>
        <td>3244976.4</td>
        <td>ERS-4000027226-1850401</td>
        <td>0.00</td>
        <td>PO-0000157954-Invoice</td>
        <td>Receipt Invoice automatically created on 30-SEP-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>30-09-21</td>
        <td>3832422</td>
        <td>ERS-4000027228-1850402</td>
        <td>06-10-21</td>
        <td>1924986</td>
        <td>0</td>
        <td>ERS-4000027228-1850402</td>
        <td>0.00</td>
        <td>PO-0000157982-Invoice</td>
        <td>Receipt Invoice automatically created on 30-SEP-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>30-09-21</td>
        <td>3832421</td>
        <td>ERS-4000027226-1850401</td>
        <td>06-10-21</td>
        <td>1924986</td>
        <td>0</td>
        <td>ERS-4000027226-1850401</td>
        <td>0.00</td>
        <td>PO-0000157954-Invoice</td>
        <td>Receipt Invoice automatically created on 30-SEP-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>30-09-21</td>
        <td>3832423</td>
        <td>ERS-4000027229-1850403</td>
        <td>06-10-21</td>
        <td>0</td>
        <td>2443126.69</td>
        <td>ERS-4000027229-1850403</td>
        <td>0.00</td>
        <td>PO-0000157983-Invoice</td>
        <td>Receipt Invoice automatically created on 30-SEP-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>06-10-21</td>
        <td>3836701</td>
        <td>ERS-4000027228-1850402-RTN-TDS-SI-816554</td>
        <td>06-10-21</td>
        <td>0</td>
        <td>1925</td>
        <td>ERS-4000027228-1850402-RTN-TDS-SI-816554</td>
        <td>0.00</td>
        <td>PO-0000157982-Invoice</td>
        <td>ERS-4000027228-1850402-RTN-TDS-SI-816554</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>UNMATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>45030</td>
        <td>Advances to Suppliers - Goods</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>30-09-21</td>
        <td>3832422</td>
        <td>ERS-4000027228-1850402</td>
        <td>06-10-21</td>
        <td>0</td>
        <td>1924986</td>
        <td>ERS-4000027228-1850402</td>
        <td>0.00</td>
        <td>PO-0000157982-Invoice</td>
        <td>Receipt Invoice automatically created on 30-SEP-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CRM INV</td>
        <td>30-09-21</td>
        <td>2881856</td>
        <td>ERS-4000027226-1850401-TDS-CM-816593</td>
        <td>06-10-21</td>
        <td>2750</td>
        <td>0</td>
        <td>ERS-4000027226-1850401-TDS-CM-816593</td>
        <td>0.00</td>
        <td>PO-0000157954-Invoice</td>
        <td>ERS-4000027226-1850401-TDS-CM-816593</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td></td>
        <td>2</td>
        <td>CREDIT MEMO VALIDATED</td>
        <td>UNMATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>45030</td>
        <td>Advances to Suppliers - Goods</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>30-09-21</td>
        <td>3831243</td>
        <td>ERS-4000027207-1849516</td>
        <td>08-10-21</td>
        <td>0</td>
        <td>178827</td>
        <td>ERS-4000027207-1849516</td>
        <td>0.00</td>
        <td>PO-0000157957-Invoice</td>
        <td>Receipt Invoice automatically created on 30-SEP-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>30-09-21</td>
        <td>3831243</td>
        <td>ERS-4000027207-1849516</td>
        <td>08-10-21</td>
        <td>178827</td>
        <td>0</td>
        <td>ERS-4000027207-1849516</td>
        <td>0.00</td>
        <td>PO-0000157957-Invoice</td>
        <td>Receipt Invoice automatically created on 30-SEP-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>45030</td>
        <td>Advances to Suppliers - Goods</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>30-09-21</td>
        <td>3832423</td>
        <td>ERS-4000027229-1850403</td>
        <td>08-10-21</td>
        <td>0</td>
        <td>1449312</td>
        <td>ERS-4000027229-1850403</td>
        <td>0.00</td>
        <td>PO-0000157983-Invoice</td>
        <td>Receipt Invoice automatically created on 30-SEP-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>30-09-21</td>
        <td>3832423</td>
        <td>ERS-4000027229-1850403</td>
        <td>08-10-21</td>
        <td>1449312</td>
        <td>0</td>
        <td>ERS-4000027229-1850403</td>
        <td>0.00</td>
        <td>PO-0000157983-Invoice</td>
        <td>Receipt Invoice automatically created on 30-SEP-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>12-10-21</td>
        <td>51220142</td>
        <td>511020247</td>
        <td>12-10-21</td>
        <td>3727062.27</td>
        <td>1680</td>
        <td>ERS-4000026874-1836793</td>
        <td>1215289.25</td>
        <td>PO-0000145025-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3708226</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>12-10-21</td>
        <td>51220142</td>
        <td>511020247</td>
        <td>12-10-21</td>
        <td>3727062.27</td>
        <td>1680</td>
        <td>ERS-4000026870-1836035</td>
        <td>830225.49</td>
        <td>PO-0000145004-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3708226</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>12-10-21</td>
        <td>51220142</td>
        <td>511020247</td>
        <td>12-10-21</td>
        <td>3727062.27</td>
        <td>1680</td>
        <td>ERS-4000026866-1836033-TDS-CM-805281</td>
        <td>0.00</td>
        <td>PO-0000144918-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td>3708226</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>12-10-21</td>
        <td>51220142</td>
        <td>511020247</td>
        <td>12-10-21</td>
        <td>3727062.27</td>
        <td>1680</td>
        <td>ERS-4000026869-1836034</td>
        <td>874961.78</td>
        <td>PO-0000144995-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3708226</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>12-10-21</td>
        <td>51220142</td>
        <td>511020247</td>
        <td>12-10-21</td>
        <td>3727062.27</td>
        <td>1680</td>
        <td>ERS-4000026866-1836033</td>
        <td>806585.75</td>
        <td>PO-0000144918-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3708226</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>27-09-21</td>
        <td>3827413</td>
        <td>ERS-4000027141-1847382</td>
        <td>25-10-21</td>
        <td>0</td>
        <td>404139.5</td>
        <td>ERS-4000027141-1847382</td>
        <td>0.00</td>
        <td>PO-0000163528-Invoice</td>
        <td>Receipt Invoice automatically created on 27-SEP-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>23-09-21</td>
        <td>3825441</td>
        <td>ERS-4000027116-1846033</td>
        <td>25-10-21</td>
        <td>0</td>
        <td>555210.12</td>
        <td>ERS-4000027116-1846033</td>
        <td>0.00</td>
        <td>PO-0000163531-Invoice</td>
        <td>Receipt Invoice automatically created on 23-SEP-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>45030</td>
        <td>Advances to Suppliers - Goods</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>27-09-21</td>
        <td>3827413</td>
        <td>ERS-4000027141-1847382</td>
        <td>26-10-21</td>
        <td>0</td>
        <td>239744.98</td>
        <td>ERS-4000027141-1847382</td>
        <td>0.00</td>
        <td>PO-0000163528-Invoice</td>
        <td>Receipt Invoice automatically created on 27-SEP-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>45030</td>
        <td>Advances to Suppliers - Goods</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>23-09-21</td>
        <td>3825441</td>
        <td>ERS-4000027116-1846033</td>
        <td>26-10-21</td>
        <td>0</td>
        <td>329362</td>
        <td>ERS-4000027116-1846033</td>
        <td>0.00</td>
        <td>PO-0000163531-Invoice</td>
        <td>Receipt Invoice automatically created on 23-SEP-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>27-09-21</td>
        <td>3827413</td>
        <td>ERS-4000027141-1847382</td>
        <td>26-10-21</td>
        <td>239744.98</td>
        <td>0</td>
        <td>ERS-4000027141-1847382</td>
        <td>0.00</td>
        <td>PO-0000163528-Invoice</td>
        <td>Receipt Invoice automatically created on 27-SEP-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>23-09-21</td>
        <td>3825441</td>
        <td>ERS-4000027116-1846033</td>
        <td>26-10-21</td>
        <td>329362</td>
        <td>0</td>
        <td>ERS-4000027116-1846033</td>
        <td>0.00</td>
        <td>PO-0000163531-Invoice</td>
        <td>Receipt Invoice automatically created on 23-SEP-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>27-10-21</td>
        <td>51221607</td>
        <td>511021653</td>
        <td>27-10-21</td>
        <td>1369610.82</td>
        <td>0</td>
        <td>ERS-4000027011-1842002</td>
        <td>674467.74</td>
        <td>PO-0000153877-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3713499</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>27-10-21</td>
        <td>51221607</td>
        <td>511021653</td>
        <td>27-10-21</td>
        <td>1369610.82</td>
        <td>0</td>
        <td>ERS-4000027009-1842000</td>
        <td>695143.08</td>
        <td>PO-0000153873-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3713499</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>29-10-21</td>
        <td>51221824</td>
        <td>511021874</td>
        <td>29-10-21</td>
        <td>237104.04</td>
        <td>0</td>
        <td>ERS-4000027010-1842001</td>
        <td>237104.04</td>
        <td>PO-0000153874-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3714437</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>30-10-21</td>
        <td>51221948</td>
        <td>511022016</td>
        <td>30-10-21</td>
        <td>551527.42</td>
        <td>0</td>
        <td>ERS-4000027042-1843473</td>
        <td>367667.81</td>
        <td>PO-0000156013-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3715192</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI EPAY</td>
        <td>30-10-21</td>
        <td>545108</td>
        <td>95107772</td>
        <td>30-10-21</td>
        <td>225848.12</td>
        <td>0</td>
        <td>ERS-4000027116-1846033</td>
        <td>225848.12</td>
        <td>PO-0000163531-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3714724</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>30-10-21</td>
        <td>51221948</td>
        <td>511022016</td>
        <td>30-10-21</td>
        <td>551527.42</td>
        <td>0</td>
        <td>ERS-4000027043-1843474</td>
        <td>183859.61</td>
        <td>PO-0000156017-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3715192</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>45030</td>
        <td>Advances to Suppliers - Goods</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>28-10-21</td>
        <td>3853247</td>
        <td>ERS-5000013928-1860518</td>
        <td>31-10-21</td>
        <td>0</td>
        <td>4309.5</td>
        <td>ERS-5000013928-1860518</td>
        <td>0.00</td>
        <td>PO-0000169935-Invoice</td>
        <td>Receipt Invoice automatically created on 28-OCT-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CRM INV</td>
        <td>28-10-21</td>
        <td>2890770</td>
        <td>ERS-5000013928-1860518-TDS-CM-824952</td>
        <td>31-10-21</td>
        <td>9</td>
        <td>0</td>
        <td>ERS-5000013928-1860518-TDS-CM-824952</td>
        <td>0.00</td>
        <td>PO-0000169935-Invoice</td>
        <td>ERS-5000013928-1860518-TDS-CM-824952</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td></td>
        <td>2</td>
        <td>CREDIT MEMO VALIDATED</td>
        <td>UNMATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>28-10-21</td>
        <td>3853247</td>
        <td>ERS-5000013928-1860518</td>
        <td>31-10-21</td>
        <td>0</td>
        <td>10170.42</td>
        <td>ERS-5000013928-1860518</td>
        <td>0.00</td>
        <td>PO-0000169935-Invoice</td>
        <td>Receipt Invoice automatically created on 28-OCT-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>28-10-21</td>
        <td>3853247</td>
        <td>ERS-5000013928-1860518</td>
        <td>31-10-21</td>
        <td>4309.5</td>
        <td>0</td>
        <td>ERS-5000013928-1860518</td>
        <td>0.00</td>
        <td>PO-0000169935-Invoice</td>
        <td>Receipt Invoice automatically created on 28-OCT-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CRM INV</td>
        <td>27-09-21</td>
        <td>2898223</td>
        <td>ERS-4000027141-1847382-TDS-CM-831908</td>
        <td>01-11-21</td>
        <td>342</td>
        <td>0</td>
        <td>ERS-4000027141-1847382-TDS-CM-831908</td>
        <td>0.00</td>
        <td></td>
        <td>ERS-4000027141-1847382-TDS-CM-831908</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td></td>
        <td>2</td>
        <td>CREDIT MEMO VALIDATED</td>
        <td>UNMATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>09-11-21</td>
        <td>51222855</td>
        <td>511022909</td>
        <td>09-11-21</td>
        <td>659918.34</td>
        <td>0</td>
        <td>ERS-4000027142-1847383</td>
        <td>659918.34</td>
        <td>PO-0000157094-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3718008</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>12-11-21</td>
        <td>51223416</td>
        <td>511023493</td>
        <td>12-11-21</td>
        <td>3760270.08</td>
        <td>5500</td>
        <td>ERS-4000027226-1850401</td>
        <td>1319990.40</td>
        <td>PO-0000157954-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3719135</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>12-11-21</td>
        <td>51223416</td>
        <td>511023493</td>
        <td>12-11-21</td>
        <td>3760270.08</td>
        <td>5500</td>
        <td>ERS-4000027228-1850402</td>
        <td>1319990.40</td>
        <td>PO-0000157982-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3719135</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>12-11-21</td>
        <td>51223416</td>
        <td>511023493</td>
        <td>12-11-21</td>
        <td>3760270.08</td>
        <td>5500</td>
        <td>ERS-4000027229-1850403</td>
        <td>993814.69</td>
        <td>PO-0000157983-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3719135</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>12-11-21</td>
        <td>51223416</td>
        <td>511023493</td>
        <td>12-11-21</td>
        <td>3760270.08</td>
        <td>5500</td>
        <td>ERS-4000027207-1849516</td>
        <td>122624.59</td>
        <td>PO-0000157957-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3719135</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>12-11-21</td>
        <td>51223416</td>
        <td>511023493</td>
        <td>12-11-21</td>
        <td>3760270.08</td>
        <td>5500</td>
        <td>ERS-4000027226-1850401-RTN-TDS-SI-816594</td>
        <td>1925.00</td>
        <td>PO-0000157954-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>STANDARD</td>
        <td>3719135</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>12-11-21</td>
        <td>51223416</td>
        <td>511023493</td>
        <td>12-11-21</td>
        <td>3760270.08</td>
        <td>5500</td>
        <td>ERS-4000027228-1850402-RTN-TDS-SI-816554</td>
        <td>1925.00</td>
        <td>PO-0000157982-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>STANDARD</td>
        <td>3719135</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>12-11-21</td>
        <td>51223416</td>
        <td>511023493</td>
        <td>12-11-21</td>
        <td>3760270.08</td>
        <td>5500</td>
        <td>ERS-4000027226-1850401-TDS-CM-816593</td>
        <td>0.00</td>
        <td>PO-0000157954-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td>3719135</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>12-11-21</td>
        <td>51223416</td>
        <td>511023493</td>
        <td>12-11-21</td>
        <td>3760270.08</td>
        <td>5500</td>
        <td>ERS-4000027228-1850402-TDS-CM-816553</td>
        <td>0.00</td>
        <td>PO-0000157982-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td>3719135</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>45030</td>
        <td>Advances to Suppliers - Goods</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CGN PV Adv</td>
        <td>15-11-21</td>
        <td>578879</td>
        <td>Po No 1000068515 C173</td>
        <td>15-11-21</td>
        <td>9277504</td>
        <td>0</td>
        <td>Po No 1000068515 C173</td>
        <td>0.00</td>
        <td></td>
        <td>70% ADV AGAINST RAW MATERIAL INSPEC DDC173</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>Manual Invoice Entry</td>
        <td>PREPAYMENT</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT VALIDATED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CGN PV Adv</td>
        <td>15-11-21</td>
        <td>578879</td>
        <td>Po No 1000068515 C173</td>
        <td>15-11-21</td>
        <td>0</td>
        <td>9277504</td>
        <td>Po No 1000068515 C173</td>
        <td>0.00</td>
        <td></td>
        <td>70% ADV AGAINST RAW MATERIAL INSPEC DDC173</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>Manual Invoice Entry</td>
        <td>PREPAYMENT</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT VALIDATED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI UTILITY EPAY</td>
        <td>15-11-21</td>
        <td>51304441</td>
        <td>851001429</td>
        <td>15-11-21</td>
        <td>9277504</td>
        <td>9278</td>
        <td>Po No 1000068515 C173</td>
        <td>9277504.00</td>
        <td></td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>Manual Invoice Entry</td>
        <td>PREPAYMENT</td>
        <td>3720179</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI UTILITY EPAY</td>
        <td>15-11-21</td>
        <td>51304441</td>
        <td>851001429</td>
        <td>15-11-21</td>
        <td>9277504</td>
        <td>9278</td>
        <td>Po No 1000068515 C173-TDS-CM-827951</td>
        <td>0.00</td>
        <td></td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td>3720179</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CRM INV</td>
        <td>15-11-21</td>
        <td>2894015</td>
        <td>Po No 1000068515 C173-TDS-CM-827951</td>
        <td>15-11-21</td>
        <td>9278</td>
        <td>0</td>
        <td>Po No 1000068515 C173-TDS-CM-827951</td>
        <td>0.00</td>
        <td></td>
        <td>Po No 1000068515 C173-TDS-CM-827951</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td></td>
        <td>2</td>
        <td>CREDIT MEMO VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI UTILITY EPAY</td>
        <td>23-11-21</td>
        <td>51304460</td>
        <td>851001448</td>
        <td>23-11-21</td>
        <td>4947306</td>
        <td>4947</td>
        <td>1000068515 C173 A-TDS-CM-829183</td>
        <td>0.00</td>
        <td></td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td>3721833</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CRM INV</td>
        <td>23-11-21</td>
        <td>2895320</td>
        <td>1000068515 C173 A-TDS-CM-829183</td>
        <td>23-11-21</td>
        <td>4947</td>
        <td>0</td>
        <td>1000068515 C173 A-TDS-CM-829183</td>
        <td>0.00</td>
        <td></td>
        <td>1000068515 C173 A-TDS-CM-829183</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td></td>
        <td>2</td>
        <td>CREDIT MEMO VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI UTILITY EPAY</td>
        <td>23-11-21</td>
        <td>51304460</td>
        <td>851001448</td>
        <td>23-11-21</td>
        <td>4947306</td>
        <td>4947</td>
        <td>1000068515 C173 A</td>
        <td>4947306.00</td>
        <td></td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>Manual Invoice Entry</td>
        <td>PREPAYMENT</td>
        <td>3721833</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>45030</td>
        <td>Advances to Suppliers - Goods</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CGN PV Adv</td>
        <td>23-11-21</td>
        <td>578886</td>
        <td>1000068515 C173 A</td>
        <td>23-11-21</td>
        <td>4947306</td>
        <td>0</td>
        <td>1000068515 C173 A</td>
        <td>0.00</td>
        <td></td>
        <td>70% ADVANCE ON BASIC AMOUNT</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>Manual Invoice Entry</td>
        <td>PREPAYMENT</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT VALIDATED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CGN PV Adv</td>
        <td>23-11-21</td>
        <td>578886</td>
        <td>1000068515 C173 A</td>
        <td>23-11-21</td>
        <td>0</td>
        <td>4947306</td>
        <td>1000068515 C173 A</td>
        <td>0.00</td>
        <td></td>
        <td>70% ADVANCE ON BASIC AMOUNT</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>Manual Invoice Entry</td>
        <td>PREPAYMENT</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT VALIDATED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>21-10-21</td>
        <td>3847352</td>
        <td>ERS-4000027398-1857133</td>
        <td>25-11-21</td>
        <td>1924986</td>
        <td>0</td>
        <td>ERS-4000027398-1857133</td>
        <td>0.00</td>
        <td>PO-0000174403-Invoice</td>
        <td>Receipt Invoice automatically created on 21-OCT-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CRM INV</td>
        <td>21-10-21</td>
        <td>2895972</td>
        <td>ERS-4000027398-1857133-TDS-CM-829803</td>
        <td>25-11-21</td>
        <td>2750</td>
        <td>0</td>
        <td>ERS-4000027398-1857133-TDS-CM-829803</td>
        <td>0.00</td>
        <td>PO-0000174403-Invoice</td>
        <td>ERS-4000027398-1857133-TDS-CM-829803</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td></td>
        <td>2</td>
        <td>CREDIT MEMO VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>25-11-21</td>
        <td>3868521</td>
        <td>ERS-4000027398-1857133-RTN-TDS-SI-829804</td>
        <td>25-11-21</td>
        <td>0</td>
        <td>1925</td>
        <td>ERS-4000027398-1857133-RTN-TDS-SI-829804</td>
        <td>0.00</td>
        <td></td>
        <td>ERS-4000027398-1857133-RTN-TDS-SI-829804</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>45030</td>
        <td>Advances to Suppliers - Goods</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>21-10-21</td>
        <td>3847352</td>
        <td>ERS-4000027398-1857133</td>
        <td>25-11-21</td>
        <td>0</td>
        <td>1924986</td>
        <td>ERS-4000027398-1857133</td>
        <td>0.00</td>
        <td>PO-0000174403-Invoice</td>
        <td>Receipt Invoice automatically created on 21-OCT-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>21-10-21</td>
        <td>3847352</td>
        <td>ERS-4000027398-1857133</td>
        <td>25-11-21</td>
        <td>0</td>
        <td>3244976.4</td>
        <td>ERS-4000027398-1857133</td>
        <td>0.00</td>
        <td>PO-0000174403-Invoice</td>
        <td>Receipt Invoice automatically created on 21-OCT-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>03-12-21</td>
        <td>51225229</td>
        <td>511025265</td>
        <td>03-12-21</td>
        <td>1321915.4</td>
        <td>2750</td>
        <td>ERS-4000027398-1857133</td>
        <td>1319990.40</td>
        <td>PO-0000174403-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3727185</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>03-12-21</td>
        <td>51225229</td>
        <td>511025265</td>
        <td>03-12-21</td>
        <td>1321915.4</td>
        <td>2750</td>
        <td>ERS-4000027398-1857133-TDS-CM-829803</td>
        <td>0.00</td>
        <td>PO-0000174403-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td>3727185</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>03-12-21</td>
        <td>51225229</td>
        <td>511025265</td>
        <td>03-12-21</td>
        <td>1321915.4</td>
        <td>2750</td>
        <td>ERS-4000027398-1857133-RTN-TDS-SI-829804</td>
        <td>1925.00</td>
        <td></td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>STANDARD</td>
        <td>3727185</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>11-12-21</td>
        <td>51226239</td>
        <td>511026274</td>
        <td>11-12-21</td>
        <td>5860.92</td>
        <td>351</td>
        <td>ERS-5000013928-1860518-TDS-CM-824952</td>
        <td>0.00</td>
        <td>PO-0000169935-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td>3731015</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>11-12-21</td>
        <td>51226239</td>
        <td>511026274</td>
        <td>11-12-21</td>
        <td>5860.92</td>
        <td>351</td>
        <td>ERS-5000013928-1860518</td>
        <td>1551.42</td>
        <td>PO-0000169935-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3731015</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>11-12-21</td>
        <td>51226239</td>
        <td>511026274</td>
        <td>11-12-21</td>
        <td>5860.92</td>
        <td>351</td>
        <td>ERS-4000027141-1847382-TDS-CM-831908</td>
        <td>0.00</td>
        <td></td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td>3731015</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>11-12-21</td>
        <td>51226239</td>
        <td>511026274</td>
        <td>11-12-21</td>
        <td>5860.92</td>
        <td>351</td>
        <td>ERS-5000013928-1860518</td>
        <td>4309.50</td>
        <td>PO-0000169935-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3731015</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>31-08-21</td>
        <td>3809330</td>
        <td>ERS-5000013482-1837462</td>
        <td>23-12-21</td>
        <td>0</td>
        <td>95502.71</td>
        <td>ERS-5000013482-1837462</td>
        <td>0.00</td>
        <td>PO-0000145178-Invoice</td>
        <td>Receipt Invoice automatically created on 31-AUG-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>28-12-21</td>
        <td>51227630</td>
        <td>511027666</td>
        <td>28-12-21</td>
        <td>80934.5</td>
        <td>0</td>
        <td>ERS-5000013482-1837462</td>
        <td>80934.50</td>
        <td>PO-0000145178-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3736702</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>29-12-21</td>
        <td>51227749</td>
        <td>511027823</td>
        <td>29-12-21</td>
        <td>164394.52</td>
        <td>0</td>
        <td>ERS-4000027141-1847382</td>
        <td>164394.52</td>
        <td>PO-0000163528-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3736981</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>30-11-21</td>
        <td>3873100</td>
        <td>ERS-4000027672-1872381</td>
        <td>31-12-21</td>
        <td>65230.2</td>
        <td>0</td>
        <td>ERS-4000027672-1872381</td>
        <td>0.00</td>
        <td>PO-0000194297-Invoice</td>
        <td>Receipt Invoice automatically created on 30-NOV-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CRM INV</td>
        <td>31-10-21</td>
        <td>2909857</td>
        <td>ERS-4000027487-1862443-TDS-CM-842898</td>
        <td>31-12-21</td>
        <td>1375</td>
        <td>0</td>
        <td>ERS-4000027487-1862443-TDS-CM-842898</td>
        <td>0.00</td>
        <td>PO-0000194296-Invoice</td>
        <td>ERS-4000027487-1862443-TDS-CM-842898</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td></td>
        <td>2</td>
        <td>CREDIT MEMO VALIDATED</td>
        <td>UNMATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>30-11-21</td>
        <td>3873102</td>
        <td>ERS-4000027675-1872383</td>
        <td>31-12-21</td>
        <td>65230.2</td>
        <td>0</td>
        <td>ERS-4000027675-1872383</td>
        <td>0.00</td>
        <td>PO-0000194285-Invoice</td>
        <td>Receipt Invoice automatically created on 30-NOV-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>30-11-21</td>
        <td>3873102</td>
        <td>ERS-4000027675-1872383</td>
        <td>31-12-21</td>
        <td>0</td>
        <td>109959.48</td>
        <td>ERS-4000027675-1872383</td>
        <td>0.00</td>
        <td>PO-0000194285-Invoice</td>
        <td>Receipt Invoice automatically created on 30-NOV-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>31-12-21</td>
        <td>3902779</td>
        <td>ERS-4000027487-1862443-RTN-TDS-SI-842899</td>
        <td>31-12-21</td>
        <td>0</td>
        <td>963</td>
        <td>ERS-4000027487-1862443-RTN-TDS-SI-842899</td>
        <td>0.00</td>
        <td>PO-0000194296-Invoice</td>
        <td>ERS-4000027487-1862443-RTN-TDS-SI-842899</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>UNMATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>31-10-21</td>
        <td>3857040</td>
        <td>ERS-4000027487-1862443</td>
        <td>31-12-21</td>
        <td>962493</td>
        <td>0</td>
        <td>ERS-4000027487-1862443</td>
        <td>0.00</td>
        <td>PO-0000194296-Invoice</td>
        <td>Receipt Invoice automatically created on 31-OCT-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>28-10-21</td>
        <td>3853246</td>
        <td>ERS-4000027439-1860517</td>
        <td>31-12-21</td>
        <td>0</td>
        <td>2433732.3</td>
        <td>ERS-4000027439-1860517</td>
        <td>0.00</td>
        <td>PO-0000194286-Invoice</td>
        <td>Receipt Invoice automatically created on 28-OCT-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CRM INV</td>
        <td>31-10-21</td>
        <td>2914202</td>
        <td>ERS-4000027486-1862442-TDS-CM-846977</td>
        <td>31-12-21</td>
        <td>1375</td>
        <td>0</td>
        <td>ERS-4000027486-1862442-TDS-CM-846977</td>
        <td>0.00</td>
        <td>PO-0000194293-Invoice</td>
        <td>ERS-4000027486-1862442-TDS-CM-846977</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td></td>
        <td>2</td>
        <td>CREDIT MEMO VALIDATED</td>
        <td>UNMATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>31-10-21</td>
        <td>3857040</td>
        <td>ERS-4000027487-1862443</td>
        <td>31-12-21</td>
        <td>0</td>
        <td>1622488.2</td>
        <td>ERS-4000027487-1862443</td>
        <td>0.00</td>
        <td>PO-0000194296-Invoice</td>
        <td>Receipt Invoice automatically created on 31-OCT-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CRM INV</td>
        <td>28-10-21</td>
        <td>2911259</td>
        <td>ERS-4000027439-1860517-TDS-CM-844262</td>
        <td>31-12-21</td>
        <td>2062</td>
        <td>0</td>
        <td>ERS-4000027439-1860517-TDS-CM-844262</td>
        <td>0.00</td>
        <td>PO-0000194286-Invoice</td>
        <td>ERS-4000027439-1860517-TDS-CM-844262</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td></td>
        <td>2</td>
        <td>CREDIT MEMO VALIDATED</td>
        <td>UNMATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>30-11-21</td>
        <td>3873101</td>
        <td>ERS-4000027673-1872382</td>
        <td>31-12-21</td>
        <td>0</td>
        <td>109959.48</td>
        <td>ERS-4000027673-1872382</td>
        <td>0.00</td>
        <td>PO-0000194294-Invoice</td>
        <td>Receipt Invoice automatically created on 30-NOV-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>31-12-21</td>
        <td>3904219</td>
        <td>ERS-4000027439-1860517-RTN-TDS-SI-844263</td>
        <td>31-12-21</td>
        <td>0</td>
        <td>1443</td>
        <td>ERS-4000027439-1860517-RTN-TDS-SI-844263</td>
        <td>0.00</td>
        <td>PO-0000194286-Invoice</td>
        <td>ERS-4000027439-1860517-RTN-TDS-SI-844263</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>UNMATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CRM INV</td>
        <td>30-11-21</td>
        <td>2914191</td>
        <td>ERS-4000027673-1872382-TDS-CM-846971</td>
        <td>31-12-21</td>
        <td>93</td>
        <td>0</td>
        <td>ERS-4000027673-1872382-TDS-CM-846971</td>
        <td>0.00</td>
        <td>PO-0000194294-Invoice</td>
        <td>ERS-4000027673-1872382-TDS-CM-846971</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td></td>
        <td>2</td>
        <td>CREDIT MEMO VALIDATED</td>
        <td>UNMATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CRM INV</td>
        <td>30-11-21</td>
        <td>2911820</td>
        <td>ERS-4000027675-1872383-TDS-CM-844793</td>
        <td>31-12-21</td>
        <td>93</td>
        <td>0</td>
        <td>ERS-4000027675-1872383-TDS-CM-844793</td>
        <td>0.00</td>
        <td>PO-0000194285-Invoice</td>
        <td>ERS-4000027675-1872383-TDS-CM-844793</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td></td>
        <td>2</td>
        <td>CREDIT MEMO VALIDATED</td>
        <td>UNMATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>45030</td>
        <td>Advances to Suppliers - Goods</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>31-10-21</td>
        <td>3857041</td>
        <td>ERS-4000027488-1862444</td>
        <td>31-12-21</td>
        <td>0</td>
        <td>481246.5</td>
        <td>ERS-4000027488-1862444</td>
        <td>0.00</td>
        <td>PO-0000194295-Invoice</td>
        <td>Receipt Invoice automatically created on 31-OCT-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>45030</td>
        <td>Advances to Suppliers - Goods</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>30-11-21</td>
        <td>3873100</td>
        <td>ERS-4000027672-1872381</td>
        <td>31-12-21</td>
        <td>0</td>
        <td>65230.2</td>
        <td>ERS-4000027672-1872381</td>
        <td>0.00</td>
        <td>PO-0000194297-Invoice</td>
        <td>Receipt Invoice automatically created on 30-NOV-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>31-10-21</td>
        <td>3857041</td>
        <td>ERS-4000027488-1862444</td>
        <td>31-12-21</td>
        <td>481246.5</td>
        <td>0</td>
        <td>ERS-4000027488-1862444</td>
        <td>0.00</td>
        <td>PO-0000194295-Invoice</td>
        <td>Receipt Invoice automatically created on 31-OCT-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>28-10-21</td>
        <td>3853246</td>
        <td>ERS-4000027439-1860517</td>
        <td>31-12-21</td>
        <td>1443740</td>
        <td>0</td>
        <td>ERS-4000027439-1860517</td>
        <td>0.00</td>
        <td>PO-0000194286-Invoice</td>
        <td>Receipt Invoice automatically created on 28-OCT-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>45030</td>
        <td>Advances to Suppliers - Goods</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>30-11-21</td>
        <td>3873102</td>
        <td>ERS-4000027675-1872383</td>
        <td>31-12-21</td>
        <td>0</td>
        <td>65230.2</td>
        <td>ERS-4000027675-1872383</td>
        <td>0.00</td>
        <td>PO-0000194285-Invoice</td>
        <td>Receipt Invoice automatically created on 30-NOV-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>45030</td>
        <td>Advances to Suppliers - Goods</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>31-10-21</td>
        <td>3857040</td>
        <td>ERS-4000027487-1862443</td>
        <td>31-12-21</td>
        <td>0</td>
        <td>962493</td>
        <td>ERS-4000027487-1862443</td>
        <td>0.00</td>
        <td>PO-0000194296-Invoice</td>
        <td>Receipt Invoice automatically created on 31-OCT-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>45030</td>
        <td>Advances to Suppliers - Goods</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>28-10-21</td>
        <td>3853246</td>
        <td>ERS-4000027439-1860517</td>
        <td>31-12-21</td>
        <td>0</td>
        <td>1443740</td>
        <td>ERS-4000027439-1860517</td>
        <td>0.00</td>
        <td>PO-0000194286-Invoice</td>
        <td>Receipt Invoice automatically created on 28-OCT-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>31-12-21</td>
        <td>3905486</td>
        <td>ERS-4000027488-1862444-RTN-TDS-SI-845285</td>
        <td>31-12-21</td>
        <td>0</td>
        <td>481</td>
        <td>ERS-4000027488-1862444-RTN-TDS-SI-845285</td>
        <td>0.00</td>
        <td></td>
        <td>ERS-4000027488-1862444-RTN-TDS-SI-845285</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>UNMATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>31-12-21</td>
        <td>3907405</td>
        <td>ERS-4000027486-1862442-RTN-TDS-SI-846978</td>
        <td>31-12-21</td>
        <td>0</td>
        <td>567</td>
        <td>ERS-4000027486-1862442-RTN-TDS-SI-846978</td>
        <td>0.00</td>
        <td></td>
        <td>ERS-4000027486-1862442-RTN-TDS-SI-846978</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>UNMATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CRM INV</td>
        <td>30-11-21</td>
        <td>2907968</td>
        <td>ERS-4000027672-1872381-TDS-CM-841110</td>
        <td>31-12-21</td>
        <td>93</td>
        <td>0</td>
        <td>ERS-4000027672-1872381-TDS-CM-841110</td>
        <td>0.00</td>
        <td>PO-0000194297-Invoice</td>
        <td>ERS-4000027672-1872381-TDS-CM-841110</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td></td>
        <td>2</td>
        <td>CREDIT MEMO VALIDATED</td>
        <td>UNMATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>31-10-21</td>
        <td>3857041</td>
        <td>ERS-4000027488-1862444</td>
        <td>31-12-21</td>
        <td>0</td>
        <td>811244.1</td>
        <td>ERS-4000027488-1862444</td>
        <td>0.00</td>
        <td>PO-0000194295-Invoice</td>
        <td>Receipt Invoice automatically created on 31-OCT-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>31-10-21</td>
        <td>3857039</td>
        <td>ERS-4000027486-1862442</td>
        <td>31-12-21</td>
        <td>0</td>
        <td>1622488.2</td>
        <td>ERS-4000027486-1862442</td>
        <td>0.00</td>
        <td>PO-0000194293-Invoice</td>
        <td>Receipt Invoice automatically created on 31-OCT-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>30-11-21</td>
        <td>3873100</td>
        <td>ERS-4000027672-1872381</td>
        <td>31-12-21</td>
        <td>0</td>
        <td>109959.48</td>
        <td>ERS-4000027672-1872381</td>
        <td>0.00</td>
        <td>PO-0000194297-Invoice</td>
        <td>Receipt Invoice automatically created on 30-NOV-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CRM INV</td>
        <td>31-10-21</td>
        <td>2912330</td>
        <td>ERS-4000027488-1862444-TDS-CM-845282</td>
        <td>31-12-21</td>
        <td>687</td>
        <td>0</td>
        <td>ERS-4000027488-1862444-TDS-CM-845282</td>
        <td>0.00</td>
        <td>PO-0000194295-Invoice</td>
        <td>ERS-4000027488-1862444-TDS-CM-845282</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td></td>
        <td>2</td>
        <td>CREDIT MEMO VALIDATED</td>
        <td>UNMATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>31-10-21</td>
        <td>3857039</td>
        <td>ERS-4000027486-1862442</td>
        <td>01-01-22</td>
        <td>566778</td>
        <td>0</td>
        <td>ERS-4000027486-1862442</td>
        <td>0.00</td>
        <td>PO-0000194293-Invoice</td>
        <td>Receipt Invoice automatically created on 31-OCT-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>45030</td>
        <td>Advances to Suppliers - Goods</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>31-10-21</td>
        <td>3857039</td>
        <td>ERS-4000027486-1862442</td>
        <td>01-01-22</td>
        <td>0</td>
        <td>566778</td>
        <td>ERS-4000027486-1862442</td>
        <td>0.00</td>
        <td>PO-0000194293-Invoice</td>
        <td>Receipt Invoice automatically created on 31-OCT-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>04-01-22</td>
        <td>51228052</td>
        <td>511028125</td>
        <td>04-01-22</td>
        <td>14568.21</td>
        <td>0</td>
        <td>ERS-5000013482-1837462</td>
        <td>14568.21</td>
        <td>PO-0000145178-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3738617</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>08-01-22</td>
        <td>51228624</td>
        <td>511028722</td>
        <td>08-01-22</td>
        <td>2643830.3</td>
        <td>5499</td>
        <td>ERS-4000027439-1860517-TDS-CM-844262</td>
        <td>0.00</td>
        <td>PO-0000194286-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td>3740630</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>08-01-22</td>
        <td>51228624</td>
        <td>511028722</td>
        <td>08-01-22</td>
        <td>2643830.3</td>
        <td>5499</td>
        <td>ERS-4000027486-1862442-TDS-CM-846977</td>
        <td>0.00</td>
        <td>PO-0000194293-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td>3740630</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>08-01-22</td>
        <td>51228624</td>
        <td>511028722</td>
        <td>08-01-22</td>
        <td>2643830.3</td>
        <td>5499</td>
        <td>ERS-4000027439-1860517</td>
        <td>989992.30</td>
        <td>PO-0000194286-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3740630</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>08-01-22</td>
        <td>51228624</td>
        <td>511028722</td>
        <td>08-01-22</td>
        <td>2643830.3</td>
        <td>5499</td>
        <td>ERS-4000027488-1862444</td>
        <td>329997.60</td>
        <td>PO-0000194295-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3740630</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>08-01-22</td>
        <td>51228624</td>
        <td>511028722</td>
        <td>08-01-22</td>
        <td>2643830.3</td>
        <td>5499</td>
        <td>ERS-4000027487-1862443-RTN-TDS-SI-842899</td>
        <td>963.00</td>
        <td>PO-0000194296-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>STANDARD</td>
        <td>3740630</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>08-01-22</td>
        <td>51228624</td>
        <td>511028722</td>
        <td>08-01-22</td>
        <td>2643830.3</td>
        <td>5499</td>
        <td>ERS-4000027488-1862444-TDS-CM-845282</td>
        <td>0.00</td>
        <td>PO-0000194295-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td>3740630</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>08-01-22</td>
        <td>51228624</td>
        <td>511028722</td>
        <td>08-01-22</td>
        <td>2643830.3</td>
        <td>5499</td>
        <td>ERS-4000027486-1862442-RTN-TDS-SI-846992</td>
        <td>396.00</td>
        <td></td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>STANDARD</td>
        <td>3740630</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>08-01-22</td>
        <td>51228624</td>
        <td>511028722</td>
        <td>08-01-22</td>
        <td>2643830.3</td>
        <td>5499</td>
        <td>ERS-4000027487-1862443-TDS-CM-842898</td>
        <td>0.00</td>
        <td>PO-0000194296-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td>3740630</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>08-01-22</td>
        <td>51228624</td>
        <td>511028722</td>
        <td>08-01-22</td>
        <td>2643830.3</td>
        <td>5499</td>
        <td>ERS-4000027439-1860517-RTN-TDS-SI-844263</td>
        <td>1443.00</td>
        <td>PO-0000194286-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>STANDARD</td>
        <td>3740630</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>08-01-22</td>
        <td>51228624</td>
        <td>511028722</td>
        <td>08-01-22</td>
        <td>2643830.3</td>
        <td>5499</td>
        <td>ERS-4000027488-1862444-RTN-TDS-SI-845285</td>
        <td>481.00</td>
        <td></td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>STANDARD</td>
        <td>3740630</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>08-01-22</td>
        <td>51228624</td>
        <td>511028722</td>
        <td>08-01-22</td>
        <td>2643830.3</td>
        <td>5499</td>
        <td>ERS-4000027486-1862442-RTN-TDS-SI-846978</td>
        <td>567.00</td>
        <td></td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>STANDARD</td>
        <td>3740630</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>08-01-22</td>
        <td>51228624</td>
        <td>511028722</td>
        <td>08-01-22</td>
        <td>2643830.3</td>
        <td>5499</td>
        <td>ERS-4000027487-1862443</td>
        <td>659995.20</td>
        <td>PO-0000194296-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3740630</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>08-01-22</td>
        <td>51228624</td>
        <td>511028722</td>
        <td>08-01-22</td>
        <td>2643830.3</td>
        <td>5499</td>
        <td>ERS-4000027486-1862442</td>
        <td>659995.20</td>
        <td>PO-0000194293-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3740630</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>45030</td>
        <td>Advances to Suppliers - Goods</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>31-10-21</td>
        <td>3857039</td>
        <td>ERS-4000027486-1862442</td>
        <td>09-01-22</td>
        <td>0</td>
        <td>395715</td>
        <td>ERS-4000027486-1862442</td>
        <td>0.00</td>
        <td>PO-0000194293-Invoice</td>
        <td>Receipt Invoice automatically created on 31-OCT-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>09-01-22</td>
        <td>3907600</td>
        <td>ERS-4000027486-1862442-RTN-TDS-SI-846992</td>
        <td>09-01-22</td>
        <td>0</td>
        <td>396</td>
        <td>ERS-4000027486-1862442-RTN-TDS-SI-846992</td>
        <td>0.00</td>
        <td></td>
        <td>ERS-4000027486-1862442-RTN-TDS-SI-846992</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>UNMATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>31-10-21</td>
        <td>3857039</td>
        <td>ERS-4000027486-1862442</td>
        <td>09-01-22</td>
        <td>395715</td>
        <td>0</td>
        <td>ERS-4000027486-1862442</td>
        <td>0.00</td>
        <td>PO-0000194293-Invoice</td>
        <td>Receipt Invoice automatically created on 31-OCT-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>12-01-22</td>
        <td>51228969</td>
        <td>511029068</td>
        <td>12-01-22</td>
        <td>89458.56</td>
        <td>279</td>
        <td>ERS-4000027672-1872381-TDS-CM-841110</td>
        <td>0.00</td>
        <td>PO-0000194297-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td>3742253</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>12-01-22</td>
        <td>51228969</td>
        <td>511029068</td>
        <td>12-01-22</td>
        <td>89458.56</td>
        <td>279</td>
        <td>ERS-4000027675-1872383-TDS-CM-844793</td>
        <td>0.00</td>
        <td>PO-0000194285-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td>3742253</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>12-01-22</td>
        <td>51228969</td>
        <td>511029068</td>
        <td>12-01-22</td>
        <td>89458.56</td>
        <td>279</td>
        <td>ERS-4000027675-1872383</td>
        <td>44729.28</td>
        <td>PO-0000194285-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3742253</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>12-01-22</td>
        <td>51228969</td>
        <td>511029068</td>
        <td>12-01-22</td>
        <td>89458.56</td>
        <td>279</td>
        <td>ERS-4000027672-1872381</td>
        <td>44729.28</td>
        <td>PO-0000194297-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3742253</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>12-01-22</td>
        <td>51228969</td>
        <td>511029068</td>
        <td>12-01-22</td>
        <td>89458.56</td>
        <td>279</td>
        <td>ERS-4000027673-1872382-TDS-CM-846971</td>
        <td>0.00</td>
        <td>PO-0000194294-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td>3742253</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>30-11-21</td>
        <td>3873098</td>
        <td>ERS-4000027670-1872379</td>
        <td>14-01-22</td>
        <td>0</td>
        <td>384858.18</td>
        <td>ERS-4000027670-1872379</td>
        <td>0.00</td>
        <td>PO-0000202853-Invoice</td>
        <td>Receipt Invoice automatically created on 30-NOV-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>30-11-21</td>
        <td>3873097</td>
        <td>ERS-4000027668-1872378</td>
        <td>14-01-22</td>
        <td>967487.5</td>
        <td>0</td>
        <td>ERS-4000027668-1872378</td>
        <td>0.00</td>
        <td>PO-0000202837-Invoice</td>
        <td>Receipt Invoice automatically created on 30-NOV-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CRM INV</td>
        <td>30-12-21</td>
        <td>2919151</td>
        <td>ERS-4000027985-1887104-TDS-CM-851713</td>
        <td>14-01-22</td>
        <td>1302</td>
        <td>0</td>
        <td>ERS-4000027985-1887104-TDS-CM-851713</td>
        <td>0.00</td>
        <td>PO-0000202839-Invoice</td>
        <td>ERS-4000027985-1887104-TDS-CM-851713</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td></td>
        <td>2</td>
        <td>CREDIT MEMO VALIDATED</td>
        <td>UNMATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CRM INV</td>
        <td>30-12-21</td>
        <td>2919174</td>
        <td>ERS-4000028002-1887105-TDS-CM-851725</td>
        <td>14-01-22</td>
        <td>1152</td>
        <td>0</td>
        <td>ERS-4000028002-1887105-TDS-CM-851725</td>
        <td>0.00</td>
        <td>PO-0000202840-Invoice</td>
        <td>ERS-4000028002-1887105-TDS-CM-851725</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td></td>
        <td>2</td>
        <td>CREDIT MEMO VALIDATED</td>
        <td>UNMATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>30-11-21</td>
        <td>3873096</td>
        <td>ERS-4000027666-1872377</td>
        <td>14-01-22</td>
        <td>0</td>
        <td>1871209.49</td>
        <td>ERS-4000027666-1872377</td>
        <td>0.00</td>
        <td>PO-0000202854-Invoice</td>
        <td>Receipt Invoice automatically created on 30-NOV-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>14-01-22</td>
        <td>3915031</td>
        <td>ERS-4000027985-1887104-RTN-TDS-SI-851714</td>
        <td>14-01-22</td>
        <td>0</td>
        <td>911</td>
        <td>ERS-4000027985-1887104-RTN-TDS-SI-851714</td>
        <td>0.00</td>
        <td></td>
        <td>ERS-4000027985-1887104-RTN-TDS-SI-851714</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>UNMATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CRM INV</td>
        <td>30-11-21</td>
        <td>2919083</td>
        <td>ERS-4000027671-1872380-TDS-CM-851660</td>
        <td>14-01-22</td>
        <td>326</td>
        <td>0</td>
        <td>ERS-4000027671-1872380-TDS-CM-851660</td>
        <td>0.00</td>
        <td>PO-0000202852-Invoice</td>
        <td>ERS-4000027671-1872380-TDS-CM-851660</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td></td>
        <td>2</td>
        <td>CREDIT MEMO VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>30-12-21</td>
        <td>3897682</td>
        <td>ERS-4000028002-1887105</td>
        <td>14-01-22</td>
        <td>0</td>
        <td>1359090.08</td>
        <td>ERS-4000028002-1887105</td>
        <td>0.00</td>
        <td>PO-0000202840-Invoice</td>
        <td>Receipt Invoice automatically created on 30-DEC-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>14-01-22</td>
        <td>3914962</td>
        <td>ERS-4000027668-1872378-RTN-TDS-SI-851640</td>
        <td>14-01-22</td>
        <td>0</td>
        <td>967</td>
        <td>ERS-4000027668-1872378-RTN-TDS-SI-851640</td>
        <td>0.00</td>
        <td></td>
        <td>ERS-4000027668-1872378-RTN-TDS-SI-851640</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>UNMATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>30-12-21</td>
        <td>3897681</td>
        <td>ERS-4000027985-1887104</td>
        <td>14-01-22</td>
        <td>0</td>
        <td>1536358.23</td>
        <td>ERS-4000027985-1887104</td>
        <td>0.00</td>
        <td>PO-0000202839-Invoice</td>
        <td>Receipt Invoice automatically created on 30-DEC-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>30-11-21</td>
        <td>3873099</td>
        <td>ERS-4000027671-1872380</td>
        <td>14-01-22</td>
        <td>0</td>
        <td>384858.18</td>
        <td>ERS-4000027671-1872380</td>
        <td>0.00</td>
        <td>PO-0000202852-Invoice</td>
        <td>Receipt Invoice automatically created on 30-NOV-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>45030</td>
        <td>Advances to Suppliers - Goods</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>30-11-21</td>
        <td>3873097</td>
        <td>ERS-4000027668-1872378</td>
        <td>14-01-22</td>
        <td>0</td>
        <td>967487.5</td>
        <td>ERS-4000027668-1872378</td>
        <td>0.00</td>
        <td>PO-0000202837-Invoice</td>
        <td>Receipt Invoice automatically created on 30-NOV-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CRM INV</td>
        <td>30-11-21</td>
        <td>2919059</td>
        <td>ERS-4000027668-1872378-TDS-CM-851638</td>
        <td>14-01-22</td>
        <td>1382</td>
        <td>0</td>
        <td>ERS-4000027668-1872378-TDS-CM-851638</td>
        <td>0.00</td>
        <td>PO-0000202837-Invoice</td>
        <td>ERS-4000027668-1872378-TDS-CM-851638</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td></td>
        <td>2</td>
        <td>CREDIT MEMO VALIDATED</td>
        <td>UNMATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CRM INV</td>
        <td>30-11-21</td>
        <td>2919073</td>
        <td>ERS-4000027670-1872379-TDS-CM-851654</td>
        <td>14-01-22</td>
        <td>326</td>
        <td>0</td>
        <td>ERS-4000027670-1872379-TDS-CM-851654</td>
        <td>0.00</td>
        <td>PO-0000202853-Invoice</td>
        <td>ERS-4000027670-1872379-TDS-CM-851654</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td></td>
        <td>2</td>
        <td>CREDIT MEMO VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>14-01-22</td>
        <td>3915048</td>
        <td>ERS-4000028002-1887105-RTN-TDS-SI-851726</td>
        <td>14-01-22</td>
        <td>0</td>
        <td>806</td>
        <td>ERS-4000028002-1887105-RTN-TDS-SI-851726</td>
        <td>0.00</td>
        <td></td>
        <td>ERS-4000028002-1887105-RTN-TDS-SI-851726</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>UNMATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>30-11-21</td>
        <td>3873097</td>
        <td>ERS-4000027668-1872378</td>
        <td>14-01-22</td>
        <td>0</td>
        <td>1630908.09</td>
        <td>ERS-4000027668-1872378</td>
        <td>0.00</td>
        <td>PO-0000202837-Invoice</td>
        <td>Receipt Invoice automatically created on 30-NOV-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>17-01-22</td>
        <td>51229358</td>
        <td>511029393</td>
        <td>17-01-22</td>
        <td>664387.59</td>
        <td>2034</td>
        <td>ERS-4000027670-1872379-TDS-CM-851654</td>
        <td>0.00</td>
        <td>PO-0000202853-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td>3744076</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI UTILITY EPAY</td>
        <td>17-01-22</td>
        <td>51304763</td>
        <td>851001751</td>
        <td>17-01-22</td>
        <td>5044013</td>
        <td>5044</td>
        <td>1000068515  C173 C</td>
        <td>5044013.00</td>
        <td></td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>Manual Invoice Entry</td>
        <td>PREPAYMENT</td>
        <td>3743168</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>17-01-22</td>
        <td>51229358</td>
        <td>511029393</td>
        <td>17-01-22</td>
        <td>664387.59</td>
        <td>2034</td>
        <td>ERS-4000027671-1872380-TDS-CM-851660</td>
        <td>0.00</td>
        <td>PO-0000202852-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td>3744076</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>45030</td>
        <td>Advances to Suppliers - Goods</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>30-11-21</td>
        <td>3873096</td>
        <td>ERS-4000027666-1872377</td>
        <td>17-01-22</td>
        <td>0</td>
        <td>1150506.7</td>
        <td>ERS-4000027666-1872377</td>
        <td>0.00</td>
        <td>PO-0000202854-Invoice</td>
        <td>Receipt Invoice automatically created on 30-NOV-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>30-11-21</td>
        <td>3873096</td>
        <td>ERS-4000027666-1872377</td>
        <td>17-01-22</td>
        <td>1150506.7</td>
        <td>0</td>
        <td>ERS-4000027666-1872377</td>
        <td>0.00</td>
        <td>PO-0000202854-Invoice</td>
        <td>Receipt Invoice automatically created on 30-NOV-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CGN PV Adv</td>
        <td>17-01-22</td>
        <td>579049</td>
        <td>1000068515  C173 C</td>
        <td>17-01-22</td>
        <td>0</td>
        <td>5044013</td>
        <td>1000068515  C173 C</td>
        <td>0.00</td>
        <td></td>
        <td>70% ADVANCE ON BASIC AMOUNT</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>Manual Invoice Entry</td>
        <td>PREPAYMENT</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT VALIDATED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>17-01-22</td>
        <td>51229358</td>
        <td>511029393</td>
        <td>17-01-22</td>
        <td>664387.59</td>
        <td>2034</td>
        <td>ERS-4000027668-1872378-RTN-TDS-SI-851640</td>
        <td>967.00</td>
        <td></td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>STANDARD</td>
        <td>3744076</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>17-01-22</td>
        <td>51229358</td>
        <td>511029393</td>
        <td>17-01-22</td>
        <td>664387.59</td>
        <td>2034</td>
        <td>ERS-4000027668-1872378</td>
        <td>663420.59</td>
        <td>PO-0000202837-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3744076</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI UTILITY EPAY</td>
        <td>17-01-22</td>
        <td>51304763</td>
        <td>851001751</td>
        <td>17-01-22</td>
        <td>5044013</td>
        <td>5044</td>
        <td>1000068515  C173 C-TDS-CM-851873</td>
        <td>0.00</td>
        <td></td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td>3743168</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>17-01-22</td>
        <td>51229358</td>
        <td>511029393</td>
        <td>17-01-22</td>
        <td>664387.59</td>
        <td>2034</td>
        <td>ERS-4000027668-1872378-TDS-CM-851638</td>
        <td>0.00</td>
        <td>PO-0000202837-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td>3744076</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CRM INV</td>
        <td>17-01-22</td>
        <td>2919335</td>
        <td>1000068515  C173 C-TDS-CM-851873</td>
        <td>17-01-22</td>
        <td>5044</td>
        <td>0</td>
        <td>1000068515  C173 C-TDS-CM-851873</td>
        <td>0.00</td>
        <td></td>
        <td>1000068515  C173 C-TDS-CM-851873</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td></td>
        <td>2</td>
        <td>CREDIT MEMO VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>45030</td>
        <td>Advances to Suppliers - Goods</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CGN PV Adv</td>
        <td>17-01-22</td>
        <td>579049</td>
        <td>1000068515  C173 C</td>
        <td>17-01-22</td>
        <td>5044013</td>
        <td>0</td>
        <td>1000068515  C173 C</td>
        <td>0.00</td>
        <td></td>
        <td>70% ADVANCE ON BASIC AMOUNT</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>Manual Invoice Entry</td>
        <td>PREPAYMENT</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT VALIDATED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI LABOUR EPAY</td>
        <td>20-01-22</td>
        <td>51406615</td>
        <td>51306615</td>
        <td>20-01-22</td>
        <td>125801.1</td>
        <td>0</td>
        <td>ERS-4000027670-1872379</td>
        <td>97845.30</td>
        <td>PO-0000202853-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3744750</td>
        <td>2</td>
        <td></td>
        <td>UNMATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI LABOUR EPAY</td>
        <td>20-01-22</td>
        <td>51406615</td>
        <td>51306615</td>
        <td>20-01-22</td>
        <td>125801.1</td>
        <td>0</td>
        <td>ERS-4000027673-1872382</td>
        <td>27955.80</td>
        <td>PO-0000194294-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3744750</td>
        <td>2</td>
        <td></td>
        <td>UNMATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI LABOUR EPAY</td>
        <td>24-01-22</td>
        <td>51406665</td>
        <td>51306665</td>
        <td>24-01-22</td>
        <td>75480.66</td>
        <td>0</td>
        <td>ERS-4000027673-1872382</td>
        <td>16773.48</td>
        <td>PO-0000194294-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3745991</td>
        <td>2</td>
        <td></td>
        <td>UNMATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI LABOUR EPAY</td>
        <td>24-01-22</td>
        <td>51406665</td>
        <td>51306665</td>
        <td>24-01-22</td>
        <td>75480.66</td>
        <td>0</td>
        <td>ERS-4000027670-1872379</td>
        <td>58707.18</td>
        <td>PO-0000202853-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3745991</td>
        <td>2</td>
        <td></td>
        <td>UNMATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>28-01-22</td>
        <td>51230872</td>
        <td>511030927</td>
        <td>28-01-22</td>
        <td>720702.79</td>
        <td>0</td>
        <td>ERS-4000027666-1872377</td>
        <td>720702.79</td>
        <td>PO-0000202854-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3748470</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>30-11-21</td>
        <td>3873101</td>
        <td>ERS-4000027673-1872382</td>
        <td>01-02-22</td>
        <td>65230.2</td>
        <td>0</td>
        <td>ERS-4000027673-1872382</td>
        <td>0.00</td>
        <td>PO-0000194294-Invoice</td>
        <td>Receipt Invoice automatically created on 30-NOV-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>30-11-21</td>
        <td>3873098</td>
        <td>ERS-4000027670-1872379</td>
        <td>01-02-22</td>
        <td>228305.7</td>
        <td>0</td>
        <td>ERS-4000027670-1872379</td>
        <td>0.00</td>
        <td>PO-0000202853-Invoice</td>
        <td>Receipt Invoice automatically created on 30-NOV-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>45030</td>
        <td>Advances to Suppliers - Goods</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>30-11-21</td>
        <td>3873101</td>
        <td>ERS-4000027673-1872382</td>
        <td>01-02-22</td>
        <td>0</td>
        <td>65230.2</td>
        <td>ERS-4000027673-1872382</td>
        <td>0.00</td>
        <td>PO-0000194294-Invoice</td>
        <td>Receipt Invoice automatically created on 30-NOV-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>45030</td>
        <td>Advances to Suppliers - Goods</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>30-11-21</td>
        <td>3873098</td>
        <td>ERS-4000027670-1872379</td>
        <td>01-02-22</td>
        <td>0</td>
        <td>228305.7</td>
        <td>ERS-4000027670-1872379</td>
        <td>0.00</td>
        <td>PO-0000202853-Invoice</td>
        <td>Receipt Invoice automatically created on 30-NOV-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>31-12-21</td>
        <td>3899933</td>
        <td>ERS-4000028069-1888025</td>
        <td>05-02-22</td>
        <td>546839.3</td>
        <td>0</td>
        <td>ERS-4000028069-1888025</td>
        <td>0.00</td>
        <td>PO-0000207842-Invoice</td>
        <td>Receipt Invoice automatically created on 31-DEC-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>31-12-21</td>
        <td>3899933</td>
        <td>ERS-4000028069-1888025</td>
        <td>05-02-22</td>
        <td>0</td>
        <td>921814.94</td>
        <td>ERS-4000028069-1888025</td>
        <td>0.00</td>
        <td>PO-0000207842-Invoice</td>
        <td>Receipt Invoice automatically created on 31-DEC-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>05-02-22</td>
        <td>3934383</td>
        <td>ERS-4000028069-1888025-RTN-TDS-SI-862209</td>
        <td>05-02-22</td>
        <td>0</td>
        <td>547</td>
        <td>ERS-4000028069-1888025-RTN-TDS-SI-862209</td>
        <td>0.00</td>
        <td></td>
        <td>ERS-4000028069-1888025-RTN-TDS-SI-862209</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>UNMATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CRM INV</td>
        <td>31-12-21</td>
        <td>2930139</td>
        <td>ERS-4000028069-1888025-TDS-CM-862208</td>
        <td>05-02-22</td>
        <td>781</td>
        <td>0</td>
        <td>ERS-4000028069-1888025-TDS-CM-862208</td>
        <td>0.00</td>
        <td>PO-0000207842-Invoice</td>
        <td>ERS-4000028069-1888025-TDS-CM-862208</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td></td>
        <td>2</td>
        <td>CREDIT MEMO VALIDATED</td>
        <td>UNMATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>45030</td>
        <td>Advances to Suppliers - Goods</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>31-12-21</td>
        <td>3899933</td>
        <td>ERS-4000028069-1888025</td>
        <td>05-02-22</td>
        <td>0</td>
        <td>546839.3</td>
        <td>ERS-4000028069-1888025</td>
        <td>0.00</td>
        <td>PO-0000207842-Invoice</td>
        <td>Receipt Invoice automatically created on 31-DEC-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>12-02-22</td>
        <td>51232904</td>
        <td>511032968</td>
        <td>12-02-22</td>
        <td>377239.64</td>
        <td>3235</td>
        <td>ERS-4000028069-1888025</td>
        <td>234359.80</td>
        <td>PO-0000207842-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3754578</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>12-02-22</td>
        <td>51232904</td>
        <td>511032968</td>
        <td>12-02-22</td>
        <td>377239.64</td>
        <td>3235</td>
        <td>ERS-4000028069-1888025</td>
        <td>140615.84</td>
        <td>PO-0000207842-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3754578</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>12-02-22</td>
        <td>51232904</td>
        <td>511032968</td>
        <td>12-02-22</td>
        <td>377239.64</td>
        <td>3235</td>
        <td>ERS-4000027985-1887104-RTN-TDS-SI-851714</td>
        <td>911.00</td>
        <td></td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>STANDARD</td>
        <td>3754578</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>12-02-22</td>
        <td>51232904</td>
        <td>511032968</td>
        <td>12-02-22</td>
        <td>377239.64</td>
        <td>3235</td>
        <td>ERS-4000028002-1887105-TDS-CM-851725</td>
        <td>0.00</td>
        <td>PO-0000202840-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td>3754578</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>12-02-22</td>
        <td>51232904</td>
        <td>511032968</td>
        <td>12-02-22</td>
        <td>377239.64</td>
        <td>3235</td>
        <td>ERS-4000028069-1888025-RTN-TDS-SI-862209</td>
        <td>547.00</td>
        <td></td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>STANDARD</td>
        <td>3754578</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>12-02-22</td>
        <td>51232904</td>
        <td>511032968</td>
        <td>12-02-22</td>
        <td>377239.64</td>
        <td>3235</td>
        <td>ERS-4000028002-1887105-RTN-TDS-SI-851726</td>
        <td>806.00</td>
        <td></td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>STANDARD</td>
        <td>3754578</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>12-02-22</td>
        <td>51232904</td>
        <td>511032968</td>
        <td>12-02-22</td>
        <td>377239.64</td>
        <td>3235</td>
        <td>ERS-4000027985-1887104-TDS-CM-851713</td>
        <td>0.00</td>
        <td>PO-0000202839-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td>3754578</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>12-02-22</td>
        <td>51232904</td>
        <td>511032968</td>
        <td>12-02-22</td>
        <td>377239.64</td>
        <td>3235</td>
        <td>ERS-4000028069-1888025-TDS-CM-862208</td>
        <td>0.00</td>
        <td>PO-0000207842-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td>3754578</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>31-08-21</td>
        <td>3809329</td>
        <td>ERS-5000013480-1837461</td>
        <td>15-02-22</td>
        <td>0</td>
        <td>400527.4</td>
        <td>ERS-5000013480-1837461</td>
        <td>0.00</td>
        <td>PO-0000144747-Invoice</td>
        <td>Receipt Invoice automatically created on 31-AUG-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>10-07-21</td>
        <td>3766195</td>
        <td>ERS-5000012994-1812142</td>
        <td>15-02-22</td>
        <td>0</td>
        <td>121189</td>
        <td>ERS-5000012994-1812142</td>
        <td>0.00</td>
        <td>PO-0000120351-Invoice</td>
        <td>Receipt Invoice automatically created on 10-JUL-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>UNMATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>16-02-22</td>
        <td>51233185</td>
        <td>511033203</td>
        <td>16-02-22</td>
        <td>274117.5</td>
        <td>0</td>
        <td>ERS-5000013480-1837461</td>
        <td>171396.50</td>
        <td>PO-0000144747-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3755929</td>
        <td>2</td>
        <td></td>
        <td>UNMATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>31-08-21</td>
        <td>3809329</td>
        <td>ERS-5000013480-1837461</td>
        <td>16-02-22</td>
        <td>168033.5</td>
        <td>0</td>
        <td>ERS-5000013480-1837461</td>
        <td>0.00</td>
        <td>PO-0000144747-Invoice</td>
        <td>Receipt Invoice automatically created on 31-AUG-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>45030</td>
        <td>Advances to Suppliers - Goods</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>31-08-21</td>
        <td>3809329</td>
        <td>ERS-5000013480-1837461</td>
        <td>16-02-22</td>
        <td>0</td>
        <td>168033.5</td>
        <td>ERS-5000013480-1837461</td>
        <td>0.00</td>
        <td>PO-0000144747-Invoice</td>
        <td>Receipt Invoice automatically created on 31-AUG-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>16-02-22</td>
        <td>51233185</td>
        <td>511033203</td>
        <td>16-02-22</td>
        <td>274117.5</td>
        <td>0</td>
        <td>ERS-5000012994-1812142</td>
        <td>102721.00</td>
        <td>PO-0000120351-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3755929</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>28-12-21</td>
        <td>3895316</td>
        <td>ERS-5000014389-1885458</td>
        <td>21-02-22</td>
        <td>0</td>
        <td>847535</td>
        <td>ERS-5000014389-1885458</td>
        <td>0.00</td>
        <td>PO-0000218288-Invoice</td>
        <td>Receipt Invoice automatically created on 28-DEC-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>17-01-22</td>
        <td>3916157</td>
        <td>ERS-5000014557-1893300</td>
        <td>22-02-22</td>
        <td>0</td>
        <td>1152647.6</td>
        <td>ERS-5000014557-1893300</td>
        <td>0.00</td>
        <td>PO-0000219847-Invoice</td>
        <td>Receipt Invoice automatically created on 17-JAN-22</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>45030</td>
        <td>Advances to Suppliers - Goods</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>28-12-21</td>
        <td>3895316</td>
        <td>ERS-5000014389-1885458</td>
        <td>22-02-22</td>
        <td>0</td>
        <td>359125</td>
        <td>ERS-5000014389-1885458</td>
        <td>0.00</td>
        <td>PO-0000218288-Invoice</td>
        <td>Receipt Invoice automatically created on 28-DEC-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>28-12-21</td>
        <td>3895316</td>
        <td>ERS-5000014389-1885458</td>
        <td>22-02-22</td>
        <td>359125</td>
        <td>0</td>
        <td>ERS-5000014389-1885458</td>
        <td>0.00</td>
        <td>PO-0000218288-Invoice</td>
        <td>Receipt Invoice automatically created on 28-DEC-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>23-02-22</td>
        <td>51233610</td>
        <td>511033665</td>
        <td>23-02-22</td>
        <td>61097.4</td>
        <td>0</td>
        <td>ERS-5000013480-1837461</td>
        <td>61097.40</td>
        <td>PO-0000144747-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3758106</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>45030</td>
        <td>Advances to Suppliers - Goods</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>17-01-22</td>
        <td>3916157</td>
        <td>ERS-5000014557-1893300</td>
        <td>25-02-22</td>
        <td>0</td>
        <td>488410</td>
        <td>ERS-5000014557-1893300</td>
        <td>0.00</td>
        <td>PO-0000219847-Invoice</td>
        <td>Receipt Invoice automatically created on 17-JAN-22</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>17-01-22</td>
        <td>3916157</td>
        <td>ERS-5000014557-1893300</td>
        <td>25-02-22</td>
        <td>488410</td>
        <td>0</td>
        <td>ERS-5000014557-1893300</td>
        <td>0.00</td>
        <td>PO-0000219847-Invoice</td>
        <td>Receipt Invoice automatically created on 17-JAN-22</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>45030</td>
        <td>Advances to Suppliers - Goods</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CGN PV Adv</td>
        <td>26-02-22</td>
        <td>579125</td>
        <td>1000069115 C173</td>
        <td>26-02-22</td>
        <td>7921022</td>
        <td>0</td>
        <td>1000069115 C173</td>
        <td>0.00</td>
        <td>ADV WID 8597</td>
        <td>70% ADVANCE ON BASIC AMOUNT</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>Manual Invoice Entry</td>
        <td>PREPAYMENT</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT VALIDATED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CRM INV</td>
        <td>26-02-22</td>
        <td>2941551</td>
        <td>1000069115 C173-TDS-CM-872966</td>
        <td>26-02-22</td>
        <td>7921</td>
        <td>0</td>
        <td>1000069115 C173-TDS-CM-872966</td>
        <td>0.00</td>
        <td></td>
        <td>1000069115 C173-TDS-CM-872966</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td></td>
        <td>2</td>
        <td>CREDIT MEMO VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CGN PV Adv</td>
        <td>26-02-22</td>
        <td>579125</td>
        <td>1000069115 C173</td>
        <td>26-02-22</td>
        <td>0</td>
        <td>7921022</td>
        <td>1000069115 C173</td>
        <td>0.00</td>
        <td>ADV WID 8597</td>
        <td>70% ADVANCE ON BASIC AMOUNT</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>Manual Invoice Entry</td>
        <td>PREPAYMENT</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT VALIDATED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI UTILITY EPAY</td>
        <td>28-02-22</td>
        <td>51305009</td>
        <td>851001997</td>
        <td>28-02-22</td>
        <td>7921022</td>
        <td>7921</td>
        <td>1000069115 C173</td>
        <td>7921022.00</td>
        <td>ADV WID 8597</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>Manual Invoice Entry</td>
        <td>PREPAYMENT</td>
        <td>3759630</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI UTILITY EPAY</td>
        <td>28-02-22</td>
        <td>51305009</td>
        <td>851001997</td>
        <td>28-02-22</td>
        <td>7921022</td>
        <td>7921</td>
        <td>1000069115 C173-TDS-CM-872966</td>
        <td>0.00</td>
        <td></td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td>3759630</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>45030</td>
        <td>Advances to Suppliers - Goods</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>30-12-21</td>
        <td>3897682</td>
        <td>ERS-4000028002-1887105</td>
        <td>01-03-22</td>
        <td>0</td>
        <td>806239.7</td>
        <td>ERS-4000028002-1887105</td>
        <td>0.00</td>
        <td>PO-0000202840-Invoice</td>
        <td>Receipt Invoice automatically created on 30-DEC-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>30-12-21</td>
        <td>3897682</td>
        <td>ERS-4000028002-1887105</td>
        <td>01-03-22</td>
        <td>806239.7</td>
        <td>0</td>
        <td>ERS-4000028002-1887105</td>
        <td>0.00</td>
        <td>PO-0000202840-Invoice</td>
        <td>Receipt Invoice automatically created on 30-DEC-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>45030</td>
        <td>Advances to Suppliers - Goods</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>30-12-21</td>
        <td>3897681</td>
        <td>ERS-4000027985-1887104</td>
        <td>01-03-22</td>
        <td>0</td>
        <td>911399.3</td>
        <td>ERS-4000027985-1887104</td>
        <td>0.00</td>
        <td>PO-0000202839-Invoice</td>
        <td>Receipt Invoice automatically created on 30-DEC-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>30-12-21</td>
        <td>3897681</td>
        <td>ERS-4000027985-1887104</td>
        <td>01-03-22</td>
        <td>911399.3</td>
        <td>0</td>
        <td>ERS-4000027985-1887104</td>
        <td>0.00</td>
        <td>PO-0000202839-Invoice</td>
        <td>Receipt Invoice automatically created on 30-DEC-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI LABOUR EPAY</td>
        <td>03-03-22</td>
        <td>51407076</td>
        <td>51307076</td>
        <td>03-03-22</td>
        <td>1177809.31</td>
        <td>0</td>
        <td>ERS-4000027985-1887104</td>
        <td>390599.20</td>
        <td>PO-0000202839-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3761297</td>
        <td>2</td>
        <td></td>
        <td>UNMATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI LABOUR EPAY</td>
        <td>03-03-22</td>
        <td>51407076</td>
        <td>51307076</td>
        <td>03-03-22</td>
        <td>1177809.31</td>
        <td>0</td>
        <td>ERS-4000028002-1887105</td>
        <td>207318.83</td>
        <td>PO-0000202840-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3761297</td>
        <td>2</td>
        <td></td>
        <td>UNMATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI LABOUR EPAY</td>
        <td>03-03-22</td>
        <td>51407076</td>
        <td>51307076</td>
        <td>03-03-22</td>
        <td>1177809.31</td>
        <td>0</td>
        <td>ERS-4000028002-1887105</td>
        <td>345531.55</td>
        <td>PO-0000202840-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3761297</td>
        <td>2</td>
        <td></td>
        <td>UNMATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI LABOUR EPAY</td>
        <td>03-03-22</td>
        <td>51407076</td>
        <td>51307076</td>
        <td>03-03-22</td>
        <td>1177809.31</td>
        <td>0</td>
        <td>ERS-4000027985-1887104</td>
        <td>234359.73</td>
        <td>PO-0000202839-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3761297</td>
        <td>2</td>
        <td></td>
        <td>UNMATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CRM INV</td>
        <td>31-01-22</td>
        <td>2946071</td>
        <td>ERS-4000028325-1899878-TDS-CM-877309</td>
        <td>04-03-22</td>
        <td>1215</td>
        <td>0</td>
        <td>ERS-4000028325-1899878-TDS-CM-877309</td>
        <td>0.00</td>
        <td>PO-0000223675-Invoice</td>
        <td>ERS-4000028325-1899878-TDS-CM-877309</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td></td>
        <td>2</td>
        <td>CREDIT MEMO VALIDATED</td>
        <td>UNMATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>31-01-22</td>
        <td>3929695</td>
        <td>ERS-4000028325-1899878</td>
        <td>04-03-22</td>
        <td>850639.3</td>
        <td>0</td>
        <td>ERS-4000028325-1899878</td>
        <td>0.00</td>
        <td>PO-0000223675-Invoice</td>
        <td>Receipt Invoice automatically created on 31-JAN-22</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>31-01-22</td>
        <td>3929695</td>
        <td>ERS-4000028325-1899878</td>
        <td>04-03-22</td>
        <td>0</td>
        <td>1433934.35</td>
        <td>ERS-4000028325-1899878</td>
        <td>0.00</td>
        <td>PO-0000223675-Invoice</td>
        <td>Receipt Invoice automatically created on 31-JAN-22</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>45030</td>
        <td>Advances to Suppliers - Goods</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>31-01-22</td>
        <td>3929695</td>
        <td>ERS-4000028325-1899878</td>
        <td>04-03-22</td>
        <td>0</td>
        <td>850639.3</td>
        <td>ERS-4000028325-1899878</td>
        <td>0.00</td>
        <td>PO-0000223675-Invoice</td>
        <td>Receipt Invoice automatically created on 31-JAN-22</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>04-03-22</td>
        <td>3963814</td>
        <td>ERS-4000028325-1899878-RTN-TDS-SI-877311</td>
        <td>04-03-22</td>
        <td>0</td>
        <td>851</td>
        <td>ERS-4000028325-1899878-RTN-TDS-SI-877311</td>
        <td>0.00</td>
        <td></td>
        <td>ERS-4000028325-1899878-RTN-TDS-SI-877311</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>UNMATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>15-03-22</td>
        <td>51235885</td>
        <td>511035972</td>
        <td>15-03-22</td>
        <td>584146.05</td>
        <td>1215</td>
        <td>ERS-4000028325-1899878-TDS-CM-877309</td>
        <td>0.00</td>
        <td>PO-0000223675-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td>3766410</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>15-03-22</td>
        <td>51235885</td>
        <td>511035972</td>
        <td>15-03-22</td>
        <td>584146.05</td>
        <td>1215</td>
        <td>ERS-4000028325-1899878</td>
        <td>218735.75</td>
        <td>PO-0000223675-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3766410</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>15-03-22</td>
        <td>51235885</td>
        <td>511035972</td>
        <td>15-03-22</td>
        <td>584146.05</td>
        <td>1215</td>
        <td>ERS-4000028325-1899878-RTN-TDS-SI-877311</td>
        <td>851.00</td>
        <td></td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>STANDARD</td>
        <td>3766410</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI MSMED EPAY</td>
        <td>15-03-22</td>
        <td>51235885</td>
        <td>511035972</td>
        <td>15-03-22</td>
        <td>584146.05</td>
        <td>1215</td>
        <td>ERS-4000028325-1899878</td>
        <td>364559.30</td>
        <td>PO-0000223675-Invoice</td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td>3766410</td>
        <td>2</td>
        <td></td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>45030</td>
        <td>Advances to Suppliers - Goods</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>27-02-22</td>
        <td>3957770</td>
        <td>ERS-4000028607-1912701</td>
        <td>16-03-22</td>
        <td>0</td>
        <td>1926882.3</td>
        <td>ERS-4000028607-1912701</td>
        <td>0.00</td>
        <td>PO-0000233360-Invoice</td>
        <td>Receipt Invoice automatically created on 27-FEB-22</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CRM INV</td>
        <td>27-02-22</td>
        <td>2953253</td>
        <td>ERS-4000028607-1912701-TDS-CM-884162</td>
        <td>16-03-22</td>
        <td>2753</td>
        <td>0</td>
        <td>ERS-4000028607-1912701-TDS-CM-884162</td>
        <td>0.00</td>
        <td>PO-0000233360-Invoice</td>
        <td>ERS-4000028607-1912701-TDS-CM-884162</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td></td>
        <td>2</td>
        <td>CREDIT MEMO VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>16-03-22</td>
        <td>3977730</td>
        <td>ERS-4000028607-1912701-RTN-TDS-SI-884164</td>
        <td>16-03-22</td>
        <td>0</td>
        <td>1927</td>
        <td>ERS-4000028607-1912701-RTN-TDS-SI-884164</td>
        <td>0.00</td>
        <td></td>
        <td>ERS-4000028607-1912701-RTN-TDS-SI-884164</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>27-02-22</td>
        <td>3957770</td>
        <td>ERS-4000028607-1912701</td>
        <td>16-03-22</td>
        <td>0</td>
        <td>3248173.02</td>
        <td>ERS-4000028607-1912701</td>
        <td>0.00</td>
        <td>PO-0000233360-Invoice</td>
        <td>Receipt Invoice automatically created on 27-FEB-22</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>27-02-22</td>
        <td>3957770</td>
        <td>ERS-4000028607-1912701</td>
        <td>16-03-22</td>
        <td>1926882.3</td>
        <td>0</td>
        <td>ERS-4000028607-1912701</td>
        <td>0.00</td>
        <td>PO-0000233360-Invoice</td>
        <td>Receipt Invoice automatically created on 27-FEB-22</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>45030</td>
        <td>Advances to Suppliers - Goods</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>22-02-22</td>
        <td>3951753</td>
        <td>ERS-4000028544-1909821</td>
        <td>18-03-22</td>
        <td>0</td>
        <td>1926882.3</td>
        <td>ERS-4000028544-1909821</td>
        <td>0.00</td>
        <td>PO-0000233489-Invoice</td>
        <td>Receipt Invoice automatically created on 22-FEB-22</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>45030</td>
        <td>Advances to Suppliers - Goods</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>24-02-22</td>
        <td>3954276</td>
        <td>ERS-4000028564-1911089</td>
        <td>18-03-22</td>
        <td>0</td>
        <td>1926882.3</td>
        <td>ERS-4000028564-1911089</td>
        <td>0.00</td>
        <td>PO-0000233469-Invoice</td>
        <td>Receipt Invoice automatically created on 24-FEB-22</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>24-02-22</td>
        <td>3954276</td>
        <td>ERS-4000028564-1911089</td>
        <td>18-03-22</td>
        <td>1926882.3</td>
        <td>0</td>
        <td>ERS-4000028564-1911089</td>
        <td>0.00</td>
        <td>PO-0000233469-Invoice</td>
        <td>Receipt Invoice automatically created on 24-FEB-22</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>24-02-22</td>
        <td>3954276</td>
        <td>ERS-4000028564-1911089</td>
        <td>18-03-22</td>
        <td>0</td>
        <td>3248173.02</td>
        <td>ERS-4000028564-1911089</td>
        <td>0.00</td>
        <td>PO-0000233469-Invoice</td>
        <td>Receipt Invoice automatically created on 24-FEB-22</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>18-03-22</td>
        <td>3981359</td>
        <td>ERS-4000028544-1909821-RTN-TDS-SI-886244</td>
        <td>18-03-22</td>
        <td>0</td>
        <td>1927</td>
        <td>ERS-4000028544-1909821-RTN-TDS-SI-886244</td>
        <td>0.00</td>
        <td></td>
        <td>ERS-4000028544-1909821-RTN-TDS-SI-886244</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>22-02-22</td>
        <td>3951753</td>
        <td>ERS-4000028544-1909821</td>
        <td>18-03-22</td>
        <td>1926882.3</td>
        <td>0</td>
        <td>ERS-4000028544-1909821</td>
        <td>0.00</td>
        <td>PO-0000233489-Invoice</td>
        <td>Receipt Invoice automatically created on 22-FEB-22</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CRM INV</td>
        <td>22-02-22</td>
        <td>2955382</td>
        <td>ERS-4000028544-1909821-TDS-CM-886242</td>
        <td>18-03-22</td>
        <td>2753</td>
        <td>0</td>
        <td>ERS-4000028544-1909821-TDS-CM-886242</td>
        <td>0.00</td>
        <td>PO-0000233489-Invoice</td>
        <td>ERS-4000028544-1909821-TDS-CM-886242</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td></td>
        <td>2</td>
        <td>CREDIT MEMO VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>22-02-22</td>
        <td>3951753</td>
        <td>ERS-4000028544-1909821</td>
        <td>18-03-22</td>
        <td>0</td>
        <td>3248173.02</td>
        <td>ERS-4000028544-1909821</td>
        <td>0.00</td>
        <td>PO-0000233489-Invoice</td>
        <td>Receipt Invoice automatically created on 22-FEB-22</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>45030</td>
        <td>Advances to Suppliers - Goods</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>28-02-22</td>
        <td>3958908</td>
        <td>ERS-4000028647-1913517</td>
        <td>21-03-22</td>
        <td>0</td>
        <td>1348817.4</td>
        <td>ERS-4000028647-1913517</td>
        <td>0.00</td>
        <td>PO-0000233372-Invoice</td>
        <td>Receipt Invoice automatically created on 28-FEB-22</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>28-02-22</td>
        <td>3958910</td>
        <td>ERS-4000028649-1913519</td>
        <td>21-03-22</td>
        <td>1926882.3</td>
        <td>0</td>
        <td>ERS-4000028649-1913519</td>
        <td>0.00</td>
        <td>PO-0000233371-Invoice</td>
        <td>Receipt Invoice automatically created on 28-FEB-22</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>28-02-22</td>
        <td>3958907</td>
        <td>ERS-4000028646-1913516</td>
        <td>21-03-22</td>
        <td>0</td>
        <td>2273721.11</td>
        <td>ERS-4000028646-1913516</td>
        <td>0.00</td>
        <td>PO-0000233459-Invoice</td>
        <td>Receipt Invoice automatically created on 28-FEB-22</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>28-02-22</td>
        <td>3958908</td>
        <td>ERS-4000028647-1913517</td>
        <td>21-03-22</td>
        <td>1348817.4</td>
        <td>0</td>
        <td>ERS-4000028647-1913517</td>
        <td>0.00</td>
        <td>PO-0000233372-Invoice</td>
        <td>Receipt Invoice automatically created on 28-FEB-22</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CRM INV</td>
        <td>28-02-22</td>
        <td>2956178</td>
        <td>ERS-4000028649-1913519-TDS-CM-887027</td>
        <td>21-03-22</td>
        <td>2753</td>
        <td>0</td>
        <td>ERS-4000028649-1913519-TDS-CM-887027</td>
        <td>0.00</td>
        <td>PO-0000233371-Invoice</td>
        <td>ERS-4000028649-1913519-TDS-CM-887027</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td></td>
        <td>2</td>
        <td>CREDIT MEMO VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CRM INV</td>
        <td>28-02-22</td>
        <td>2956195</td>
        <td>ERS-4000028647-1913517-TDS-CM-887043</td>
        <td>21-03-22</td>
        <td>1927</td>
        <td>0</td>
        <td>ERS-4000028647-1913517-TDS-CM-887043</td>
        <td>0.00</td>
        <td>PO-0000233372-Invoice</td>
        <td>ERS-4000028647-1913517-TDS-CM-887043</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td></td>
        <td>2</td>
        <td>CREDIT MEMO VALIDATED</td>
        <td>UNMATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CRM INV</td>
        <td>28-02-22</td>
        <td>2956202</td>
        <td>ERS-4000028646-1913516-TDS-CM-887050</td>
        <td>21-03-22</td>
        <td>1927</td>
        <td>0</td>
        <td>ERS-4000028646-1913516-TDS-CM-887050</td>
        <td>0.00</td>
        <td>PO-0000233459-Invoice</td>
        <td>ERS-4000028646-1913516-TDS-CM-887050</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td></td>
        <td>2</td>
        <td>CREDIT MEMO VALIDATED</td>
        <td>UNMATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>28-02-22</td>
        <td>3958910</td>
        <td>ERS-4000028649-1913519</td>
        <td>21-03-22</td>
        <td>0</td>
        <td>3248173.02</td>
        <td>ERS-4000028649-1913519</td>
        <td>0.00</td>
        <td>PO-0000233371-Invoice</td>
        <td>Receipt Invoice automatically created on 28-FEB-22</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>21-03-22</td>
        <td>3982532</td>
        <td>ERS-4000028647-1913517-RTN-TDS-SI-887044</td>
        <td>21-03-22</td>
        <td>0</td>
        <td>1349</td>
        <td>ERS-4000028647-1913517-RTN-TDS-SI-887044</td>
        <td>0.00</td>
        <td></td>
        <td>ERS-4000028647-1913517-RTN-TDS-SI-887044</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>UNMATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>28-02-22</td>
        <td>3958908</td>
        <td>ERS-4000028647-1913517</td>
        <td>21-03-22</td>
        <td>0</td>
        <td>2273721.11</td>
        <td>ERS-4000028647-1913517</td>
        <td>0.00</td>
        <td>PO-0000233372-Invoice</td>
        <td>Receipt Invoice automatically created on 28-FEB-22</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>21-03-22</td>
        <td>3982544</td>
        <td>ERS-4000028646-1913516-RTN-TDS-SI-887051</td>
        <td>21-03-22</td>
        <td>0</td>
        <td>1349</td>
        <td>ERS-4000028646-1913516-RTN-TDS-SI-887051</td>
        <td>0.00</td>
        <td></td>
        <td>ERS-4000028646-1913516-RTN-TDS-SI-887051</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>UNMATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>21-03-22</td>
        <td>3982515</td>
        <td>ERS-4000028649-1913519-RTN-TDS-SI-887028</td>
        <td>21-03-22</td>
        <td>0</td>
        <td>1927</td>
        <td>ERS-4000028649-1913519-RTN-TDS-SI-887028</td>
        <td>0.00</td>
        <td></td>
        <td>ERS-4000028649-1913519-RTN-TDS-SI-887028</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>45030</td>
        <td>Advances to Suppliers - Goods</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>28-02-22</td>
        <td>3958907</td>
        <td>ERS-4000028646-1913516</td>
        <td>21-03-22</td>
        <td>0</td>
        <td>1348817</td>
        <td>ERS-4000028646-1913516</td>
        <td>0.00</td>
        <td>PO-0000233459-Invoice</td>
        <td>Receipt Invoice automatically created on 28-FEB-22</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>45030</td>
        <td>Advances to Suppliers - Goods</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>28-02-22</td>
        <td>3958910</td>
        <td>ERS-4000028649-1913519</td>
        <td>21-03-22</td>
        <td>0</td>
        <td>1926882.3</td>
        <td>ERS-4000028649-1913519</td>
        <td>0.00</td>
        <td>PO-0000233371-Invoice</td>
        <td>Receipt Invoice automatically created on 28-FEB-22</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>28-02-22</td>
        <td>3958907</td>
        <td>ERS-4000028646-1913516</td>
        <td>21-03-22</td>
        <td>1348817</td>
        <td>0</td>
        <td>ERS-4000028646-1913516</td>
        <td>0.00</td>
        <td>PO-0000233459-Invoice</td>
        <td>Receipt Invoice automatically created on 28-FEB-22</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CRM INV</td>
        <td>28-02-22</td>
        <td>2958572</td>
        <td>ERS-4000028648-1913518-TDS-CM-889303</td>
        <td>24-03-22</td>
        <td>1927</td>
        <td>0</td>
        <td>ERS-4000028648-1913518-TDS-CM-889303</td>
        <td>0.00</td>
        <td>PO-0000233373-Invoice</td>
        <td>ERS-4000028648-1913518-TDS-CM-889303</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td></td>
        <td>2</td>
        <td>CREDIT MEMO VALIDATED</td>
        <td>UNMATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>28-02-22</td>
        <td>3958909</td>
        <td>ERS-4000028648-1913518</td>
        <td>24-03-22</td>
        <td>0</td>
        <td>2273721.11</td>
        <td>ERS-4000028648-1913518</td>
        <td>0.00</td>
        <td>PO-0000233373-Invoice</td>
        <td>Receipt Invoice automatically created on 28-FEB-22</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>24-03-22</td>
        <td>3987090</td>
        <td>ERS-4000028648-1913518-RTN-TDS-SI-889304</td>
        <td>24-03-22</td>
        <td>0</td>
        <td>1349</td>
        <td>ERS-4000028648-1913518-RTN-TDS-SI-889304</td>
        <td>0.00</td>
        <td></td>
        <td>ERS-4000028648-1913518-RTN-TDS-SI-889304</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>UNMATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>45030</td>
        <td>Advances to Suppliers - Goods</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>28-02-22</td>
        <td>3958909</td>
        <td>ERS-4000028648-1913518</td>
        <td>24-03-22</td>
        <td>0</td>
        <td>1348817.4</td>
        <td>ERS-4000028648-1913518</td>
        <td>0.00</td>
        <td>PO-0000233373-Invoice</td>
        <td>Receipt Invoice automatically created on 28-FEB-22</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>28-02-22</td>
        <td>3958909</td>
        <td>ERS-4000028648-1913518</td>
        <td>24-03-22</td>
        <td>1348817.4</td>
        <td>0</td>
        <td>ERS-4000028648-1913518</td>
        <td>0.00</td>
        <td>PO-0000233373-Invoice</td>
        <td>Receipt Invoice automatically created on 28-FEB-22</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>PREPAYMENT APPLIED</td>
        <td>CONTRA</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CRM INV</td>
        <td>22-03-22</td>
        <td>2962049</td>
        <td>ERS-5000014989-1925419-TDS-CM-892671</td>
        <td>28-03-22</td>
        <td>9</td>
        <td>0</td>
        <td>ERS-5000014989-1925419-TDS-CM-892671</td>
        <td>0.00</td>
        <td>PO-0000239022-Invoice</td>
        <td>ERS-5000014989-1925419-TDS-CM-892671</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td></td>
        <td>2</td>
        <td>CREDIT MEMO VALIDATED</td>
        <td>UNMATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>22-03-22</td>
        <td>3985373</td>
        <td>ERS-5000014989-1925419</td>
        <td>28-03-22</td>
        <td>0</td>
        <td>10170.42</td>
        <td>ERS-5000014989-1925419</td>
        <td>0.00</td>
        <td>PO-0000239022-Invoice</td>
        <td>Receipt Invoice automatically created on 22-MAR-22</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>23-03-22</td>
        <td>3986756</td>
        <td>ERS-5000015000-1926126</td>
        <td>29-03-22</td>
        <td>0</td>
        <td>102789.21</td>
        <td>ERS-5000015000-1926126</td>
        <td>0.00</td>
        <td>PO-0000239419-Invoice</td>
        <td>Receipt Invoice automatically created on 23-MAR-22</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20330</td>
        <td>Creditors For Expenses</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI EPAY</td>
        <td>31-03-22</td>
        <td>551820</td>
        <td>95114497</td>
        <td>31-03-22</td>
        <td>31034</td>
        <td>3103</td>
        <td>91 MSME Interest 2020-2021</td>
        <td>31034.00</td>
        <td></td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>MANUAL INVOICE ENTRY</td>
        <td>STANDARD</td>
        <td>3773703</td>
        <td>2</td>
        <td></td>
        <td>UNMATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20330</td>
        <td>Creditors For Expenses</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CGN PV DN</td>
        <td>31-03-22</td>
        <td>618322</td>
        <td>08-PROV-21.22_PO_278</td>
        <td>31-03-22</td>
        <td>1599.39</td>
        <td>0</td>
        <td>08-PROV-21.22_PO_278</td>
        <td>0.00</td>
        <td></td>
        <td>Tds on AP accrual as on 31st March 2022</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>MANUAL INVOICE ENTRY</td>
        <td>DEBIT</td>
        <td></td>
        <td>2</td>
        <td>DEBIT MEMO VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20330</td>
        <td>Creditors For Expenses</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CGN PV DN</td>
        <td>31-03-22</td>
        <td>618324</td>
        <td>08-PROV-21.22_PO_529</td>
        <td>31-03-22</td>
        <td>3248.17</td>
        <td>0</td>
        <td>08-PROV-21.22_PO_529</td>
        <td>0.00</td>
        <td></td>
        <td>Tds on AP accrual as on 31st March 2022</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>MANUAL INVOICE ENTRY</td>
        <td>DEBIT</td>
        <td></td>
        <td>2</td>
        <td>DEBIT MEMO VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20330</td>
        <td>Creditors For Expenses</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CGN PV DN</td>
        <td>31-03-22</td>
        <td>618323</td>
        <td>08-PROV-21.22_PO_29</td>
        <td>31-03-22</td>
        <td>1786.5</td>
        <td>0</td>
        <td>08-PROV-21.22_PO_29</td>
        <td>0.00</td>
        <td></td>
        <td>Tds on AP accrual as on 31st March 2022</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>MANUAL INVOICE ENTRY</td>
        <td>DEBIT</td>
        <td></td>
        <td>2</td>
        <td>DEBIT MEMO VALIDATED</td>
        <td>UNMATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>31-03-22</td>
        <td>4011626</td>
        <td>Q4 94Q CORRECTION</td>
        <td>31-03-22</td>
        <td>87109.5</td>
        <td>87109.5</td>
        <td>Q4 94Q CORRECTION</td>
        <td>0.00</td>
        <td></td>
        <td>Q4 94Q CORRECTION</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>Manual Invoice Entry</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>UNMATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CRM INV</td>
        <td>31-03-22</td>
        <td>2975340</td>
        <td>Q4 94Q CORRECTION-TDS-CM-905493</td>
        <td>31-03-22</td>
        <td>87</td>
        <td>0</td>
        <td>Q4 94Q CORRECTION-TDS-CM-905493</td>
        <td>0.00</td>
        <td></td>
        <td>Q4 94Q CORRECTION-TDS-CM-905493</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td></td>
        <td>2</td>
        <td>CREDIT MEMO VALIDATED</td>
        <td>UNMATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20330</td>
        <td>Creditors For Expenses</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CGN PV DN</td>
        <td>31-03-22</td>
        <td>618321</td>
        <td>08-PROV-21.22_PO_254</td>
        <td>31-03-22</td>
        <td>204.85</td>
        <td>0</td>
        <td>08-PROV-21.22_PO_254</td>
        <td>0.00</td>
        <td></td>
        <td>Tds on AP accrual as on 31st March 2022</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>MANUAL INVOICE ENTRY</td>
        <td>DEBIT</td>
        <td></td>
        <td>2</td>
        <td>DEBIT MEMO VALIDATED</td>
        <td>UNMATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CRM INV</td>
        <td>31-03-22</td>
        <td>2970768</td>
        <td>ERS-5000015144-1933076-TDS-CM-901028</td>
        <td>31-03-22</td>
        <td>22</td>
        <td>0</td>
        <td>ERS-5000015144-1933076-TDS-CM-901028</td>
        <td>0.00</td>
        <td></td>
        <td>ERS-5000015144-1933076-TDS-CM-901028</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td></td>
        <td>2</td>
        <td>CREDIT MEMO VALIDATED</td>
        <td>UNMATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20330</td>
        <td>Creditors For Expenses</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CGN EPV</td>
        <td>30-03-22</td>
        <td>411559</td>
        <td>91 MSME Interest 2020-2021</td>
        <td>31-03-22</td>
        <td>0</td>
        <td>31034</td>
        <td>91 MSME Interest 2020-2021</td>
        <td>0.00</td>
        <td></td>
        <td>MSME Interest for F.Y. 2020-2021</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>MANUAL INVOICE ENTRY</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>UNMATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20330</td>
        <td>Creditors For Expenses</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>TFS BV CITI EPAY</td>
        <td>31-03-22</td>
        <td>551820</td>
        <td>95114497</td>
        <td>31-03-22</td>
        <td>31034</td>
        <td>3103</td>
        <td>91 MSME Interest 2020-2021-TDS-CM-895608</td>
        <td>0.00</td>
        <td></td>
        <td></td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td>3773703</td>
        <td>2</td>
        <td></td>
        <td>UNMATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>10-08-21</td>
        <td>3790881</td>
        <td>ERS-5000013267-1826995</td>
        <td>31-03-22</td>
        <td>0</td>
        <td>181492.44</td>
        <td>ERS-5000013267-1826995</td>
        <td>0.00</td>
        <td>PO-0000133698-Invoice</td>
        <td>Receipt Invoice automatically created on 10-AUG-21</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>UNMATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20330</td>
        <td>Creditors For Expenses</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CRM INV</td>
        <td>30-03-22</td>
        <td>2965079</td>
        <td>91 MSME Interest 2020-2021-TDS-CM-895608</td>
        <td>31-03-22</td>
        <td>3103</td>
        <td>0</td>
        <td>91 MSME Interest 2020-2021-TDS-CM-895608</td>
        <td>0.00</td>
        <td></td>
        <td>91 MSME Interest 2020-2021-TDS-CM-895608</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>INDIA TDS</td>
        <td>CREDIT</td>
        <td></td>
        <td>2</td>
        <td>CREDIT MEMO VALIDATED</td>
        <td>UNMATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20330</td>
        <td>Creditors For Expenses</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>CGN PV DN</td>
        <td>31-03-22</td>
        <td>618320</td>
        <td>08-PROV-21.22_PO_103</td>
        <td>31-03-22</td>
        <td>3248.17</td>
        <td>0</td>
        <td>08-PROV-21.22_PO_103</td>
        <td>0.00</td>
        <td></td>
        <td>Tds on AP accrual as on 31st March 2022</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>MANUAL INVOICE ENTRY</td>
        <td>DEBIT</td>
        <td></td>
        <td>2</td>
        <td>DEBIT MEMO VALIDATED</td>
        <td>MATCHED</td>
    </tr>
    <tr>
        <td>08</td>
        <td>Power</td>
        <td>20321</td>
        <td>Creditors For Goods - Domestic</td>
        <td>146491</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
        <td>DURGAPUR</td>
        <td>STD INV</td>
        <td>31-03-22</td>
        <td>4001135</td>
        <td>ERS-5000015144-1933076</td>
        <td>31-03-22</td>
        <td>0</td>
        <td>26432</td>
        <td>ERS-5000015144-1933076</td>
        <td>0.00</td>
        <td>PO-0000245527-Invoice</td>
        <td>Receipt Invoice automatically created on 31-MAR-22</td>
        <td>Transactions</td>
        <td>2021-04-01 00:00:00</td>
        <td>2022-03-31 00:00:00</td>
        <td>0.00</td>
        <td>ERS</td>
        <td>STANDARD</td>
        <td></td>
        <td>2</td>
        <td>INVOICE VALIDATED</td>
        <td>MATCHED</td>
    </tr>
</table>
  </div>
  )
}



export default ThermaxStatement;
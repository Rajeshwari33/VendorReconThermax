import React from "react";
// import React,{useEffect, useState} from 'react';

import "./etlsecound.css";
import { Icon, Input, Button,Dropdown, Grid, Popup,Segment,Select,Tab,Table,Menu , Form, TextArea, Label, Checkbox, GridColumn} from 'semantic-ui-react'

const options = [
    { key: 1, text: 'coloum 1', value: 1 },
    { key: 2, text: 'coloum 2', value: 2 },
    { key: 3, text: 'coloum 3', value: 3 },
    { key: 4, text: 'coloum 4', value: 4 },
    { key: 5, text: 'coloum 5', value: 5 },
    { key: 6, text: 'coloum 6', value: 6 },
  ]
  const options2 = [
    { key: 1, text: 'SBI 1', value: 1 },
    { key: 2, text: 'SBI 2', value: 2 },
    { key: 3, text: 'SBI 3', value: 3 },
    { key: 4, text: 'HDFC 4', value: 4 },
    { key: 5, text: 'ICICI 5', value: 5 },
    { key: 6, text: 'AXIS 6', value: 6 },
    { key: 7, text: 'AXIS 7', value: 7 },
  ]


const DropdownExampleMultipleSelection = (props) => (
  <Dropdown placeholder={props.filename} fluid multiple selection options={options} />
)
const DropdownExampleMultipleSelectionSource = (props) => (
  <Dropdown placeholder={props.filename} fluid multiple selection options={options2} />
)
const selectYes = [
    { key: 'af', value: 'af', text: 'Yes' },
    { key: 'ax', value: 'ax', text: 'No' },
   
  ]
  const selectType = [
    { key: 'af', value: 'af', text: '2 way' },
    { key: 'ax', value: 'ax', text: '3 way' },
    { key: 'ax', value: 'ax', text: 'Life Cycle' },

   
  ]
  const selectSource = [
    { key: 'af', value: 'af', text: 'Table name 1' },
    { key: 'ax', value: 'ax', text: 'Table name 2' },
    { key: 'ax', value: 'ax', text: 'Table name 3' },

   
  ]
  
  const SelectExample = (props) => (
    <Select placeholder={props.selectname} options={selectYes} />
  )
  
  const SelectType = (props) => (
    <Select placeholder={props.selectname} options={selectType} />
  )

  const SelectSource = (props) => (
    <Select placeholder={props.selectname} options={selectSource} />
  )

  const InputExampleIconPosition5 = () => (
    <Input icon='clipboard outline' iconPosition='left' placeholder='Enter Source Name' />
  )
  
  const ButtonExampleSocial = () => (
    <div>
      <Button color='#0A2352'>
        <Icon name='cogs' /> Configure Rule
      </Button>
    </div>
  )
  
class Etlrelation extends React.Component {

  

    render() {
        
      return (
        <div>
         {/* <h1>hi</h1> */}
         <div className="side">
         <Grid columns='equal' style={{ padding:"10px"}}>
              <Grid.Row style={{ backgroundColor:"#e9e8d9",borderRadius:"12px"}}>
              <Grid.Column>
                    <label>Source Name</label>
                    <InputExampleIconPosition5/>
                </Grid.Column>
                <Grid.Column>
                <label>Source Descriptions</label>
                <Form>
                    <TextArea placeholder='Tell us more' />
                </Form>
                </Grid.Column>
                <Grid.Column >
                    <label>Selection Type</label>
                    <SelectType selectname="Choose a type"/>
                </Grid.Column>
                <Grid.Column>
                    <label>Selection Source</label>
                    <SelectSource selectname="Choose a Source"/>
                </Grid.Column>
                <Grid.Column>
                    <label>Select Your Source</label>
                    <DropdownExampleMultipleSelectionSource filename="Choose your source"/>
                </Grid.Column>
                
                <Grid.Column>
                    <label>.</label>
                    <ButtonExampleSocial/>
                </Grid.Column>
             </Grid.Row>
                      
             <Grid.Row style={{ backgroundColor:"#e9e8d9",borderRadius:"12px",marginTop:"10px"}}>
                <Grid.Column style={{ height:"227px" , overflowY:"scroll"}}>
                  <table id="customers" style={{borderRadius: "15px"}}>
                      <tr>
                        <th><DropdownExampleMultipleSelection filename="SBI 1"/></th>
                        <th><DropdownExampleMultipleSelection filename="SBI 2"/></th>
                        <th><SelectExample selectname="Primary"/></th>
                        <th><SelectExample selectname="Tolernce"/></th>
                        <th><SelectExample selectname="Amount Tolernce"/></th>
                        <th><SelectExample selectname="Date Tolernce"/></th>

                      </tr>
                      <tr>
                        <th><DropdownExampleMultipleSelection filename="HDFC 1"/></th>
                        <th><DropdownExampleMultipleSelection filename="SBI 2"/></th>
                        <th><SelectExample selectname="Primary"/></th>
                        <th><SelectExample selectname="Tolernce"/></th>
                        <th><SelectExample selectname="Amount Tolernce"/></th>
                        <th><SelectExample selectname="Date Tolernce"/></th>
                      </tr>
                      <tr>
                        <th><DropdownExampleMultipleSelection filename="SBI 1"/></th>
                        <th><DropdownExampleMultipleSelection filename="SBI 398"/></th>
                        <th><SelectExample selectname="Primary"/></th>
                        <th><SelectExample selectname="Tolernce"/></th>
                        <th><SelectExample selectname="Amount Tolernce"/></th>
                        <th><SelectExample selectname="Date Tolernce"/></th>
                      </tr>
                      <tr>
                        <th><DropdownExampleMultipleSelection filename="AXIS 1"/></th>
                        <th><DropdownExampleMultipleSelection filename="ICICI"/></th>
                        <th><SelectExample selectname="Primary"/></th>
                        <th><SelectExample selectname="Tolernce"/></th>
                        <th><SelectExample selectname="Amount Tolernce"/></th>
                        <th><SelectExample selectname="Date Tolernce"/></th>
                      </tr>
                      
                    </table>
                  </Grid.Column>
                  
             </Grid.Row>
             

          </Grid>
  
  
         </div>
        </div>
      );
    }
  }
  
  export default Etlrelation;
  
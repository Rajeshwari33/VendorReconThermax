import React, { useState, useEffect, useRef } from 'react';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-balham.css';
import { AgGridReact } from 'ag-grid-react';
import LoaderComponent from "../../../libraries/loader/loader";
import Paper from '@mui/material/Paper';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TablePagination from '@mui/material/TablePagination';
import TableRow from '@mui/material/TableRow';
// import Button from 'react-bootstrap/Button'; getSingleMailSentFromServer
import { getSingleMailSentFromServer, getClientNameFromServer, port, fetchProcessedEmailsList, deactivateemailid, activateemailid } from '../../../services/process/medical-insurance/medicalInsuranceReportService';
import Modal from 'react-bootstrap/Modal';
import { Form, Input, Button, Grid, Checkbox } from 'semantic-ui-react';
import axios from 'axios';
import Select, { AriaOnFocus } from 'react-select';
import { baseUrl } from "../../../services/common/credentials";

import excelIcon from '../../../assets/images/excel.png';
import * as XLSX from 'xlsx';




var selectedOptionss;
var col_data = new Array();
const localhost_url = baseUrl + port;

const CustomAriaLive = ({ data }) => {

  const [isMenuOpen, setIsMenuOpen] = useState(false);
  // const [value, setValue] = useState(undefined);
  const onMenuOpen = () => setIsMenuOpen(true);
  const onMenuClose = () => setIsMenuOpen(false);

  const selectedOption = (e) => {
    // selectedOption.pop();
    // selectedOptionss=[];
    selectedOptionss = e;
    console.log('clicked', e);
  }
  // const Options = [
  //   {value:"1", label:"anh"},
  //   {value:"2", label:"ank"},
  //   {value:"3", label:"an123"},
  //   {value:"4", label:"anhjhg"}
  // ]

  return (
    <form>
      <Select
        aria-labelledby="aria-label"
        inputId="aria-example-input"
        name="aria-live-color"
        onMenuOpen={onMenuOpen}
        onMenuClose={onMenuClose}
        options={data}
        onChange={e => selectedOption(e)}

      />
    </form>
  );
}


function EmailsList() {
  // const [paginationSize] = useState(15);
  const [loaderOpen, setLoaderOpen] = useState(false);
  const [hideResultGrid, setHideResultGrid] = useState(true);
  const [rowData, setRowData] = useState([]);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const [formValues, setFormValues] = useState({ id: "", client_id: "", client_name: "", email_address: "" });
  const [show, setShow] = useState(false);
  const [show1, setShow1] = useState(false);
  const [show2, setShow2] = useState(false);
  const [show3, setShow3] = useState(false);
  // const [filteredData, setFilteredData] = useState(undefined);
  // const [tenantId, settenantId] = useState(undefined);
  const [formCreate, setFormCreate] = useState(true);
  const [options, setOptions] = useState(undefined);
  const [fromDate, setFromDate] = useState(undefined);
  const [toDate, setToDate] = useState(undefined);
  const [date, setDate] = useState(undefined);
  // const [checkbox, setCheckbox] = useState(false);
  const [selectedColumns, setSelectedColumns] = useState({});
  const ref = useRef([]);
  const [userCredentials] = useState(JSON.parse(sessionStorage.getItem("userCredentials")));

  const [rowData1, setRowData1] = useState([]);
  const [hideResultGrid1, setHideResultGrid1] = useState(true);

  var gridColumns = [
       
    { field: 'client_id', headerName: 'client_id', sortable: true, filter: true, resizable: true},
    { field: 'client_name', headerName: 'client_name', sortable: true, filter: true, resizable: true},
    { field: 'email_address', headerName: 'email_address', sortable: true, filter: true, resizable: true},
    
    { field: 'last_send_on', headerName: 'last_send_on', sortable: true, filter: true, resizable: true},
    { field: 'is_active', headerName: 'is_active', sortable: true, filter: true, resizable: true},
    { field: 'processed_date', headerName: 'processed_date', sortable: true, filter: true, resizable: true},
    
    
  ]


  const columns = [
    // { id: 'all', label: 'all', minWidth: 10 },
    { id: 'id', label: 'id', minWidth: 10 },
    { id: 'client_id', label: 'client_id', minWidth: 10 },
    { id: 'client_name', label: 'client_name', minWidth: 10 },
    {
      id: 'email_address',
      label: 'email_address',
      minWidth: 10
    },
    {
      id: 'actions',
      label: 'actions',
      minWidth: 10
    },

  ];


  function getClientdata() {
    setLoaderOpen(true);
    let payload = {
      'entities_id': userCredentials["entities_id"],
    }

    var getclientdetails = getClientNameFromServer();

    axios.post(getclientdetails[1], payload, getclientdetails[0])
      .then(
        response => {
          console.log(" get client data Response!!!", response)
          let data = response["data"];
          // setRowData(data);
          console.log('data', data);
          let options = [{ value: "ALL", label: "ALL" }];
          data.map(data => {
            console.log('{value:"1", label:"anh"},{id: 1, client_id: "vgfd", client_name: "ramu"}', data);
            options.push({ value: data.client_name, label: data.client_id })
          })
          console.log(options);
          setOptions(options);
          setLoaderOpen(false);
        }
      ).catch(
        error => {
          console.log("Error in get client details!!!", error);
          setLoaderOpen(false);
        }
      );

  }


  useEffect(() => {
    setLoaderOpen(false);
    // let url = `http://127.0.0.1:8002/api/v2/alcs/emails_list/`;
    // makeAPICall(url);
    getClientdata();
  }, []);

  // const makeAPICall = async (url) => {
  //   try {
  //     setLoaderOpen(true);
  //     console.log(url);
  //     const response = await fetch(url);
  //     const data = await response.json();
  //     // setRowData(data);
  //     console.log('data', data);
  //     let options = [{value:"ALL", label:"ALL"}];
  //     data.map(data =>{
  //       console.log('{value:"1", label:"anh"},{id: 1, client_id: "vgfd", client_name: "ramu"}', data);
  //       options.push({value:data.client_name, label:data.client_id})
  //     })
  //     console.log(options);
  //     setOptions(options)
  //     setLoaderOpen(false);
  //   }
  //   catch (e) {
  //     console.log(e);
  //     setLoaderOpen(false);

  //   }
  // }

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(+event.target.value);
    setPage(0);
  };

  const EditActions = ({ row }) => {
    setFormCreate(false);
    setShow(true);
    setFormValues({ id: row.id, client_id: row.client_id, client_name: row.client_name, email_address: row.email_address });
  };


  const handleClose = () => {
    setFormValues({ id: "", client_id: "", client_name: "", email_address: "" });
    setShow(false);
    setShow1(false);
    setShow2(false);
    setShow3(false);
  };

  const handleChange = (e) => {

    setFormValues({
      ...formValues,
      [e.target.name]: e.target.value
    })
  }

  let handleSubmit = (event) => {
    event.preventDefault();
    if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(formValues.email_address)) {
      alert('Invalid email address')
    } else {
      let url;

      let data = {
        'tenants_id': userCredentials["tenants_id"],
        'groups_id': userCredentials["groups_id"],
        'entities_id': userCredentials["entities_id"],
        'user_id': userCredentials["user_id"],
        'client_id': formValues.client_id,
        'client_name': formValues.client_name,
        'email_address': formValues.email_address,
        'is_active': 'yes',
      }

      if (formCreate == true) {
        url = localhost_url + `/api/v2/alcs/createmail/`;
      } else {
        url = localhost_url + `/api/v2/alcs/updateemails/${formValues.id}/`;
      }
      console.log('userCredentials["tenants_id"]', userCredentials["tenants_id"]);


      fetch(url, {
        method: 'POST',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
      }).then((result) => {
        result.json().then((resp) => {
          console.log(resp);
          if (formCreate == true) {
            setFormValues({ id: "", client_id: "", client_name: "", email_address: "" });
            setFormCreate(true);
            setShow(false);
            setShow2(true);
            let value = selectedOptionss.label;
            console.log('selectedOptionss', selectedOptionss);
            let url = localhost_url + `/api/v2/alcs/filteremails/${value}/`;
            makeAPICall1(url);
          } else {
            if (resp == 'updated successfully' || resp == 'created successfully') {
              setFormValues({ id: "", client_id: "", client_name: "", email_address: "" });
              setFormCreate(true);
              setShow(false);
              let value = selectedOptionss.label;
              console.log('selectedOptionss', selectedOptionss);
              let url = localhost_url + `/api/v2/alcs/filteremails/${value}/`;
              makeAPICall1(url);
            }
          }
        })
      })
    }
  }

  // const handleFilterChange = (value) => {
  //   settenantId(value);
  //   if (value) {
  //     let url = `http://127.0.0.1:8000/api/v2/user_modules/filteremails/${value}/`;
  //     makeAPICall(url);
  //   }
  // };

  const displayDialogbox = () => {
    setFormValues({ id: '', client_id: selectedOptionss.label, client_name: selectedOptionss.value, email_address: '' });
    setFormCreate(true);
    setShow(true);
  }

  const makeAPICall1 = async (url) => {
    try {
      setLoaderOpen(true);
      console.log(url);
      const response = await fetch(url);
      const data = await response.json();
      setRowData(data);
      console.log('data', data);

      setHideResultGrid(false);
      setHideResultGrid1(true);
      setLoaderOpen(false);
    }
    catch (e) {
      console.log(e);
      setHideResultGrid1(true);
      setHideResultGrid(true);
      setLoaderOpen(false);
      
    }
  }

  const viewTable = () => {
    let value = selectedOptionss.label;
    let entities_id = userCredentials["entities_id"];
    console.log('selectedOptionss', selectedOptionss);
    let url = localhost_url + `/api/v2/alcs/filteremails/?type=${value}&&entities_id=${entities_id}`;
    makeAPICall1(url);
    // setHideResultGrid(true);
  }


  function handleDropdownChange(event, item) {
    console.log('data' + event);

    if (event.target.checked == false) {
      // setCheckbox(false);
      // setSelectedColumns({});
      // col_data.remove(item);
      const index = col_data.indexOf(item);
      col_data.splice(index, 1);
    }
    else if (event.target.checked) {
      col_data.push(item);

    }
    console.log('123' + col_data);
  }


  const Unchecked = (event) => {

    if (event.target.checked == false) {
      for (let i = 0; i < rowData.length; i++) {
        ref.current[i].checked = false;
      }
      rowData.map(data => {
        col_data.push(data);
      })
    } else {
      for (let i = 0; i < rowData.length; i++) {
        ref.current[i].checked = true;
      }
      col_data = [];
    }
  }
  const DeleteEmails = () => {
    setShow1(true);
  }

  const DeleteEmails1 = () => {
    console.log('col_data', col_data);
    col_data.map(id => {
      axios.delete(localhost_url + `/api/v2/alcs/deletemails/${id}/`)
        .then(res => {
          console.log(res);
          console.log(res.data);
          let value = selectedOptionss.label;
          console.log('selectedOptionss', selectedOptionss);
          let url = localhost_url + `/api/v2/alcs/filteremails/${value}/`;
          makeAPICall1(url);
        });
    })
    setShow1(false);
  }



  // const sendemails = async () =>{
  //   let value = selectedOptionss.label;
  //   console.log('selectedOptionss', selectedOptionss);
  //   let url = `http://127.0.0.1:8002/api/v2/alcs/filteremails/${value}/`;
  //   // makeAPICall1(url);
  //   try {
  //     setLoaderOpen(true);
  //     console.log(url);
  //     const response = await fetch(url);
  //     const data = await response.json();
  //     // setRowData(data);
  //     // console.log('data', data);
  //     let data1 = [];
  //     data.map(data =>{
  //       data1.push(data.email_address)
  //     })
  //     let url1 = `http://127.0.0.1:50010/api/v1/alcs/common/alcs_clent_mail_sent_revised/`;
  //     fetch(url1, {
  //       method: 'POST',
  //       headers: {
  //         'Accept': 'application/json',
  //         'Content-Type': 'application/json'
  //       },
  //       body: JSON.stringify(data1)
  //     }).then((result) => {
  //       result.json().then((resp) => {
  //       console.log(resp); 
  //       })
  //     })

  //     setLoaderOpen(false);
  //   }
  //   catch (e) {
  //     console.log(e);
  //     setLoaderOpen(false);
  //   }

  // };



  function sendemails() {
    setLoaderOpen(true);
    let payload = {
      "payment_from_date": fromDate,
      "payment_to_date": toDate,
      "client_id": selectedOptionss.label,
      "report_date": date,
      'entities_id': userCredentials["entities_id"],
    }
    console.log('payload', payload);

    var getSingleMailSent = getSingleMailSentFromServer();

    axios.post(getSingleMailSent[1], JSON.stringify(payload), getSingleMailSent[0])
      .then(
        response => {
          console.log("Mail Sent Response!!!", response)
          let data = response["data"];
          if (data["Status"] === "Success") {
            alert("Mail Sent Successfully!!!");
            setLoaderOpen(false);
            
          }
          else if (data["Status"] === "Unsuccess") {
            alert("Client Id Not Found!!!");
            setLoaderOpen(false);
            
          }
        }
      ).catch(
        error => {
          console.log("Error in File Upload List!!!", error);
          setLoaderOpen(false);
          setHideResultGrid(true);
          setHideResultGrid1(true);
        }
      );

  }

  function get_report() {
    setLoaderOpen(true);
    let payload = {
      "client_id": selectedOptionss.label,
      "report_date": date,
      'entities_id': userCredentials["entities_id"],
    }
    console.log('payload', payload);

    var getSingleMailSent = fetchProcessedEmailsList();

    axios.post(getSingleMailSent[1], payload, getSingleMailSent[0])
      .then(
        response => {
          console.log("fetch processed emails list", response)
          let data = response["data"];
          if (data && data.hasOwnProperty('Status') && data['Status'] == 'Error') {
            setHideResultGrid(true);
            setHideResultGrid1(true);
            setLoaderOpen(false);
          }
          else {
            setRowData1(data);
            setHideResultGrid1(false);
            setHideResultGrid(true);
            setLoaderOpen(false);
          }
          
        }
      ).catch(
        error => {
          console.log("Error in Fetching processed emails list", error);
          setLoaderOpen(false);
        }
      );

  }

  const displaySendEmail = () => {
    setShow3(true);
  }

  function exportJsonToXLSX(data, sheetName, excelFileName) {
    try {
        var workBook = XLSX.utils.book_new();
        var workSheet = XLSX.utils.json_to_sheet(data, {
            skipHeader: false,
        });
        XLSX.utils.book_append_sheet(workBook, workSheet, sheetName);
        XLSX.writeFile(workBook, excelFileName);
        return true;
    }
    catch
    {
        return false;
    }
}

function exportToExcel() {
    let fileNameChange = "emailsReport.xlsx";
    let sheetName = "sheet";

    let excelExportData = [];

    for (let i = 0; i < rowData1.length; i++) {
        let data = {};
        for (let key in rowData1[i]) {
            for (let j = 0; j < gridColumns.length; j++) {
                if (key === gridColumns[j]["field"]) {
                    data[gridColumns[j]["headerName"]] = rowData1[i][key]
                }
            }
        }

        excelExportData.push(data);
    };

    exportJsonToXLSX(excelExportData, sheetName, fileNameChange);

}

  // const HandleSubmitEmail = () => {
  //   let data = [];

  //   rowData.map(data =>{
  //     data.push(data.email_address)
  //   })
  //   console.log('email submit');
  //   let url = `http://127.0.0.1:50010/api/v1/alcs/common/alcs_clent_mail_sent_revised/`;
  //     fetch(url, {
  //       method: 'POST',
  //       headers: {
  //         'Accept': 'application/json',
  //         'Content-Type': 'application/json'
  //       },
  //       body: JSON.stringify(data)
  //     }).then((result) => {
  //       result.json().then((resp) => {
  //       console.log(resp); 
  //       })
  //     })
  // }

  const deactivateEmailId = ({row}) => {
    // setLoaderOpen(true);
    let payload = {
      'id': row.id,
      'entities_id': userCredentials["entities_id"],
      'tenants_id': userCredentials["tenants_id"],
    }
    console.log('payload', payload);

    var getSingleMailSent = deactivateemailid();

    axios.post(getSingleMailSent[1], payload, getSingleMailSent[0])
      .then(
        response => {
          console.log("fetch processed emails list", response);    
          
        }
      ).catch(
        error => {
          console.log("Error in Fetching processed emails list", error);
          // setLoaderOpen(false);
        }
      );
  }

  const activateEmailId = ({row}) => {
    // setLoaderOpen(true);
    let payload = {
      'id': row.id,
      'entities_id': userCredentials["entities_id"],
      'tenants_id': userCredentials["tenants_id"],
    }
    console.log('payload', payload);

    var getSingleMailSent = activateemailid();

    axios.post(getSingleMailSent[1], payload, getSingleMailSent[0])
      .then(
        response => {
          console.log("fetch processed emails list", response);    
          
        }
      ).catch(
        error => {
          console.log("Error in Fetching processed emails list", error);
          // setLoaderOpen(false);
        }
      );
  }

  return (
    <>
      <div className="side" style={{ padding: "10px" }}>
        <Grid columns='equal'>
          <Grid.Row style={{ backgroundColor: "#e9e8d9", borderRadius: "12px", marginTop: "10px" }}>
            <Grid.Column>
              <CustomAriaLive data={options} />
            </Grid.Column>
            <Grid.Column style={{ width: '12em' }}>
              <Input type="date" onChange={e => setDate(e.target.value)} />
            </Grid.Column>
            <Grid.Column style={{ width: '12em' }}>
              <Button variant="contained" color="primary" type="button" onClick={viewTable}>View</Button>
            </Grid.Column>
            <Grid.Column style={{ marginLeft: '-13em' }}>
              <Button variant="contained" color="primary" type="button" onClick={displaySendEmail}>Send Email</Button>
            </Grid.Column>
            <Grid.Column>
              <Button variant="contained" color="primary" type="button" onClick={displayDialogbox}>Add</Button>
            </Grid.Column>

            <Grid.Column>
              <Button variant="contained" color="primary" type="button" onClick={get_report}>Get Report</Button>
            </Grid.Column>
          </Grid.Row>

          <Button variant="contained" color="primary" type="button" style={{ float: 'right', marginTop: '1.2em' }} onClick={DeleteEmails} hidden={hideResultGrid}>Delete</Button>
          <Grid.Row style={{ backgroundColor: "#e9e8d9", borderRadius: "12px", marginTop: "2.3em" }} hidden={hideResultGrid}>
            <Paper sx={{ width: '97%', overflow: 'hidden', marginLeft: '1em' }}>
              <TableContainer sx={{ maxHeight: 260 }} style={{ width: '102%', marginLeft: '-0.8em' }}>
                <Table stickyHeader aria-label="sticky table">
                  <TableHead>
                    <TableRow style={{ backgroundColor: 'rgb(233, 232, 217)' }}>
                      <TableCell
                        key={'all'}
                        align={'all'}
                        class="header_column"
                      >
                        <input
                          type="checkbox"
                          onChange={(event) => Unchecked(event)}
                          value='All'
                          name='All'
                          id="All"
                        />
                      </TableCell>
                      {columns.map((column) => (
                        <TableCell
                          key={column.id}
                          align={column.align}
                          class="header_column"
                        >
                          {column.label}
                        </TableCell>
                      ))}
                    </TableRow>
                  </TableHead>
                  <TableBody>

                    {rowData && rowData
                      .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                      .map((row, index) => {
                        return (
                          <TableRow hover role="checkbox" tabIndex={-1} key={index}>
                            <TableCell className="cell_data">
                              <input
                                type="checkbox"
                                onChange={(event) => handleDropdownChange(event, row.id)}
                                value={row.id}
                                name={row.id}
                                ref={(element) => { ref.current[index] = element }}
                                id={index}
                              />
                            </TableCell>
                            <TableCell className="cell_data"> {row.id}</TableCell>
                            <TableCell className="cell_data"> {row.client_id}</TableCell>
                            <TableCell className="cell_data"> {row.client_name}</TableCell>
                            <TableCell className="cell_data"> {row.email_address}</TableCell>
                            <TableCell className="cell_data">
                              <span onClick={e => EditActions({ row })}><ion-icon size="small" name="create-outline" style={{ 'color': 'black' }}></ion-icon></span>
                              {row && row.is_active ? 
                              (<>
                                <Button variant="contained" color="primary" type="button" style={{ marginLeft: '1em' }} onClick={e => deactivateEmailId({ row })}>deactive</Button>
                              </>):(
                                <>
                                <Button variant="contained" color="primary" type="button" style={{ marginLeft: '1em' }} onClick={e => activateEmailId({ row })}>active</Button>
                                </>
                              )
                                }
                              {/* <span style={{ marginLeft: '1em' }} onClick={e => DeleteActions({ row })}><i class='fa fa-trash-o'></i></span> */}
                            </TableCell>
                          </TableRow>
                        );
                      })}

                  </TableBody>
                </Table>
              </TableContainer>
              <TablePagination
                rowsPerPageOptions={[5, 10]}
                component="div"
                count={rowData?.length}
                rowsPerPage={rowsPerPage}
                page={page}
                onPageChange={handleChangePage}
                onRowsPerPageChange={handleChangeRowsPerPage}
              />
            </Paper>

            <Modal
              show={show}
              onHide={handleClose}
              backdrop="static"
              keyboard={false}
            >
              <Modal.Header closeButton>
                <Modal.Title>Emails Add/Update</Modal.Title>
              </Modal.Header>
              <Modal.Body>
                <Form>
                  {/* <Form.Field style={{marginBottom:'0em'}}>
            <label>id</label>
          <input type="text" name="id" value={formValues && formValues.id || ""} disabled={true} /><br /> <br />
            </Form.Field> */}
                  <Form.Field style={{ marginBottom: '0em' }}><label>Client id</label>
                    {formCreate ? <input type="text" disabled={true} name="client_id" value={formValues && formValues.client_id || ""} onChange={e => handleChange(e)} /> :
                      <input type="text" required name="client_id" value={formValues && formValues.client_id || ""} onChange={e => handleChange(e)} />}

                  </Form.Field>
                  <Form.Field style={{ marginBottom: '0em' }}>
                    <label>Client Name</label>
                    {formCreate ? <input type="text" disabled={true} name="client_name" value={formValues && formValues.client_name || ""} onChange={e => handleChange(e)} /> :
                      <input type="text" required name="client_name" value={formValues && formValues.client_name || ""} onChange={e => handleChange(e)} />}

                  </Form.Field>
                  <Form.Field style={{ marginBottom: '0em' }}>
                    <label >Email Id</label>
                    <input type="email" required name="email_address" value={formValues && formValues.email_address || ""} onChange={e => handleChange(e)} /><br /><br />
                  </Form.Field>

                </Form>
              </Modal.Body>
              <Modal.Footer>
                <Button variant="secondary" onClick={handleClose}>
                  Close
                </Button>
                {formCreate ? <Button type='submit' onClick={handleSubmit}>Save</Button> :
                  <Button type='submit' onClick={handleSubmit}>Update</Button>}
              </Modal.Footer>
            </Modal>

            <Modal
              show={show1}
              onHide={handleClose}
              backdrop="static"
              keyboard={false}
            >
              <Modal.Header closeButton>
                <Modal.Title>Delete Emails list</Modal.Title>
              </Modal.Header>
              <Modal.Body>
                <p>Are you sure you want to delete !!!</p>
              </Modal.Body>
              <Modal.Footer>
                <Button variant="secondary" onClick={handleClose}>
                  Cancel
                </Button>

                <Button type='submit' onClick={DeleteEmails1}>Ok</Button>
              </Modal.Footer>
            </Modal>
            <Modal
              show={show3}
              onHide={handleClose}
              backdrop="static"
              keyboard={false}
            >
              <Modal.Header closeButton>
                <Modal.Title> Send Emails List</Modal.Title>
              </Modal.Header>
              <Modal.Body>
                <Form>
                  <Form.Field style={{ marginBottom: '0em' }}>
                    <label>From Date</label>
                    <input type="date" required name="from_date" value={fromDate} onChange={e => setFromDate(e.target.value)} />
                  </Form.Field>
                  <Form.Field style={{ marginBottom: '0em' }}>
                    <label>To Date</label>
                    <input type="date" required name="to_date" value={toDate} onChange={e => setToDate(e.target.value)} />
                  </Form.Field>
                </Form>
              </Modal.Body>
              <Modal.Footer>
                <Button variant="secondary" onClick={handleClose}>
                  Cancel
                </Button>
                <Button type='submit' onClick={sendemails}>Send</Button>
              </Modal.Footer>
            </Modal>
            <Modal
              show={show2}
              onHide={handleClose}
              backdrop="static"
              keyboard={false}
            >
              <Modal.Header closeButton>
                <Modal.Title>Add Email</Modal.Title>
              </Modal.Header>
              <Modal.Body>
                <p>Email is added successfully !!!</p>
              </Modal.Body>
              <Modal.Footer>
                <Button variant="secondary" onClick={handleClose}>
                  Ok
                </Button>
              </Modal.Footer>
            </Modal>
            
          </Grid.Row>

        </Grid>
      </div>


      {/* <form onSubmit={handleSubmit} style={{ justifyContent: 'center', marginLeft: '25em', marginTop: '2em' }}>

        <div className="form-inline">

         

          <label className="label">Tenant_id:</label>
          <input type="text" name="tenant_id" value={formValues && formValues.tenant_id || ""} onChange={e => handleChange(e)} /><br /> <br />

          <label className="label">mail Id:</label>
          <input type="text" name="mail_id" value={formValues && formValues.mail_id || ""} onChange={e => handleChange(e)} /><br /><br />

          <br /><br />
        </div>

        <div className="button-section">
          {formCreate ? <Button variant="contained" color="primary" type="submit" style={{ marginLeft: '6em' }}>Create</Button> :
            <Button variant="contained" color="primary" type="submit" style={{ marginLeft: '6em' }}>Save</Button>}
        </div>
      </form> */}

      {/* <div style={{ marginTop: '1em', marginLeft: '1em', marginBottom: '1em' }}>
        <Input
          type="text"
          value={tenantId}
          onChange={e => handleFilterChange(e.target.value)}
          placeholder="Filter by tenant id"
        />
      </div> */}
    <div className="report" hidden={hideResultGrid1}>
      <img src={excelIcon} alt="No Images" style={{ width: '40px', height: '37px' }} className="excel-icon-class" onClick={() => { exportToExcel() }} title="Export" />
    </div>
  <div className="ag-theme-balham report-layer" style={{width:'100%', heidght:'100%'}} hidden={hideResultGrid1}>
                    <AgGridReact
                        columnDefs={gridColumns}
                        rowData={rowData1}
                        paginationPageSize={20}
                        pagination={true}
                        animateRows={true}
                        rowSelection={'multiple'}
                        groupSelectsChildren={true}
                        
                        suppressAggAtRootLevel={true}
                        suppressRowClickSelection={true}
                        
                    >
                    </AgGridReact>
                </div>
                <LoaderComponent loaderOpen={loaderOpen} />
    </>
  );
}


export default EmailsList;


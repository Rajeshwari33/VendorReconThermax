import React from "react";

function ForgotPassword()
{
    return (
        <h2>Forgot Password!!!</h2>
    );
}

export default ForgotPassword;
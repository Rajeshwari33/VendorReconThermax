import React, { useState, useMemo } from 'react';
// import Select from "react-select";
// import './dashboard.css';
import './gst.css';
import axios from 'axios';
import { monthWiseGstToServer } from '../../../../services/process/migrations/migrationService.js';
import { Select, Dropdown } from 'semantic-ui-react';
import ReactApexChart from 'react-apexcharts';
import { BarChart, Bar, XAxis, YAxis, Legend, Tooltip } from 'recharts';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';


function GST({ hidden }) {
  const processedList = [{ "source_name": 'Invoice_Salary_Report_CM' }]
  const pendingList = [{ "source_name": 'Invoice_Salary_Report_CM' }]
  const [gstHidden, setGstHidden] = useState(true);
  const [inputMonth, setInputMonth] = useState(undefined);
  const [inputMonth1, setInputMonth1] = useState(undefined);
  const [show, setshow] = useState(false);

  const [rowData, setrowData] = useState([{ "customer": "CS0034", "Gross-value": 126248498 }, { "customer": "CN0068", "Gross-value": 86548622 }, { "customer": "cm0004", "Gross-value": 77441605 }, { "customer": "CE0002", "Gross-value": 63655956 },]);
  const [columnames, setcolumnnames] = useState(null);

  const [filtervalue, setfiltervalue] = useState(undefined);
  const [reports, setreports] = useState(undefined);
  const customStyles = undefined;

  const [customers, setcustomers] = useState([]);
  const [grossValues, setgrossValues] = useState([]);
  const [grossValues1, setgrossValues1] = useState([]);
  const [issalestrends, setissalestrends] = useState(false);
  const [isfilterHidden, setisfilterHidden] = useState(false);


  const customer = [{ "customer": "CS0034", "Gross-value": 126248498 }, { "customer": "CN0068", "Gross-value": 86548622 }, { "customer": "cm0004", "Gross-value": 77441605 }, { "customer": "CE0002", "Gross-value": 63655956 }, { "customer": "CU0042", "Gross-value": 54855521 }, { "customer": "CJ0097", "Gross-value": 48320679 }, { "customer": "CC0103", "Gross-value": 35777712 }, { "customer": "CM0210", "Gross-value": 31875460 }, { "customer": "CI0077", "Gross-value": 28272840 }, { "customer": "CJ0128", "Gross-value": 27492228 }, { "customer": "CM0163", "Gross-value": 25251375 }, { "customer": "cm0210", "Gross-value": 25024013 }, { "customer": "CM0004", "Gross-value": 22899282 }, { "customer": "cm0226", "Gross-value": 22735850 }, { "customer": "cm0163", "Gross-value": 22191865 }, { "customer": "CC0118", "Gross-value": 17609646 }, { "customer": "cm0053", "Gross-value": 17571316 }, { "customer": "cm0219", "Gross-value": 17257134 }, { "customer": "CH0008", "Gross-value": 16566002 }, { "customer": "CC0064", "Gross-value": 16537128 }, { "customer": "cm0165", "Gross-value": 16504746 }, { "customer": "CM0053", "Gross-value": 15503183 }, { "customer": "CK0128", "Gross-value": 15265641 }, { "customer": "cs0034", "Gross-value": 14631332 }, { "customer": "CA0008", "Gross-value": 14486831 }, { "customer": "CE0007", "Gross-value": 12206339 }, { "customer": "CM0226", "Gross-value": 10384627 }, { "customer": "CH0166", "Gross-value": 9378105 }, { "customer": "CS0003", "Gross-value": 9141132 }, { "customer": "CD0098", "Gross-value": 8658964 }, { "customer": "CC0119", "Gross-value": 7907280 }, { "customer": "CV0067", "Gross-value": 7817317 }, { "customer": "CV0143", "Gross-value": 7582000 }, { "customer": "CA0127", "Gross-value": 6981285 }, { "customer": "CT0006", "Gross-value": 6753964 }, { "customer": "CC0150", "Gross-value": 6180706 }, { "customer": "CM0231", "Gross-value": 5935355 }, { "customer": "cs0003", "Gross-value": 5667830 }, { "customer": "CD0072", "Gross-value": 5503258 }, { "customer": "CN0067", "Gross-value": 5502082 }, { "customer": "CK0123", "Gross-value": 5420820 }, { "customer": "CD0001", "Gross-value": 5319692 }, { "customer": "CD0065", "Gross-value": 5006098 }, { "customer": "CM0049", "Gross-value": 4923850 }, { "customer": "ck0128", "Gross-value": 4814163 }, { "customer": "CC0152", "Gross-value": 4798985 }, { "customer": "CJ0069", "Gross-value": 4635720 }, { "customer": "CJ0133", "Gross-value": 4418987 }, { "customer": "CS0332", "Gross-value": 4391936 }, { "customer": "CS0224", "Gross-value": 4288583 }, { "customer": "cg0159", "Gross-value": 4212340 }, { "customer": "CF0045", "Gross-value": 4177258 }, { "customer": "CG0159", "Gross-value": 4150696 }, { "customer": "cm0016", "Gross-value": 4049568 }, { "customer": "CC0073", "Gross-value": 3652974 }, { "customer": "CC0002", "Gross-value": 3614992 }, { "customer": "CK0108", "Gross-value": 3607740 }, { "customer": "CR0012", "Gross-value": 3429245 }, { "customer": "CK0126", "Gross-value": 3335735 }, { "customer": "cv0067", "Gross-value": 3330932 }, { "customer": "CG0157", "Gross-value": 3307983 }, { "customer": "CN0098", "Gross-value": 3266737 }, { "customer": "CS0390", "Gross-value": 2988668 }, { "customer": "CA0001", "Gross-value": 2923003 }, { "customer": "CS0444", "Gross-value": 2880023 }, { "customer": "ck0123", "Gross-value": 2875800 }, { "customer": "CA0018", "Gross-value": 2839072 }, { "customer": "CG0001", "Gross-value": 2785777 }, { "customer": "ce0002", "Gross-value": 2563312 }, { "customer": "CN0042", "Gross-value": 2543110 }, { "customer": "CA0223", "Gross-value": 2521650 }, { "customer": "CR0001", "Gross-value": 2453840 }, { "customer": "CA0020", "Gross-value": 2407732 }, { "customer": "CA0309", "Gross-value": 2369195 }, { "customer": "CM0008", "Gross-value": 2349665 }, { "customer": "CG0148", "Gross-value": 2196206 }, { "customer": "CA0198", "Gross-value": 2194970 }, { "customer": "CB0121", "Gross-value": 2143800 }, { "customer": "CJ0003", "Gross-value": 2100667 }, { "customer": "CS0035", "Gross-value": 2095860 }, { "customer": "cp0008", "Gross-value": 2093367 }, { "customer": "CG0079", "Gross-value": 2085579 }, { "customer": "ch0169", "Gross-value": 2027000 }, { "customer": "CE0092", "Gross-value": 1968445 }, { "customer": "CD0099", "Gross-value": 1953236 }, { "customer": "cm0049", "Gross-value": 1779094 }, { "customer": "CV0151", "Gross-value": 1778164 }, { "customer": "CP0017", "Gross-value": 1701475 }, { "customer": "CD0002", "Gross-value": 1676772 }, { "customer": "cw0031", "Gross-value": 1648080 }, { "customer": "CM0164", "Gross-value": 1631221 }, { "customer": "CN0063", "Gross-value": 1600665 }, { "customer": "ce0078", "Gross-value": 1586640 }, { "customer": "CB0032", "Gross-value": 1543360 }, { "customer": "cd0128", "Gross-value": 1530000 }, { "customer": "cs0224", "Gross-value": 1506370 }, { "customer": "CI0074", "Gross-value": 1484142 }, { "customer": "CC0089", "Gross-value": 1483967 }, { "customer": "CS0474", "Gross-value": 1483919 }, { "customer": "CD0011", "Gross-value": 1449778 }, { "customer": "CS0008", "Gross-value": 1449543 }, { "customer": "ca0096", "Gross-value": 1435000 }, { "customer": "CJ0146", "Gross-value": 1390640 }, { "customer": "ca0001", "Gross-value": 1383866 }, { "customer": "ck0126", "Gross-value": 1351025 }, { "customer": "CC0004", "Gross-value": 1333410 }, { "customer": "CM0106", "Gross-value": 1252240 }, { "customer": "CR0002", "Gross-value": 1212653 }, { "customer": "ce0007", "Gross-value": 1190800 }, { "customer": "CH0009", "Gross-value": 1182931 }, { "customer": "CD0100", "Gross-value": 1182832 }, { "customer": "CT0054", "Gross-value": 1175670 }, { "customer": "CK0129", "Gross-value": 1140450 }, { "customer": "ch0008", "Gross-value": 1139068 }, { "customer": "ca0004", "Gross-value": 1114437 }, { "customer": "ce0021", "Gross-value": 1096290 }, { "customer": "CA0004", "Gross-value": 1085962 }, { "customer": "CC0093", "Gross-value": 1044870 }, { "customer": "cm0225", "Gross-value": 1037782 }, { "customer": "CS0006", "Gross-value": 1035111 }, { "customer": "cd0001", "Gross-value": 1033329 }, { "customer": "CJ0138", "Gross-value": 1032460 }, { "customer": "cg0079", "Gross-value": 1028567 }, { "customer": "cn0042", "Gross-value": 1003510 }, { "customer": "cd0011", "Gross-value": 999942 }, { "customer": "CS0472", "Gross-value": 998123 }, { "customer": "CV0068", "Gross-value": 992881 }, { "customer": "cn0098", "Gross-value": 978691 }, { "customer": "CS0032", "Gross-value": 968395 }, { "customer": "cv0151", "Gross-value": 948238 }, { "customer": "CV0001", "Gross-value": 936640 }, { "customer": "CP0165", "Gross-value": 923374 }, { "customer": "CD0135", "Gross-value": 874355 }, { "customer": "CN0112", "Gross-value": 873600 }, { "customer": "ca0223", "Gross-value": 834750 }, { "customer": "CB0008", "Gross-value": 834470 }, { "customer": "CD0017", "Gross-value": 810162 }, { "customer": "CT0106", "Gross-value": 802920 }, { "customer": "cl0016", "Gross-value": 766180 }, { "customer": "CA0096", "Gross-value": 763050 }, { "customer": "CA0076", "Gross-value": 755677 }, { "customer": "CJ0031", "Gross-value": 726300 }, { "customer": "CT0187", "Gross-value": 719886 }, { "customer": "cW0031", "Gross-value": 716130 }, { "customer": "CM0237", "Gross-value": 710400 }, { "customer": "CR0138", "Gross-value": 687300 }, { "customer": "CC0158", "Gross-value": 680580 }, { "customer": "cm0008", "Gross-value": 668678 }, { "customer": "CB0132", "Gross-value": 659100 }, { "customer": "cc0089", "Gross-value": 657120 }, { "customer": "CR0144", "Gross-value": 649095 }, { "customer": "CS0291", "Gross-value": 589900 }, { "customer": "CM0219", "Gross-value": 575851 }, { "customer": "CS0004", "Gross-value": 563053 }, { "customer": "ca0127", "Gross-value": 545045 }, { "customer": "CM0214", "Gross-value": 524252 }, { "customer": "CI0003", "Gross-value": 518700 }, { "customer": "CT0011", "Gross-value": 497200 }, { "customer": "CS0426", "Gross-value": 480760 }, { "customer": "CM0225", "Gross-value": 449811 }, { "customer": "ce0092", "Gross-value": 432026 }, { "customer": "CP0158", "Gross-value": 431900 }, { "customer": "CA0242", "Gross-value": 427350 }, { "customer": "CA0310", "Gross-value": 423848 }, { "customer": "ct0164", "Gross-value": 420346 }, { "customer": "CL0016", "Gross-value": 420220 }, { "customer": "CL0089", "Gross-value": 415083 }, { "customer": "CS0465", "Gross-value": 410700 }, { "customer": "CM0232", "Gross-value": 405812 }, { "customer": "CP0221", "Gross-value": 397750 }, { "customer": "CC0147", "Gross-value": 396031 }, { "customer": "ca0198", "Gross-value": 394693 }, { "customer": "CT0186", "Gross-value": 387600 }, { "customer": "CH0141", "Gross-value": 376500 }, { "customer": "cj0115", "Gross-value": 376200 }, { "customer": "CM0024", "Gross-value": 373730 }, { "customer": "CM0165", "Gross-value": 372898 }, { "customer": "ca0309", "Gross-value": 364436 }, { "customer": "cs0408", "Gross-value": 360680 }, { "customer": "cc0073", "Gross-value": 359763 }, { "customer": "cs0471", "Gross-value": 351372 }, { "customer": "CK0131", "Gross-value": 350700 }, { "customer": "CM0235", "Gross-value": 343750 }, { "customer": "CT0168", "Gross-value": 342420 }, { "customer": "CM0007", "Gross-value": 339950 }, { "customer": "cl0089", "Gross-value": 335763 }, { "customer": "CS0408", "Gross-value": 333037 }, { "customer": "CT0179", "Gross-value": 332350 }, { "customer": "CD0095", "Gross-value": 316050 }, { "customer": "cr0002", "Gross-value": 314880 }, { "customer": "CS0126", "Gross-value": 312956 }, { "customer": "cn0063", "Gross-value": 309261 }, { "customer": "CD0139", "Gross-value": 306150 }, { "customer": "CH0029", "Gross-value": 305230 }, { "customer": "ca0020", "Gross-value": 303010 }, { "customer": "cv0068", "Gross-value": 294956 }, { "customer": "CT0097", "Gross-value": 294040 }, { "customer": "cd0072", "Gross-value": 293725 }, { "customer": "CB0044", "Gross-value": 284184 }, { "customer": "CS0466", "Gross-value": 283800 }, { "customer": "cr0001", "Gross-value": 283770 }, { "customer": "cr0012", "Gross-value": 275015 }, { "customer": "cb0032", "Gross-value": 269920 }, { "customer": "cc0002", "Gross-value": 269750 }, { "customer": "CS0271", "Gross-value": 267607 }, { "customer": "cm0007", "Gross-value": 261079 }, { "customer": "ck0003", "Gross-value": 252080 }, { "customer": "ch0009", "Gross-value": 251521 }, { "customer": "CM0233", "Gross-value": 249043 }, { "customer": "cp0017", "Gross-value": 244150 }, { "customer": "CS0141", "Gross-value": 239906 }, { "customer": "cf0045", "Gross-value": 235516 }, { "customer": "cs0332", "Gross-value": 227412 }, { "customer": "CS0419", "Gross-value": 224801 }, { "customer": "CR0142", "Gross-value": 212280 }, { "customer": "CS0009", "Gross-value": 211244 }, { "customer": "CM0019", "Gross-value": 208200 }, { "customer": "CT0164", "Gross-value": 201452 }, { "customer": "CL0046", "Gross-value": 200541 }, { "customer": "cr0138", "Gross-value": 197490 }, { "customer": "CA0233", "Gross-value": 196900 }, { "customer": "cb0151", "Gross-value": 193743 }, { "customer": "CP0102", "Gross-value": 192889 }, { "customer": "CR0008", "Gross-value": 192775 }, { "customer": "CS0324", "Gross-value": 184300 }, { "customer": "cs0126", "Gross-value": 183600 }, { "customer": "CM0030", "Gross-value": 175000 }, { "customer": "CB0205", "Gross-value": 169080 }, { "customer": "ch0166", "Gross-value": 167210 }, { "customer": "CK0120", "Gross-value": 165075 }, { "customer": "CK0003", "Gross-value": 164160 }, { "customer": "cs0459", "Gross-value": 158760 }, { "customer": "cs0444", "Gross-value": 156370 }, { "customer": "CR0139", "Gross-value": 154000 }, { "customer": "CR0095", "Gross-value": 153850 }, { "customer": "CE0025", "Gross-value": 152647 }, { "customer": "CP0149", "Gross-value": 149075 }, { "customer": "CA0266", "Gross-value": 148500 }, { "customer": "cj0003", "Gross-value": 145004 }, { "customer": "CA0029", "Gross-value": 142400 }, { "customer": "CS0463", "Gross-value": 137660 }, { "customer": "CB0185", "Gross-value": 136020 }, { "customer": "CH0174", "Gross-value": 135905 }, { "customer": "cS0003", "Gross-value": 127380 }, { "customer": "CS0471", "Gross-value": 126800 }, { "customer": "CH0175", "Gross-value": 126000 }, { "customer": "CH0133", "Gross-value": 125160 }, { "customer": "CT0170", "Gross-value": 120990 }, { "customer": "ce0025", "Gross-value": 120845 }, { "customer": "CK0017", "Gross-value": 120600 }, { "customer": "CR0141", "Gross-value": 120350 }, { "customer": "CB0099", "Gross-value": 117560 }, { "customer": "CS0075", "Gross-value": 114630 }, { "customer": "cd0017", "Gross-value": 113950 }, { "customer": "CF0003", "Gross-value": 113194 }, { "customer": "CE0096", "Gross-value": 113050 }, { "customer": "CE0063", "Gross-value": 112200 }, { "customer": "CF0039", "Gross-value": 110450 }, { "customer": "CH0170", "Gross-value": 105175 }, { "customer": "CF0002", "Gross-value": 104355 }, { "customer": "CK0058", "Gross-value": 103506 }, { "customer": "CS0443", "Gross-value": 103322 }, { "customer": "ct0168", "Gross-value": 100620 }, { "customer": "CG0040", "Gross-value": 100390 }, { "customer": "CH0058", "Gross-value": 96926 }, { "customer": "CM0244", "Gross-value": 96550 }, { "customer": "CD0137", "Gross-value": 96412 }, { "customer": "CI0001", "Gross-value": 91784 }, { "customer": "cp0102", "Gross-value": 89953 }, { "customer": "CK0130", "Gross-value": 89038 }, { "customer": "CC0111", "Gross-value": 87386 }, { "customer": "cs0390", "Gross-value": 83783 }, { "customer": "cg0156", "Gross-value": 82400 }, { "customer": "cg0148", "Gross-value": 82170 }, { "customer": "CS0046", "Gross-value": 81806 }, { "customer": "ca0316", "Gross-value": 81622 }, { "customer": "CC0003", "Gross-value": 81536 }, { "customer": "CT0188", "Gross-value": 81000 }, { "customer": "CG0118", "Gross-value": 80600 }, { "customer": "CR0130", "Gross-value": 79560 }, { "customer": "CB0203", "Gross-value": 78718 }, { "customer": "CA0195", "Gross-value": 78300 }, { "customer": "CS0459", "Gross-value": 77000 }, { "customer": "cs0141", "Gross-value": 76000 }, { "customer": "CL0093", "Gross-value": 75810 }, { "customer": "CR0143", "Gross-value": 75000 }, { "customer": "CU0025", "Gross-value": 74880 }, { "customer": "ct0170", "Gross-value": 74064 }, { "customer": "ca0276", "Gross-value": 73200 }, { "customer": "CP0228", "Gross-value": 72500 }, { "customer": "cR0001", "Gross-value": 69300 }, { "customer": "CS0353", "Gross-value": 68353 }, { "customer": "CA0296", "Gross-value": 67995 }, { "customer": "CP0214", "Gross-value": 67532 }, { "customer": "CA0314", "Gross-value": 67500 }, { "customer": "CR0054", "Gross-value": 67200 }, { "customer": "CN0113", "Gross-value": 67040 }, { "customer": "cs0195", "Gross-value": 65704 }, { "customer": "cd0003", "Gross-value": 65070 }, { "customer": "CS0351", "Gross-value": 65035 }, { "customer": "CO0049", "Gross-value": 62865 }, { "customer": "CA0011", "Gross-value": 60900 }, { "customer": "ca0018", "Gross-value": 59880 }, { "customer": "CR0145", "Gross-value": 58650 }, { "customer": "CH100", "Gross-value": 58580 }, { "customer": "CM0239", "Gross-value": 57430 }, { "customer": "CA0302", "Gross-value": 57300 }, { "customer": "cc0111", "Gross-value": 56400 }, { "customer": "CM0227", "Gross-value": 56300 }, { "customer": "CJ0052", "Gross-value": 56051 }, { "customer": "CV0020", "Gross-value": 55920 }, { "customer": "CA0276", "Gross-value": 54900 }, { "customer": "CJ0047", "Gross-value": 54800 }, { "customer": "CS0430", "Gross-value": 54217 }, { "customer": "CO0027", "Gross-value": 54000 }, { "customer": "CY0010", "Gross-value": 53250 }, { "customer": "co0004", "Gross-value": 52962 }, { "customer": "CD0125", "Gross-value": 51200 }, { "customer": "cs0009", "Gross-value": 50914 }, { "customer": "CI0044", "Gross-value": 48594 }, { "customer": "CV0146", "Gross-value": 48137 }, { "customer": "CR0019", "Gross-value": 48000 }, { "customer": "CT0157", "Gross-value": 47900 }, { "customer": "CS0440", "Gross-value": 47400 }, { "customer": "CB0139", "Gross-value": 46350 }, { "customer": "CI0009", "Gross-value": 46077 }, { "customer": "CA0300", "Gross-value": 44000 }, { "customer": "CB0144", "Gross-value": 43884 }, { "customer": "CS0195", "Gross-value": 43778 }, { "customer": "CA0194", "Gross-value": 42380 }, { "customer": "cm0019", "Gross-value": 41640 }, { "customer": "CT0147", "Gross-value": 41520 }, { "customer": "CB0007", "Gross-value": 41096 }, { "customer": "cd0135", "Gross-value": 40281 }, { "customer": "CB0199", "Gross-value": 38925 }, { "customer": "Cv0067", "Gross-value": 38726 }, { "customer": "CW0009", "Gross-value": 38700 }, { "customer": "CT0040", "Gross-value": 38289 }, { "customer": "CA0311", "Gross-value": 37790 }, { "customer": "cj0133", "Gross-value": 37000 }, { "customer": "CB0218", "Gross-value": 34500 }, { "customer": "CD0003", "Gross-value": 34320 }, { "customer": "CI0097", "Gross-value": 34250 }, { "customer": "CT0088", "Gross-value": 33898 }, { "customer": "cp0158", "Gross-value": 33000 }, { "customer": "CO0004", "Gross-value": 31950 }, { "customer": "cm0231", "Gross-value": 31237 }, { "customer": "CJ0123", "Gross-value": 31200 }, { "customer": "CG0142", "Gross-value": 31171 }, { "customer": "cm0232", "Gross-value": 30900 }, { "customer": "CO0037", "Gross-value": 30000 }, { "customer": "cs0419", "Gross-value": 29800 }, { "customer": "CS0470", "Gross-value": 27878 }, { "customer": "ct0006", "Gross-value": 27032 }, { "customer": "cd0139", "Gross-value": 26500 }, { "customer": "CN0028", "Gross-value": 26400 }, { "customer": "CA0313", "Gross-value": 25300 }, { "customer": "CF0082", "Gross-value": 25000 }, { "customer": "CJ0118", "Gross-value": 24850 }, { "customer": "CW0030", "Gross-value": 24200 }, { "customer": "CH0019", "Gross-value": 24150 }, { "customer": "Cs0224", "Gross-value": 23850 }, { "customer": "CC0037", "Gross-value": 21625 }, { "customer": "CM0199", "Gross-value": 21000 }, { "customer": "ck0131", "Gross-value": 20400 }, { "customer": "cu0038", "Gross-value": 19530 }, { "customer": "CH115", "Gross-value": 19200 }, { "customer": "CW0031", "Gross-value": 17650 }, { "customer": "cc0158", "Gross-value": 17140 }, { "customer": "CO0017", "Gross-value": 16860 }, { "customer": "CR0109", "Gross-value": 16800 }, { "customer": "CG0011", "Gross-value": 16480 }, { "customer": "CS0475", "Gross-value": 15890 }, { "customer": "CA0305", "Gross-value": 14500 }, { "customer": "CV0148", "Gross-value": 14500 }, { "customer": "CN0114", "Gross-value": 14485 }, { "customer": "cs0032", "Gross-value": 14400 }, { "customer": "ce0087", "Gross-value": 14322 }, { "customer": "CE0101", "Gross-value": 13690 }, { "customer": "cg0001", "Gross-value": 13500 }, { "customer": "cr0109", "Gross-value": 13320 }, { "customer": "cm0024", "Gross-value": 12700 }, { "customer": "CJ0107", "Gross-value": 12600 }, { "customer": "CS0479", "Gross-value": 12544 }, { "customer": "ck0130", "Gross-value": 12330 }, { "customer": "CA0312", "Gross-value": 12000 }, { "customer": "CS0001", "Gross-value": 11220 }, { "customer": "CS0328", "Gross-value": 11200 }, { "customer": "cs0305", "Gross-value": 11168 }, { "customer": "ce0063", "Gross-value": 11050 }, { "customer": "cl0093", "Gross-value": 11047 }, { "customer": "ct0108", "Gross-value": 10950 }, { "customer": "CS0022", "Gross-value": 10868 }, { "customer": "CB0221", "Gross-value": 10000 }, { "customer": "CA0315", "Gross-value": 9590 }, { "customer": "CA0236", "Gross-value": 9000 }, { "customer": "CB0161", "Gross-value": 8636 }, { "customer": "cs0478", "Gross-value": 8600 }, { "customer": "CE0023", "Gross-value": 8600 }, { "customer": "CS0432", "Gross-value": 8430 }, { "customer": "cs0430", "Gross-value": 8100 }, { "customer": "cd0065", "Gross-value": 7841 }, { "customer": "ci0009", "Gross-value": 7696 }, { "customer": "CK0134", "Gross-value": 7690 }, { "customer": "CS0476", "Gross-value": 7235 }, { "customer": "CH0169", "Gross-value": 7000 }, { "customer": "ct0040", "Gross-value": 6235 }, { "customer": "CP0207", "Gross-value": 5827 }, { "customer": "CP0230", "Gross-value": 5600 }, { "customer": "cs0351", "Gross-value": 5560 }, { "customer": "CP0010", "Gross-value": 5551 }, { "customer": "cc0160", "Gross-value": 5250 }, { "customer": "CS0473", "Gross-value": 5130 }, { "customer": "CW0038", "Gross-value": 4890 }, { "customer": "CS0015", "Gross-value": 4200 }, { "customer": "CK0133", "Gross-value": 4018 }, { "customer": "CS0435", "Gross-value": 3750 }, { "customer": "CM0197", "Gross-value": 3498 }, { "customer": "CL0098", "Gross-value": 2200 }, { "customer": "CY0013", "Gross-value": 2197 }, { "customer": "CP0216", "Gross-value": 2000 }, { "customer": "CL0079", "Gross-value": 1750 }, { "customer": "cb0203", "Gross-value": 0 }, { "customer": "cn0112", "Gross-value": 0 }, { "customer": "CM0016", "Gross-value": 0 }];

  const channel = [{ "channel": "LOCAL", "Gross-value": 1107934564 }, { "channel": "EXPORT", "Gross-value": 125848217 }, { "channel": "WARRANTY", "Gross-value": 21810 }, { "channel": "BRANCH", "Gross-value": 13350 }];

  const region = [{ "Region": "HB01", "Gross-value": 344445118 }, { "Region": "BMUM", "Gross-value": 329271859 }, { "Region": "BDEL", "Gross-value": 224128617 }, { "Region": "BPUN", "Gross-value": 151775245 }, { "Region": "BKLK", "Gross-value": 96102301 }, { "Region": "BABD", "Gross-value": 34962783 }, { "Region": "BCHN", "Gross-value": 24036691 }, { "Region": "BHYD", "Gross-value": 14322202 }, { "Region": "bdel", "Gross-value": 6960542 }, { "Region": "BCAL", "Gross-value": 6719702 }, { "Region": "BIND", "Gross-value": 616781 }, { "Region": "bchn", "Gross-value": 464900 }, { "Region": "bmum", "Gross-value": 11200 }];

  const product = [{ "Product": "PU2AB008", "Gross-value": 59236157 }, { "Product": "PF2AB503", "Gross-value": 56831594 }, { "Product": "JDIGP001", "Gross-value": 54855521 }, { "Product": "84211833", "Gross-value": 45130563 }, { "Product": "PF2AB505", "Gross-value": 40098218 }, { "Product": "PT2AB001", "Gross-value": 35010107 }, { "Product": "I6.Y1300.61.1", "Gross-value": 30773734 }, { "Product": "I6.D1000.05.1", "Gross-value": 28814630 }, { "Product": "PT2AB028", "Gross-value": 28395723 }, { "Product": "4924739", "Gross-value": 26239676 }, { "Product": "PJ2A4003", "Gross-value": 24485783 }, { "Product": "PT2AB012", "Gross-value": 22681965 }, { "Product": "PE2AX003", "Gross-value": 22357810 }, { "Product": "pf2ag004", "Gross-value": 18738900 }, { "Product": "I6.W3000.05.1", "Gross-value": 18715054 }, { "Product": "pt2ab001", "Gross-value": 18631873 }, { "Product": "I6.Q0400.05.1", "Gross-value": 18482419 }, { "Product": "PV2AB003", "Gross-value": 17135475 }, { "Product": "PA2AE126", "Gross-value": 16700162 }, { "Product": "PF2AG011", "Gross-value": 16268026 }, { "Product": "3634648", "Gross-value": 16041697 }, { "Product": "4096427", "Gross-value": 15612034 }, { "Product": "PA2AG128", "Gross-value": 15329397 }, { "Product": "PF2AH001", "Gross-value": 14690041 }, { "Product": "pf2ab503", "Gross-value": 13455226 }, { "Product": "PE2AD019", "Gross-value": 12961710 }, { "Product": "I6.T6100.05.1", "Gross-value": 11521188 }, { "Product": "YSCRP002", "Gross-value": 10637242 }, { "Product": "PT2A7002", "Gross-value": 10199638 }, { "Product": "PRICE-DIFFERENCE", "Gross-value": 10076047 }, { "Product": "PS0A0001", "Gross-value": 9330813 }, { "Product": "PF2AG010", "Gross-value": 8850465 }, { "Product": "PA3A6070", "Gross-value": 8730880 }, { "Product": "PE2A2001", "Gross-value": 7846650 }, { "Product": "PT2AB018", "Gross-value": 7542372 }, { "Product": "PF2AB018", "Gross-value": 7356769 }, { "Product": "PT2AU005", "Gross-value": 6976150 }, { "Product": "4372337", "Gross-value": 6943183 }, { "Product": "PS0A0002", "Gross-value": 6730826 }, { "Product": "PT2A7021", "Gross-value": 6713092 }, { "Product": "pk2a7002", "Gross-value": 6688600 }, { "Product": "pf2ab009", "Gross-value": 6561307 }, { "Product": "3092984", "Gross-value": 5760232 }, { "Product": "PT2A9010", "Gross-value": 5734040 }, { "Product": "PB2AD026", "Gross-value": 5691305 }, { "Product": "I6.CK700.05.1", "Gross-value": 5670304 }, { "Product": "PE2AB036", "Gross-value": 5574030 }, { "Product": "PT2A9008", "Gross-value": 5199983 }, { "Product": "PK2AS004", "Gross-value": 5088763 }, { "Product": "YSCRP092", "Gross-value": 5060222 }, { "Product": "4372339", "Gross-value": 5010104 }, { "Product": "I6.P1100.05.0", "Gross-value": 4626806 }, { "Product": "PT2AB013", "Gross-value": 4598790 }, { "Product": "PB2AF002", "Gross-value": 4591402 }, { "Product": "PA2A9058", "Gross-value": 4474012 }, { "Product": "PT2AE003", "Gross-value": 4473648 }, { "Product": "PA3AD001", "Gross-value": 4421353 }, { "Product": "DSPL17246017CB-CB", "Gross-value": 4232888 }, { "Product": "I6.U7300.05.0", "Gross-value": 4178298 }, { "Product": "DSPR17246001CB-4CB", "Gross-value": 4171244 }, { "Product": "PF2AB508", "Gross-value": 4162500 }, { "Product": "DHCC506P000-00", "Gross-value": 4049568 }, { "Product": "4372340", "Gross-value": 3975962 }, { "Product": "PA2AB112", "Gross-value": 3950581 }, { "Product": "PA2A7032", "Gross-value": 3847596 }, { "Product": "4372338", "Gross-value": 3840748 }, { "Product": "PA2A9031", "Gross-value": 3781701 }, { "Product": "PT2AB030", "Gross-value": 3586455 }, { "Product": "I6.T0200.05.0", "Gross-value": 3579152 }, { "Product": "PC1A3002", "Gross-value": 3487225 }, { "Product": "PF2AG004", "Gross-value": 3412820 }, { "Product": "PA2AG052", "Gross-value": 3346254 }, { "Product": "PA3A8028", "Gross-value": 3311783 }, { "Product": "PT2AB024", "Gross-value": 3303390 }, { "Product": "PA1A9008", "Gross-value": 3276400 }, { "Product": "YSCRP004", "Gross-value": 3235715 }, { "Product": "PA2AD056", "Gross-value": 3221980 }, { "Product": "PT2AT004", "Gross-value": 3210483 }, { "Product": "3634640", "Gross-value": 3158117 }, { "Product": "PE2AB024", "Gross-value": 3068466 }, { "Product": "PN6A5008", "Gross-value": 3068250 }, { "Product": "PE2AX002", "Gross-value": 2987503 }, { "Product": "PK2AS001", "Gross-value": 2923235 }, { "Product": "PA2AB030", "Gross-value": 2842542 }, { "Product": "PA3A7027", "Gross-value": 2762553 }, { "Product": "PA2AE081", "Gross-value": 2723488 }, { "Product": "PA2AL039", "Gross-value": 2671695 }, { "Product": "PJ2A3007", "Gross-value": 2613000 }, { "Product": "PA2AB047", "Gross-value": 2539126 }, { "Product": "PJ2AH006", "Gross-value": 2419719 }, { "Product": "PF2AB501", "Gross-value": 2396006 }, { "Product": "PA2A4016", "Gross-value": 2374457 }, { "Product": "PA3A3039", "Gross-value": 2364210 }, { "Product": "PJ2AK001", "Gross-value": 2350798 }, { "Product": "PJ2A1007", "Gross-value": 2305100 }, { "Product": "PF2AE016", "Gross-value": 2279296 }, { "Product": "84421120", "Gross-value": 2244021 }, { "Product": "101100261-FG", "Gross-value": 2206980 }, { "Product": "PA2AE099", "Gross-value": 2033985 }, { "Product": "FHAL1440I-3", "Gross-value": 2027000 }, { "Product": "PA2AG047", "Gross-value": 2002470 }, { "Product": "pu2ab008", "Gross-value": 2000364 }, { "Product": "PT2A9002", "Gross-value": 1954776 }, { "Product": "PA2AD058", "Gross-value": 1945080 }, { "Product": "PT2AT001", "Gross-value": 1923108 }, { "Product": "F550129759", "Gross-value": 1816668 }, { "Product": "PX4A6012", "Gross-value": 1764000 }, { "Product": "pk2ak006", "Gross-value": 1762427 }, { "Product": "PA2AD064", "Gross-value": 1758229 }, { "Product": "PA2AD033", "Gross-value": 1756546 }, { "Product": "PA1A1010", "Gross-value": 1735830 }, { "Product": "3643961", "Gross-value": 1724900 }, { "Product": "PA1A8008", "Gross-value": 1713006 }, { "Product": "PA3A6033", "Gross-value": 1696296 }, { "Product": "PA2AE044", "Gross-value": 1691126 }, { "Product": "PA3A7005", "Gross-value": 1689880 }, { "Product": "PA2AF001", "Gross-value": 1680200 }, { "Product": "PA3A7012", "Gross-value": 1666229 }, { "Product": "PA2AJ038", "Gross-value": 1632197 }, { "Product": "PA4A4021", "Gross-value": 1627880 }, { "Product": "PA1A5011", "Gross-value": 1586787 }, { "Product": "PB2AE031", "Gross-value": 1556439 }, { "Product": "PA4A8003", "Gross-value": 1554133 }, { "Product": "8429304", "Gross-value": 1530000 }, { "Product": "113300153-FG", "Gross-value": 1490300 }, { "Product": "MEIS0001", "Gross-value": 1483919 }, { "Product": "PT2AB027", "Gross-value": 1465990 }, { "Product": "pj2a4003", "Gross-value": 1443312 }, { "Product": "CKW326", "Gross-value": 1430600 }, { "Product": "102500175B-FG", "Gross-value": 1408260 }, { "Product": "PA1A4015", "Gross-value": 1341804 }, { "Product": "PA1A7016", "Gross-value": 1341535 }, { "Product": "PA3A9026", "Gross-value": 1338065 }, { "Product": "102211001-FG", "Gross-value": 1335980 }, { "Product": "AIR-FREIGHT-CHARGE", "Gross-value": 1334710 }, { "Product": "pt2ab013", "Gross-value": 1271885 }, { "Product": "PV2AB008", "Gross-value": 1266480 }, { "Product": "2.1518.105.0", "Gross-value": 1260000 }, { "Product": "113211047-FG", "Gross-value": 1234750 }, { "Product": "PA3A8057", "Gross-value": 1209657 }, { "Product": "PT2AJ002", "Gross-value": 1202385 }, { "Product": "PA3A5035", "Gross-value": 1197807 }, { "Product": "PT2A2003", "Gross-value": 1190800 }, { "Product": "PB3A9044", "Gross-value": 1185725 }, { "Product": "PF2AB011", "Gross-value": 1147283 }, { "Product": "PA2AL040", "Gross-value": 1125520 }, { "Product": "PT2AA001", "Gross-value": 1102191 }, { "Product": "pa1a9006", "Gross-value": 1102000 }, { "Product": "PA1A2007", "Gross-value": 1073253 }, { "Product": "PT2A9003", "Gross-value": 1067403 }, { "Product": "PE2AE021", "Gross-value": 1049128 }, { "Product": "pk2ak001", "Gross-value": 1037782 }, { "Product": "PA2AB038", "Gross-value": 1002870 }, { "Product": "PY2AA001", "Gross-value": 995720 }, { "Product": "PA4A4046", "Gross-value": 992788 }, { "Product": "PA4A6044", "Gross-value": 992646 }, { "Product": "PA2AE062", "Gross-value": 990424 }, { "Product": "PA2A9123", "Gross-value": 981396 }, { "Product": "PB2AL012", "Gross-value": 979020 }, { "Product": "PA4A2033", "Gross-value": 975690 }, { "Product": "PA1A3013", "Gross-value": 959565 }, { "Product": "F550130045", "Gross-value": 948674 }, { "Product": "PA2AG061", "Gross-value": 931004 }, { "Product": "PA3A9005", "Gross-value": 926005 }, { "Product": "PF2AE013", "Gross-value": 920333 }, { "Product": "PB2AJ008", "Gross-value": 919828 }, { "Product": "PK2AA004", "Gross-value": 870090 }, { "Product": "PA3AB009", "Gross-value": 858064 }, { "Product": "PK2S0016", "Gross-value": 853676 }, { "Product": "PA4A1047", "Gross-value": 848360 }, { "Product": "PA4A5039", "Gross-value": 843103 }, { "Product": "PT2AB008", "Gross-value": 842713 }, { "Product": "PA3A2064", "Gross-value": 834470 }, { "Product": "3634065", "Gross-value": 832567 }, { "Product": "PT2A7009", "Gross-value": 807236 }, { "Product": "M22A3009", "Gross-value": 802689 }, { "Product": "YSCRP001", "Gross-value": 790290 }, { "Product": "101100262-FG", "Gross-value": 762750 }, { "Product": "PA4A7026", "Gross-value": 762623 }, { "Product": "PT2AB031", "Gross-value": 744975 }, { "Product": "PE2AE007", "Gross-value": 734600 }, { "Product": "PA4A3038", "Gross-value": 729414 }, { "Product": "PF2A7003", "Gross-value": 722250 }, { "Product": "PX3A6026", "Gross-value": 718980 }, { "Product": "YSCRP005", "Gross-value": 711950 }, { "Product": "PB3A9014", "Gross-value": 702000 }, { "Product": "PE2AD066", "Gross-value": 701831 }, { "Product": "PJ2AU017", "Gross-value": 696000 }, { "Product": "pf2ab505", "Gross-value": 692694 }, { "Product": "PB3A5031", "Gross-value": 675000 }, { "Product": "1422022105-FG", "Gross-value": 668450 }, { "Product": "PA2AF002", "Gross-value": 662200 }, { "Product": "PJ2AE007", "Gross-value": 658770 }, { "Product": "PK2AK003", "Gross-value": 652614 }, { "Product": "PK2AK008", "Gross-value": 648600 }, { "Product": "PT2AA002", "Gross-value": 645892 }, { "Product": "PE2AJ010", "Gross-value": 644660 }, { "Product": "PF2AB017", "Gross-value": 642950 }, { "Product": "PB3A9051", "Gross-value": 641648 }, { "Product": "PA3A5006", "Gross-value": 639600 }, { "Product": "SAS00001-FG", "Gross-value": 621480 }, { "Product": "PK2AG001", "Gross-value": 616933 }, { "Product": "pe2ad019", "Gross-value": 606400 }, { "Product": "SAP00012-FG", "Gross-value": 604680 }, { "Product": "PE2AB016", "Gross-value": 599190 }, { "Product": "pn6a5008", "Gross-value": 588000 }, { "Product": "PA3A6019", "Gross-value": 584530 }, { "Product": "SAS00007-FG", "Gross-value": 576390 }, { "Product": "PJ2AD004", "Gross-value": 576000 }, { "Product": "YSCRP009", "Gross-value": 565111 }, { "Product": "yscrp002", "Gross-value": 556521 }, { "Product": "PA3A6044", "Gross-value": 552350 }, { "Product": "PT2AF001", "Gross-value": 550850 }, { "Product": "Tooling", "Gross-value": 550000 }, { "Product": "PT2A7006", "Gross-value": 547340 }, { "Product": "PE2AB008", "Gross-value": 543140 }, { "Product": "PK2AN006", "Gross-value": 540775 }, { "Product": "PT2AF002", "Gross-value": 539150 }, { "Product": "PJ2AS019", "Gross-value": 521550 }, { "Product": "SAS00072-FG", "Gross-value": 512440 }, { "Product": "P02U1012", "Gross-value": 508333 }, { "Product": "P02U1011", "Gross-value": 508333 }, { "Product": "PE2AE035", "Gross-value": 506650 }, { "Product": "PT2A7005", "Gross-value": 504330 }, { "Product": "SAPV0021-FG", "Gross-value": 503800 }, { "Product": "PA3A3026", "Gross-value": 501594 }, { "Product": "PA3A6059", "Gross-value": 496830 }, { "Product": "pf2ab016", "Gross-value": 489740 }, { "Product": "113300070-FG", "Gross-value": 487500 }, { "Product": "PE2A9032", "Gross-value": 484649 }, { "Product": "PA3a7005", "Gross-value": 477180 }, { "Product": "PB2AB009", "Gross-value": 469432 }, { "Product": "SADC0631-FG", "Gross-value": 466416 }, { "Product": "PL2AL005", "Gross-value": 465000 }, { "Product": "102200635-FG", "Gross-value": 464900 }, { "Product": "PJ2A4012", "Gross-value": 464600 }, { "Product": "PK2AK001", "Gross-value": 460572 }, { "Product": "113200104-FG", "Gross-value": 457600 }, { "Product": "14457382", "Gross-value": 456000 }, { "Product": "PA3A6108", "Gross-value": 455055 }, { "Product": "PA1A1011", "Gross-value": 449848 }, { "Product": "PF2AA001", "Gross-value": 441600 }, { "Product": "0.012.8018.3\/10", "Gross-value": 433860 }, { "Product": "PT2AE006", "Gross-value": 425700 }, { "Product": "SAS00002-FG", "Gross-value": 423851 }, { "Product": "PA2A4031", "Gross-value": 421400 }, { "Product": "113206342-FG", "Gross-value": 414400 }, { "Product": "PT2AA005", "Gross-value": 413756 }, { "Product": "PA2AD100", "Gross-value": 412110 }, { "Product": "pk2as004", "Gross-value": 411212 }, { "Product": "101111003-FG", "Gross-value": 409917 }, { "Product": "PB4A2008", "Gross-value": 407400 }, { "Product": "PF2AB013", "Gross-value": 399600 }, { "Product": "PA2AD048", "Gross-value": 397260 }, { "Product": "M22AU001", "Gross-value": 393750 }, { "Product": "PA2AB017", "Gross-value": 387560 }, { "Product": "PK2A4004", "Gross-value": 385164 }, { "Product": "PB3A9008", "Gross-value": 383475 }, { "Product": "102400474-FG", "Gross-value": 381650 }, { "Product": "760-P1-1113", "Gross-value": 381398 }, { "Product": "102300574-FG", "Gross-value": 379450 }, { "Product": "PK2AU012", "Gross-value": 377460 }, { "Product": "PB2A9007", "Gross-value": 375816 }, { "Product": "PK2AA005", "Gross-value": 375630 }, { "Product": "YSCRP003", "Gross-value": 369155 }, { "Product": "4099225", "Gross-value": 367450 }, { "Product": "SAPV0206-FG", "Gross-value": 363600 }, { "Product": "SAPV0204-FG", "Gross-value": 362700 }, { "Product": "SAS00005-A-FG", "Gross-value": 359768 }, { "Product": "206195", "Gross-value": 359376 }, { "Product": "118200026-FG", "Gross-value": 358700 }, { "Product": "4372336", "Gross-value": 356197 }, { "Product": "PV2A1003", "Gross-value": 354907 }, { "Product": "102300573-FG", "Gross-value": 353470 }, { "Product": "PE2A9037", "Gross-value": 341202 }, { "Product": "PF2AB016", "Gross-value": 340200 }, { "Product": "PA2A9032", "Gross-value": 338593 }, { "Product": "PE2AJ017", "Gross-value": 336300 }, { "Product": "PE2AB032", "Gross-value": 333200 }, { "Product": "113403134-FG", "Gross-value": 332400 }, { "Product": "0.009.2382.0\/20", "Gross-value": 332145 }, { "Product": "PB2AB002", "Gross-value": 328850 }, { "Product": "113400067-FG", "Gross-value": 328700 }, { "Product": "PA2A3001", "Gross-value": 326800 }, { "Product": "3634643", "Gross-value": 324983 }, { "Product": "113303064-FG", "Gross-value": 324220 }, { "Product": "113200060-FG", "Gross-value": 323760 }, { "Product": "PB3A6023", "Gross-value": 321725 }, { "Product": "PA2AE132", "Gross-value": 318450 }, { "Product": "FPRA1001", "Gross-value": 316050 }, { "Product": "PB2A9020", "Gross-value": 315638 }, { "Product": "PE2A9005", "Gross-value": 315172 }, { "Product": "PB3A7020", "Gross-value": 314073 }, { "Product": "4099228", "Gross-value": 311859 }, { "Product": "PT2AC001", "Gross-value": 311520 }, { "Product": "113403037-FG", "Gross-value": 304810 }, { "Product": "SAS00058-FG", "Gross-value": 303450 }, { "Product": "PF2AG013", "Gross-value": 303122 }, { "Product": "118300018-FG", "Gross-value": 302800 }, { "Product": "PF2AG014", "Gross-value": 302400 }, { "Product": "PB2AJ029", "Gross-value": 301440 }, { "Product": "SAL00009-FG", "Gross-value": 294070 }, { "Product": "F5501126629", "Gross-value": 283364 }, { "Product": "PT2AB017", "Gross-value": 282350 }, { "Product": "PA3A8088", "Gross-value": 281478 }, { "Product": "SAS00024-FG", "Gross-value": 280925 }, { "Product": "SAS00096-FG", "Gross-value": 278300 }, { "Product": "PA2AJ014", "Gross-value": 276780 }, { "Product": "PT2AD004", "Gross-value": 271451 }, { "Product": "PA2A7025", "Gross-value": 270900 }, { "Product": "PA3A6085", "Gross-value": 270608 }, { "Product": "PA2AG025", "Gross-value": 268898 }, { "Product": "1021D0034-FG", "Gross-value": 267000 }, { "Product": "PX3A5005", "Gross-value": 260525 }, { "Product": "PA1A4039", "Gross-value": 258900 }, { "Product": "PE2A7003", "Gross-value": 253500 }, { "Product": "SAS00073-FG", "Gross-value": 250650 }, { "Product": "102300959-FG", "Gross-value": 249600 }, { "Product": "PA3A6048", "Gross-value": 247715 }, { "Product": "PB2A9001", "Gross-value": 243818 }, { "Product": "PX3A8029", "Gross-value": 243767 }, { "Product": "PA3A8061", "Gross-value": 239360 }, { "Product": "PA3A8062", "Gross-value": 239008 }, { "Product": "PA2AE121", "Gross-value": 236500 }, { "Product": "PA2AE005", "Gross-value": 232685 }, { "Product": "0.009.2379.0\/70", "Gross-value": 230160 }, { "Product": "113400064-FG", "Gross-value": 228000 }, { "Product": "113303105-FG", "Gross-value": 227000 }, { "Product": "PB3A8029", "Gross-value": 226827 }, { "Product": "M22A1001", "Gross-value": 225203 }, { "Product": "PB1A5008", "Gross-value": 224330 }, { "Product": "PB3A6025", "Gross-value": 223577 }, { "Product": "PB2AL017", "Gross-value": 220750 }, { "Product": "PE2AD064", "Gross-value": 219200 }, { "Product": "PA3AB002", "Gross-value": 218479 }, { "Product": "PT2AU001", "Gross-value": 214948 }, { "Product": "PB2AJ012", "Gross-value": 213340 }, { "Product": "PX3A8014", "Gross-value": 213189 }, { "Product": "PA4A2028", "Gross-value": 212527 }, { "Product": "PB3A6022", "Gross-value": 209440 }, { "Product": "PA4A8001", "Gross-value": 209100 }, { "Product": "PB2AD018", "Gross-value": 206447 }, { "Product": "PB3A7040", "Gross-value": 206206 }, { "Product": "PB3A2001", "Gross-value": 206206 }, { "Product": "PT2A7004", "Gross-value": 205650 }, { "Product": "PB2AB006", "Gross-value": 205630 }, { "Product": "PA3AC001", "Gross-value": 204931 }, { "Product": "112600222A-FG", "Gross-value": 204050 }, { "Product": "PA3A7015", "Gross-value": 203386 }, { "Product": "2.1559.332.0", "Gross-value": 202500 }, { "Product": "PB3A6016", "Gross-value": 199225 }, { "Product": "PX4A8009", "Gross-value": 199050 }, { "Product": "0.012.1130.3\/30", "Gross-value": 198712 }, { "Product": "SAP00183-P", "Gross-value": 196808 }, { "Product": "118100099D-FG", "Gross-value": 195000 }, { "Product": "PB3A7009", "Gross-value": 192400 }, { "Product": "PV2AE004", "Gross-value": 191250 }, { "Product": "PT2A7001", "Gross-value": 189673 }, { "Product": "PA1A4005", "Gross-value": 188398 }, { "Product": "PB3A5014", "Gross-value": 188365 }, { "Product": "PX3A6037", "Gross-value": 187380 }, { "Product": "PA4A3032", "Gross-value": 184484 }, { "Product": "102400800-FG", "Gross-value": 181900 }, { "Product": "PF2AB009", "Gross-value": 181504 }, { "Product": "PA2A7009", "Gross-value": 180288 }, { "Product": "PA3A6046", "Gross-value": 179520 }, { "Product": "PA2AE080", "Gross-value": 179500 }, { "Product": "M22A3008", "Gross-value": 178826 }, { "Product": "PA3A8046", "Gross-value": 176748 }, { "Product": "PA3A3005", "Gross-value": 176300 }, { "Product": "PA2AB062", "Gross-value": 176175 }, { "Product": "PK2AK006", "Gross-value": 175968 }, { "Product": "yscrp005", "Gross-value": 172840 }, { "Product": "3029684", "Gross-value": 171074 }, { "Product": "0.009.2399.3\/60", "Gross-value": 170434 }, { "Product": "pb3a9044", "Gross-value": 168500 }, { "Product": "PB1A4004", "Gross-value": 168300 }, { "Product": "113700077A-FG", "Gross-value": 168000 }, { "Product": "PA1A1002", "Gross-value": 167750 }, { "Product": "3029687", "Gross-value": 167641 }, { "Product": "102300008-H-FG", "Gross-value": 167350 }, { "Product": "3093411", "Gross-value": 166829 }, { "Product": "105111035-FG", "Gross-value": 165000 }, { "Product": "SAS00085-FG", "Gross-value": 163125 }, { "Product": "5373084", "Gross-value": 162240 }, { "Product": "SPSK3001", "Gross-value": 162070 }, { "Product": "0.009.2402.0\/10", "Gross-value": 161240 }, { "Product": "PE2AD009", "Gross-value": 157500 }, { "Product": "1021D0020-FG", "Gross-value": 155500 }, { "Product": "3627834", "Gross-value": 154959 }, { "Product": "SCAY055-FG", "Gross-value": 154000 }, { "Product": "PA3A8097", "Gross-value": 153802 }, { "Product": "113300076-FG", "Gross-value": 153000 }, { "Product": "PU2AB002", "Gross-value": 152395 }, { "Product": "550-2-31636-888", "Gross-value": 151667 }, { "Product": "113303026-FG", "Gross-value": 151200 }, { "Product": "PA3A5007", "Gross-value": 150540 }, { "Product": "PF2AB510", "Gross-value": 148800 }, { "Product": "PB2AJ022", "Gross-value": 147660 }, { "Product": "SAS00005-FG", "Gross-value": 147066 }, { "Product": "113600060-FG", "Gross-value": 146500 }, { "Product": "PT2AG002", "Gross-value": 146035 }, { "Product": "PE2AF004", "Gross-value": 145884 }, { "Product": "PT2AB006", "Gross-value": 144800 }, { "Product": "PB2AL005", "Gross-value": 144125 }, { "Product": "112600132-FG", "Gross-value": 144000 }, { "Product": "F550129999", "Gross-value": 142922 }, { "Product": "BSE42007", "Gross-value": 141942 }, { "Product": "112600222-FG", "Gross-value": 140100 }, { "Product": "pa3a8028", "Gross-value": 138600 }, { "Product": "PA3A6115", "Gross-value": 137660 }, { "Product": "102400691-FG", "Gross-value": 137100 }, { "Product": "SPSK2001", "Gross-value": 134701 }, { "Product": "PA4A1026", "Gross-value": 134459 }, { "Product": "5117726", "Gross-value": 132480 }, { "Product": "113200098-FG", "Gross-value": 130900 }, { "Product": "102200636-FG", "Gross-value": 128700 }, { "Product": "3641331", "Gross-value": 128611 }, { "Product": "PA2AD044", "Gross-value": 128305 }, { "Product": "PA3A8085", "Gross-value": 127568 }, { "Product": "PV2AE003", "Gross-value": 124400 }, { "Product": "551\/2\/01692", "Gross-value": 123976 }, { "Product": "PA2AJ039", "Gross-value": 123256 }, { "Product": "pb3a7003", "Gross-value": 122600 }, { "Product": "PX3A2001", "Gross-value": 121212 }, { "Product": "PB2AG013", "Gross-value": 120900 }, { "Product": "0.009.2846.0\/10", "Gross-value": 120141 }, { "Product": "PA3A5022", "Gross-value": 119680 }, { "Product": "112700084B-FG", "Gross-value": 118000 }, { "Product": "PX3A9026", "Gross-value": 117560 }, { "Product": "4372330", "Gross-value": 115830 }, { "Product": "pt2ae003", "Gross-value": 115800 }, { "Product": "PA2A9121", "Gross-value": 115419 }, { "Product": "SADC0014-FG", "Gross-value": 114960 }, { "Product": "0.016.6848.0", "Gross-value": 114000 }, { "Product": "F550130046", "Gross-value": 111788 }, { "Product": "f550130050", "Gross-value": 111700 }, { "Product": "SAPV0200-FG", "Gross-value": 111225 }, { "Product": "0.015.9122.3", "Gross-value": 110400 }, { "Product": "PF2AB001", "Gross-value": 107850 }, { "Product": "PB2A7009", "Gross-value": 106112 }, { "Product": "PA2AL012", "Gross-value": 105895 }, { "Product": "PB2AD008", "Gross-value": 104200 }, { "Product": "PT2AB010", "Gross-value": 103400 }, { "Product": "PB4A7010", "Gross-value": 101900 }, { "Product": "11H200190-FG", "Gross-value": 100600 }, { "Product": "SADC0634-FG", "Gross-value": 99600 }, { "Product": "0.009.2847.0\/10", "Gross-value": 99427 }, { "Product": "PA2AJ076", "Gross-value": 98880 }, { "Product": "SAX00011-FG", "Gross-value": 98228 }, { "Product": "PB2AT001", "Gross-value": 98038 }, { "Product": "SAS00041-FG", "Gross-value": 97190 }, { "Product": "SAS00022-FG", "Gross-value": 97040 }, { "Product": "3030487", "Gross-value": 96552 }, { "Product": "PE2ad019", "Gross-value": 96000 }, { "Product": "181121077-FG", "Gross-value": 94500 }, { "Product": "PA3A2022", "Gross-value": 94450 }, { "Product": "PV2AB004", "Gross-value": 94000 }, { "Product": "113206375-FG", "Gross-value": 93750 }, { "Product": "3092349", "Gross-value": 93457 }, { "Product": "PB3A8015", "Gross-value": 92939 }, { "Product": "PB3A8030", "Gross-value": 92793 }, { "Product": "PJ2AA007", "Gross-value": 92300 }, { "Product": "PB3A5007", "Gross-value": 91950 }, { "Product": "1021D0101-FG", "Gross-value": 91875 }, { "Product": "E_PE2AB036", "Gross-value": 91440 }, { "Product": "PB3A5013", "Gross-value": 91248 }, { "Product": "PA2A4088", "Gross-value": 90300 }, { "Product": "SAS00040-FG", "Gross-value": 89900 }, { "Product": "SAS00056-FG", "Gross-value": 89250 }, { "Product": "5169834", "Gross-value": 89125 }, { "Product": "PB3A7003", "Gross-value": 88800 }, { "Product": "pt2aj002", "Gross-value": 88740 }, { "Product": "2.1539.271.0", "Gross-value": 88550 }, { "Product": "PB3A3012", "Gross-value": 88080 }, { "Product": "PJ2AE001", "Gross-value": 87766 }, { "Product": "PX4A1001", "Gross-value": 87200 }, { "Product": "PB1A8013", "Gross-value": 85980 }, { "Product": "102200707-FG", "Gross-value": 85500 }, { "Product": "PB1A2002", "Gross-value": 85345 }, { "Product": "PF2A9005", "Gross-value": 85095 }, { "Product": "PE2AE005", "Gross-value": 85000 }, { "Product": "SAS00021-FG", "Gross-value": 83550 }, { "Product": "PB4A7011", "Gross-value": 83465 }, { "Product": "PA4A4052", "Gross-value": 82696 }, { "Product": "pa1a5011", "Gross-value": 82500 }, { "Product": "181121001-FG", "Gross-value": 82300 }, { "Product": "SAPV0197-FG", "Gross-value": 82250 }, { "Product": "PA3A3003", "Gross-value": 82025 }, { "Product": "PN7A5014", "Gross-value": 81900 }, { "Product": "Lease Rent", "Gross-value": 81622 }, { "Product": "SPSK3003", "Gross-value": 81200 }, { "Product": "pa2a9031", "Gross-value": 80250 }, { "Product": "PJ2A6007", "Gross-value": 80155 }, { "Product": "112600132-fg", "Gross-value": 80100 }, { "Product": "551\/2\/01688", "Gross-value": 79815 }, { "Product": "105111001-FG", "Gross-value": 79200 }, { "Product": "PB2AJ003", "Gross-value": 77780 }, { "Product": "SARC0046-FG", "Gross-value": 77500 }, { "Product": "PF2AB010", "Gross-value": 77413 }, { "Product": "SAS00059-FG", "Gross-value": 77250 }, { "Product": "PX3A5009", "Gross-value": 76802 }, { "Product": "ps0a0001", "Gross-value": 76752 }, { "Product": "PB3A9059", "Gross-value": 76625 }, { "Product": "PB2AG009", "Gross-value": 76194 }, { "Product": "PX3A6053", "Gross-value": 76125 }, { "Product": "PX3A7061", "Gross-value": 76073 }, { "Product": "PA3A3013", "Gross-value": 76027 }, { "Product": "SAPV0074-FG", "Gross-value": 75900 }, { "Product": "1021D0005-FG", "Gross-value": 75600 }, { "Product": "pa2ag061", "Gross-value": 73200 }, { "Product": "PX3A2004", "Gross-value": 71200 }, { "Product": "SAS00037-FG", "Gross-value": 70096 }, { "Product": "pk2as001", "Gross-value": 69993 }, { "Product": "pa2ad048", "Gross-value": 69944 }, { "Product": "PA2A5001", "Gross-value": 69692 }, { "Product": "SAS00009-FG", "Gross-value": 69560 }, { "Product": "113600133-FG", "Gross-value": 69500 }, { "Product": "PT2ae003", "Gross-value": 69480 }, { "Product": "3093724", "Gross-value": 68534 }, { "Product": "YSCRP022", "Gross-value": 68386 }, { "Product": "SADC0303-FG", "Gross-value": 68250 }, { "Product": "113300167-FG", "Gross-value": 68120 }, { "Product": "SAS00007-A-FG", "Gross-value": 68000 }, { "Product": "PB2AJ015", "Gross-value": 67580 }, { "Product": "PA2AJ087", "Gross-value": 67500 }, { "Product": "PT2AA702", "Gross-value": 66933 }, { "Product": "PB1A3005", "Gross-value": 66645 }, { "Product": "pa3ab002", "Gross-value": 66600 }, { "Product": "SAS00004-FG", "Gross-value": 66300 }, { "Product": "102500175-FG", "Gross-value": 65500 }, { "Product": "PF2AE004", "Gross-value": 65424 }, { "Product": "0.009.2374.0\/30", "Gross-value": 65025 }, { "Product": "112500202-FG", "Gross-value": 65000 }, { "Product": "113303135-FG", "Gross-value": 64000 }, { "Product": "113200074-FG", "Gross-value": 64000 }, { "Product": "113403036-FG", "Gross-value": 63750 }, { "Product": "SAS00052-FG", "Gross-value": 63750 }, { "Product": "PB2AL008", "Gross-value": 63600 }, { "Product": "PB2AD010", "Gross-value": 63450 }, { "Product": "SAS00046-FG", "Gross-value": 62625 }, { "Product": "SAX00003-FG", "Gross-value": 62400 }, { "Product": "PA2A9036", "Gross-value": 62160 }, { "Product": "PB3A8032", "Gross-value": 62028 }, { "Product": "0.020.4282.0\/20", "Gross-value": 62000 }, { "Product": "118200023-FG", "Gross-value": 61900 }, { "Product": "PA4A3002", "Gross-value": 61882 }, { "Product": "PA2AD008", "Gross-value": 61710 }, { "Product": "0.012.8021.0", "Gross-value": 60000 }, { "Product": "PA4A2043", "Gross-value": 59442 }, { "Product": "PB2AJ028", "Gross-value": 59430 }, { "Product": "PA3A6015", "Gross-value": 59153 }, { "Product": "117200055-FG", "Gross-value": 58000 }, { "Product": "PT2AU003", "Gross-value": 57900 }, { "Product": "118100012A-FG", "Gross-value": 57600 }, { "Product": "PX3A9003", "Gross-value": 57300 }, { "Product": "spsk2001", "Gross-value": 57250 }, { "Product": "SAS00011-FG", "Gross-value": 57120 }, { "Product": "SAL00047-FG", "Gross-value": 56300 }, { "Product": "PA3A3007", "Gross-value": 56121 }, { "Product": "5117727", "Gross-value": 56065 }, { "Product": "E_PK2A3004", "Gross-value": 56051 }, { "Product": "0.009.2404.3", "Gross-value": 56000 }, { "Product": "PA3A7011", "Gross-value": 55276 }, { "Product": "PA2AB031", "Gross-value": 54830 }, { "Product": "PA2AG014", "Gross-value": 54710 }, { "Product": "118100044-FG", "Gross-value": 54600 }, { "Product": "SAS00050-FG", "Gross-value": 54375 }, { "Product": "E_PK2AK010", "Gross-value": 54064 }, { "Product": "PA1A5019", "Gross-value": 54050 }, { "Product": "PA3A7021", "Gross-value": 53486 }, { "Product": "112105246-FG", "Gross-value": 53350 }, { "Product": "112105246A-FG", "Gross-value": 53350 }, { "Product": "PA2A9004", "Gross-value": 53200 }, { "Product": "102161001F-FG", "Gross-value": 53000 }, { "Product": "104130130-FG", "Gross-value": 53000 }, { "Product": "sapv0203-fg", "Gross-value": 52962 }, { "Product": "3093723", "Gross-value": 52565 }, { "Product": "PA2AB007", "Gross-value": 52375 }, { "Product": "SAP00182-P", "Gross-value": 52235 }, { "Product": "181520001-FG", "Gross-value": 52000 }, { "Product": "PT2AB022", "Gross-value": 51840 }, { "Product": "SACY084-FG", "Gross-value": 51800 }, { "Product": "118200026B-FG", "Gross-value": 51600 }, { "Product": "PA2AX002", "Gross-value": 51600 }, { "Product": "PA4A4020", "Gross-value": 51444 }, { "Product": "SARC0086-FG", "Gross-value": 51200 }, { "Product": "SPSK1001", "Gross-value": 51050 }, { "Product": "102400800A-FG", "Gross-value": 51000 }, { "Product": "PA2AL045", "Gross-value": 50700 }, { "Product": "PA3A9032", "Gross-value": 50530 }, { "Product": "PA2AE043", "Gross-value": 50280 }, { "Product": "yscrp120", "Gross-value": 50160 }, { "Product": "PB1A4005", "Gross-value": 49950 }, { "Product": "PB2AE004", "Gross-value": 49850 }, { "Product": "SADC0432-FG", "Gross-value": 49650 }, { "Product": "pj2a1008", "Gross-value": 49140 }, { "Product": "PA4A5009", "Gross-value": 49120 }, { "Product": "SAPV0205-FG", "Gross-value": 48594 }, { "Product": "102311001-B-FG", "Gross-value": 48000 }, { "Product": "PB1A1004", "Gross-value": 47945 }, { "Product": "PA2A7034", "Gross-value": 47488 }, { "Product": "PA2AD026", "Gross-value": 46330 }, { "Product": "PB3AB011", "Gross-value": 45975 }, { "Product": "PA2AJ045", "Gross-value": 45552 }, { "Product": "113400068-FG", "Gross-value": 45300 }, { "Product": "0.009.3193.3\/30", "Gross-value": 45000 }, { "Product": "SAPV0201-FG", "Gross-value": 44980 }, { "Product": "SPSK4001", "Gross-value": 44710 }, { "Product": "M22A3004", "Gross-value": 44567 }, { "Product": "SACY083-FG", "Gross-value": 44500 }, { "Product": "SPSK2005", "Gross-value": 44500 }, { "Product": "PE2AJ006", "Gross-value": 44100 }, { "Product": "E_VATA1002", "Gross-value": 44000 }, { "Product": "SPSK4008", "Gross-value": 43884 }, { "Product": "pf2ag011", "Gross-value": 43423 }, { "Product": "PA2A9009", "Gross-value": 43370 }, { "Product": "PB2AL026", "Gross-value": 43350 }, { "Product": "4348760", "Gross-value": 43087 }, { "Product": "PT2aa001", "Gross-value": 43080 }, { "Product": "SAS00020-FG", "Gross-value": 42960 }, { "Product": "0.009.3434.0", "Gross-value": 42900 }, { "Product": "PA1A8001", "Gross-value": 42675 }, { "Product": "PA1A5001", "Gross-value": 42670 }, { "Product": "PA1A1016", "Gross-value": 42500 }, { "Product": "PA1AA007", "Gross-value": 42500 }, { "Product": "pb3a9033", "Gross-value": 42230 }, { "Product": "PA3A8013", "Gross-value": 42147 }, { "Product": "PB2AG023", "Gross-value": 41800 }, { "Product": "PB2A7002", "Gross-value": 41770 }, { "Product": "SMP00204-FG", "Gross-value": 41520 }, { "Product": "PA3A7009", "Gross-value": 41473 }, { "Product": "PA3A7065", "Gross-value": 41473 }, { "Product": "PA3A5095", "Gross-value": 41444 }, { "Product": "pa2x0002", "Gross-value": 41150 }, { "Product": "PX2ADA05", "Gross-value": 40992 }, { "Product": "PX4A2014", "Gross-value": 40800 }, { "Product": "PA2AE050", "Gross-value": 40320 }, { "Product": "PA2AJ082", "Gross-value": 40200 }, { "Product": "PB2A4002", "Gross-value": 40000 }, { "Product": "PX2A7A04", "Gross-value": 40000 }, { "Product": "PT2A7007", "Gross-value": 39600 }, { "Product": "SAS00016-FG", "Gross-value": 39402 }, { "Product": "SADC0636-FG", "Gross-value": 39400 }, { "Product": "PB3A5029", "Gross-value": 39400 }, { "Product": "PB2AB008", "Gross-value": 39350 }, { "Product": "PJ2AN001", "Gross-value": 39156 }, { "Product": "SARC0103-FG", "Gross-value": 38934 }, { "Product": "PT2A7020", "Gross-value": 38700 }, { "Product": "5CLO205100-FG", "Gross-value": 38700 }, { "Product": "102600219-FG", "Gross-value": 38400 }, { "Product": "RATE DIFF-IND", "Gross-value": 37908 }, { "Product": "PY2A9001", "Gross-value": 36740 }, { "Product": "PA2AG048", "Gross-value": 36489 }, { "Product": "SADC0375-FG", "Gross-value": 36434 }, { "Product": "PV2AJ001", "Gross-value": 36400 }, { "Product": "SACY088-FG", "Gross-value": 36225 }, { "Product": "pb3a8006", "Gross-value": 36060 }, { "Product": "pb2ae031", "Gross-value": 36000 }, { "Product": "px3a2004", "Gross-value": 35800 }, { "Product": "PA3A6004", "Gross-value": 35655 }, { "Product": "113300008-H-FG", "Gross-value": 35500 }, { "Product": "113303185-FG", "Gross-value": 35500 }, { "Product": "PJ2A4013", "Gross-value": 35100 }, { "Product": "104211001-FG", "Gross-value": 35000 }, { "Product": "PA3A5032", "Gross-value": 35000 }, { "Product": "5KIT306113-FG", "Gross-value": 35000 }, { "Product": "PA2A9117", "Gross-value": 34926 }, { "Product": "3092419", "Gross-value": 34732 }, { "Product": "PA3A6032", "Gross-value": 34677 }, { "Product": "PA3A7046", "Gross-value": 34625 }, { "Product": "SARC0004-FG", "Gross-value": 34320 }, { "Product": "SARC0063-FG", "Gross-value": 34250 }, { "Product": "0.012.8282.3", "Gross-value": 34200 }, { "Product": "pa3a7027", "Gross-value": 33900 }, { "Product": "PA3A8015", "Gross-value": 33718 }, { "Product": "SADC0031-FG", "Gross-value": 33554 }, { "Product": "SAS00076-FG", "Gross-value": 32640 }, { "Product": "SAS00075-FG", "Gross-value": 32625 }, { "Product": "5KIT105413-FG", "Gross-value": 32470 }, { "Product": "pa2a7032", "Gross-value": 32100 }, { "Product": "PA4A3010", "Gross-value": 32049 }, { "Product": "PA3A3052", "Gross-value": 31875 }, { "Product": "SMP00209-FG", "Gross-value": 31800 }, { "Product": "PA3A9013", "Gross-value": 31658 }, { "Product": "PC1A2001", "Gross-value": 31500 }, { "Product": "PC2AE002", "Gross-value": 31500 }, { "Product": "PA3A5018", "Gross-value": 31458 }, { "Product": "BDW10002", "Gross-value": 31340 }, { "Product": "PB2AL019", "Gross-value": 31200 }, { "Product": "BNU25013", "Gross-value": 30905 }, { "Product": "PA2AB027", "Gross-value": 30867 }, { "Product": "PA4A4025", "Gross-value": 30867 }, { "Product": "PB2AE021", "Gross-value": 30750 }, { "Product": "PX3A8013", "Gross-value": 30650 }, { "Product": "PX3A5004", "Gross-value": 30550 }, { "Product": "PB3A6010", "Gross-value": 30450 }, { "Product": "PB3A3010", "Gross-value": 30450 }, { "Product": "102400248-1-FG", "Gross-value": 30400 }, { "Product": "0.016.6844.0", "Gross-value": 30250 }, { "Product": "PB4A6013", "Gross-value": 30200 }, { "Product": "PB4A5015", "Gross-value": 30200 }, { "Product": "PB4A8005", "Gross-value": 30150 }, { "Product": "PB4A8007", "Gross-value": 30130 }, { "Product": "E_PA1A3038", "Gross-value": 30000 }, { "Product": "0.001.3659.0", "Gross-value": 30000 }, { "Product": "PA3A5046", "Gross-value": 30000 }, { "Product": "PB3A6021", "Gross-value": 30000 }, { "Product": "102600218-FG", "Gross-value": 29950 }, { "Product": "PA3A9018", "Gross-value": 29920 }, { "Product": "SAS00015-FG", "Gross-value": 29890 }, { "Product": "PA3A5004", "Gross-value": 29876 }, { "Product": "PA3A7025", "Gross-value": 29876 }, { "Product": "PA3A6091", "Gross-value": 29876 }, { "Product": "14457581", "Gross-value": 29667 }, { "Product": "PA2A7043", "Gross-value": 29600 }, { "Product": "SMP00052-FG", "Gross-value": 29500 }, { "Product": "PA3A6089", "Gross-value": 29458 }, { "Product": "PA3A5030", "Gross-value": 29458 }, { "Product": "PA3A8073", "Gross-value": 29458 }, { "Product": "BSE52006", "Gross-value": 29086 }, { "Product": "0.020.0869.0", "Gross-value": 29000 }, { "Product": "pa2aj038", "Gross-value": 28950 }, { "Product": "SADC0442-FG", "Gross-value": 28758 }, { "Product": "181010043-FG", "Gross-value": 28600 }, { "Product": "SMP00751-FG", "Gross-value": 28500 }, { "Product": "112600132A-FG", "Gross-value": 28400 }, { "Product": "M22A3003", "Gross-value": 28084 }, { "Product": "PA2AJ052", "Gross-value": 27990 }, { "Product": "DYCVC031-01C", "Gross-value": 27878 }, { "Product": "SAS00109-FG", "Gross-value": 27850 }, { "Product": "PB4A6002", "Gross-value": 27825 }, { "Product": "PA1A2008", "Gross-value": 27772 }, { "Product": "PF2AB007", "Gross-value": 27762 }, { "Product": "PE2AB020", "Gross-value": 27600 }, { "Product": "E_PK2AK012", "Gross-value": 27032 }, { "Product": "5KIT105412-FG", "Gross-value": 27000 }, { "Product": "0.009.2390.3\/20", "Gross-value": 26800 }, { "Product": "PA3A3050", "Gross-value": 26520 }, { "Product": "PX3A6035", "Gross-value": 26520 }, { "Product": "PA3A2017", "Gross-value": 26481 }, { "Product": "PA3A8007", "Gross-value": 26450 }, { "Product": "SADC0633-fg", "Gross-value": 26400 }, { "Product": "PV2AE002", "Gross-value": 26100 }, { "Product": "SAS00014-FG", "Gross-value": 25950 }, { "Product": "pa2ad056", "Gross-value": 25800 }, { "Product": "102500492-FG", "Gross-value": 25500 }, { "Product": "PA3A6090", "Gross-value": 25326 }, { "Product": "117211009N-FG", "Gross-value": 25150 }, { "Product": "PA2AG021", "Gross-value": 25140 }, { "Product": "PA2AJ036", "Gross-value": 25140 }, { "Product": "87604912", "Gross-value": 25125 }, { "Product": "PB2AB004", "Gross-value": 25022 }, { "Product": "113211047A-FG", "Gross-value": 25000 }, { "Product": "PA2AD071", "Gross-value": 24901 }, { "Product": "SAL00032-FG", "Gross-value": 24680 }, { "Product": "PA2AE123", "Gross-value": 24400 }, { "Product": "PA1A3015", "Gross-value": 24220 }, { "Product": "SMP00324-FG", "Gross-value": 24200 }, { "Product": "SAPV0158-FG", "Gross-value": 24000 }, { "Product": "SADC0542-FG", "Gross-value": 23800 }, { "Product": "5LEV108000-FG", "Gross-value": 23600 }, { "Product": "PA3A9052", "Gross-value": 23566 }, { "Product": "pa4a7026", "Gross-value": 23500 }, { "Product": "0.009.2389.3\/10", "Gross-value": 23400 }, { "Product": "PE2AB029", "Gross-value": 23400 }, { "Product": "PA4A7010", "Gross-value": 23300 }, { "Product": "PT2AT003", "Gross-value": 23160 }, { "Product": "M02U1001", "Gross-value": 23154 }, { "Product": "PU2AF007", "Gross-value": 23135 }, { "Product": "P03U1001", "Gross-value": 23120 }, { "Product": "P03U1002", "Gross-value": 23120 }, { "Product": "pa4a6044", "Gross-value": 23100 }, { "Product": "PA4A6011", "Gross-value": 23100 }, { "Product": "PA2AE017", "Gross-value": 22770 }, { "Product": "PA3A5072", "Gross-value": 22768 }, { "Product": "14457281", "Gross-value": 22688 }, { "Product": "SADC0406-FG", "Gross-value": 22500 }, { "Product": "PA1AB008", "Gross-value": 22484 }, { "Product": "PJ2AN008", "Gross-value": 22240 }, { "Product": "YSCRP019", "Gross-value": 22078 }, { "Product": "PE2AJ020", "Gross-value": 22000 }, { "Product": "PA2AB005", "Gross-value": 21970 }, { "Product": "PT3A5001", "Gross-value": 21900 }, { "Product": "PB1A8009", "Gross-value": 21894 }, { "Product": "SAS00010-FG", "Gross-value": 21835 }, { "Product": "118400042A-FG", "Gross-value": 21500 }, { "Product": "PA4A6086", "Gross-value": 21488 }, { "Product": "PA2A9033", "Gross-value": 21450 }, { "Product": "pv2ab008", "Gross-value": 21360 }, { "Product": "PA1A7028", "Gross-value": 21250 }, { "Product": "PB2AG008", "Gross-value": 21200 }, { "Product": "SARC0092-FG", "Gross-value": 21200 }, { "Product": "PB2AD004", "Gross-value": 21200 }, { "Product": "BSE42005", "Gross-value": 21064 }, { "Product": "pa4a2033", "Gross-value": 20700 }, { "Product": "PA2A7020", "Gross-value": 20620 }, { "Product": "5163958", "Gross-value": 20599 }, { "Product": "SAX00008-FG", "Gross-value": 20500 }, { "Product": "YSCRP120", "Gross-value": 20460 }, { "Product": "102211001-fg", "Gross-value": 20400 }, { "Product": "PA1A3022", "Gross-value": 20313 }, { "Product": "PA1A1009", "Gross-value": 20313 }, { "Product": "PA2A9030", "Gross-value": 20254 }, { "Product": "PA2A7036", "Gross-value": 20254 }, { "Product": "SARC0078-FG", "Gross-value": 20225 }, { "Product": "PB2A9003", "Gross-value": 20000 }, { "Product": "112400224-FG", "Gross-value": 20000 }, { "Product": "113800048-FG", "Gross-value": 19900 }, { "Product": "102211001R-FG", "Gross-value": 19500 }, { "Product": "113700077-FG", "Gross-value": 19500 }, { "Product": "PA3A6006", "Gross-value": 19450 }, { "Product": "yscrp022", "Gross-value": 19350 }, { "Product": "PA1A4016", "Gross-value": 19200 }, { "Product": "PE2AD070", "Gross-value": 19200 }, { "Product": "SAPV0024-FG", "Gross-value": 19200 }, { "Product": "PA2AG075", "Gross-value": 18900 }, { "Product": "PA2AE042", "Gross-value": 18900 }, { "Product": "E_PA2AG126", "Gross-value": 18740 }, { "Product": "PB2AG045", "Gross-value": 18508 }, { "Product": "113300005F-FG", "Gross-value": 18500 }, { "Product": "PA3A5047", "Gross-value": 18420 }, { "Product": "SARC0022-FG", "Gross-value": 17975 }, { "Product": "PA3A8087", "Gross-value": 17952 }, { "Product": "102200634-FG", "Gross-value": 17800 }, { "Product": "PA1A7002", "Gross-value": 17760 }, { "Product": "PA2A7033", "Gross-value": 17760 }, { "Product": "PA2A9026", "Gross-value": 17760 }, { "Product": "SARC0006-fg", "Gross-value": 17720 }, { "Product": "M22AF002", "Gross-value": 17650 }, { "Product": "SARM0093-FG", "Gross-value": 17634 }, { "Product": "BSE22006", "Gross-value": 17630 }, { "Product": "SAFC0016-FG", "Gross-value": 17561 }, { "Product": "0.009.2848.3", "Gross-value": 17535 }, { "Product": "113403104-FG", "Gross-value": 17500 }, { "Product": "pa4a8003", "Gross-value": 17425 }, { "Product": "PE2A4001", "Gross-value": 17400 }, { "Product": "PA1A5010", "Gross-value": 17257 }, { "Product": "SADC0635-FG", "Gross-value": 17000 }, { "Product": "3CU2310106-H-FG", "Gross-value": 17000 }, { "Product": "PN7AA002", "Gross-value": 16875 }, { "Product": "PB3A7002", "Gross-value": 16848 }, { "Product": "pa2ae017", "Gross-value": 16830 }, { "Product": "PE2C0014", "Gross-value": 16809 }, { "Product": "SCAY054-FG", "Gross-value": 16800 }, { "Product": "PA2AL054", "Gross-value": 16750 }, { "Product": "sas00007-fg", "Gross-value": 16450 }, { "Product": "SMP00459-FG", "Gross-value": 16400 }, { "Product": "PA1A8009", "Gross-value": 16240 }, { "Product": "2.1520.026.0", "Gross-value": 16225 }, { "Product": "pt2ag002", "Gross-value": 16050 }, { "Product": "PA3A3058", "Gross-value": 15889 }, { "Product": "112200115-FG", "Gross-value": 15800 }, { "Product": "PC2AE006", "Gross-value": 15750 }, { "Product": "0.009.2391.0\/10", "Gross-value": 15600 }, { "Product": "SAS00108-FG", "Gross-value": 15500 }, { "Product": "118200024B-FG", "Gross-value": 15500 }, { "Product": "PX3A7005", "Gross-value": 15325 }, { "Product": "PB3AB001", "Gross-value": 15325 }, { "Product": "PB3A9015", "Gross-value": 15325 }, { "Product": "PX3A9016", "Gross-value": 15325 }, { "Product": "PB3A8010", "Gross-value": 15325 }, { "Product": "PB3A8028", "Gross-value": 15325 }, { "Product": "pb3a7020", "Gross-value": 15325 }, { "Product": "PB3A6033", "Gross-value": 15325 }, { "Product": "0.009.2393.0\/20", "Gross-value": 15200 }, { "Product": "pa3a9026", "Gross-value": 15100 }, { "Product": "113500064-FG", "Gross-value": 14900 }, { "Product": "P01U1003", "Gross-value": 14878 }, { "Product": "P01U1004", "Gross-value": 14878 }, { "Product": "5LEV110000-FG", "Gross-value": 14750 }, { "Product": "XCAR120313-FG", "Gross-value": 14700 }, { "Product": "yscrp012", "Gross-value": 14322 }, { "Product": "YSCRP011", "Gross-value": 14260 }, { "Product": "E_PJ2A6007", "Gross-value": 14145 }, { "Product": "YSCRP118", "Gross-value": 14040 }, { "Product": "PB3A5018", "Gross-value": 13900 }, { "Product": "PA3A8008", "Gross-value": 13850 }, { "Product": "SAS00102-FG", "Gross-value": 13847 }, { "Product": "PA2C0005", "Gross-value": 13750 }, { "Product": "SMP00150-FG", "Gross-value": 13700 }, { "Product": "0.9087.452.3\/10", "Gross-value": 13668 }, { "Product": "PJ2AR008", "Gross-value": 13500 }, { "Product": "SADC0565-FG", "Gross-value": 13500 }, { "Product": "SPCK3003", "Gross-value": 13480 }, { "Product": "sarm0086-fg", "Gross-value": 13320 }, { "Product": "PA2AD034", "Gross-value": 13215 }, { "Product": "SAS00023-FG", "Gross-value": 13170 }, { "Product": "PE2AF003", "Gross-value": 13050 }, { "Product": "pe2ae021", "Gross-value": 13050 }, { "Product": "3CU2210130-FG", "Gross-value": 13000 }, { "Product": "PA1AB006", "Gross-value": 12943 }, { "Product": "PT2A3001", "Gross-value": 12900 }, { "Product": "PB2AD015", "Gross-value": 12900 }, { "Product": "pt2ae006", "Gross-value": 12900 }, { "Product": "SARM0052-FG", "Gross-value": 12700 }, { "Product": "550\/2\/20250-30", "Gross-value": 12632 }, { "Product": "PN7A5015", "Gross-value": 12600 }, { "Product": "SPSK2004", "Gross-value": 12600 }, { "Product": "101100262-fg", "Gross-value": 12500 }, { "Product": "0CC16002001-FG", "Gross-value": 12400 }, { "Product": "5120761", "Gross-value": 12368 }, { "Product": "PX4S0002", "Gross-value": 12198 }, { "Product": "PA1A3019", "Gross-value": 12188 }, { "Product": "113200059-FG", "Gross-value": 12000 }, { "Product": "PA3A5034", "Gross-value": 11950 }, { "Product": "SADC0581-FG", "Gross-value": 11874 }, { "Product": "pa2ae132", "Gross-value": 11580 }, { "Product": "PA4A6040", "Gross-value": 11550 }, { "Product": "PA4A6037", "Gross-value": 11550 }, { "Product": "PA4A1033", "Gross-value": 11400 }, { "Product": "5LEV105000-FG", "Gross-value": 11370 }, { "Product": "pj2a3007", "Gross-value": 11300 }, { "Product": "5GD13300005-H-FG", "Gross-value": 11300 }, { "Product": "SMP00240-FG", "Gross-value": 11200 }, { "Product": "0.009.2380.0", "Gross-value": 11200 }, { "Product": "SAX00038-FG", "Gross-value": 11200 }, { "Product": "PA2AB002", "Gross-value": 11125 }, { "Product": "550\/2\/17119-30", "Gross-value": 11123 }, { "Product": "5V11105000-FG", "Gross-value": 11100 }, { "Product": "PA1A3014", "Gross-value": 11030 }, { "Product": "PT2at001", "Gross-value": 10980 }, { "Product": "PJ2A1008", "Gross-value": 10920 }, { "Product": "PA3AB011", "Gross-value": 10830 }, { "Product": "SAX00078-FG", "Gross-value": 10800 }, { "Product": "550\/2\/19946-30", "Gross-value": 10639 }, { "Product": "PB2AG027", "Gross-value": 10600 }, { "Product": "pb2ae021", "Gross-value": 10600 }, { "Product": "PX2ABA06", "Gross-value": 10600 }, { "Product": "PB2AL023", "Gross-value": 10600 }, { "Product": "M22N7001", "Gross-value": 10560 }, { "Product": "PA3FS001", "Gross-value": 10497 }, { "Product": "PJ2AX010", "Gross-value": 10400 }, { "Product": "SARC0011-FG", "Gross-value": 10350 }, { "Product": "PB2AG019", "Gross-value": 10000 }, { "Product": "1520041102-H-FG", "Gross-value": 10000 }, { "Product": "SADC0632-FG", "Gross-value": 10000 }, { "Product": "0.9123.454.3\/10", "Gross-value": 9900 }, { "Product": "SPSK2021", "Gross-value": 9849 }, { "Product": "BSE42004", "Gross-value": 9715 }, { "Product": "SADC0324-FG", "Gross-value": 9708 }, { "Product": "pt2ab030", "Gross-value": 9625 }, { "Product": "SADC0373-FG", "Gross-value": 9587 }, { "Product": "551\/2\/01749", "Gross-value": 9499 }, { "Product": "pa2ae044", "Gross-value": 9450 }, { "Product": "SPSK2007", "Gross-value": 9436 }, { "Product": "PB1A8002", "Gross-value": 9350 }, { "Product": "PB1A5005", "Gross-value": 9350 }, { "Product": "PW2AD001", "Gross-value": 9254 }, { "Product": "pf2ab501", "Gross-value": 9254 }, { "Product": "SADC0329-FG", "Gross-value": 9130 }, { "Product": "3CC1630E11-FG", "Gross-value": 9100 }, { "Product": "PB2AJ018", "Gross-value": 9070 }, { "Product": "20063470", "Gross-value": 9029 }, { "Product": "pa2al012", "Gross-value": 8970 }, { "Product": "PB2AD012", "Gross-value": 8920 }, { "Product": "112300131E-FG", "Gross-value": 8900 }, { "Product": "0.9123.450.3\/10", "Gross-value": 8730 }, { "Product": "YSCRP006", "Gross-value": 8670 }, { "Product": "PE2AE034", "Gross-value": 8550 }, { "Product": "PB2A9005", "Gross-value": 8524 }, { "Product": "SMP00775-FG", "Gross-value": 8450 }, { "Product": "PB3A9033", "Gross-value": 8446 }, { "Product": "PN7AP001", "Gross-value": 8400 }, { "Product": "pa3ab009", "Gross-value": 8325 }, { "Product": "PA3AB006", "Gross-value": 8325 }, { "Product": "102211001H-FG", "Gross-value": 8000 }, { "Product": "PA2AD099", "Gross-value": 7890 }, { "Product": "SPSK2002", "Gross-value": 7650 }, { "Product": "pj2an001", "Gross-value": 7500 }, { "Product": "5V11110000-FG", "Gross-value": 7500 }, { "Product": "550\/2\/20240-30", "Gross-value": 7480 }, { "Product": "SMP00770-FG", "Gross-value": 7400 }, { "Product": "550\/2\/31151-30", "Gross-value": 7256 }, { "Product": "5GD17211009-H-FG", "Gross-value": 7100 }, { "Product": "M22AV001", "Gross-value": 7027 }, { "Product": "PA2AG076", "Gross-value": 6920 }, { "Product": "3030518", "Gross-value": 6900 }, { "Product": "SAP00184-FG", "Gross-value": 6900 }, { "Product": "3CU2310100-FG", "Gross-value": 6800 }, { "Product": "101100261-fg", "Gross-value": 6750 }, { "Product": "550\/2\/32971-30", "Gross-value": 6547 }, { "Product": "102400474-fg", "Gross-value": 6500 }, { "Product": "1560021109-FG", "Gross-value": 6500 }, { "Product": "BSE53001", "Gross-value": 6420 }, { "Product": "BSE53002", "Gross-value": 6420 }, { "Product": "BSE52002", "Gross-value": 6420 }, { "Product": "BSE43001", "Gross-value": 6420 }, { "Product": "BSE42001", "Gross-value": 6420 }, { "Product": "BSE52001", "Gross-value": 6420 }, { "Product": "SADC0437-FG", "Gross-value": 6379 }, { "Product": "3XCAR110213-FG", "Gross-value": 6250 }, { "Product": "PA2AE075", "Gross-value": 6100 }, { "Product": "5lev108000-fg", "Gross-value": 6000 }, { "Product": "PA3A9057", "Gross-value": 5984 }, { "Product": "550\/2\/20562-30", "Gross-value": 5676 }, { "Product": "pj2ae001", "Gross-value": 5560 }, { "Product": "SARC0074-FG", "Gross-value": 5551 }, { "Product": "SARM0019-FG", "Gross-value": 5540 }, { "Product": "X011411101-FG", "Gross-value": 5250 }, { "Product": "5117730", "Gross-value": 5166 }, { "Product": "3CU2325100-FG", "Gross-value": 5100 }, { "Product": "pt2a9003", "Gross-value": 5039 }, { "Product": "105111001-H-FG", "Gross-value": 5000 }, { "Product": "PJ2AJ002", "Gross-value": 4756 }, { "Product": "pa3a3005", "Gross-value": 4725 }, { "Product": "pa1a3014", "Gross-value": 4720 }, { "Product": "0.007.1978.0", "Gross-value": 4700 }, { "Product": "PF2AB004", "Gross-value": 4627 }, { "Product": "yscrp011", "Gross-value": 4600 }, { "Product": "SMP00092-FG", "Gross-value": 4400 }, { "Product": "SMP00771-FG", "Gross-value": 4380 }, { "Product": "E_PJ2A4013", "Gross-value": 3900 }, { "Product": "PE2AE029", "Gross-value": 3825 }, { "Product": "4TAP318010-FG", "Gross-value": 3750 }, { "Product": "14457381", "Gross-value": 3739 }, { "Product": "0.009.3002.0\/10", "Gross-value": 3600 }, { "Product": "PA1A2017", "Gross-value": 3460 }, { "Product": "PA2AD041", "Gross-value": 3460 }, { "Product": "2.1531.184.0", "Gross-value": 3432 }, { "Product": "14458081", "Gross-value": 3396 }, { "Product": "2.1011.308.2", "Gross-value": 3380 }, { "Product": "pa1a4015", "Gross-value": 3360 }, { "Product": "3029702", "Gross-value": 3325 }, { "Product": "0.009.3363.3", "Gross-value": 3296 }, { "Product": "2.1539.156.0", "Gross-value": 3234 }, { "Product": "PA2AD042", "Gross-value": 3150 }, { "Product": "E_PA2AG127", "Gross-value": 3106 }, { "Product": "5117728", "Gross-value": 3091 }, { "Product": "5117736", "Gross-value": 3055 }, { "Product": "3CAP211370-H-FG", "Gross-value": 3000 }, { "Product": "E_PJ2AU017", "Gross-value": 3000 }, { "Product": "SAX00009-FG", "Gross-value": 3000 }, { "Product": "PA2AB003", "Gross-value": 2960 }, { "Product": "PA1A7038", "Gross-value": 2960 }, { "Product": "1410021100-FG", "Gross-value": 2950 }, { "Product": "14454081", "Gross-value": 2950 }, { "Product": "3CU2510210-FG", "Gross-value": 2800 }, { "Product": "5CLO208000-H-P-FG", "Gross-value": 2800 }, { "Product": "XCAR308115-FG", "Gross-value": 2700 }, { "Product": "SPSK2003", "Gross-value": 2700 }, { "Product": "PA2AB033", "Gross-value": 2675 }, { "Product": "SMP00774-FG", "Gross-value": 2610 }, { "Product": "PA2A9073", "Gross-value": 2591 }, { "Product": "PA2A9052", "Gross-value": 2591 }, { "Product": "5117741", "Gross-value": 2578 }, { "Product": "PE2FS008", "Gross-value": 2563 }, { "Product": "SAS00049-FG", "Gross-value": 2540 }, { "Product": "5117735", "Gross-value": 2422 }, { "Product": "2.1530.034.0", "Gross-value": 2400 }, { "Product": "yscrp112", "Gross-value": 2341 }, { "Product": "5156289", "Gross-value": 2338 }, { "Product": "SAS00061-FG", "Gross-value": 2300 }, { "Product": "596854", "Gross-value": 2254 }, { "Product": "2.0522.216.7", "Gross-value": 2250 }, { "Product": "SYS-FMIS0019-FG", "Gross-value": 2038 }, { "Product": "PA2AB013", "Gross-value": 2025 }, { "Product": "20063580", "Gross-value": 2018 }, { "Product": "SAX00014-FG", "Gross-value": 2000 }, { "Product": "SMP00312-FG", "Gross-value": 2000 }, { "Product": "SYS-FMIS0018-FG", "Gross-value": 1980 }, { "Product": "YGIU522460-H-FG", "Gross-value": 1980 }, { "Product": "206196", "Gross-value": 1950 }, { "Product": "BSE32011", "Gross-value": 1901 }, { "Product": "550239967", "Gross-value": 1900 }, { "Product": "SAS00071-FG", "Gross-value": 1800 }, { "Product": "5GD02300572-FG", "Gross-value": 1700 }, { "Product": "SMP00569-FG", "Gross-value": 1680 }, { "Product": "550\/2\/20056", "Gross-value": 1664 }, { "Product": "2.1560.011.0", "Gross-value": 1600 }, { "Product": "5COP108000-FG", "Gross-value": 1600 }, { "Product": "BBA10001", "Gross-value": 1573 }, { "Product": "M22D3006", "Gross-value": 1565 }, { "Product": "5GD18200024-H-FG", "Gross-value": 1360 }, { "Product": "BBL12142", "Gross-value": 1267 }, { "Product": "5V08105000-FG", "Gross-value": 1250 }, { "Product": "550236012", "Gross-value": 1200 }, { "Product": "M22N3001", "Gross-value": 1118 }, { "Product": "5GD02200004-H-FG", "Gross-value": 1100 }, { "Product": "0.001.3702.0", "Gross-value": 1089 }, { "Product": "BBL12147", "Gross-value": 1056 }, { "Product": "M22W0001", "Gross-value": 1056 }, { "Product": "BKY11001", "Gross-value": 1000 }, { "Product": "SAX00026-FG", "Gross-value": 1000 }, { "Product": "BKY21001", "Gross-value": 1000 }, { "Product": "PA2FG075", "Gross-value": 987 }, { "Product": "BKY22005", "Gross-value": 965 }, { "Product": "SMP00176-FG", "Gross-value": 960 }, { "Product": "BSE22010", "Gross-value": 903 }, { "Product": "SAX00019-FG", "Gross-value": 800 }, { "Product": "5156290", "Gross-value": 796 }, { "Product": "PN7T0006", "Gross-value": 730 }, { "Product": "2.4019.813.1", "Gross-value": 610 }, { "Product": "SMP00466-FG", "Gross-value": 600 }, { "Product": "2.1699.155.0", "Gross-value": 560 }, { "Product": "YSCRP112", "Gross-value": 545 }, { "Product": "BPC20002", "Gross-value": 500 }, { "Product": "BPC20005", "Gross-value": 500 }, { "Product": "BSE52004", "Gross-value": 493 }, { "Product": "RAE00030", "Gross-value": 452 }, { "Product": "PE2C0001", "Gross-value": 448 }, { "Product": "5120771", "Gross-value": 446 }, { "Product": "PN7T0009", "Gross-value": 390 }, { "Product": "RAE00009", "Gross-value": 362 }, { "Product": "4973361", "Gross-value": 302 }, { "Product": "bwa21002", "Gross-value": 280 }, { "Product": "BSE22002", "Gross-value": 275 }, { "Product": "BNU21002", "Gross-value": 250 }, { "Product": "SAX00083-FG", "Gross-value": 240 }, { "Product": "BBL12119", "Gross-value": 212 }, { "Product": "BKY22001", "Gross-value": 170 }, { "Product": "BWA11001", "Gross-value": 141 }, { "Product": "BNU25002", "Gross-value": 125 }, { "Product": "BSL10001", "Gross-value": 112 }, { "Product": "BSE32006", "Gross-value": 100 }, { "Product": "BCR20002", "Gross-value": 86 }, { "Product": "5115469", "Gross-value": 76 }, { "Product": "5122030", "Gross-value": 53 }, { "Product": "px3a6035", "Gross-value": 0 }, { "Product": "118200023-fg", "Gross-value": 0 }, { "Product": "DSPP700P11063", "Gross-value": 0 }, { "Product": "DSPP700P21269", "Gross-value": 0 }, { "Product": "e_pn6a5008", "Gross-value": -4950 }, { "Product": "550139952-FG", "Gross-value": -36000 }, { "Product": "PK2AN007", "Gross-value": -291285 }];

  const sales_trends = [{ "data-1 invoice_date": "2019-04", "data-1 Gross-value": 185539202, "Month": "April", "data-2 invoice_date": "2018-04", "data-2 Gross-value": 194568105 }, { "data-1 invoice_date": "2019-05", "data-1 Gross-value": 215424065, "Month": "May", "data-2 invoice_date": "2018-05", "data-2 Gross-value": 203689423 }, { "data-1 invoice_date": "2019-06", "data-1 Gross-value": 225503351, "Month": "June", "data-2 invoice_date": "2018-06", "data-2 Gross-value": 203560703 }, { "data-1 invoice_date": "2019-07", "data-1 Gross-value": 210935132, "Month": "July", "data-2 invoice_date": "2018-07", "data-2 Gross-value": 200497867 }];

  const sales_forecast = [{ "Month": "April", "Actual Gross-value": 185539202, "Sales target": 190000000 }, { "Month": "May", "Actual Gross-value": 215424065, "Sales target": 203000000 }, { "Month": "June", "Actual Gross-value": 225503351, "Sales target": 203500000 }, { "Month": "July", "Actual Gross-value": 210935132, "Sales target": 200000000 }];

  const intColumnDefs = useMemo(() => {
    if (rowData.length > 0) {
      const keys = Object.keys(rowData[0]);

      const intColumnDefs = [
        {
          headerName: '',
          checkboxSelection: true,
          width: 50,
        },
        ...keys.map((key) => ({
          headerName: key,
          field: key,
          sortable: true,
          filter: true,
          resizable: true,
        })),
      ];

      return intColumnDefs;
    }
    return [];
  }, [rowData]);

  const monthWisegst = () => {
    const rowData1 = rowData.length > 10 ? rowData.slice(0, 10) : rowData;
    const keys1 = Object.keys(rowData1[0]);
    console.log('keys1', keys1);
    let customer = keys1[0];
    let customers1;
    let grossValues1;
    let grossValues2;
    if (reports == 'Top 10 Sales') {
      customers1 = rowData1.map(item => item[customer]);
      grossValues1 = rowData1.map(item => item["Gross-value"]);
      setcustomers(customers1);
      setgrossValues(grossValues1);

    } else if (reports == 'Salestrends') {
      customers1 = rowData1.map(item => item["Month"]);

      grossValues1 = rowData1.map(item => item["data-1 Gross-value"]);

      grossValues2 = rowData1.map(item => item["data-2 Gross-value"]);

      setcustomers(customers1);
      setgrossValues(grossValues1);
      setgrossValues1(grossValues2);

    }
    else if (reports == 'Salesforecast') {
      customers1 = rowData1.map(item => item["Month"]);

      grossValues1 = rowData1.map(item => item["Actual Gross-value"]);

      grossValues2 = rowData1.map(item => item["Sales target"]);

      setcustomers(customers1);
      setgrossValues(grossValues1);
      setgrossValues1(grossValues2);

    }
    // Extract the "customer" and "Gross-value" properties into separate arrays


    console.log("Customers:", customers1);
    console.log("Gross Values:", grossValues1);


    setTimeout(() => {
      setGstHidden(false);
    }, 1000);

  };

  var gridColumns = [
    { field: 'customer', headerName: 'Customer', sortable: true, filter: true, resizable: true },
    { field: 'Gross-value', headerName: 'Gross value', sortable: true, filter: true, resizable: true },
  ]

  const clickChart = () => {
    setcolumnnames(gridColumns);

    setshow(true);
  };

  const handleClose = () => {
    setshow(false);
  };


  const options = [
    { text: 'Top 10 Sales', value: 'Top 10 Sales' },
    { text: 'Salesforecast', value: 'Salesforecast' },
    { text: 'Salestrends', value: 'Salestrends' },

  ];

  const handleSelectChange = (e, { value }) => {
    // Do something with the selected value
    console.log('Selected value:', value);
    setGstHidden(true);
    if (value == 'Salestrends') {
      setfiltervalue('');
      setrowData(sales_trends)
      setissalestrends(true);
      setisfilterHidden(true);
    } else if (value == 'Salesforecast') {
      setfiltervalue('');
      setrowData(sales_forecast)
      setissalestrends(true);
      setisfilterHidden(true);
    }
    else if (value == 'Top 10 Sales') {
      setissalestrends(false);
      setisfilterHidden(false);
    }
    setreports(value);
  };

  const options1 = [
    { text: 'region', value: 'region' },
    { text: 'customer', value: 'customer' },
    { text: 'product', value: 'product' },
    { text: 'channel', value: 'channel' },

  ];

  const handleSelectChange1 = (e, { value }) => {
    // Do something with the selected value
    console.log('Selected value1:', value);
    setGstHidden(true);
    if (value == 'region') {
      setrowData(region);
    } else if (value == 'customer') {
      setrowData(customer);
    } else if (value == 'product') {
      setrowData(product);
    } else if (value == 'channel') {
      setrowData(channel);
    }
    setfiltervalue(value);

  };

  //     const barChartOnClick = () => {
  //         // Handle bar chart click event if needed
  //     };

  //     const data = [{"channel":"LOCAL","Gross-value":3055088734},
  //     {"channel":"EXPORT","Gross-value":324997300},
  //     {"channel":"BRANCH","Gross-value":75222286},
  //     {"channel":"WARRANTY","Gross-value":21810}]

  //     // Prepare chart data
  //   const chartData = data.map(item => ({ x: item.channel, y: item["Gross-value"] }));

  // ApexCharts options
  const options2 = {
    chart: {
      type: 'bar',
      toolbar: {
        show: false,
      },
    },
    plotOptions: {
      bar: {
        horizontal: false,
      },
    },
    xaxis: {
      title: {
        text: filtervalue,
      },
      categories: customers,
    },
    yaxis: {
      title: {
        text: "Invoice value",
      },
    },
    tooltip: {
      shared: false,
    },

    tooltip: {
      shared: false,
    },
    legend: {
      show: true,
      position: 'right',
      offsetY: 0,
      offsetX: -10,
    },
    responsive: [
      {
        breakpoint: 480,
        options: {
          chart: {
            width: '100%',
          },
          legend: {
            position: 'bottom',
            offsetY: 0,
            offsetX: 0,
          },
        },
      },
    ],

  };

  //   const series = [
  //     {
  //       name: 'Sales',
  //       data: [30, 40, 25, 50, 49, 21, 70],
  //     },
  //   ];

  const seriesData = [
    {
      name: 'Invoice value1',
      type: 'column',
      data: grossValues
    },
    {
      name: 'Invoice value2',
      type: 'column',
      data: grossValues1
    },

  ];

  const chartOptions = {
    chart: {
      height: 350,
      type: 'line',
      stacked: false
    },
    dataLabels: {
      enabled: false
    },
    stroke: {
      width: [1, 1, 4]
    },

    xaxis: {
      categories: customers,
    },
    yaxis: [
      {
        axisTicks: {
          show: true,
        },
        axisBorder: {
          show: true,
          color: '#008FFB'
        },
        labels: {
          style: {
            colors: '#008FFB',
          }
        },
        title: {
          text: "Invoice value1",
          style: {
            color: '#008FFB',
          }
        },
        // tooltip: {
        //   enabled: true
        // }
      },
      {
        seriesName: 'Invoice value1',
        opposite: true,
        axisTicks: {
          show: true,
        },
        axisBorder: {
          show: true,
          color: '#00E396'
        },
        labels: {
          style: {
            colors: '#00E396',
          }
        },
        title: {
          text: "Invoice value2",
          style: {
            color: '#00E396',
          }
        },
      },
      // {
      //   seriesName: 'Invoice value2',
      //   opposite: true,
      //   axisTicks: {
      //     show: true,
      //   },
      //   axisBorder: {
      //     show: true,
      //     color: '#FEB019'
      //   },
      //   labels: {
      //     style: {
      //       colors: '#FEB019',
      //     },
      //   },

      // },
    ],
    // tooltip: {
    //   fixed: {
    //     enabled: true,
    //     position: 'topLeft', // topRight, topLeft, bottomRight, bottomLeft
    //     offsetY: 30,
    //     offsetX: 60
    //   },
    // },
    // legend: {
    //   horizontalAlign: 'left',
    //   offsetX: 40
    // }
  };


  return (
    <>
      <div>
        <div hidden={hidden}>
          <div className="gstchartbox1">
            <div className="gstchart-box-layer">
              <table style={{ width: "35%", marginTop: "-12px" }}>

                <tbody>
                  <tr>
                    <td className="gstaddcontracttext">Reports</td>
                    <td style={{ paddingRight: '0.9em' }}>:</td>
                    <td style={{ paddingRight: '0.9em' }}><Select
                      options={options}
                      placeholder="Select an option"
                      onChange={handleSelectChange}
                    /></td>
                    <td className="gstaddcontracttext" hidden={isfilterHidden}>Filtering</td>
                    <td style={{ paddingRight: '0.9em' }} hidden={isfilterHidden}>:</td>
                    <td style={{ paddingRight: '0.9em' }} hidden={isfilterHidden}><Select
                      options={options1}
                      selection

                      onChange={handleSelectChange1}
                    /></td>
                    <td className="gstaddcontracttext">Date1</td>
                    <td style={{ paddingRight: '0.9em' }}>:</td>
                    <td style={{ paddingRight: '0.9em' }}><input type="date" name="" onChange={(e) => { setInputMonth(e.target.value) }} /></td>
                    <td className="gstaddcontracttext">Date2</td>
                    <td style={{ paddingRight: '0.9em' }}>:</td>
                    <td style={{ paddingRight: '0.9em' }}><input type="date" name="" onChange={(e) => { setInputMonth1(e.target.value) }} /></td>
                    <td><button style={{ textAlign: "center", border: ".1px solid #000055", color: "#ffffff", padding: "4px 16px", borderRadius: "15px", backgroundColor: "#024f9d" }} onClick={monthWisegst}>
                      Search
                    </button>&nbsp;</td>
                  </tr>

                </tbody>

              </table>


            </div>
          </div>

          {/* secound layer */}
          <div className="brschartbox">
            <div className="brsrecentOrders" hidden={gstHidden}>
              <h5 style={{ textAlign: "center" }}>{reports}</h5>
              <div className='row'>
                <div className="brsbanklayer brsoverflow col-md-4">
                  <div>
                    <div class="popup-link-13">
                      <a href="#popup13" >

                        <div className="brsbankbox" >
                          <table>
                            <tbody>
                              <thead>


                                <tr>
                                  <td>bank_name</td>
                                </tr>
                                <tr>
                                  <td>balance</td>
                                </tr>
                              </thead>
                            </tbody>
                          </table>
                        </div>
                      </a>
                    </div>
                  </div>
                </div>

              
              <div className="brsbanklayer col-md-7" style={{marginLeft:'2.7em'}}>
                {/* <div className='col-md-1'></div> */}
                <div>

                  <div className="popup-link-3" hidden={issalestrends}>
                    <a href="#">
                      <ReactApexChart options={options2} series={[{ data: grossValues }]} type="bar" width={600} height={350} onClick={clickChart} />
                    </a>
                  </div>
                  <div className="popup-link-3" hidden={!issalestrends}>
                    <a href="#">
                      <ReactApexChart options={chartOptions} series={seriesData} type="line" width={600} height={300} onClick={clickChart} />
                    </a>
                  </div>
                </div>
                {/* <div className='col-md-1'></div> */}
              </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Modal
        show={show}
        size="lg"
        onHide={handleClose}
        backdrop="static"
        keyboard={false}
      >
        <Modal.Header closeButton>
          <Modal.Title></Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <div className="ag-theme-alpine" style={{ height: '400px', width: '100%' }}>
            <AgGridReact
              columnDefs={intColumnDefs}
              rowData={rowData}
              animateRows={true}
              pagination={true}
              paginationPageSize={20}
              groupSelectsChildren={true}
              suppressAggAtRootLevel={true}

              suppressRowClickSelection={true}
            />
          </div>
        </Modal.Body>
        <Modal.Footer>
          <Button onClick={handleClose}>
            Close
          </Button>

        </Modal.Footer>
      </Modal>
    </>
  );
}

export default GST;
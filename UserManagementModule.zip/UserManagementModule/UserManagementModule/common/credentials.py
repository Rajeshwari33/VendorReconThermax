
localhost = "http://127.0.0.1:8000"

headers = {
    'content-type': "application/json",
    "Accept": "application/json, text/plain, */*",
}
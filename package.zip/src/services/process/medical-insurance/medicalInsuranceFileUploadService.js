import { headers, baseUrl } from "../../common/credentials";

export const port = "8000";

export const getFileUploadListFromServer = () => {
    let url = baseUrl + port + "/api/v2/user_modules/medical_insurance/file_uploads/";
    return ([headers, url]);
}

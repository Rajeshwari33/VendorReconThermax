import React from "react";
// import styles from "./BoxOne.css";

function brsBanks({bank_name='', balance='', images = {}}) {
    return(
        <div className="bankbox">
            <table >
                <tbody>
                    <thead>
                        <tr>
                            <td><img src={images} alt="" height="100px" width="100px" /></td>
                        </tr>
                        
                        <tr>
                            <td>{bank_name}</td>
                        </tr>
                        <tr>
                            <td>{balance}</td>
                        </tr>
                    </thead>
                </tbody>
            </table>
        </div>
        // <div id="boxOneContainer" style={style}>
        //     <p className="boxOneText">{label}</p>
        // </div>
    );
}

export default brsBanks;
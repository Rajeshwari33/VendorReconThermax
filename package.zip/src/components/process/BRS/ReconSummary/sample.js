import React, { useCallback, useMemo, useRef, useState, useEffect } from "react";
import { render } from "react-dom";

import "./reconSummary.css";
import {
  Icon,
  Input,
  Button,
  Dropdown,
  Grid,
  Popup,
  Segment,
  Select,
  Tab,
  Table,
  Menu,
  Form,
  TextArea,
  Label,
  Checkbox,
  GridColumn,
  Search,
  Pagination,
  Step,
} from "semantic-ui-react";
import { AgGridReact } from "ag-grid-react";

// import 'ag-grid-enterprise';
// import 'npm i ag-grid-enterprise ';

import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import ApexChart from "./apexdontchart";
import ApexChartBar from "./apexbar";
import ApexChartBarColum from "./apexbarcolum";

const options = [
  { key: "a", value: "a", text: "HDFC1" },
  { key: "b", value: "b", text: "HDFC 2" },
  { key: "c", value: "c", text: "HDFC 3" },
  { key: "d", value: "d", text: "SBI 1" },
  { key: "e", value: "e", text: "ICICI" },
  { key: "f", value: "f", text: "ICICI 2" },
];

var checkboxSelection = function (params) {
  // we put checkbox on the name if we are not doing grouping
  return params.columnApi.getRowGroupColumns().length === 0;
};

var headerCheckboxSelection = function (params) {
  // we put checkbox on the name if we are not doing grouping
  return params.columnApi.getRowGroupColumns().length === 0;
};

const GridExample = () => {
  const containerStyle = useMemo(() => ({ width: "100%", height: "100%" }), []);
  const gridStyle = useMemo(() => ({ height: "100%", width: "100%" }), []);
  const [rowData, setRowData] = useState();
  const [columnDefs, setColumnDefs] = useState([
    {
      field: "athlete",
      minWidth: 100,
      checkboxSelection: checkboxSelection,
      headerCheckboxSelection: headerCheckboxSelection,
    },
    { field: "age" },
    { field: "country" },
    { field: "year" },
    { field: "date" },
    { field: "sport" },
    { field: "gold" },
    { field: "silver" },
    { field: "bronze" },
    { field: "total" },
  ]);
  const autoGroupColumnDef = useMemo(() => {
    return {
      headerName: "Group",
      minWidth: 170,
      field: "athlete",
      valueGetter: (params) => {
        if (params.node.group) {
          return params.node.key;
        } else {
          return params.data[params.colDef.field];
        }
      },
      headerCheckboxSelection: true,
      cellRenderer: "agGroupCellRenderer",
      cellRendererParams: {
        checkbox: true,
      },
    };
  }, []);
  const defaultColDef = useMemo(() => {
    return {
      editable: true,
      enableRowGroup: true,
      enablePivot: true,
      enableValue: true,
      sortable: true,
      resizable: true,
      filter: true,
      flex: 1,
      minWidth: 100,
    };
  }, []);

  const onGridReady = useCallback((params) => {
    fetch("https://www.ag-grid.com/example-assets/olympic-winners.json")
      .then((resp) => resp.json())
      .then((data) => setRowData(data));
  }, []);

  return (
    <div style={containerStyle}>
      <div style={gridStyle} className="ag-theme-alpine">
        <AgGridReact
          rowData={rowData}
          columnDefs={columnDefs}
          autoGroupColumnDef={autoGroupColumnDef}
          defaultColDef={defaultColDef}
          suppressRowClickSelection={true}
          groupSelectsChildren={true}
          rowSelection={"multiple"}
          rowGroupPanelShow={"always"}
          pivotPanelShow={"always"}
          pagination={true}
          onGridReady={onGridReady}
        ></AgGridReact>
      </div>
    </div>
  );
};

const GridExample2 = () => {
  const containerStyle = useMemo(() => ({ width: "100%", height: "100%" }), []);
  const gridStyle = useMemo(() => ({ height: "100%", width: "100%" }), []);
  const [rowData, setRowData] = useState();
  const [columnDefs, setColumnDefs] = useState([
    { field: "athlete", minWidth: 170 },
    { field: "age" },
    { field: "country" },
    { field: "year" },
    { field: "date" },
    { field: "sport" },
    { field: "gold" },
    { field: "silver" },
    { field: "bronze" },
    { field: "total" },
  ]);
  const defaultColDef = useMemo(() => {
    return {
      editable: true,
      sortable: true,
      filter: true,
      resizable: true,
    };
  }, []);

  const onGridReady = useCallback((params) => {
    fetch("https://www.ag-grid.com/example-assets/olympic-winners.json")
      .then((resp) => resp.json())
      .then((data) => setRowData(data));
  }, []);

  return (
    <div style={containerStyle}>
      <div style={gridStyle} className="ag-theme-alpine">
        <AgGridReact
          rowData={rowData}
          columnDefs={columnDefs}
          defaultColDef={defaultColDef}
          sideBar={true}
          suppressMenuHide={true}
          onGridReady={onGridReady}
        ></AgGridReact>
      </div>
    </div>
  );
};

const DropdownExampleSearchSelection = () => (
  <Dropdown
    deburr
    options={options}
    placeholder='Source Name"'
    icon=""
    search
    selection
  />
);

const CheckboxExampleShorthandElement = (props) => (
  <Checkbox label={<label>{props.name}</label>} />
);

const TableExampleVeryCompact = () => (
  <Table compact="very">
    <Table.Header>
      <Table.Row>
        <Table.HeaderCell>
          <Checkbox />
        </Table.HeaderCell>
        <Table.HeaderCell>Name</Table.HeaderCell>
        <Table.HeaderCell>Status</Table.HeaderCell>
        <Table.HeaderCell>Notes</Table.HeaderCell>
        <Table.HeaderCell>Name</Table.HeaderCell>
        <Table.HeaderCell>Status</Table.HeaderCell>
        <Table.HeaderCell>Notes</Table.HeaderCell>
      </Table.Row>
    </Table.Header>

    <Table.Body>
      <Table.Row>
        <Table.Cell>
          <Checkbox />
        </Table.Cell>
        <Table.Cell>John</Table.Cell>
        <Table.Cell>Approved</Table.Cell>
        <Table.Cell>None</Table.Cell>
        <Table.Cell>John</Table.Cell>
        <Table.Cell>Approved</Table.Cell>
        <Table.Cell>None</Table.Cell>
      </Table.Row>
      <Table.Row>
        <Table.Cell>
          <Checkbox />
        </Table.Cell>

        <Table.Cell>Jamie</Table.Cell>
        <Table.Cell>Approved</Table.Cell>
        <Table.Cell>Requires call</Table.Cell>
        <Table.Cell>Jamie</Table.Cell>
        <Table.Cell>Approved</Table.Cell>
        <Table.Cell>Requires call</Table.Cell>
      </Table.Row>
      <Table.Row>
        <Table.Cell>
          <Checkbox />
        </Table.Cell>

        <Table.Cell>John</Table.Cell>
        <Table.Cell>Approved</Table.Cell>
        <Table.Cell>None</Table.Cell>
        <Table.Cell>John</Table.Cell>
        <Table.Cell>Approved</Table.Cell>
        <Table.Cell>None</Table.Cell>
      </Table.Row>
      <Table.Row>
        <Table.Cell>
          <Checkbox />
        </Table.Cell>

        <Table.Cell>Jamie</Table.Cell>
        <Table.Cell>Approved</Table.Cell>
        <Table.Cell>Requires call</Table.Cell>

        <Table.Cell>Jamie</Table.Cell>
        <Table.Cell>Approved</Table.Cell>
        <Table.Cell>Requires call</Table.Cell>
      </Table.Row>
      <Table.Row>
        <Table.Cell>
          <Checkbox />
        </Table.Cell>

        <Table.Cell>John</Table.Cell>
        <Table.Cell>Approved</Table.Cell>
        <Table.Cell>None</Table.Cell>
        <Table.Cell>John</Table.Cell>
        <Table.Cell>Approved</Table.Cell>
        <Table.Cell>None</Table.Cell>
      </Table.Row>
      <Table.Row>
        <Table.Cell>
          <Checkbox />
        </Table.Cell>

        <Table.Cell>Jamie</Table.Cell>
        <Table.Cell>Approved</Table.Cell>
        <Table.Cell>Requires call</Table.Cell>
        <Table.Cell>Jamie</Table.Cell>
        <Table.Cell>Approved</Table.Cell>
        <Table.Cell>Requires call</Table.Cell>
      </Table.Row>
      <Table.Row>
        <Table.Cell>
          <Checkbox />
        </Table.Cell>

        <Table.Cell>John</Table.Cell>
        <Table.Cell>Approved</Table.Cell>
        <Table.Cell>None</Table.Cell>

        <Table.Cell>John</Table.Cell>
        <Table.Cell>Approved</Table.Cell>
        <Table.Cell>None</Table.Cell>
      </Table.Row>
      <Table.Row>
        <Table.Cell>
          <Checkbox />
        </Table.Cell>

        <Table.Cell>Jamie</Table.Cell>
        <Table.Cell>Approved</Table.Cell>
        <Table.Cell>Requires call</Table.Cell>
        <Table.Cell>Jamie</Table.Cell>
        <Table.Cell>Approved</Table.Cell>
        <Table.Cell>Requires call</Table.Cell>
      </Table.Row>
    </Table.Body>
  </Table>
);

const TableExampleVeryCompact2 = () => (
  <Table compact="very">
    <Table.Header>
      <Table.Row>
        <Table.HeaderCell>
          <Checkbox />
        </Table.HeaderCell>
        <Table.HeaderCell>Name</Table.HeaderCell>
        <Table.HeaderCell>Status</Table.HeaderCell>
        <Table.HeaderCell>Notes</Table.HeaderCell>
        <Table.HeaderCell>Name</Table.HeaderCell>
        <Table.HeaderCell>Status</Table.HeaderCell>
        <Table.HeaderCell>Notes</Table.HeaderCell>
      </Table.Row>
    </Table.Header>

    <Table.Body>
      <Table.Row>
        <Table.Cell>
          <Checkbox />
        </Table.Cell>

        <Table.Cell>John</Table.Cell>
        <Table.Cell>Approved</Table.Cell>
        <Table.Cell>None</Table.Cell>
        <Table.Cell>John</Table.Cell>
        <Table.Cell>Approved</Table.Cell>
        <Table.Cell>None</Table.Cell>
      </Table.Row>
    </Table.Body>
  </Table>
);
const PaginationExamplePagination = () => (
  <Pagination defaultActivePage={5} totalPages={10} />
);

const InputExampleDatalist = () => (
  <div>
    <Input
      list="languages"
      placeholder="Search ..."
      icon="sort"
      iconPosition="right"
    />
    <datalist id="languages">
      <option value="HDFC 1">HDFC 1</option>
      <option value="HDFC 2">HDFC 2</option>
      <option value="SBI 1">SBI 1</option>
      <option value="HDFC 3">HDFC 3</option>
      <option value="HDFC 4">HDFC 4</option>
      <option value="SBI 2">SBI 2</option>
    </datalist>
  </div>
);
const ButtonExampleSocial = () => (
  <div>
    <Button color="#0A2352">
      <Icon name="filter" /> Button
    </Button>
  </div>
);



function BrsTypeList()
{
    setLoaderOpen(true);
    let payload = {
        "tenantId": userCredentials["tenants_id"],
        "groupId": userCredentials["groups_id"],
        "entityId": userCredentials["entities_id"],
        "mProcessingLayerId": userCredentials["m_processing_layer_id"],
        "mProcessingSubLayerId": userCredentials["m_processing_sub_layer_id"],
        "typeId": userCredentials["processing_layer_id"]
    }

    var getProcessingLayerList = getProcessingLayerListFromServer();

    axios.get(getProcessingLayerList[1], {params : payload}, getProcessingLayerList[0])
    .then(
        response => {
            console.log("Processing Layer List!!!", response)
            let data = response["data"];
            if (data["Status"] === "Success")
            {
                // let rowData = data["response_data"];
                // for(let i = 0; i < rowData.length; i++)
                // {
                //     rowData[i]["file_size_bytes"] = Math.round( rowData[i]["file_size_bytes"] * 0.001 ) / 100;
                // }

                // setRowData(rowData);
                setLoaderOpen(false);
            }
        }
    ).catch(
        error => {
            console.log("Error in File Upload List!!!", error);
            setLoaderOpen(false);
        }
    );

}


class reconSummary extends React.Component {
  state = {};
  // componentDidMount() {
  //   BrsTypeList();
  // }

  handleClick = (e, { title }) => this.setState({ active: title });

  render() {
    const { active } = this.state;
    return (
      <div>
        {/* <h1>hi</h1> */}
        <div className="side">
          <Grid columns="equal" style={{ padding: "10px" }}>
            <Grid.Row
              style={{ backgroundColor: "#e9e8d9", borderRadius: "12px" }}
            >
              <Grid.Column width={3}>
                <InputExampleDatalist />
              </Grid.Column>


              <Grid.Column width={2}>
                <ButtonExampleSocial />
              </Grid.Column>
              <Grid.Column width={2}>
                <ButtonExampleSocial />
              </Grid.Column>
              <Grid.Column width={2}>
                <ButtonExampleSocial />
              </Grid.Column>
            </Grid.Row>
            {/*  */}
            <Grid.Row
              style={{
                backgroundColor: "#e9e8d9",
                borderRadius: "12px",
                marginTop: "10px",
              }}
            >
              <Grid.Column
                width={5}
                style={{
                  backgroundColor: "white",
                  marginLeft: "15px",
                  borderRadius: "12px",
                }}
              >
                <div style={{ marginTop: "25px" }}>
                  <ApexChart />
                </div>
              </Grid.Column>
              <Grid.Column
                width={5}
                style={{
                  backgroundColor: "white",
                  marginLeft: "20px",
                  borderRadius: "12px",
                }}
              >
                <ApexChartBarColum />
              </Grid.Column>
              <Grid.Column
                width={5}
                style={{
                  backgroundColor: "white",
                  marginLeft: "20px",
                  borderRadius: "12px",
                }}
              >
                <ApexChartBar />
              </Grid.Column>
            </Grid.Row>
            <Grid.Row
              style={{
                backgroundColor: "#e9e8d9",
                borderRadius: "12px",
                marginTop: "10px",
                height: "248px",
              }}
            >
              <Grid.Column>
                <GridExample />
              </Grid.Column>
              <Grid.Column>
                <GridExample />
              </Grid.Column>
            </Grid.Row>
            {/*  */}
            <Grid.Row
              style={{
                backgroundColor: "#e9e8d9",
                borderRadius: "12px",
                marginTop: "10px",
                height: "248px",
              }}
            >
              <Grid.Column>
                <GridExample />
              </Grid.Column>
              <Grid.Column>
                <GridExample />
              </Grid.Column>
            </Grid.Row>
          </Grid>
        </div>
      </div>
    );
  }
}

export default reconSummary;

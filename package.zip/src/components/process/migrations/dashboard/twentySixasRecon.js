import React, { useState, useMemo } from 'react';
// import Select from "react-select";
// import './dashboard.css';
import './gst.css';
import axios from 'axios';
import { monthWiseGstToServer } from '../../../../services/process/migrations/migrationService.js';
import { Select, Dropdown } from 'semantic-ui-react';
import ReactApexChart from 'react-apexcharts';
import { BarChart, Bar, XAxis, YAxis, Legend, Tooltip } from 'recharts';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';


function Twentysixrecon({ hidden }) {
    const processedList = [{ "source_name": 'Invoice_Salary_Report_CM' }]
    const pendingList = [{ "source_name": 'Invoice_Salary_Report_CM' }]
    const [gstHidden, setGstHidden] = useState(true);
    const [inputMonth, setInputMonth] = useState(undefined);
    const [inputMonth1, setInputMonth1] = useState(undefined);
    const [show, setshow] = useState(false);
    
    const [rowData, setrowData] = useState([{"customer":"CS0034","Gross-value":126248498},{"customer":"CN0068","Gross-value":86548622},{"customer":"cm0004","Gross-value":77441605},{"customer":"CE0002","Gross-value":63655956},]);
    const [columnames, setcolumnnames] = useState(null);

    const [filtervalue, setfiltervalue] = useState(undefined);
    const [reports, setreports] = useState(undefined);
    const customStyles = undefined;

    const [customers, setcustomers] = useState([]);
    const [grossValues, setgrossValues] = useState([]);
    const [grossValues1, setgrossValues1] = useState([]);
    const [issalestrends, setissalestrends] = useState(false);
    const [isfilterHidden, setisfilterHidden] = useState(false);


    const sales_vs_collections = [{"data-1 customer":"CA0223","data-1 Gross-value":-236250,"data-2 customer":"CA0223","data-2 Gross-value":1.0},{"data-1 customer":"CA0223","data-1 Gross-value":-236250,"data-2 customer":"CA0223","data-2 Gross-value":2716993.0},{"data-1 customer":"CS0443","data-1 Gross-value":-85050,"data-2 customer":"CS0443","data-2 Gross-value":-2.0},{"data-1 customer":"CS0443","data-1 Gross-value":-85050,"data-2 customer":"CS0443","data-2 Gross-value":446041.0},{"data-1 customer":"CM0016","data-1 Gross-value":-72000,"data-2 customer":"CM0016","data-2 Gross-value":0.0},{"data-1 customer":"CM0016","data-1 Gross-value":-72000,"data-2 customer":"CM0016","data-2 Gross-value":1587431.0},{"data-1 customer":"CS0491","data-1 Gross-value":0,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CR0138","data-1 Gross-value":0,"data-2 customer":"CR0138","data-2 Gross-value":0.0},{"data-1 customer":"CR0138","data-1 Gross-value":0,"data-2 customer":"CR0138","data-2 Gross-value":1044053.0},{"data-1 customer":"CT0168","data-1 Gross-value":0,"data-2 customer":"CT0168","data-2 Gross-value":414281.0},{"data-1 customer":"CT0157","data-1 Gross-value":0,"data-2 customer":"CT0157","data-2 Gross-value":56522.0},{"data-1 customer":"CT0192","data-1 Gross-value":0,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CF0002","data-1 Gross-value":0,"data-2 customer":"CF0002","data-2 Gross-value":124596.0},{"data-1 customer":"CE0007","data-1 Gross-value":200,"data-2 customer":"CE0007","data-2 Gross-value":-652.0},{"data-1 customer":"CE0007","data-1 Gross-value":200,"data-2 customer":"CE0007","data-2 Gross-value":11930550.0},{"data-1 customer":"CT0160","data-1 Gross-value":500,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CJ0136","data-1 Gross-value":600,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CD0144","data-1 Gross-value":1100,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CW0041","data-1 Gross-value":1500,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CK0136","data-1 Gross-value":2275,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CS0490","data-1 Gross-value":2976,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CV0020","data-1 Gross-value":3610,"data-2 customer":"CV0020","data-2 Gross-value":45076.0},{"data-1 customer":"CC0111","data-1 Gross-value":3735,"data-2 customer":"CC0111","data-2 Gross-value":0.0},{"data-1 customer":"CC0111","data-1 Gross-value":3735,"data-2 customer":"CC0111","data-2 Gross-value":113679.0},{"data-1 customer":"CS0351","data-1 Gross-value":3750,"data-2 customer":"CS0351","data-2 Gross-value":54457.0},{"data-1 customer":"CS0476","data-1 Gross-value":3825,"data-2 customer":"CS0476","data-2 Gross-value":8793.0},{"data-1 customer":"CF0089","data-1 Gross-value":3925,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CH0177","data-1 Gross-value":4018,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CS0015","data-1 Gross-value":4200,"data-2 customer":"CS0015","data-2 Gross-value":5105.0},{"data-1 customer":"CP0231","data-1 Gross-value":4900,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CA0309","data-1 Gross-value":5182,"data-2 customer":"CA0309","data-2 Gross-value":608543.0},{"data-1 customer":"CA0309","data-1 Gross-value":5182,"data-2 customer":"CA0309","data-2 Gross-value":5484652.0},{"data-1 customer":"CP0103","data-1 Gross-value":5800,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CH0157","data-1 Gross-value":5850,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CD0142","data-1 Gross-value":6578,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CJ0107","data-1 Gross-value":6752,"data-2 customer":"CJ0107","data-2 Gross-value":147624.0},{"data-1 customer":"CT0088","data-1 Gross-value":7100,"data-2 customer":"CT0088","data-2 Gross-value":40002.0},{"data-1 customer":"CJ0146","data-1 Gross-value":7500,"data-2 customer":"CJ0146","data-2 Gross-value":35400.0},{"data-1 customer":"CJ0146","data-1 Gross-value":7500,"data-2 customer":"CJ0146","data-2 Gross-value":1423499.0},{"data-1 customer":"CM0249","data-1 Gross-value":7593,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CW0039","data-1 Gross-value":7755,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CE0104","data-1 Gross-value":7990,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CB0207","data-1 Gross-value":8000,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CB0185","data-1 Gross-value":9000,"data-2 customer":"CB0185","data-2 Gross-value":147052.0},{"data-1 customer":"CA0236","data-1 Gross-value":9000,"data-2 customer":"CA0236","data-2 Gross-value":10989.0},{"data-1 customer":"CS0305","data-1 Gross-value":9700,"data-2 customer":"CS0305","data-2 Gross-value":0.0},{"data-1 customer":"CS0305","data-1 Gross-value":9700,"data-2 customer":"CS0305","data-2 Gross-value":12824.0},{"data-1 customer":"CT0040","data-1 Gross-value":9790,"data-2 customer":"CT0040","data-2 Gross-value":52002.0},{"data-1 customer":"CT0082","data-1 Gross-value":10400,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CW0040","data-1 Gross-value":11000,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CB0224","data-1 Gross-value":11031,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CP0206","data-1 Gross-value":11050,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CV0130","data-1 Gross-value":11410,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CK0058","data-1 Gross-value":11788,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CS0419","data-1 Gross-value":12000,"data-2 customer":"CS0419","data-2 Gross-value":284445.0},{"data-1 customer":"CL0093","data-1 Gross-value":12000,"data-2 customer":"CL0093","data-2 Gross-value":26070.0},{"data-1 customer":"CW0038","data-1 Gross-value":12000,"data-2 customer":"CW0038","data-2 Gross-value":5943.0},{"data-1 customer":"CZ0006","data-1 Gross-value":12008,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CR0008","data-1 Gross-value":12150,"data-2 customer":"CR0008","data-2 Gross-value":131519.0},{"data-1 customer":"CR0109","data-1 Gross-value":12500,"data-2 customer":"CR0109","data-2 Gross-value":20419.0},{"data-1 customer":"CO0017","data-1 Gross-value":12500,"data-2 customer":"CO0017","data-2 Gross-value":20492.0},{"data-1 customer":"CF0090","data-1 Gross-value":12500,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CI0001","data-1 Gross-value":12600,"data-2 customer":"CI0001","data-2 Gross-value":157800.0},{"data-1 customer":"CV0045","data-1 Gross-value":12700,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CG0142","data-1 Gross-value":14117,"data-2 customer":"CG0142","data-2 Gross-value":37885.0},{"data-1 customer":"CG0161","data-1 Gross-value":14160,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CS0195","data-1 Gross-value":15137,"data-2 customer":"CS0195","data-2 Gross-value":117831.0},{"data-1 customer":"CG0149","data-1 Gross-value":17000,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CM0239","data-1 Gross-value":17270,"data-2 customer":"CM0239","data-2 Gross-value":23348.0},{"data-1 customer":"CM0239","data-1 Gross-value":17270,"data-2 customer":"CM0239","data-2 Gross-value":69423.0},{"data-1 customer":"CS0001","data-1 Gross-value":17480,"data-2 customer":"CS0001","data-2 Gross-value":15571.0},{"data-1 customer":"CS0001","data-1 Gross-value":17480,"data-2 customer":"CS0001","data-2 Gross-value":141095.0},{"data-1 customer":"CC0073","data-1 Gross-value":17840,"data-2 customer":"CC0073","data-2 Gross-value":0.0},{"data-1 customer":"CC0073","data-1 Gross-value":17840,"data-2 customer":"CC0073","data-2 Gross-value":3716554.0},{"data-1 customer":"CJ0118","data-1 Gross-value":19880,"data-2 customer":"CJ0118","data-2 Gross-value":42163.0},{"data-1 customer":"CS0492","data-1 Gross-value":21250,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CT0190","data-1 Gross-value":21500,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CT0170","data-1 Gross-value":22000,"data-2 customer":"CT0170","data-2 Gross-value":739785.0},{"data-1 customer":"CS0195","data-1 Gross-value":22110,"data-2 customer":"CS0195","data-2 Gross-value":117831.0},{"data-1 customer":"CE0027","data-1 Gross-value":22500,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CR0148","data-1 Gross-value":23000,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CD0143","data-1 Gross-value":23000,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CN0063","data-1 Gross-value":23160,"data-2 customer":"CN0063","data-2 Gross-value":213154.0},{"data-1 customer":"CN0063","data-1 Gross-value":23160,"data-2 customer":"CN0063","data-2 Gross-value":1440350.0},{"data-1 customer":"CC0171","data-1 Gross-value":23700,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CW0031","data-1 Gross-value":24525,"data-2 customer":"CW0031","data-2 Gross-value":1146004.0},{"data-1 customer":"CW0031","data-1 Gross-value":24525,"data-2 customer":"CW0031","data-2 Gross-value":2300802.0},{"data-1 customer":"CT0193","data-1 Gross-value":26369,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CA0319","data-1 Gross-value":26400,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CC0037","data-1 Gross-value":27550,"data-2 customer":"CC0037","data-2 Gross-value":26283.0},{"data-1 customer":"CJ0069","data-1 Gross-value":27653,"data-2 customer":"CJ0069","data-2 Gross-value":226702.0},{"data-1 customer":"CJ0069","data-1 Gross-value":27653,"data-2 customer":"CJ0069","data-2 Gross-value":13982244.0},{"data-1 customer":"CS0075","data-1 Gross-value":27660,"data-2 customer":"CS0075","data-2 Gross-value":50000.0},{"data-1 customer":"CS0075","data-1 Gross-value":27660,"data-2 customer":"CS0075","data-2 Gross-value":250347.0},{"data-1 customer":"CD0109","data-1 Gross-value":27950,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CU0021","data-1 Gross-value":28500,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CE0096","data-1 Gross-value":28840,"data-2 customer":"CE0096","data-2 Gross-value":179856.0},{"data-1 customer":"CE0096","data-1 Gross-value":28840,"data-2 customer":"CE0096","data-2 Gross-value":187401.0},{"data-1 customer":"CA0194","data-1 Gross-value":29340,"data-2 customer":"CA0194","data-2 Gross-value":51507.0},{"data-1 customer":"CA0279","data-1 Gross-value":30468,"data-2 customer":"CA0279","data-2 Gross-value":32477.0},{"data-1 customer":"CA0279","data-1 Gross-value":30468,"data-2 customer":"CA0279","data-2 Gross-value":45322.0},{"data-1 customer":"CM0231","data-1 Gross-value":31237,"data-2 customer":"CM0231","data-2 Gross-value":1821235.0},{"data-1 customer":"CM0231","data-1 Gross-value":31237,"data-2 customer":"CM0231","data-2 Gross-value":4947605.0},{"data-1 customer":"CT0191","data-1 Gross-value":34250,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CE0103","data-1 Gross-value":35050,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CB0185","data-1 Gross-value":36000,"data-2 customer":"CB0185","data-2 Gross-value":147052.0},{"data-1 customer":"CM0024","data-1 Gross-value":36750,"data-2 customer":"CM0024","data-2 Gross-value":0.0},{"data-1 customer":"CM0024","data-1 Gross-value":36750,"data-2 customer":"CM0024","data-2 Gross-value":208636.0},{"data-1 customer":"CJ0133","data-1 Gross-value":37000,"data-2 customer":"CJ0133","data-2 Gross-value":0.0},{"data-1 customer":"CJ0133","data-1 Gross-value":37000,"data-2 customer":"CJ0133","data-2 Gross-value":4254419.0},{"data-1 customer":"CH0178","data-1 Gross-value":39160,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CH100","data-1 Gross-value":40200,"data-2 customer":"CH100","data-2 Gross-value":71198.0},{"data-1 customer":"CA0020","data-1 Gross-value":42576,"data-2 customer":"CA0020","data-2 Gross-value":180981.0},{"data-1 customer":"CA0020","data-1 Gross-value":42576,"data-2 customer":"CA0020","data-2 Gross-value":4877276.0},{"data-1 customer":"CS0466","data-1 Gross-value":42600,"data-2 customer":"CS0466","data-2 Gross-value":1.0},{"data-1 customer":"CS0466","data-1 Gross-value":42600,"data-2 customer":"CS0466","data-2 Gross-value":357083.0},{"data-1 customer":"CN0078","data-1 Gross-value":43350,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CL0093","data-1 Gross-value":43400,"data-2 customer":"CL0093","data-2 Gross-value":26070.0},{"data-1 customer":"CC0121","data-1 Gross-value":44400,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CP0207","data-1 Gross-value":47768,"data-2 customer":"CP0207","data-2 Gross-value":4147.0},{"data-1 customer":"CA0276","data-1 Gross-value":48800,"data-2 customer":"CA0276","data-2 Gross-value":465805.0},{"data-1 customer":"CM0248","data-1 Gross-value":49600,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CT0164","data-1 Gross-value":50850,"data-2 customer":"CT0164","data-2 Gross-value":272983.0},{"data-1 customer":"CA0296","data-1 Gross-value":52000,"data-2 customer":"CA0296","data-2 Gross-value":82209.0},{"data-1 customer":"CF0003","data-1 Gross-value":55284,"data-2 customer":"CF0003","data-2 Gross-value":99975.0},{"data-1 customer":"CS0009","data-1 Gross-value":56238,"data-2 customer":"CS0009","data-2 Gross-value":734456.0},{"data-1 customer":"CO0027","data-1 Gross-value":57500,"data-2 customer":"CO0027","data-2 Gross-value":3646.0},{"data-1 customer":"CO0027","data-1 Gross-value":57500,"data-2 customer":"CO0027","data-2 Gross-value":65632.0},{"data-1 customer":"CY0010","data-1 Gross-value":59850,"data-2 customer":"CY0010","data-2 Gross-value":64721.0},{"data-1 customer":"CE0063","data-1 Gross-value":60000,"data-2 customer":"CE0063","data-2 Gross-value":183011.0},{"data-1 customer":"CP0221","data-1 Gross-value":60900,"data-2 customer":"CP0221","data-2 Gross-value":89941.0},{"data-1 customer":"CP0221","data-1 Gross-value":60900,"data-2 customer":"CP0221","data-2 Gross-value":202365.0},{"data-1 customer":"CJ0047","data-1 Gross-value":61800,"data-2 customer":"CJ0047","data-2 Gross-value":7333.0},{"data-1 customer":"CF0039","data-1 Gross-value":62000,"data-2 customer":"CF0039","data-2 Gross-value":136621.0},{"data-1 customer":"CV0141","data-1 Gross-value":62724,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CS0430","data-1 Gross-value":62780,"data-2 customer":"CS0430","data-2 Gross-value":1.0},{"data-1 customer":"CS0430","data-1 Gross-value":62780,"data-2 customer":"CS0430","data-2 Gross-value":76576.0},{"data-1 customer":"CP0194","data-1 Gross-value":63000,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CC0111","data-1 Gross-value":63131,"data-2 customer":"CC0111","data-2 Gross-value":0.0},{"data-1 customer":"CC0111","data-1 Gross-value":63131,"data-2 customer":"CC0111","data-2 Gross-value":113679.0},{"data-1 customer":"CS0485","data-1 Gross-value":63935,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CL0089","data-1 Gross-value":64964,"data-2 customer":"CL0089","data-2 Gross-value":371756.0},{"data-1 customer":"CL0089","data-1 Gross-value":64964,"data-2 customer":"CL0089","data-2 Gross-value":830001.0},{"data-1 customer":"CC0166","data-1 Gross-value":65872,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CU0037","data-1 Gross-value":66630,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CT0040","data-1 Gross-value":67056,"data-2 customer":"CT0040","data-2 Gross-value":52002.0},{"data-1 customer":"CU0032","data-1 Gross-value":67136,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CD0099","data-1 Gross-value":68600,"data-2 customer":"CD0099","data-2 Gross-value":4938388.0},{"data-1 customer":"CR0002","data-1 Gross-value":69300,"data-2 customer":"CR0002","data-2 Gross-value":2628.0},{"data-1 customer":"CR0002","data-1 Gross-value":69300,"data-2 customer":"CR0002","data-2 Gross-value":1790220.0},{"data-1 customer":"CK0130","data-1 Gross-value":73270,"data-2 customer":"CK0130","data-2 Gross-value":109280.0},{"data-1 customer":"CS0277","data-1 Gross-value":75000,"data-2 customer":"CS0277","data-2 Gross-value":367956.0},{"data-1 customer":"CH0058","data-1 Gross-value":79416,"data-2 customer":"CH0058","data-2 Gross-value":38793.0},{"data-1 customer":"CO0049","data-1 Gross-value":80090,"data-2 customer":"CO0049","data-2 Gross-value":76406.0},{"data-1 customer":"CH0170","data-1 Gross-value":80280,"data-2 customer":"CH0170","data-2 Gross-value":96478.0},{"data-1 customer":"CA0076","data-1 Gross-value":81025,"data-2 customer":"CA0076","data-2 Gross-value":0.0},{"data-1 customer":"CA0076","data-1 Gross-value":81025,"data-2 customer":"CA0076","data-2 Gross-value":528047.0},{"data-1 customer":"CA0316","data-1 Gross-value":81622,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CA0316","data-1 Gross-value":81622,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CT0011","data-1 Gross-value":90400,"data-2 customer":"CT0011","data-2 Gross-value":466690.0},{"data-1 customer":"CL0046","data-1 Gross-value":91155,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CS0493","data-1 Gross-value":92340,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CG0040","data-1 Gross-value":92500,"data-2 customer":"CG0040","data-2 Gross-value":64112.0},{"data-1 customer":"CG0040","data-1 Gross-value":92500,"data-2 customer":"CG0040","data-2 Gross-value":119273.0},{"data-1 customer":"CT0097","data-1 Gross-value":94500,"data-2 customer":"CT0097","data-2 Gross-value":336781.0},{"data-1 customer":"CT0097","data-1 Gross-value":94500,"data-2 customer":"CT0097","data-2 Gross-value":448407.0},{"data-1 customer":"CS0324","data-1 Gross-value":95488,"data-2 customer":"CS0324","data-2 Gross-value":294180.0},{"data-1 customer":"CA0047","data-1 Gross-value":95900,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CJ0145","data-1 Gross-value":96090,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CJ0115","data-1 Gross-value":99000,"data-2 customer":"CJ0115","data-2 Gross-value":405504.0},{"data-1 customer":"CA0310","data-1 Gross-value":101974,"data-2 customer":"CA0310","data-2 Gross-value":450240.0},{"data-1 customer":"CL0064","data-1 Gross-value":102201,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CP0008","data-1 Gross-value":106572,"data-2 customer":"CP0008","data-2 Gross-value":2764272.0},{"data-1 customer":"CP0008","data-1 Gross-value":106572,"data-2 customer":"CP0008","data-2 Gross-value":2814756.0},{"data-1 customer":"CH0133","data-1 Gross-value":108900,"data-2 customer":"CH0133","data-2 Gross-value":118915.0},{"data-1 customer":"CM0007","data-1 Gross-value":109046,"data-2 customer":"CM0007","data-2 Gross-value":0.0},{"data-1 customer":"CM0007","data-1 Gross-value":109046,"data-2 customer":"CM0007","data-2 Gross-value":1007032.0},{"data-1 customer":"CS0471","data-1 Gross-value":115200,"data-2 customer":"CS0471","data-2 Gross-value":320423.0},{"data-1 customer":"CS0471","data-1 Gross-value":118130,"data-2 customer":"CS0471","data-2 Gross-value":320423.0},{"data-1 customer":"CI0043","data-1 Gross-value":128100,"data-2 customer":"CI0043","data-2 Gross-value":485157.0},{"data-1 customer":"CC0002","data-1 Gross-value":131893,"data-2 customer":"CC0002","data-2 Gross-value":3249345.0},{"data-1 customer":"CC0002","data-1 Gross-value":131893,"data-2 customer":"CC0002","data-2 Gross-value":3482453.0},{"data-1 customer":"CM0106","data-1 Gross-value":136480,"data-2 customer":"CM0106","data-2 Gross-value":429240.0},{"data-1 customer":"CM0106","data-1 Gross-value":136480,"data-2 customer":"CM0106","data-2 Gross-value":1324048.0},{"data-1 customer":"CB0205","data-1 Gross-value":137100,"data-2 customer":"CB0205","data-2 Gross-value":228058.0},{"data-1 customer":"CS0465","data-1 Gross-value":137700,"data-2 customer":"CS0465","data-2 Gross-value":241256.0},{"data-1 customer":"CS0465","data-1 Gross-value":137700,"data-2 customer":"CS0465","data-2 Gross-value":257909.0},{"data-1 customer":"CF0002","data-1 Gross-value":140624,"data-2 customer":"CF0002","data-2 Gross-value":124596.0},{"data-1 customer":"CM0232","data-1 Gross-value":151556,"data-2 customer":"CM0232","data-2 Gross-value":824000.0},{"data-1 customer":"CS0408","data-1 Gross-value":154408,"data-2 customer":"CS0408","data-2 Gross-value":0.0},{"data-1 customer":"CS0408","data-1 Gross-value":154408,"data-2 customer":"CS0408","data-2 Gross-value":826869.0},{"data-1 customer":"CD0137","data-1 Gross-value":154973,"data-2 customer":"CD0137","data-2 Gross-value":16422.0},{"data-1 customer":"CD0137","data-1 Gross-value":154973,"data-2 customer":"CD0137","data-2 Gross-value":100757.0},{"data-1 customer":"CS0426","data-1 Gross-value":158201,"data-2 customer":"CS0426","data-2 Gross-value":774442.0},{"data-1 customer":"CD0095","data-1 Gross-value":166279,"data-2 customer":"CD0095","data-2 Gross-value":159675.0},{"data-1 customer":"CM0024","data-1 Gross-value":171660,"data-2 customer":"CM0024","data-2 Gross-value":0.0},{"data-1 customer":"CM0024","data-1 Gross-value":171660,"data-2 customer":"CM0024","data-2 Gross-value":208636.0},{"data-1 customer":"CV0068","data-1 Gross-value":174924,"data-2 customer":"CV0068","data-2 Gross-value":0.0},{"data-1 customer":"CV0068","data-1 Gross-value":174924,"data-2 customer":"CV0068","data-2 Gross-value":2221996.0},{"data-1 customer":"CB0144","data-1 Gross-value":178170,"data-2 customer":"CB0144","data-2 Gross-value":51344.0},{"data-1 customer":"CR0142","data-1 Gross-value":178200,"data-2 customer":"CR0142","data-2 Gross-value":211102.0},{"data-1 customer":"CU0025","data-1 Gross-value":181400,"data-2 customer":"CU0025","data-2 Gross-value":56881.0},{"data-1 customer":"CS0035","data-1 Gross-value":183300,"data-2 customer":"CS0035","data-2 Gross-value":1634174.0},{"data-1 customer":"CS0035","data-1 Gross-value":183300,"data-2 customer":"CS0035","data-2 Gross-value":2083126.0},{"data-1 customer":"CS0141","data-1 Gross-value":190000,"data-2 customer":"CS0141","data-2 Gross-value":322760.0},{"data-1 customer":"CS0141","data-1 Gross-value":190000,"data-2 customer":"CS0141","data-2 Gross-value":1209280.0},{"data-1 customer":"CO0004","data-1 Gross-value":191300,"data-2 customer":"CO0004","data-2 Gross-value":0.0},{"data-1 customer":"CO0004","data-1 Gross-value":191300,"data-2 customer":"CO0004","data-2 Gross-value":85943.0},{"data-1 customer":"CA0242","data-1 Gross-value":196350,"data-2 customer":"CA0242","data-2 Gross-value":844998.0},{"data-1 customer":"CN0113","data-1 Gross-value":200865,"data-2 customer":"CN0113","data-2 Gross-value":80689.0},{"data-1 customer":"CB0121","data-1 Gross-value":205200,"data-2 customer":"CB0121","data-2 Gross-value":2088364.0},{"data-1 customer":"CR0012","data-1 Gross-value":205452,"data-2 customer":"CR0012","data-2 Gross-value":38074.0},{"data-1 customer":"CR0012","data-1 Gross-value":205452,"data-2 customer":"CR0012","data-2 Gross-value":3175990.0},{"data-1 customer":"CA0233","data-1 Gross-value":208330,"data-2 customer":"CA0233","data-2 Gross-value":248567.0},{"data-1 customer":"CD0017","data-1 Gross-value":209050,"data-2 customer":"CD0017","data-2 Gross-value":1469148.0},{"data-1 customer":"CI0001","data-1 Gross-value":217609,"data-2 customer":"CI0001","data-2 Gross-value":157800.0},{"data-1 customer":"CM0247","data-1 Gross-value":220844,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CN0102","data-1 Gross-value":224250,"data-2 customer":"CN0102","data-2 Gross-value":0.0},{"data-1 customer":"CN0102","data-1 Gross-value":224250,"data-2 customer":"CN0102","data-2 Gross-value":651360.0},{"data-1 customer":"CD0135","data-1 Gross-value":224940,"data-2 customer":"CD0135","data-2 Gross-value":208371.0},{"data-1 customer":"CD0135","data-1 Gross-value":224940,"data-2 customer":"CD0135","data-2 Gross-value":884941.0},{"data-1 customer":"CA0011","data-1 Gross-value":226200,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CK0131","data-1 Gross-value":229550,"data-2 customer":"CK0131","data-2 Gross-value":87326.0},{"data-1 customer":"CK0131","data-1 Gross-value":229550,"data-2 customer":"CK0131","data-2 Gross-value":100000.0},{"data-1 customer":"CM0235","data-1 Gross-value":230020,"data-2 customer":"CM0235","data-2 Gross-value":271415.0},{"data-1 customer":"CD0139","data-1 Gross-value":230300,"data-2 customer":"CD0139","data-2 Gross-value":93751.0},{"data-1 customer":"CD0139","data-1 Gross-value":230300,"data-2 customer":"CD0139","data-2 Gross-value":188387.0},{"data-1 customer":"CS0489","data-1 Gross-value":233500,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CS0126","data-1 Gross-value":240000,"data-2 customer":"CS0126","data-2 Gross-value":96999.0},{"data-1 customer":"CS0126","data-1 Gross-value":240000,"data-2 customer":"CS0126","data-2 Gross-value":455568.0},{"data-1 customer":"CS0419","data-1 Gross-value":246970,"data-2 customer":"CS0419","data-2 Gross-value":284445.0},{"data-1 customer":"CJ0138","data-1 Gross-value":249268,"data-2 customer":"CJ0138","data-2 Gross-value":1361702.0},{"data-1 customer":"CK0122","data-1 Gross-value":249280,"data-2 customer":"CK0122","data-2 Gross-value":16000.0},{"data-1 customer":"CA0004","data-1 Gross-value":255105,"data-2 customer":"CA0004","data-2 Gross-value":1071184.0},{"data-1 customer":"CA0004","data-1 Gross-value":255105,"data-2 customer":"CA0004","data-2 Gross-value":1613546.0},{"data-1 customer":"CU0048","data-1 Gross-value":256400,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CA0029","data-1 Gross-value":259200,"data-2 customer":"CA0029","data-2 Gross-value":268299.0},{"data-1 customer":"CT0106","data-1 Gross-value":261900,"data-2 customer":"CT0106","data-2 Gross-value":492227.0},{"data-1 customer":"CT0106","data-1 Gross-value":261900,"data-2 customer":"CT0106","data-2 Gross-value":1846484.0},{"data-1 customer":"CV0151","data-1 Gross-value":263580,"data-2 customer":"CV0151","data-2 Gross-value":977756.0},{"data-1 customer":"CV0151","data-1 Gross-value":263580,"data-2 customer":"CV0151","data-2 Gross-value":5351607.0},{"data-1 customer":"CS0004","data-1 Gross-value":264660,"data-2 customer":"CS0004","data-2 Gross-value":965000.0},{"data-1 customer":"CS0004","data-1 Gross-value":264660,"data-2 customer":"CS0004","data-2 Gross-value":1135000.0},{"data-1 customer":"CA0096","data-1 Gross-value":267775,"data-2 customer":"CA0096","data-2 Gross-value":0.0},{"data-1 customer":"CA0096","data-1 Gross-value":267775,"data-2 customer":"CA0096","data-2 Gross-value":3389710.0},{"data-1 customer":"CV0159","data-1 Gross-value":285040,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CC0089","data-1 Gross-value":285404,"data-2 customer":"CC0089","data-2 Gross-value":315000.0},{"data-1 customer":"CC0089","data-1 Gross-value":285404,"data-2 customer":"CC0089","data-2 Gross-value":1905984.0},{"data-1 customer":"CJ0031","data-1 Gross-value":300000,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CJ0142","data-1 Gross-value":305000,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CV0159","data-1 Gross-value":313040,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CD0065","data-1 Gross-value":315286,"data-2 customer":"CD0065","data-2 Gross-value":5230898.0},{"data-1 customer":"CD0065","data-1 Gross-value":315286,"data-2 customer":"CD0065","data-2 Gross-value":6637306.0},{"data-1 customer":"CB0008","data-1 Gross-value":320950,"data-2 customer":"CB0008","data-2 Gross-value":931612.0},{"data-1 customer":"CA0018","data-1 Gross-value":340290,"data-2 customer":"CA0018","data-2 Gross-value":626244.0},{"data-1 customer":"CA0018","data-1 Gross-value":340290,"data-2 customer":"CA0018","data-2 Gross-value":2249752.0},{"data-1 customer":"CP0165","data-1 Gross-value":341340,"data-2 customer":"CP0165","data-2 Gross-value":1116678.0},{"data-1 customer":"CP0165","data-1 Gross-value":341340,"data-2 customer":"CP0165","data-2 Gross-value":5015588.0},{"data-1 customer":"CE0025","data-1 Gross-value":345042,"data-2 customer":"CE0025","data-2 Gross-value":217648.0},{"data-1 customer":"CG0148","data-1 Gross-value":357084,"data-2 customer":"CG0148","data-2 Gross-value":1680654.0},{"data-1 customer":"CG0148","data-1 Gross-value":357084,"data-2 customer":"CG0148","data-2 Gross-value":2144708.0},{"data-1 customer":"CL0016","data-1 Gross-value":357420,"data-2 customer":"CL0016","data-2 Gross-value":1380869.0},{"data-1 customer":"CM0114","data-1 Gross-value":374260,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CT0054","data-1 Gross-value":374510,"data-2 customer":"CT0054","data-2 Gross-value":300000.0},{"data-1 customer":"CT0054","data-1 Gross-value":374510,"data-2 customer":"CT0054","data-2 Gross-value":1282968.0},{"data-1 customer":"CD0141","data-1 Gross-value":382550,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CS0444","data-1 Gross-value":395110,"data-2 customer":"CS0444","data-2 Gross-value":1212651.0},{"data-1 customer":"CS0444","data-1 Gross-value":395110,"data-2 customer":"CS0444","data-2 Gross-value":3796841.0},{"data-1 customer":"CS0390","data-1 Gross-value":398668,"data-2 customer":"CS0390","data-2 Gross-value":1410001.0},{"data-1 customer":"CS0390","data-1 Gross-value":398668,"data-2 customer":"CS0390","data-2 Gross-value":1738001.0},{"data-1 customer":"CA0001","data-1 Gross-value":407410,"data-2 customer":"CA0001","data-2 Gross-value":1700244.0},{"data-1 customer":"CA0001","data-1 Gross-value":407410,"data-2 customer":"CA0001","data-2 Gross-value":4928158.0},{"data-1 customer":"CT0097","data-1 Gross-value":411520,"data-2 customer":"CT0097","data-2 Gross-value":336781.0},{"data-1 customer":"CT0097","data-1 Gross-value":411520,"data-2 customer":"CT0097","data-2 Gross-value":448407.0},{"data-1 customer":"CR0144","data-1 Gross-value":418910,"data-2 customer":"CR0144","data-2 Gross-value":644831.0},{"data-1 customer":"CA0300","data-1 Gross-value":427550,"data-2 customer":"CA0300","data-2 Gross-value":75520.0},{"data-1 customer":"CM0165","data-1 Gross-value":437176,"data-2 customer":"CM0165","data-2 Gross-value":-434.0},{"data-1 customer":"CM0165","data-1 Gross-value":437176,"data-2 customer":"CM0165","data-2 Gross-value":21660348.0},{"data-1 customer":"CT0164","data-1 Gross-value":439890,"data-2 customer":"CT0164","data-2 Gross-value":272983.0},{"data-1 customer":"CM0049","data-1 Gross-value":439940,"data-2 customer":"CM0049","data-2 Gross-value":0.0},{"data-1 customer":"CM0049","data-1 Gross-value":439940,"data-2 customer":"CM0049","data-2 Gross-value":7071136.0},{"data-1 customer":"CP0221","data-1 Gross-value":447675,"data-2 customer":"CP0221","data-2 Gross-value":89941.0},{"data-1 customer":"CP0221","data-1 Gross-value":447675,"data-2 customer":"CP0221","data-2 Gross-value":202365.0},{"data-1 customer":"CN0063","data-1 Gross-value":448764,"data-2 customer":"CN0063","data-2 Gross-value":213154.0},{"data-1 customer":"CN0063","data-1 Gross-value":448764,"data-2 customer":"CN0063","data-2 Gross-value":1440350.0},{"data-1 customer":"CH0141","data-1 Gross-value":450124,"data-2 customer":"CH0141","data-2 Gross-value":169251.0},{"data-1 customer":"CH0141","data-1 Gross-value":450124,"data-2 customer":"CH0141","data-2 Gross-value":221804.0},{"data-1 customer":"CL0016","data-1 Gross-value":466135,"data-2 customer":"CL0016","data-2 Gross-value":1380869.0},{"data-1 customer":"CA0198","data-1 Gross-value":473022,"data-2 customer":"CA0198","data-2 Gross-value":657961.0},{"data-1 customer":"CA0198","data-1 Gross-value":473022,"data-2 customer":"CA0198","data-2 Gross-value":3998996.0},{"data-1 customer":"CS0126","data-1 Gross-value":480000,"data-2 customer":"CS0126","data-2 Gross-value":96999.0},{"data-1 customer":"CS0126","data-1 Gross-value":480000,"data-2 customer":"CS0126","data-2 Gross-value":455568.0},{"data-1 customer":"CB0032","data-1 Gross-value":491640,"data-2 customer":"CB0032","data-2 Gross-value":89131.0},{"data-1 customer":"CB0032","data-1 Gross-value":491640,"data-2 customer":"CB0032","data-2 Gross-value":3769633.0},{"data-1 customer":"CR0002","data-1 Gross-value":495781,"data-2 customer":"CR0002","data-2 Gross-value":2628.0},{"data-1 customer":"CR0002","data-1 Gross-value":495781,"data-2 customer":"CR0002","data-2 Gross-value":1790220.0},{"data-1 customer":"CN0115","data-1 Gross-value":509096,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CP0149","data-1 Gross-value":530500,"data-2 customer":"CP0149","data-2 Gross-value":600.0},{"data-1 customer":"CP0149","data-1 Gross-value":530500,"data-2 customer":"CP0149","data-2 Gross-value":98196.0},{"data-1 customer":"CA0309","data-1 Gross-value":532158,"data-2 customer":"CA0309","data-2 Gross-value":608543.0},{"data-1 customer":"CA0309","data-1 Gross-value":532158,"data-2 customer":"CA0309","data-2 Gross-value":5484652.0},{"data-1 customer":"CP0158","data-1 Gross-value":541000,"data-2 customer":"CP0158","data-2 Gross-value":170253.0},{"data-1 customer":"CP0158","data-1 Gross-value":541000,"data-2 customer":"CP0158","data-2 Gross-value":313100.0},{"data-1 customer":"CE0105","data-1 Gross-value":546090,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CD0135","data-1 Gross-value":549619,"data-2 customer":"CD0135","data-2 Gross-value":208371.0},{"data-1 customer":"CD0135","data-1 Gross-value":549619,"data-2 customer":"CD0135","data-2 Gross-value":884941.0},{"data-1 customer":"CM0235","data-1 Gross-value":559700,"data-2 customer":"CM0235","data-2 Gross-value":271415.0},{"data-1 customer":"CM0106","data-1 Gross-value":566562,"data-2 customer":"CM0106","data-2 Gross-value":429240.0},{"data-1 customer":"CM0106","data-1 Gross-value":566562,"data-2 customer":"CM0106","data-2 Gross-value":1324048.0},{"data-1 customer":"CC0097","data-1 Gross-value":584587,"data-2 customer":"CC0097","data-2 Gross-value":577610.0},{"data-1 customer":"CH0009","data-1 Gross-value":587874,"data-2 customer":"CH0009","data-2 Gross-value":0.0},{"data-1 customer":"CH0009","data-1 Gross-value":587874,"data-2 customer":"CH0009","data-2 Gross-value":2171945.0},{"data-1 customer":"CK0122","data-1 Gross-value":601712,"data-2 customer":"CK0122","data-2 Gross-value":16000.0},{"data-1 customer":"CS0408","data-1 Gross-value":632822,"data-2 customer":"CS0408","data-2 Gross-value":0.0},{"data-1 customer":"CS0408","data-1 Gross-value":632822,"data-2 customer":"CS0408","data-2 Gross-value":826869.0},{"data-1 customer":"CS0291","data-1 Gross-value":638910,"data-2 customer":"CS0291","data-2 Gross-value":585996.0},{"data-1 customer":"CD0011","data-1 Gross-value":644667,"data-2 customer":"CD0011","data-2 Gross-value":61698.0},{"data-1 customer":"CD0011","data-1 Gross-value":644667,"data-2 customer":"CD0011","data-2 Gross-value":2794233.0},{"data-1 customer":"CM0007","data-1 Gross-value":646730,"data-2 customer":"CM0007","data-2 Gross-value":0.0},{"data-1 customer":"CM0007","data-1 Gross-value":646730,"data-2 customer":"CM0007","data-2 Gross-value":1007032.0},{"data-1 customer":"CS0006","data-1 Gross-value":656654,"data-2 customer":"CS0006","data-2 Gross-value":550309.0},{"data-1 customer":"CS0006","data-1 Gross-value":656654,"data-2 customer":"CS0006","data-2 Gross-value":1951053.0},{"data-1 customer":"CC0158","data-1 Gross-value":660600,"data-2 customer":"CC0158","data-2 Gross-value":0.0},{"data-1 customer":"CC0158","data-1 Gross-value":660600,"data-2 customer":"CC0158","data-2 Gross-value":810736.0},{"data-1 customer":"CM0016","data-1 Gross-value":672000,"data-2 customer":"CM0016","data-2 Gross-value":0.0},{"data-1 customer":"CM0016","data-1 Gross-value":672000,"data-2 customer":"CM0016","data-2 Gross-value":1587431.0},{"data-1 customer":"CJ0003","data-1 Gross-value":687270,"data-2 customer":"CJ0003","data-2 Gross-value":296439.0},{"data-1 customer":"CJ0003","data-1 Gross-value":687270,"data-2 customer":"CJ0003","data-2 Gross-value":2181079.0},{"data-1 customer":"CP0231","data-1 Gross-value":694112,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CM0219","data-1 Gross-value":706529,"data-2 customer":"CM0219","data-2 Gross-value":1269868.0},{"data-1 customer":"CM0219","data-1 Gross-value":706529,"data-2 customer":"CM0219","data-2 Gross-value":21993482.0},{"data-1 customer":"CS0006","data-1 Gross-value":708314,"data-2 customer":"CS0006","data-2 Gross-value":550309.0},{"data-1 customer":"CS0006","data-1 Gross-value":708314,"data-2 customer":"CS0006","data-2 Gross-value":1951053.0},{"data-1 customer":"CA0127","data-1 Gross-value":711088,"data-2 customer":"CA0127","data-2 Gross-value":0.0},{"data-1 customer":"CA0127","data-1 Gross-value":711088,"data-2 customer":"CA0127","data-2 Gross-value":12205211.0},{"data-1 customer":"CS0332","data-1 Gross-value":711465,"data-2 customer":"CS0332","data-2 Gross-value":988643.0},{"data-1 customer":"CS0332","data-1 Gross-value":711465,"data-2 customer":"CS0332","data-2 Gross-value":4099852.0},{"data-1 customer":"CM0237","data-1 Gross-value":739200,"data-2 customer":"CM0237","data-2 Gross-value":959880.0},{"data-1 customer":"CL0089","data-1 Gross-value":789143,"data-2 customer":"CL0089","data-2 Gross-value":371756.0},{"data-1 customer":"CL0089","data-1 Gross-value":789143,"data-2 customer":"CL0089","data-2 Gross-value":830001.0},{"data-1 customer":"CC0003","data-1 Gross-value":795760,"data-2 customer":"CC0003","data-2 Gross-value":48107.0},{"data-1 customer":"CK0108","data-1 Gross-value":799455,"data-2 customer":"CK0108","data-2 Gross-value":816044.0},{"data-1 customer":"CK0108","data-1 Gross-value":799455,"data-2 customer":"CK0108","data-2 Gross-value":3952443.0},{"data-1 customer":"CD0100","data-1 Gross-value":816255,"data-2 customer":"CD0100","data-2 Gross-value":0.0},{"data-1 customer":"CF0045","data-1 Gross-value":824218,"data-2 customer":"CF0045","data-2 Gross-value":479247.0},{"data-1 customer":"CF0045","data-1 Gross-value":824218,"data-2 customer":"CF0045","data-2 Gross-value":5253256.0},{"data-1 customer":"CH0072","data-1 Gross-value":825240,"data-2 customer":"CH0072","data-2 Gross-value":1.0},{"data-1 customer":"CH0072","data-1 Gross-value":825240,"data-2 customer":"CH0072","data-2 Gross-value":1005772.0},{"data-1 customer":"CI0063","data-1 Gross-value":831550,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CA0324","data-1 Gross-value":855353,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CS0488","data-1 Gross-value":856035,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CI0074","data-1 Gross-value":871956,"data-2 customer":"CI0074","data-2 Gross-value":1.0},{"data-1 customer":"CI0074","data-1 Gross-value":871956,"data-2 customer":"CI0074","data-2 Gross-value":2216801.0},{"data-1 customer":"CS0488","data-1 Gross-value":883827,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CB0007","data-1 Gross-value":986304,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CK0126","data-1 Gross-value":986844,"data-2 customer":"CK0126","data-2 Gross-value":1086409.0},{"data-1 customer":"CK0126","data-1 Gross-value":986844,"data-2 customer":"CK0126","data-2 Gross-value":5969939.0},{"data-1 customer":"CJ0003","data-1 Gross-value":993758,"data-2 customer":"CJ0003","data-2 Gross-value":296439.0},{"data-1 customer":"CJ0003","data-1 Gross-value":993758,"data-2 customer":"CJ0003","data-2 Gross-value":2181079.0},{"data-1 customer":"CN0098","data-1 Gross-value":995454,"data-2 customer":"CN0098","data-2 Gross-value":1130000.0},{"data-1 customer":"CN0098","data-1 Gross-value":995454,"data-2 customer":"CN0098","data-2 Gross-value":5079999.0},{"data-1 customer":"CS0008","data-1 Gross-value":1000950,"data-2 customer":"CS0008","data-2 Gross-value":883529.0},{"data-1 customer":"CS0008","data-1 Gross-value":1000950,"data-2 customer":"CS0008","data-2 Gross-value":2413886.0},{"data-1 customer":"CS0472","data-1 Gross-value":1030050,"data-2 customer":"CS0472","data-2 Gross-value":507157.0},{"data-1 customer":"CS0463","data-1 Gross-value":1049158,"data-2 customer":"CS0463","data-2 Gross-value":0.0},{"data-1 customer":"CM0163","data-1 Gross-value":1105943,"data-2 customer":"CM0163","data-2 Gross-value":7984436.0},{"data-1 customer":"CM0163","data-1 Gross-value":1105943,"data-2 customer":"CM0163","data-2 Gross-value":37238207.0},{"data-1 customer":"CE0092","data-1 Gross-value":1109792,"data-2 customer":"CE0092","data-2 Gross-value":803045.0},{"data-1 customer":"CE0092","data-1 Gross-value":1109792,"data-2 customer":"CE0092","data-2 Gross-value":2206929.0},{"data-1 customer":"CA0020","data-1 Gross-value":1130307,"data-2 customer":"CA0020","data-2 Gross-value":180981.0},{"data-1 customer":"CA0020","data-1 Gross-value":1130307,"data-2 customer":"CA0020","data-2 Gross-value":4877276.0},{"data-1 customer":"CS0472","data-1 Gross-value":1130766,"data-2 customer":"CS0472","data-2 Gross-value":507157.0},{"data-1 customer":"CT0170","data-1 Gross-value":1137370,"data-2 customer":"CT0170","data-2 Gross-value":739785.0},{"data-1 customer":"CC0152","data-1 Gross-value":1170102,"data-2 customer":"CC0152","data-2 Gross-value":679414.0},{"data-1 customer":"CC0152","data-1 Gross-value":1170102,"data-2 customer":"CC0152","data-2 Gross-value":1016587.0},{"data-1 customer":"CD0011","data-1 Gross-value":1174822,"data-2 customer":"CD0011","data-2 Gross-value":61698.0},{"data-1 customer":"CD0011","data-1 Gross-value":1174822,"data-2 customer":"CD0011","data-2 Gross-value":2794233.0},{"data-1 customer":"CP0017","data-1 Gross-value":1180540,"data-2 customer":"CP0017","data-2 Gross-value":1993610.0},{"data-1 customer":"CT0106","data-1 Gross-value":1217289,"data-2 customer":"CT0106","data-2 Gross-value":492227.0},{"data-1 customer":"CT0106","data-1 Gross-value":1217289,"data-2 customer":"CT0106","data-2 Gross-value":1846484.0},{"data-1 customer":"CA0004","data-1 Gross-value":1226869,"data-2 customer":"CA0004","data-2 Gross-value":1071184.0},{"data-1 customer":"CA0004","data-1 Gross-value":1226869,"data-2 customer":"CA0004","data-2 Gross-value":1613546.0},{"data-1 customer":"CS0004","data-1 Gross-value":1294302,"data-2 customer":"CS0004","data-2 Gross-value":965000.0},{"data-1 customer":"CS0004","data-1 Gross-value":1294302,"data-2 customer":"CS0004","data-2 Gross-value":1135000.0},{"data-1 customer":"CG0001","data-1 Gross-value":1314852,"data-2 customer":"CG0001","data-2 Gross-value":410.0},{"data-1 customer":"CG0001","data-1 Gross-value":1314852,"data-2 customer":"CG0001","data-2 Gross-value":2390873.0},{"data-1 customer":"CC0089","data-1 Gross-value":1316893,"data-2 customer":"CC0089","data-2 Gross-value":315000.0},{"data-1 customer":"CC0089","data-1 Gross-value":1316893,"data-2 customer":"CC0089","data-2 Gross-value":1905984.0},{"data-1 customer":"CD0072","data-1 Gross-value":1399558,"data-2 customer":"CD0072","data-2 Gross-value":351336.0},{"data-1 customer":"CD0072","data-1 Gross-value":1399558,"data-2 customer":"CD0072","data-2 Gross-value":7539647.0},{"data-1 customer":"CK0129","data-1 Gross-value":1407852,"data-2 customer":"CK0129","data-2 Gross-value":615075.0},{"data-1 customer":"CK0129","data-1 Gross-value":1407852,"data-2 customer":"CK0129","data-2 Gross-value":730656.0},{"data-1 customer":"CW0031","data-1 Gross-value":1449070,"data-2 customer":"CW0031","data-2 Gross-value":1146004.0},{"data-1 customer":"CW0031","data-1 Gross-value":1449070,"data-2 customer":"CW0031","data-2 Gross-value":2300802.0},{"data-1 customer":"CG0148","data-1 Gross-value":1496177,"data-2 customer":"CG0148","data-2 Gross-value":1680654.0},{"data-1 customer":"CG0148","data-1 Gross-value":1496177,"data-2 customer":"CG0148","data-2 Gross-value":2144708.0},{"data-1 customer":"CA0322","data-1 Gross-value":1511053,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CV0067","data-1 Gross-value":1518846,"data-2 customer":"CV0067","data-2 Gross-value":16043102.0},{"data-1 customer":"CD0001","data-1 Gross-value":1553375,"data-2 customer":"CD0001","data-2 Gross-value":107963.0},{"data-1 customer":"CD0001","data-1 Gross-value":1553375,"data-2 customer":"CD0001","data-2 Gross-value":7487652.0},{"data-1 customer":"CS0035","data-1 Gross-value":1567700,"data-2 customer":"CS0035","data-2 Gross-value":1634174.0},{"data-1 customer":"CS0035","data-1 Gross-value":1567700,"data-2 customer":"CS0035","data-2 Gross-value":2083126.0},{"data-1 customer":"CS0032","data-1 Gross-value":1584779,"data-2 customer":"CS0032","data-2 Gross-value":2.0},{"data-1 customer":"CS0032","data-1 Gross-value":1584779,"data-2 customer":"CS0032","data-2 Gross-value":1367221.0},{"data-1 customer":"CG0079","data-1 Gross-value":1607689,"data-2 customer":"CG0079","data-2 Gross-value":2285853.0},{"data-1 customer":"CG0079","data-1 Gross-value":1607689,"data-2 customer":"CG0079","data-2 Gross-value":4186487.0},{"data-1 customer":"CH0166","data-1 Gross-value":1630798,"data-2 customer":"CH0166","data-2 Gross-value":754706.0},{"data-1 customer":"CH0166","data-1 Gross-value":1630798,"data-2 customer":"CH0166","data-2 Gross-value":13192136.0},{"data-1 customer":"CK0003","data-1 Gross-value":1776578,"data-2 customer":"CK0003","data-2 Gross-value":453125.0},{"data-1 customer":"CK0003","data-1 Gross-value":1776578,"data-2 customer":"CK0003","data-2 Gross-value":2109834.0},{"data-1 customer":"CA0047","data-1 Gross-value":1783996,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CC0150","data-1 Gross-value":1832641,"data-2 customer":"CC0150","data-2 Gross-value":1092976.0},{"data-1 customer":"CC0150","data-1 Gross-value":1832641,"data-2 customer":"CC0150","data-2 Gross-value":1557745.0},{"data-1 customer":"CM0006","data-1 Gross-value":1873207,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CB0032","data-1 Gross-value":1922120,"data-2 customer":"CB0032","data-2 Gross-value":89131.0},{"data-1 customer":"CB0032","data-1 Gross-value":1922120,"data-2 customer":"CB0032","data-2 Gross-value":3769633.0},{"data-1 customer":"CH0072","data-1 Gross-value":1929000,"data-2 customer":"CH0072","data-2 Gross-value":1.0},{"data-1 customer":"CH0072","data-1 Gross-value":1929000,"data-2 customer":"CH0072","data-2 Gross-value":1005772.0},{"data-1 customer":"CN0067","data-1 Gross-value":1930302,"data-2 customer":"CN0067","data-2 Gross-value":263833.0},{"data-1 customer":"CN0067","data-1 Gross-value":1930302,"data-2 customer":"CN0067","data-2 Gross-value":6307182.0},{"data-1 customer":"CM0164","data-1 Gross-value":1969038,"data-2 customer":"CM0164","data-2 Gross-value":-1.0},{"data-1 customer":"CM0164","data-1 Gross-value":1969038,"data-2 customer":"CM0164","data-2 Gross-value":36463.0},{"data-1 customer":"CG0001","data-1 Gross-value":2016876,"data-2 customer":"CG0001","data-2 Gross-value":410.0},{"data-1 customer":"CG0001","data-1 Gross-value":2016876,"data-2 customer":"CG0001","data-2 Gross-value":2390873.0},{"data-1 customer":"CA0008A","data-1 Gross-value":2081320,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CK0123","data-1 Gross-value":2103811,"data-2 customer":"CK0123","data-2 Gross-value":1473158.0},{"data-1 customer":"CK0123","data-1 Gross-value":2103811,"data-2 customer":"CK0123","data-2 Gross-value":8249070.0},{"data-1 customer":"CF0045","data-1 Gross-value":2106528,"data-2 customer":"CF0045","data-2 Gross-value":479247.0},{"data-1 customer":"CF0045","data-1 Gross-value":2106528,"data-2 customer":"CF0045","data-2 Gross-value":5253256.0},{"data-1 customer":"CV0068","data-1 Gross-value":2133253,"data-2 customer":"CV0068","data-2 Gross-value":0.0},{"data-1 customer":"CV0068","data-1 Gross-value":2133253,"data-2 customer":"CV0068","data-2 Gross-value":2221996.0},{"data-1 customer":"CJ0146","data-1 Gross-value":2140376,"data-2 customer":"CJ0146","data-2 Gross-value":35400.0},{"data-1 customer":"CJ0146","data-1 Gross-value":2140376,"data-2 customer":"CJ0146","data-2 Gross-value":1423499.0},{"data-1 customer":"CP0008","data-1 Gross-value":2148856,"data-2 customer":"CP0008","data-2 Gross-value":2764272.0},{"data-1 customer":"CP0008","data-1 Gross-value":2148856,"data-2 customer":"CP0008","data-2 Gross-value":2814756.0},{"data-1 customer":"CM0225","data-1 Gross-value":2159934,"data-2 customer":"CM0225","data-2 Gross-value":1136644.0},{"data-1 customer":"CA0018","data-1 Gross-value":2207464,"data-2 customer":"CA0018","data-2 Gross-value":626244.0},{"data-1 customer":"CA0018","data-1 Gross-value":2207464,"data-2 customer":"CA0018","data-2 Gross-value":2249752.0},{"data-1 customer":"CS0390","data-1 Gross-value":2213389,"data-2 customer":"CS0390","data-2 Gross-value":1410001.0},{"data-1 customer":"CS0390","data-1 Gross-value":2213389,"data-2 customer":"CS0390","data-2 Gross-value":1738001.0},{"data-1 customer":"CP0165","data-1 Gross-value":2264275,"data-2 customer":"CP0165","data-2 Gross-value":1116678.0},{"data-1 customer":"CP0165","data-1 Gross-value":2264275,"data-2 customer":"CP0165","data-2 Gross-value":5015588.0},{"data-1 customer":"CV0151","data-1 Gross-value":2275065,"data-2 customer":"CV0151","data-2 Gross-value":977756.0},{"data-1 customer":"CV0151","data-1 Gross-value":2275065,"data-2 customer":"CV0151","data-2 Gross-value":5351607.0},{"data-1 customer":"CS0224","data-1 Gross-value":2278137,"data-2 customer":"CS0224","data-2 Gross-value":3509155.0},{"data-1 customer":"CS0224","data-1 Gross-value":2278137,"data-2 customer":"CS0224","data-2 Gross-value":3792783.0},{"data-1 customer":"CS0444","data-1 Gross-value":2305707,"data-2 customer":"CS0444","data-2 Gross-value":1212651.0},{"data-1 customer":"CS0444","data-1 Gross-value":2305707,"data-2 customer":"CS0444","data-2 Gross-value":3796841.0},{"data-1 customer":"CH0009","data-1 Gross-value":2314457,"data-2 customer":"CH0009","data-2 Gross-value":0.0},{"data-1 customer":"CH0009","data-1 Gross-value":2314457,"data-2 customer":"CH0009","data-2 Gross-value":2171945.0},{"data-1 customer":"CC0093","data-1 Gross-value":2325342,"data-2 customer":"CC0093","data-2 Gross-value":821280.0},{"data-1 customer":"CN0042","data-1 Gross-value":2381302,"data-2 customer":"CN0042","data-2 Gross-value":1388562.0},{"data-1 customer":"CN0042","data-1 Gross-value":2381302,"data-2 customer":"CN0042","data-2 Gross-value":3389390.0},{"data-1 customer":"CN0042","data-1 Gross-value":2385845,"data-2 customer":"CN0042","data-2 Gross-value":1388562.0},{"data-1 customer":"CN0042","data-1 Gross-value":2385845,"data-2 customer":"CN0042","data-2 Gross-value":3389390.0},{"data-1 customer":"CD0065","data-1 Gross-value":2463784,"data-2 customer":"CD0065","data-2 Gross-value":5230898.0},{"data-1 customer":"CD0065","data-1 Gross-value":2463784,"data-2 customer":"CD0065","data-2 Gross-value":6637306.0},{"data-1 customer":"CG0157","data-1 Gross-value":2485614,"data-2 customer":"CG0157","data-2 Gross-value":719709.0},{"data-1 customer":"CS0003","data-1 Gross-value":2489424,"data-2 customer":"CS0003","data-2 Gross-value":1078968.0},{"data-1 customer":"CS0003","data-1 Gross-value":2489424,"data-2 customer":"CS0003","data-2 Gross-value":28695409.0},{"data-1 customer":"CE0092","data-1 Gross-value":2542631,"data-2 customer":"CE0092","data-2 Gross-value":803045.0},{"data-1 customer":"CE0092","data-1 Gross-value":2542631,"data-2 customer":"CE0092","data-2 Gross-value":2206929.0},{"data-1 customer":"CU0042","data-1 Gross-value":2594664,"data-2 customer":"CU0042","data-2 Gross-value":13115300.0},{"data-1 customer":"CU0042","data-1 Gross-value":2594664,"data-2 customer":"CU0042","data-2 Gross-value":33557660.0},{"data-1 customer":"CK0128","data-1 Gross-value":2728419,"data-2 customer":"CK0128","data-2 Gross-value":10987555.0},{"data-1 customer":"CK0128","data-1 Gross-value":2728419,"data-2 customer":"CK0128","data-2 Gross-value":12397594.0},{"data-1 customer":"CC0073","data-1 Gross-value":2739707,"data-2 customer":"CC0073","data-2 Gross-value":0.0},{"data-1 customer":"CC0073","data-1 Gross-value":2739707,"data-2 customer":"CC0073","data-2 Gross-value":3716554.0},{"data-1 customer":"CM0053","data-1 Gross-value":2802060,"data-2 customer":"CM0053","data-2 Gross-value":0.0},{"data-1 customer":"CM0053","data-1 Gross-value":2802060,"data-2 customer":"CM0053","data-2 Gross-value":26879654.0},{"data-1 customer":"CM0049","data-1 Gross-value":2881371,"data-2 customer":"CM0049","data-2 Gross-value":0.0},{"data-1 customer":"CM0049","data-1 Gross-value":2881371,"data-2 customer":"CM0049","data-2 Gross-value":7071136.0},{"data-1 customer":"CS0332","data-1 Gross-value":2889585,"data-2 customer":"CS0332","data-2 Gross-value":988643.0},{"data-1 customer":"CS0332","data-1 Gross-value":2889585,"data-2 customer":"CS0332","data-2 Gross-value":4099852.0},{"data-1 customer":"CD0072","data-1 Gross-value":2992547,"data-2 customer":"CD0072","data-2 Gross-value":351336.0},{"data-1 customer":"CD0072","data-1 Gross-value":2992547,"data-2 customer":"CD0072","data-2 Gross-value":7539647.0},{"data-1 customer":"CR0001","data-1 Gross-value":3000986,"data-2 customer":"CR0001","data-2 Gross-value":1437591.0},{"data-1 customer":"CR0001","data-1 Gross-value":3000986,"data-2 customer":"CR0001","data-2 Gross-value":2091458.0},{"data-1 customer":"CS0034","data-1 Gross-value":3088616,"data-2 customer":"CS0034","data-2 Gross-value":18361202.0},{"data-1 customer":"CS0034","data-1 Gross-value":3088616,"data-2 customer":"CS0034","data-2 Gross-value":161359885.0},{"data-1 customer":"CN0098","data-1 Gross-value":3107883,"data-2 customer":"CN0098","data-2 Gross-value":1130000.0},{"data-1 customer":"CN0098","data-1 Gross-value":3107883,"data-2 customer":"CN0098","data-2 Gross-value":5079999.0},{"data-1 customer":"CM0210","data-1 Gross-value":3300129,"data-2 customer":"CM0210","data-2 Gross-value":192.0},{"data-1 customer":"CM0210","data-1 Gross-value":3300129,"data-2 customer":"CM0210","data-2 Gross-value":35132478.0},{"data-1 customer":"CA0001","data-1 Gross-value":3364930,"data-2 customer":"CA0001","data-2 Gross-value":1700244.0},{"data-1 customer":"CA0001","data-1 Gross-value":3364930,"data-2 customer":"CA0001","data-2 Gross-value":4928158.0},{"data-1 customer":"CD0001","data-1 Gross-value":3404748,"data-2 customer":"CD0001","data-2 Gross-value":107963.0},{"data-1 customer":"CD0001","data-1 Gross-value":3404748,"data-2 customer":"CD0001","data-2 Gross-value":7487652.0},{"data-1 customer":"CE0002","data-1 Gross-value":3627518,"data-2 customer":"CE0002","data-2 Gross-value":23611703.0},{"data-1 customer":"CE0002","data-1 Gross-value":3627518,"data-2 customer":"CE0002","data-2 Gross-value":60757229.0},{"data-1 customer":"CA0127","data-1 Gross-value":3640340,"data-2 customer":"CA0127","data-2 Gross-value":0.0},{"data-1 customer":"CA0127","data-1 Gross-value":3640340,"data-2 customer":"CA0127","data-2 Gross-value":12205211.0},{"data-1 customer":"CC0002","data-1 Gross-value":3687311,"data-2 customer":"CC0002","data-2 Gross-value":3249345.0},{"data-1 customer":"CC0002","data-1 Gross-value":3687311,"data-2 customer":"CC0002","data-2 Gross-value":3482453.0},{"data-1 customer":"CD0141","data-1 Gross-value":3693903,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CD0098","data-1 Gross-value":3713643,"data-2 customer":"CD0098","data-2 Gross-value":4932967.0},{"data-1 customer":"CT0006","data-1 Gross-value":3919748,"data-2 customer":"CT0006","data-2 Gross-value":7000308.0},{"data-1 customer":"CT0006","data-1 Gross-value":3919748,"data-2 customer":"CT0006","data-2 Gross-value":8061053.0},{"data-1 customer":"CR0012","data-1 Gross-value":3968625,"data-2 customer":"CR0012","data-2 Gross-value":38074.0},{"data-1 customer":"CR0012","data-1 Gross-value":3968625,"data-2 customer":"CR0012","data-2 Gross-value":3175990.0},{"data-1 customer":"CD0002","data-1 Gross-value":4011624,"data-2 customer":"CD0002","data-2 Gross-value":1758767.0},{"data-1 customer":"CS0224","data-1 Gross-value":4285833,"data-2 customer":"CS0224","data-2 Gross-value":3509155.0},{"data-1 customer":"CS0224","data-1 Gross-value":4285833,"data-2 customer":"CS0224","data-2 Gross-value":3792783.0},{"data-1 customer":"CE0007","data-1 Gross-value":4318407,"data-2 customer":"CE0007","data-2 Gross-value":-652.0},{"data-1 customer":"CE0007","data-1 Gross-value":4318407,"data-2 customer":"CE0007","data-2 Gross-value":11930550.0},{"data-1 customer":"CG0079","data-1 Gross-value":4510149,"data-2 customer":"CG0079","data-2 Gross-value":2285853.0},{"data-1 customer":"CG0079","data-1 Gross-value":4510149,"data-2 customer":"CG0079","data-2 Gross-value":4186487.0},{"data-1 customer":"CM0004","data-1 Gross-value":4672744,"data-2 customer":"CM0004","data-2 Gross-value":592996.0},{"data-1 customer":"CM0004","data-1 Gross-value":4672744,"data-2 customer":"CM0004","data-2 Gross-value":65345272.0},{"data-1 customer":"CK0128","data-1 Gross-value":4812791,"data-2 customer":"CK0128","data-2 Gross-value":10987555.0},{"data-1 customer":"CK0128","data-1 Gross-value":4812791,"data-2 customer":"CK0128","data-2 Gross-value":12397594.0},{"data-1 customer":"CA0198","data-1 Gross-value":4907910,"data-2 customer":"CA0198","data-2 Gross-value":657961.0},{"data-1 customer":"CA0198","data-1 Gross-value":4907910,"data-2 customer":"CA0198","data-2 Gross-value":3998996.0},{"data-1 customer":"CK0126","data-1 Gross-value":4921766,"data-2 customer":"CK0126","data-2 Gross-value":1086409.0},{"data-1 customer":"CK0126","data-1 Gross-value":4921766,"data-2 customer":"CK0126","data-2 Gross-value":5969939.0},{"data-1 customer":"CK0123","data-1 Gross-value":5036794,"data-2 customer":"CK0123","data-2 Gross-value":1473158.0},{"data-1 customer":"CK0123","data-1 Gross-value":5036794,"data-2 customer":"CK0123","data-2 Gross-value":8249070.0},{"data-1 customer":"CH0008","data-1 Gross-value":5222707,"data-2 customer":"CH0008","data-2 Gross-value":14169456.0},{"data-1 customer":"CC0147","data-1 Gross-value":5961547,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CC0064","data-1 Gross-value":6236281,"data-2 customer":"CC0064","data-2 Gross-value":15949107.0},{"data-1 customer":"CC0103","data-1 Gross-value":6671150,"data-2 customer":"CC0103","data-2 Gross-value":37447050.0},{"data-1 customer":"CJ0069","data-1 Gross-value":6710478,"data-2 customer":"CJ0069","data-2 Gross-value":226702.0},{"data-1 customer":"CJ0069","data-1 Gross-value":6710478,"data-2 customer":"CJ0069","data-2 Gross-value":13982244.0},{"data-1 customer":"CB0121","data-1 Gross-value":6912360,"data-2 customer":"CB0121","data-2 Gross-value":2088364.0},{"data-1 customer":"CM0231","data-1 Gross-value":6997243,"data-2 customer":"CM0231","data-2 Gross-value":1821235.0},{"data-1 customer":"CM0231","data-1 Gross-value":6997243,"data-2 customer":"CM0231","data-2 Gross-value":4947605.0},{"data-1 customer":"CH0166","data-1 Gross-value":7010018,"data-2 customer":"CH0166","data-2 Gross-value":754706.0},{"data-1 customer":"CH0166","data-1 Gross-value":7010018,"data-2 customer":"CH0166","data-2 Gross-value":13192136.0},{"data-1 customer":"CV0067","data-1 Gross-value":7087052,"data-2 customer":"CV0067","data-2 Gross-value":16043102.0},{"data-1 customer":"CJ0133","data-1 Gross-value":7477575,"data-2 customer":"CJ0133","data-2 Gross-value":0.0},{"data-1 customer":"CJ0133","data-1 Gross-value":7477575,"data-2 customer":"CJ0133","data-2 Gross-value":4254419.0},{"data-1 customer":"CI0077","data-1 Gross-value":9557955,"data-2 customer":"CI0077","data-2 Gross-value":2220925.0},{"data-1 customer":"CI0077","data-1 Gross-value":9557955,"data-2 customer":"CI0077","data-2 Gross-value":22652147.0},{"data-1 customer":"CJ0097","data-1 Gross-value":10633672,"data-2 customer":"CJ0097","data-2 Gross-value":13921262.0},{"data-1 customer":"CJ0097","data-1 Gross-value":10633672,"data-2 customer":"CJ0097","data-2 Gross-value":60782846.0},{"data-1 customer":"CJ0097","data-1 Gross-value":12112174,"data-2 customer":"CJ0097","data-2 Gross-value":13921262.0},{"data-1 customer":"CJ0097","data-1 Gross-value":12112174,"data-2 customer":"CJ0097","data-2 Gross-value":60782846.0},{"data-1 customer":"CM0008","data-1 Gross-value":13720519,"data-2 customer":"CM0008","data-2 Gross-value":7220001.0},{"data-1 customer":"CM0008","data-1 Gross-value":13720519,"data-2 customer":"CM0008","data-2 Gross-value":16673417.0},{"data-1 customer":"CJ0128","data-1 Gross-value":14997040,"data-2 customer":"CJ0128","data-2 Gross-value":-29.0},{"data-1 customer":"CJ0128","data-1 Gross-value":14997040,"data-2 customer":"CJ0128","data-2 Gross-value":14578010.0},{"data-1 customer":"CC0148","data-1 Gross-value":15268086,"data-2 customer":null,"data-2 Gross-value":null},{"data-1 customer":"CM0219","data-1 Gross-value":15305351,"data-2 customer":"CM0219","data-2 Gross-value":1269868.0},{"data-1 customer":"CM0219","data-1 Gross-value":15305351,"data-2 customer":"CM0219","data-2 Gross-value":21993482.0},{"data-1 customer":"CS0003","data-1 Gross-value":15802994,"data-2 customer":"CS0003","data-2 Gross-value":1078968.0},{"data-1 customer":"CS0003","data-1 Gross-value":15802994,"data-2 customer":"CS0003","data-2 Gross-value":28695409.0},{"data-1 customer":"CM0008","data-1 Gross-value":17658171,"data-2 customer":"CM0008","data-2 Gross-value":7220001.0},{"data-1 customer":"CM0008","data-1 Gross-value":17658171,"data-2 customer":"CM0008","data-2 Gross-value":16673417.0},{"data-1 customer":"CM0165","data-1 Gross-value":18328772,"data-2 customer":"CM0165","data-2 Gross-value":-434.0},{"data-1 customer":"CM0165","data-1 Gross-value":18328772,"data-2 customer":"CM0165","data-2 Gross-value":21660348.0},{"data-1 customer":"CH0008","data-1 Gross-value":20785175,"data-2 customer":"CH0008","data-2 Gross-value":14169456.0},{"data-1 customer":"CM0053","data-1 Gross-value":27071078,"data-2 customer":"CM0053","data-2 Gross-value":0.0},{"data-1 customer":"CM0053","data-1 Gross-value":27071078,"data-2 customer":"CM0053","data-2 Gross-value":26879654.0},{"data-1 customer":"CM0226","data-1 Gross-value":28964111,"data-2 customer":"CM0226","data-2 Gross-value":1064443.0},{"data-1 customer":"CM0226","data-1 Gross-value":28964111,"data-2 customer":"CM0226","data-2 Gross-value":17158364.0},{"data-1 customer":"CM0210","data-1 Gross-value":32570412,"data-2 customer":"CM0210","data-2 Gross-value":192.0},{"data-1 customer":"CM0210","data-1 Gross-value":32570412,"data-2 customer":"CM0210","data-2 Gross-value":35132478.0},{"data-1 customer":"CM0163","data-1 Gross-value":34992787,"data-2 customer":"CM0163","data-2 Gross-value":7984436.0},{"data-1 customer":"CM0163","data-1 Gross-value":34992787,"data-2 customer":"CM0163","data-2 Gross-value":37238207.0},{"data-1 customer":"CS0034","data-1 Gross-value":46355589,"data-2 customer":"CS0034","data-2 Gross-value":18361202.0},{"data-1 customer":"CS0034","data-1 Gross-value":46355589,"data-2 customer":"CS0034","data-2 Gross-value":161359885.0},{"data-1 customer":"CE0002","data-1 Gross-value":49074023,"data-2 customer":"CE0002","data-2 Gross-value":23611703.0},{"data-1 customer":"CE0002","data-1 Gross-value":49074023,"data-2 customer":"CE0002","data-2 Gross-value":60757229.0},{"data-1 customer":"CN0068","data-1 Gross-value":58033480,"data-2 customer":"CN0068","data-2 Gross-value":5706765.0},{"data-1 customer":"CN0068","data-1 Gross-value":58033480,"data-2 customer":"CN0068","data-2 Gross-value":101850882.0},{"data-1 customer":"CM0004","data-1 Gross-value":67875405,"data-2 customer":"CM0004","data-2 Gross-value":592996.0},{"data-1 customer":"CM0004","data-1 Gross-value":67875405,"data-2 customer":"CM0004","data-2 Gross-value":65345272.0}];

    const collections_actual_vs_protection = [{"year":"2018","month":"April","Projected Inv_value":318423028.8199999928,"Actual Inv_value":260835164},{"year":"2018","month":"August","Projected Inv_value":234404848.6800000072,"Actual Inv_value":206326114},{"year":"2018","month":"December","Projected Inv_value":298088550.0099999905,"Actual Inv_value":256333688},{"year":"2018","month":"July","Projected Inv_value":297942613.5400000215,"Actual Inv_value":329482916},{"year":"2018","month":"June","Projected Inv_value":235443323.3299999833,"Actual Inv_value":176007348},{"year":"2018","month":"May","Projected Inv_value":202509558.5500000119,"Actual Inv_value":307924792},{"year":"2018","month":"November","Projected Inv_value":305707942.0299999714,"Actual Inv_value":300823909},{"year":"2018","month":"October","Projected Inv_value":214721471.349999994,"Actual Inv_value":150254119},{"year":"2018","month":"September","Projected Inv_value":302377029.6800000072,"Actual Inv_value":328464326},{"year":"2019","month":"April","Projected Inv_value":341927297.5400000215,"Actual Inv_value":242876811},{"year":"2019","month":"August","Projected Inv_value":312974879.2699999809,"Actual Inv_value":287402755},{"year":"2019","month":"December","Projected Inv_value":304176221.0099999905,"Actual Inv_value":280941283},{"year":"2019","month":"February","Projected Inv_value":236344542.8400000036,"Actual Inv_value":179102612},{"year":"2019","month":"January","Projected Inv_value":309250965.9399999976,"Actual Inv_value":298856783},{"year":"2019","month":"July","Projected Inv_value":328554056.1899999976,"Actual Inv_value":224068463},{"year":"2019","month":"June","Projected Inv_value":274684853.8600000143,"Actual Inv_value":132486803},{"year":"2019","month":"March","Projected Inv_value":311797424.4900000095,"Actual Inv_value":366597695},{"year":"2019","month":"May","Projected Inv_value":312964870.1600000262,"Actual Inv_value":393958927},{"year":"2019","month":"November","Projected Inv_value":342027859.2300000191,"Actual Inv_value":340956600},{"year":"2019","month":"October","Projected Inv_value":242414493.6100000143,"Actual Inv_value":373424653},{"year":"2019","month":"September","Projected Inv_value":356375929.3799999952,"Actual Inv_value":322756765},{"year":"2020","month":"February","Projected Inv_value":312074636.25,"Actual Inv_value":264115627},{"year":"2020","month":"January","Projected Inv_value":275208962.9800000191,"Actual Inv_value":329454154}];

    const Alloy_tech = [{"CUSTOMER CODE":"CA0047","CUSTOMER NAME":"ALLOY TECH","month":"August-2019","Projected Inv_value":207349.6,"Actual Inv_value":207350},{"CUSTOMER CODE":"CA0047","CUSTOMER NAME":"ALLOY TECH","month":"December-2019","Projected Inv_value":1363823.3599999999,"Actual Inv_value":1010255},{"CUSTOMER CODE":"CA0047","CUSTOMER NAME":"ALLOY TECH","month":"January-2020","Projected Inv_value":361072.94,"Actual Inv_value":1077181},{"CUSTOMER CODE":"CA0047","CUSTOMER NAME":"ALLOY TECH","month":"November-2019","Projected Inv_value":1421924.22,"Actual Inv_value":938911},{"CUSTOMER CODE":"CA0047","CUSTOMER NAME":"ALLOY TECH","month":"September-2019","Projected Inv_value":974586.2000000001,"Actual Inv_value":974587}];

    const spirit_aerosystems = [{"CUSTOMER CODE":"CS0283","CUSTOMER NAME":"SPIRIT AEROSYSTEMS (EUROPE)","month":"April-2018","Projected Inv_value":55968579.0799999982,"Actual Inv_value":28024464},{"CUSTOMER CODE":"CS0283","CUSTOMER NAME":"SPIRIT AEROSYSTEMS (EUROPE)","month":"April-2019","Projected Inv_value":56763768.2100000009,"Actual Inv_value":31555590},{"CUSTOMER CODE":"CS0283","CUSTOMER NAME":"SPIRIT AEROSYSTEMS (EUROPE)","month":"August-2018","Projected Inv_value":51286657.6300000027,"Actual Inv_value":56794253},{"CUSTOMER CODE":"CS0283","CUSTOMER NAME":"SPIRIT AEROSYSTEMS (EUROPE)","month":"August-2019","Projected Inv_value":49620252.5799999982,"Actual Inv_value":56685323},{"CUSTOMER CODE":"CS0283","CUSTOMER NAME":"SPIRIT AEROSYSTEMS (EUROPE)","month":"December-2018","Projected Inv_value":51184989.2100000009,"Actual Inv_value":52370829},{"CUSTOMER CODE":"CS0283","CUSTOMER NAME":"SPIRIT AEROSYSTEMS (EUROPE)","month":"December-2019","Projected Inv_value":57941256.0899999961,"Actual Inv_value":49877848},{"CUSTOMER CODE":"CS0283","CUSTOMER NAME":"SPIRIT AEROSYSTEMS (EUROPE)","month":"February-2019","Projected Inv_value":63238160.7700000033,"Actual Inv_value":53702930},{"CUSTOMER CODE":"CS0283","CUSTOMER NAME":"SPIRIT AEROSYSTEMS (EUROPE)","month":"February-2020","Projected Inv_value":59532484.8599999994,"Actual Inv_value":61791365},{"CUSTOMER CODE":"CS0283","CUSTOMER NAME":"SPIRIT AEROSYSTEMS (EUROPE)","month":"January-2019","Projected Inv_value":56033143.6400000006,"Actual Inv_value":63956217},{"CUSTOMER CODE":"CS0283","CUSTOMER NAME":"SPIRIT AEROSYSTEMS (EUROPE)","month":"January-2020","Projected Inv_value":58697087.8100000024,"Actual Inv_value":25891707},{"CUSTOMER CODE":"CS0283","CUSTOMER NAME":"SPIRIT AEROSYSTEMS (EUROPE)","month":"July-2018","Projected Inv_value":60209856.7700000033,"Actual Inv_value":57439107},{"CUSTOMER CODE":"CS0283","CUSTOMER NAME":"SPIRIT AEROSYSTEMS (EUROPE)","month":"July-2019","Projected Inv_value":52646613.5300000012,"Actual Inv_value":48298786},{"CUSTOMER CODE":"CS0283","CUSTOMER NAME":"SPIRIT AEROSYSTEMS (EUROPE)","month":"June-2018","Projected Inv_value":55025871.6400000006,"Actual Inv_value":58942611},{"CUSTOMER CODE":"CS0283","CUSTOMER NAME":"SPIRIT AEROSYSTEMS (EUROPE)","month":"June-2019","Projected Inv_value":49619408.7199999988,"Actual Inv_value":26108414},{"CUSTOMER CODE":"CS0283","CUSTOMER NAME":"SPIRIT AEROSYSTEMS (EUROPE)","month":"March-2019","Projected Inv_value":60338764.8100000024,"Actual Inv_value":35368629},{"CUSTOMER CODE":"CS0283","CUSTOMER NAME":"SPIRIT AEROSYSTEMS (EUROPE)","month":"May-2018","Projected Inv_value":60737565.5200000033,"Actual Inv_value":99439653},{"CUSTOMER CODE":"CS0283","CUSTOMER NAME":"SPIRIT AEROSYSTEMS (EUROPE)","month":"May-2019","Projected Inv_value":52057839.5799999982,"Actual Inv_value":107488889},{"CUSTOMER CODE":"CS0283","CUSTOMER NAME":"SPIRIT AEROSYSTEMS (EUROPE)","month":"November-2018","Projected Inv_value":59343429.2199999988,"Actual Inv_value":97227568},{"CUSTOMER CODE":"CS0283","CUSTOMER NAME":"SPIRIT AEROSYSTEMS (EUROPE)","month":"November-2019","Projected Inv_value":50666813.5399999991,"Actual Inv_value":64996798},{"CUSTOMER CODE":"CS0283","CUSTOMER NAME":"SPIRIT AEROSYSTEMS (EUROPE)","month":"October-2018","Projected Inv_value":55312683.7099999934,"Actual Inv_value":14732497},{"CUSTOMER CODE":"CS0283","CUSTOMER NAME":"SPIRIT AEROSYSTEMS (EUROPE)","month":"October-2019","Projected Inv_value":47392447.5799999982,"Actual Inv_value":81576297},{"CUSTOMER CODE":"CS0283","CUSTOMER NAME":"SPIRIT AEROSYSTEMS (EUROPE)","month":"September-2018","Projected Inv_value":57183460.700000003,"Actual Inv_value":64727828},{"CUSTOMER CODE":"CS0283","CUSTOMER NAME":"SPIRIT AEROSYSTEMS (EUROPE)","month":"September-2019","Projected Inv_value":61140696.25,"Actual Inv_value":50424647}];

    const tata_advanced_materials = [{"CUSTOMER CODE":"CT0143","CUSTOMER NAME":"TATA ADVANCED MATERIALS LTD","month":"May-2018","Projected Inv_value":2254457.5,"Actual Inv_value":336959},{"CUSTOMER CODE":"CT0143","CUSTOMER NAME":"TATA ADVANCED MATERIALS LTD","month":"June-2018","Projected Inv_value":5416226.8600000003,"Actual Inv_value":1016350},{"CUSTOMER CODE":"CT0143","CUSTOMER NAME":"TATA ADVANCED MATERIALS LTD","month":"July-2018","Projected Inv_value":922049.41,"Actual Inv_value":2571994},{"CUSTOMER CODE":"CT0143","CUSTOMER NAME":"TATA ADVANCED MATERIALS LTD","month":"August-2018","Projected Inv_value":3130916.54,"Actual Inv_value":1378582},{"CUSTOMER CODE":"CT0143","CUSTOMER NAME":"TATA ADVANCED MATERIALS LTD","month":"September-2018","Projected Inv_value":3018328.1400000001,"Actual Inv_value":3978682},{"CUSTOMER CODE":"CT0143","CUSTOMER NAME":"TATA ADVANCED MATERIALS LTD","month":"October-2018","Projected Inv_value":1740675.98,"Actual Inv_value":3220596},{"CUSTOMER CODE":"CT0143","CUSTOMER NAME":"TATA ADVANCED MATERIALS LTD","month":"November-2018","Projected Inv_value":2393666.7399999998,"Actual Inv_value":3130916},{"CUSTOMER CODE":"CT0143","CUSTOMER NAME":"TATA ADVANCED MATERIALS LTD","month":"December-2018","Projected Inv_value":2626813.5700000003,"Actual Inv_value":3018330},{"CUSTOMER CODE":"CT0143","CUSTOMER NAME":"TATA ADVANCED MATERIALS LTD","month":"January-2019","Projected Inv_value":1940520.53,"Actual Inv_value":1873557},{"CUSTOMER CODE":"CT0143","CUSTOMER NAME":"TATA ADVANCED MATERIALS LTD","month":"February-2019","Projected Inv_value":3938869.5899999999,"Actual Inv_value":3285764},{"CUSTOMER CODE":"CT0143","CUSTOMER NAME":"TATA ADVANCED MATERIALS LTD","month":"March-2019","Projected Inv_value":3462639.0100000002,"Actual Inv_value":3386028},{"CUSTOMER CODE":"CT0143","CUSTOMER NAME":"TATA ADVANCED MATERIALS LTD","month":"April-2019","Projected Inv_value":3731848.8999999999,"Actual Inv_value":1975920},{"CUSTOMER CODE":"CT0143","CUSTOMER NAME":"TATA ADVANCED MATERIALS LTD","month":"May-2019","Projected Inv_value":892096.41,"Actual Inv_value":4830964},{"CUSTOMER CODE":"CT0143","CUSTOMER NAME":"TATA ADVANCED MATERIALS LTD","month":"June-2019","Projected Inv_value":5719886.6799999997,"Actual Inv_value":2535142},{"CUSTOMER CODE":"CT0143","CUSTOMER NAME":"TATA ADVANCED MATERIALS LTD","month":"July-2019","Projected Inv_value":1001456.98,"Actual Inv_value":4623944},{"CUSTOMER CODE":"CT0143","CUSTOMER NAME":"TATA ADVANCED MATERIALS LTD","month":"August-2019","Projected Inv_value":4233142.8199999994,"Actual Inv_value":1651311},{"CUSTOMER CODE":"CT0143","CUSTOMER NAME":"TATA ADVANCED MATERIALS LTD","month":"September-2019","Projected Inv_value":3662093.0899999999,"Actual Inv_value":4789559},{"CUSTOMER CODE":"CT0143","CUSTOMER NAME":"TATA ADVANCED MATERIALS LTD","month":"October-2019","Projected Inv_value":3543309.1199999996,"Actual Inv_value":2026436},{"CUSTOMER CODE":"CT0143","CUSTOMER NAME":"TATA ADVANCED MATERIALS LTD","month":"November-2019","Projected Inv_value":1856422.8599999999,"Actual Inv_value":4527673},{"CUSTOMER CODE":"CT0143","CUSTOMER NAME":"TATA ADVANCED MATERIALS LTD","month":"December-2019","Projected Inv_value":2803865.75,"Actual Inv_value":3452948},{"CUSTOMER CODE":"CT0143","CUSTOMER NAME":"TATA ADVANCED MATERIALS LTD","month":"January-2020","Projected Inv_value":3817779.7399999998,"Actual Inv_value":2803866},{"CUSTOMER CODE":"CT0143","CUSTOMER NAME":"TATA ADVANCED MATERIALS LTD","month":"February-2020","Projected Inv_value":3198551.0899999999,"Actual Inv_value":3342983}];

    const blocked_customer_vs_pending_amount = [{"CUSTOMER CODE":"CH0005","CUSTOMER NAME":"HAL - LCA PROJECT GROUP","Pending Amount":282789}];

    const ageing1 = [{"Period":"payment done before date","Amount":186591982},{"Period":"payment done between 0-15 days","Amount":1457601688},{"Period":"payment done between 15-30 days","Amount":1267498850},{"Period":"payment done between 30-45 days","Amount":639816544},{"Period":"payment done between 45-60 days","Amount":509760976},{"Period":"payment done between 60-90 days","Amount":747416759},{"Period":"payment done after 90 days","Amount":683602543},{"Period":"not paid","Amount":-1201700761}];

    const intColumnDefs = useMemo(() => {
        if (rowData.length > 0) {
          const keys = Object.keys(rowData[0]);
    
          const intColumnDefs = [
            {
              headerName: '',
              checkboxSelection: true,
              width: 50,
            },
            ...keys.map((key) => ({
              headerName: key,
              field: key,
              sortable: true,
              filter: true,
              resizable: true,
            })),
          ];
    
          return intColumnDefs;
        }
        return [];
      }, [rowData]);

    const monthWisegst = () => {
        const rowData1 = rowData.length > 10 ? rowData.slice(0, 10) : rowData;
        // const keys1 = Object.keys(rowData1[0]);
        // console.log('keys1', keys1);
        // let customer = keys1[0];
          // Extract the "customer" and "Gross-value" properties into separate arrays
        //   const customers1 = rowData1.map(item => item[customer]);
        let customers1;
        let grossValues1;
        let grossValues2;
        if (reports == 'Sales_vs_collections'){
            customers1 = rowData1.map(item => item["data-1 customer"]);
          //const grossValues1 = rowData1.map(item => item["Gross-value"]); 
          grossValues1 = rowData1.map(item => item["data-1 Gross-value"]);
          grossValues2 = rowData1.map(item => item["data-2 Gross-value"]);
          setcustomers(customers1);
          setgrossValues(grossValues1);
          setgrossValues1(grossValues2);
          
        }else if(reports == 'collections_actual_vs_protection'){
            customers1 = rowData1.map(item => item["month"]);
            //const grossValues1 = rowData1.map(item => item["Gross-value"]); 
            grossValues1 = rowData1.map(item => item["Projected Inv_value"]);
            grossValues2 = rowData1.map(item => item["Actual Inv_value"]);
            setcustomers(customers1);
           setgrossValues(grossValues1);
           setgrossValues1(grossValues2);
        }else if(reports == 'blocked_customer_vs_pending_amount'){
            customers1 = rowData1.map(item => item["CUSTOMER NAME"]);
            grossValues1 = rowData1.map(item => item["Pending Amount"]);
            setcustomers(customers1);
            setgrossValues(grossValues1);
        }else if(reports == 'ageing'){
          customers1 = rowData1.map(item => item["Period"]);
          grossValues1 = rowData1.map(item => item["Amount"]);
          setcustomers(customers1);
          setgrossValues(grossValues1);
      }
        else{
            customers1 = rowData1.map(item => item["month"]);
            grossValues1 = rowData1.map(item => item["Actual Inv_value"]);
            setcustomers(customers1);
            setgrossValues(grossValues1);
        }
    
          console.log("Customers:", customers1);
          console.log("Gross Values:", grossValues1);
          

          
          setTimeout(() => {
            setGstHidden(false);
          }, 1000); 
        
    };

    // var gridColumns = [
    //     { field: 'customer', headerName: 'Customer', sortable: true, filter: true, resizable: true },
    //     { field: 'Gross-value', headerName: 'Gross value', sortable: true, filter: true, resizable: true },
    // ]

    const clickChart = () =>{
        // setcolumnnames(gridColumns);
        
        setshow(true);
    };

    const handleClose = () => {
        setshow(false);
    };
    

    const options = [
        { text: 'Sales_vs_collections', value: 'Sales_vs_collections' },
        { text: 'collections_actual_vs_protection', value: 'collections_actual_vs_protection' },
        { text: 'Customerwise_collections', value: 'Customerwise_collections' },
        { text: 'blocked_customer_vs_pending_amount', value: 'blocked_customer_vs_pending_amount' },
        { text: 'ageing', value: 'ageing' },

    ];

    const handleSelectChange = (e, { value }) => {
        // Do something with the selected value
        console.log('Selected value:', value);
        setrowData([]);
        setGstHidden(true);
        if(value == 'collections_actual_vs_protection'){
            setrowData(collections_actual_vs_protection);
            setfiltervalue('');
            setissalestrends(false);
            setisfilterHidden(true);
        }
        else if(value == 'Sales_vs_collections'){
            setrowData(sales_vs_collections);
            setfiltervalue('');
            setissalestrends(false);
            setisfilterHidden(true);
        }else if(value == 'blocked_customer_vs_pending_amount'){
            setrowData(blocked_customer_vs_pending_amount);
            setfiltervalue('');
            setissalestrends(false);
            setisfilterHidden(true);
        }else if(value == 'ageing'){
          setrowData(ageing1);
          setfiltervalue('');
          setissalestrends(true);
          setisfilterHidden(true);
      }
        else{
            setissalestrends(true);
            setisfilterHidden(false);
        }
        
        setreports(value);
    };

    const options1 = [
        { text: 'Alloy_tech', value: 'Alloy_tech' },
        { text: 'spirit_aerosystems', value: 'spirit_aerosystems' },
        { text: 'tata_advanced_materials', value: 'tata_advanced_materials' },
        

    ];

    const handleSelectChange1 = (e, { value }) => {
        // Do something with the selected value
        setrowData([]);
        console.log('Selected value1:', value);
        setGstHidden(true);
        if(value == 'Alloy_tech'){
            setrowData(Alloy_tech);
        }else if(value == 'spirit_aerosystems'){
            setrowData(spirit_aerosystems); 
        }else if(value == 'tata_advanced_materials'){
            setrowData(tata_advanced_materials);
        }
        setfiltervalue(value);
        
    };

//     const barChartOnClick = () => {
//         // Handle bar chart click event if needed
//     };

//     const data = [{"channel":"LOCAL","Gross-value":3055088734},
//     {"channel":"EXPORT","Gross-value":324997300},
//     {"channel":"BRANCH","Gross-value":75222286},
//     {"channel":"WARRANTY","Gross-value":21810}]

//     // Prepare chart data
//   const chartData = data.map(item => ({ x: item.channel, y: item["Gross-value"] }));

  // ApexCharts options
  const options2 = {
    chart: {
      type: 'bar',
      toolbar: {
        show: false,
      },
    },
    
    plotOptions: {
      bar: {
        horizontal: false,
      },
    },
    xaxis: {
        title: {
            text: filtervalue,
          },
         
      categories: customers,
      
    },
    yaxis: {
      title: {
        text: "Invoice value",
      },
    },
    tooltip: {
      shared: false,
    },
    
    tooltip: {
        shared: false,
      },
      legend: {
        show: true,
        position: 'right',
        offsetY: 0,
        offsetX: -10,
      },
      responsive: [
        {
          breakpoint: 480,
          options: {
            chart: {
              width: '100%',
            },
            legend: {
              position: 'bottom',
              offsetY: 0,
              offsetX: 0,
            },
          },
        },
      ],
    
  };

//   const series = [
//     {
//       name: 'Sales',
//       data: [30, 40, 25, 50, 49, 21, 70],
//     },
//   ];

const seriesData = [
    {
      name: 'Invoice value1',
      type: 'column',
      data: grossValues
    },
    {
      name: 'Invoice value2',
      type: 'column',
      data: grossValues1
    },
    
  ];

  const chartOptions = {
    chart: {
      height: 350,
      type: 'line',
      stacked: false
    },
    dataLabels: {
      enabled: false
    },
    stroke: {
      width: [1, 1, 4]
    },
    
    xaxis: {
      categories: customers,
    },
    yaxis: [
      {
        axisTicks: {
          show: true,
        },
        axisBorder: {
          show: true,
          color: '#008FFB'
        },
        labels: {
          style: {
            colors: '#008FFB',
          }
        },
        title: {
          text: "Invoice value1",
          style: {
            color: '#008FFB',
          }
        },
        tooltip: {
          enabled: true
        }
      },
      {
        seriesName: 'Invoice value1',
        opposite: true,
        axisTicks: {
          show: true,
        },
        axisBorder: {
          show: true,
          color: '#00E396'
        },
        labels: {
          style: {
            colors: '#00E396',
          }
        },
        title: {
          text: "Invoice value2",
          style: {
            color: '#00E396',
          }
        },
      },
      // {
      //   seriesName: 'Invoice value2',
      //   opposite: true,
      //   axisTicks: {
      //     show: true,
      //   },
      //   axisBorder: {
      //     show: true,
      //     color: '#FEB019'
      //   },
      //   labels: {
      //     style: {
      //       colors: '#FEB019',
      //     },
      //   },
        
      // },
    ],
    // tooltip: {
    //   fixed: {
    //     enabled: true,
    //     position: 'topLeft', // topRight, topLeft, bottomRight, bottomLeft
    //     offsetY: 30,
    //     offsetX: 60
    //   },
    // },
    // legend: {
    //   horizontalAlign: 'left',
    //   offsetX: 40
    // }
  };


    return (
        <>
        <div>
            <div hidden={hidden}>
                <div className="gstchartbox1">
                    <div className="gstchart-box-layer">
                        <table style={{ width: "35%", marginTop: "-12px" }}>

                            <tbody>
                                <tr>
                                    <td className="gstaddcontracttext">Reports</td>
                                    <td style={{paddingRight: '0.9em'}}>:</td>
                                    <td style={{paddingRight: '0.9em'}}><Select
                                        options={options}
                                        placeholder="Select an option"
                                        onChange={handleSelectChange}
                                    /></td>
                                    <td className="gstaddcontracttext" hidden={isfilterHidden}>Filtering</td>
                                    <td style={{paddingRight: '0.9em'}} hidden={isfilterHidden}>:</td>
                                    <td style={{paddingRight: '0.9em'}} hidden={isfilterHidden}><Select
                                        options={options1}
                                        selection
                                        
                                        onChange={handleSelectChange1}
                                    /></td>
                                    <td className="gstaddcontracttext">Date1</td>
                                    <td style={{paddingRight: '0.9em'}}>:</td>
                                    <td style={{paddingRight: '0.9em'}}><input type="date" name="" onChange={(e) => { setInputMonth(e.target.value) }} /></td>
                                    <td className="gstaddcontracttext">Date2</td>
                                    <td style={{paddingRight: '0.9em'}}>:</td>
                                    <td style={{paddingRight: '0.9em'}}><input type="date" name="" onChange={(e) => { setInputMonth1(e.target.value) }} /></td>
                                    <td><button style={{ textAlign: "center", border: ".1px solid #000055", color: "#ffffff", padding: "4px 16px", borderRadius: "15px", backgroundColor: "#024f9d" }} onClick={monthWisegst}>
                                        Search
                                    </button>&nbsp;</td>
                                </tr>

                            </tbody>

                        </table>


                    </div>
                </div>

                {/* secound layer */}
                <div className="brschartbox">
                    <div className="brsrecentOrders" hidden={gstHidden}>
                    <h5 style={{ textAlign: "center" }}>{reports}</h5>
                    
                        <div className="brsbanklayer row">
                            <div className='col-md-1'></div>
                            <div className='col-md-8'>
                                
                                <div className="popup-link-3"  hidden={!issalestrends}>
                                    <a href="#">
                                    <ReactApexChart options={options2} series={[{ data: grossValues }]} type="bar" width={750} height={400} onClick={clickChart}/>
                                    </a>
                                </div>
                                <div className="popup-link-3"  hidden={issalestrends}>
                                    <a href="#">
                                    <ReactApexChart options={chartOptions} series={seriesData} type="line" width={750} height={350} onClick={clickChart}/>
                                    </a>
                                </div>
                            </div>
                            <div className='col-md-1'></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <Modal
          show={show}
          size="lg"
          onHide={handleClose}
          backdrop="static"
          keyboard={false}
        >
          <Modal.Header closeButton>
            <Modal.Title></Modal.Title>
          </Modal.Header>
          <Modal.Body>
          <div className="ag-theme-alpine" style={{ height: '400px', width: '100%' }}>
          <AgGridReact
            columnDefs={intColumnDefs}
            rowData={rowData}
            animateRows={true}
            pagination={true}
            paginationPageSize={20}
            groupSelectsChildren={true}
            suppressAggAtRootLevel={true}
            
            suppressRowClickSelection={true}
            />
            </div>
          </Modal.Body>
          <Modal.Footer>
            <Button onClick={handleClose}>
              Close
            </Button>

          </Modal.Footer>
        </Modal>
</>
    );
}

export default Twentysixrecon;
// App.js
import { useEffect, useState } from "react";
// import "./App.css";
import "../etlsecound.css";
import hdfcs from '../../../../assets/images/banks/thermax.png';


function Annux6() 
{
  

  return (
  <div>
   <table className="table1">
    <tr className="bold">
        <td colSpan={8}>Debit Credit Note or any other difference</td>
      
    </tr>
    <br></br>
    <tr className="fontcolor">
        <td>DATE</td>
        <td>PARTICULARS</td>
        <td>VCH TYPE</td>
        <td>VCH NO.</td>
        <td>Cr/Dr</td>
        <td>DEBIT</td>
        <td>CREDIT</td>
        <td>Remarks</td>
    </tr>
    
    <tr>
        <td></td>
        <td>Opening balance of vendor</td>
        <td></td>
        <td></td>
        <td></td>
        <td> 8,714,154.49 </td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td>Opening balance of Thermax</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td> 8,549,998.28 </td>
        <td></td>
    </tr>
    
    <tr>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td> 8,714,154.49 </td>
        <td> 8,549,998.28</td>
    </tr>
</table>
  </div>
  )
}



export default Annux6;
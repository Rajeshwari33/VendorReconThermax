from celery import group, shared_task
# from celery.result import AsyncResult
import pandas as pd
import openpyxl
import time
from UserManagementModule.common.credentials import localhost, headers
import json
from rest_framework.response import Response
from .models import *

import requests

@shared_task(bind=True)
def test_func(self):
    for i in range(10):
        print(i)
    return "done"

@shared_task
def process_excel_sheet(url, data):
    print('localhost 2345', localhost)
    print('url 1234', url)
    
    url = localhost + url
    
    response = requests.post(url, data=json.dumps(data), headers=headers)
    res = response.json()
    print('res 1234', res)
    # message = "success"
    if res['status'] == 'success':
        message = "success"
    else:
        message = res['status']
    
    return Response({'status': message})

    
@shared_task
def process_excel_file(sheet_names):
    # Create a group of tasks to process each Excel sheet in parallel
    tasks = group(process_excel_sheet.s(sheet_name) for sheet_name in sheet_names)

    # Execute the tasks in parallel
    tasks_result = tasks.apply_async()

    # Wait for all tasks to complete
    tasks_result.join()

    # Check if any task failed
    if any(task.failed() for task in tasks_result):
        raise Exception('One or more tasks failed')



# @shared_task
# def process_excel_file(file_data):
#     # Simulate file processing by sleeping for a few seconds
#     time.sleep(5)
#     # Send the processed file to an Excel REST API
#     response = post('https://example.com/excel_api', data=file_data)
#     return response.json()
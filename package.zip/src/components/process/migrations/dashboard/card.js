import React from 'react';


const Card = ({name, image, clickedValue  }) => <div className='card' onClick={()=>{clickedValue(name)}}>
         <img src={image} alt="new"/>
        {name}
    </div>;

export default Card;
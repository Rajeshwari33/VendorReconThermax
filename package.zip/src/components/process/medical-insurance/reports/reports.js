import React, { useEffect, useState, } from "react";
import Select from "react-select";
import './reports.css';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-balham.css';
import { AgGridReact } from 'ag-grid-react';
import LoaderComponent from "../../../../libraries/loader/loader";
import { getReportGridDataFromServer } from '../../../../services/process/medical-insurance/medicalInsuranceReportService';
import axios from "axios";
import excelIcon from '../../../../assets/images/excel.png';
import * as XLSX from 'xlsx';
import { Icon, Input, Button, Dropdown, Grid, Popup, Segment, Tab, Table, Menu, Form, TextArea, Label } from 'semantic-ui-react'
import {port, port1} from "../../../../services/auth-service/authService";
import {baseUrl} from "../../../../services/common/credentials";


var local_host = baseUrl + port;
var local_host1 = baseUrl + port1;

function MedicalInsuranceReport() {
    const gridColumnDefs = [

        
        { field: 'ass_employee_no', headerName: 'ass_employee_no', sortable: true, filter: true, resizable: true },
        { field: 'ass_emp_code', headerName: 'ass_emp_code', sortable: true, filter: true, resizable: true },
        { field: 'ass_associate_name', headerName: 'ass_associate_name', sortable: true, filter: true, resizable: true },

        { field: 'ass_dob', headerName: 'ass_dob', sortable: true, filter: true, resizable: true },
        { field: 'ass_doj', headerName: 'ass_doj', sortable: true, filter: true, resizable: true },
        { field: 'ass_designation', headerName: 'ass_designation', sortable: true, filter: true, resizable: true },
        { field: 'ass_emailid', headerName: 'ass_emailid', sortable: true, filter: true, resizable: true },
        { field: 'ass_client_id', headerName: 'ass_client_id', sortable: true, filter: true, resizable: true },
        { field: 'ass_client_name', headerName: 'ass_client_name', sortable: true, filter: true, resizable: true },
       
        

        { field: 'ass_client_id_proper', headerName: 'ass_client_id_proper', sortable: true, filter: true, resizable: true },
        { field: 'ass_active_status', headerName: 'ass_active_status', sortable: true, filter: true, resizable: true },
        { field: 'ass_gender', headerName: 'ass_gender', sortable: true, filter: true, resizable: true },
        
        { field: 'ass_insurance_company_name', headerName: 'ass_insurance_company_name', sortable: true, filter: true, resizable: true },
        { field: 'ass_mobileno', headerName: 'ass_mobileno', sortable: true, filter: true, resizable: true },
        { field: 'ass_stoppay_status', headerName: 'ass_stoppay_status', sortable: true, filter: true, resizable: true },
        { field: 'ass_actual_dol', headerName: 'ass_actual_dol', sortable: true, filter: true, resizable: true },
        
        { field: 'ass_ol_basic', headerName: 'ass_ol_basic', sortable: true, filter: true, resizable: true },
        { field: 'ass_ol_ctc', headerName: 'ass_ol_ctc', sortable: true, filter: true, resizable: true },
        { field: 'ass_ol_da', headerName: 'ass_ol_da', sortable: true, filter: true, resizable: true },
        { field: 'ass_ol_empcomp', headerName: 'ass_ol_empcomp', sortable: true, filter: true, resizable: true },
        { field: 'ass_ol_empf', headerName: 'ass_ol_empf', sortable: true, filter: true, resizable: true },
        { field: 'ass_ol_esic', headerName: 'ass_ol_esic', sortable: true, filter: true, resizable: true },
        { field: 'ass_ol_gross', headerName: 'ass_ol_gross', sortable: true, filter: true, resizable: true },
        { field: 'ass_sr_basic', headerName: 'ass_sr_basic', sortable: true, filter: true, resizable: true },
        { field: 'ass_sr_ctc', headerName: 'ass_sr_ctc', sortable: true, filter: true, resizable: true },
        { field: 'ass_sr_da', headerName: 'ass_sr_da', sortable: true, filter: true, resizable: true },
        { field: 'ass_sr_empcomp', headerName: 'ass_sr_empcomp', sortable: true, filter: true, resizable: true },
        { field: 'ass_sr_empf', headerName: 'ass_sr_empf', sortable: true, filter: true, resizable: true },
        { field: 'ass_sr_esic', headerName: 'ass_sr_esic', sortable: true, filter: true, resizable: true },
        { field: 'ass_sr_gross', headerName: 'ass_sr_gross', sortable: true, filter: true, resizable: true },
        { field: 'ass_sr_effective_date', headerName: 'ass_sr_effective_date', sortable: true, filter: true, resizable: true },
        { field: 'mis_corpid', headerName: 'mis_corpid', sortable: true, filter: true, resizable: true },
        { field: 'mis_gmc', headerName: 'mis_gmc', sortable: true, filter: true, resizable: true },
        { field: 'mis_gpa', headerName: 'mis_gpa', sortable: true, filter: true, resizable: true },
        { field: 'mis_policy_end_date', headerName: 'mis_policy_end_date', sortable: true, filter: true, resizable: true },
        { field: 'mis_policy_start_date', headerName: 'mis_policy_start_date', sortable: true, filter: true, resizable: true },
        { field: 'mis_policy_type', headerName: 'mis_policy_type', sortable: true, filter: true, resizable: true },
        { field: 'mis_insurance_company', headerName: 'mis_insurance_company', sortable: true, filter: true, resizable: true },
        { field: 'mis_tpa_name', headerName: 'mis_tpa_name', sortable: true, filter: true, resizable: true },
        { field: 'mis_ec_industry_-_sales_force', headerName: 'mis_ec_industry_-_sales_force', sortable: true, filter: true, resizable: true },
        { field: 'mis_new_ec_rates', headerName: 'mis_new_ec_rates', sortable: true, filter: true, resizable: true },
        { field: 'mis_client_id', headerName: 'mis_client_id', sortable: true, filter: true, resizable: true },
        { field: 'mis_client', headerName: 'mis_client_name.1', sortable: true, filter: true, resizable: true },
        { field: 'mis_client_id_proper', headerName: 'mis_client_id_proper', sortable: true, filter: true, resizable: true },
        { field: 'mis_billing_type', headerName: 'mis_billing_type', sortable: true, filter: true, resizable: true },
     
        { field: 'classification_2', headerName: 'classification_2', sortable: true, filter: true, resizable: true },
        { field: 'classification_3', headerName: 'classification_3', sortable: true, filter: true, resizable: true },


    ];

    const [selectedOptionsPolicyType, setSelectedOptionsPolicyType] = useState(undefined);
    const [selectedOptionsInsuranceCompany, setselectedOptionsInsuranceCompany] = useState(undefined);
    const [inputMonth, setInputMonth] = useState('');
    const [hideResultGrid, setHideResultGrid] = useState(true);
    const [loaderOpen, setLoaderOpen] = useState(false);
    const [userCredentials] = useState(JSON.parse(sessionStorage.getItem("userCredentials")));
    const [rowData, setRowData] = useState(undefined);
    const [paginationSize] = useState(15);
    const [companyname, setCompanyName] = useState({});
    const [clientname, setClientName] = useState({});

    const [compynames, setCompyNames] = useState([{ value: "", label: "None" },]);
    const [clientnames, setClientNames] = useState([{ value: "", label: "None" },]);
    const [reporttype, setreporttype] = useState({});
    const [isdisablecompanyname, setisdisablecompanyname] = useState(false);

    

    const insuranceCompanyOptionsList = [
        { value: "ICICI Lombard General Insurance Company Limited", label: " ICICI Lombard General Insurance Company Limited" },
        { value: "United India Insurance Company Limited", label: " United India Insurance Company Limited" },
        { value: "National Insurance Company Limited", label: "National Insurance Company Limited" },
        { value: "No Insurance", label: "No Insurance" },
        { value: "Care Health Insurance Company Limited", label: "Care Health Insurance Company Limited" },
        { value: "IFFCO TOKIO GENERAL INSURANCE COMPANY LIMITED", label: "IFFCO TOKIO GENERAL INSURANCE COMPANY LIMITED" },
        { value: "The New India Assurance Co Ltd", label: "The New India Assurance Co Ltd" },
        { value: "The Oriental Insurance Company Limited", label: "The Oriental Insurance Company Limited" },
        { value: "Bajaj Allianz General Insurance", label: "Bajaj Allianz General Insurance" },
        { value: "ManipalCigna ProHealth Group Insurance Policy", label: "ManipalCigna ProHealth Group Insurance Policy" },
        { value: "Max Bupa Health insurance Company Limited & (GPA) TATA AIG General Insurance company Limited", label: "Max Bupa Health insurance Company Limited & (GPA) TATA AIG General Insurance company Limited" },
        { value: "Edelweiss General Insurance", label: "Edelweiss General Insurance" },
        { value: "Reliance General Insurance Co. Ltd.", label: "Reliance General Insurance Co. Ltd." },
        { value: "TATA AIG General insurance co", label: "TATA AIG General insurance co" },
        { value: "Magma HDI General Insurance Company Ltd", label: "Magma HDI General Insurance Company Ltd" },
        { value: "SHRIRAM General Insurance Company Limited", label: "SHRIRAM General Insurance Company Limited" },
    ];
    
    useEffect(() => {
        setLoaderOpen(false);
    }, []);

    const makeAPICall = async (url) => {
        try {
            setLoaderOpen(true);
            console.log(url);
            const response = await fetch(url);
            const data = await response.json();
            setRowData(data);
            console.log(data);
            setHideResultGrid(false);
            setLoaderOpen(false);
        }
        catch (e) {
            console.log(e);
            setLoaderOpen(false);
            setHideResultGrid(true);
        }
    }
  
    

    const customStyles = {
        control: base => ({
            ...base,
            height: 35,
            minHeight: 35,
            marginTop: 0,
            paddingTop: -5,
            fontSize: 14,
           
        })
    };


    // function getPolicytype(data) {
    //     setSelectedOptionsPolicyType(data);
    //     console.log(data);
    // }

    function getInsuranceCompany(data) {
        setselectedOptionsInsuranceCompany(data);
        console.log(data);
    }


    const makeAPICall3 = async (url) => {
        console.log('api call3');
        try {
            var optionList3 = [
                { value: "", label: "None" }, 
            ];
            setLoaderOpen(true);
            const response = await fetch(url);
            const data = await response.json();
            if(data != 'error'){
                Object.keys(data).map(item => {
                    console.log('item'+data[item]);
                    let object={
                        value: data[item],
                        label: data[item] 
                    }
                    optionList3.push(object);
                });
            }
            setCompyNames(optionList3);
            setLoaderOpen(false);
            console.log(data);
            
        }
        catch (e) {
            console.log(e);
            setLoaderOpen(false);
            
        }
    }



    function getSetInputMonth(data) {
        setInputMonth(data);
        console.log(data);
    }

    function searchClick(event) {
        if (companyname === undefined) {
            alert("Please Select Report Type!!!");
        }
        // else if(selectedOptionsPolicyType === undefined)
        // {
        //     alert("Please Select Policy Type!!!");
        // }
        // else if(selectedOptionsInsuranceCompany === undefined)
        // {
        //     alert("Please Select Insurance Company!!!");
        // }
        else if (inputMonth === undefined)
        {
            alert("Please Choose the Month!!!");
        }

        else{
            let url = '';
            console.log('nvnbvnvn');
            console.log('reporttype', reporttype.value);
            console.log('inputMonth', inputMonth);
            let report_type = String(reporttype.value);
            if (companyname && companyname.value && clientname && clientname.value) {
                let param = String(companyname.value);
                let param1 = String(clientname.value);
                let param2 = String(inputMonth);
                url = local_host1+`/api/v2/medical_insurance/master/?companyname=${param}&&clientname=${param1}&&month=${param2}&&reporttype=${report_type}`;
            }
            else if (companyname && companyname.value) {
                let param = String(companyname.value);
                let param1 = String(inputMonth);
                console.log('paam' + param);
                url = local_host1+`/api/v2/medical_insurance/master/?companyname=${param}&&month=${param1}&&reporttype=${report_type}`;
            }
            else if (clientname && clientname.value) {
                let param1 = String(clientname.value)
                url = local_host1+`/api/v2/medical_insurance/master/?clientname=${param1}&&month=${param1}&&reporttype=${report_type}`;
            } else {
                let param1 = String(inputMonth);
                url = local_host1+`/api/v2/medical_insurance/master/?month=${param1}&&reporttype=${report_type}`;
            }
            makeAPICall(url);
        }

    }

    function exportJsonToXLSX(data, sheetName, excelFileName) {
        try {
            var workBook = XLSX.utils.book_new();
            var workSheet = XLSX.utils.json_to_sheet(data, {
                skipHeader: false,
            });
            XLSX.utils.book_append_sheet(workBook, workSheet, sheetName);
            XLSX.writeFile(workBook, excelFileName);
            return true;
        }
        catch
        {
            return false;
        }
    }

    function exportToExcel() {
        let fileNameChange = "Report.xlsx";
        let sheetName = "sheet";

        let excelExportData = [];

        for (let i = 0; i < rowData.length; i++) {

            let data = {};
            for (let key in rowData[i]) {
                for (let j = 0; j < gridColumnDefs.length; j++) {
                    if (key === gridColumnDefs[j]["field"]) {
                        data[gridColumnDefs[j]["headerName"]] = rowData[i][key]
                    }
                }
            }

            excelExportData.push(data);
        };

        exportJsonToXLSX(excelExportData, sheetName, fileNameChange);

    }

    // function getReportGridData()
    // {
    //     setLoaderOpen(true);

    //     let payLoad ={
    //             "reportType" : selectedOptions["value"],
    //             "policyType" : selectedOptionsPolicyType["value"],
    //             "insuranceCompany" : selectedOptionsInsuranceCompany["value"],
    //             "uploadMonth" : inputMonth,
    //             "tenantsId" : userCredentials["tenants_id"],
    //             "groupsId" : userCredentials["groups_id"],
    //             "entitiesId" : userCredentials["entities_id"],
    //             "mProcessingLayerId" : userCredentials["m_processing_layer_id"],
    //             "mProcessingSubLayerId" : userCredentials["m_processing_sub_layer_id"],
    //             "processingLayerId" : userCredentials["processing_layer_id"],
    //             "userId" : userCredentials["user_id"]
    //     };

    //     var getReportGridData = getReportGridDataFromServer();

    //     axios.get(getReportGridData[1], {params : payLoad},getReportGridData[0])
    //     .then(
    //         response =>{
    //             console.log("getReportGridData Response!!!", response);
    //             let data = response["data"];
    //             if (data["Status"] === "Success")
    //             {
    //                 setRowData(data["response_data"]);
    //             };
    //             setHideResultGrid(false);
    //             setLoaderOpen(false);
    //         }
    //     ).catch(
    //         error => {
    //             console.log("Error in getReportData!!!", error);
    //             setHideResultGrid(true);
    //             setLoaderOpen(false);
    //         }      
    //     )
    // }

   

    const makeAPICall2 = async (url) => {
        console.log('api call');
        try {
            var optionList2 = [
                { value: "", label: "None" }, 
            ];
            setLoaderOpen(true);
            const response = await fetch(url);
            const data = await response.json();
            if(data != 'error'){
                Object.keys(data).map(item => {
                    console.log('item'+data[item]);
                    let object={
                        value: data[item],
                        label: data[item] 
                    }
                    optionList2.push(object);
                });
            }
            setClientNames(optionList2);
            setLoaderOpen(false);
            console.log(data);
            
        }
        catch (e) {
            console.log(e);
            
        }
    }

    function getReportType1(data) {
        
        console.log(data.value);
        setHideResultGrid(true);
        if (data && data.value) {
            let url = '';
            console.log('companyname', data.value);
            let param = String(data.value)
            let param1 = String(inputMonth)
            let param2 = String(reporttype.value)
            url = local_host1+`/api/v2/medical_insurance/client_name/?com_name=${param}&&month=${param1}&&reporttype=${param2}`;  
            makeAPICall2(url);  
        }
    }

    function handleChange(data) {
        setCompanyName(data);
        console.log(data.value);
         getReportType1(data);
        setHideResultGrid(true);

    }

    function handleChange1(data) {
        setClientName(data);
        console.log(data.value);
        setHideResultGrid(true);
    }

    const reporttype_options = [
        { value: "edli", label: "EDLI"},
        { value: "ec", label: "EC"},
        { value: "hmc_gpa", label: "HMC & GPA"},
        { value: "gpa", label: "GPA"},
        { value: "gpl", label: "GPL"},
        { value: "health card", label: "Health Card"}
    ];

    const onchangereporttype = (data) =>{
        setreporttype(data);
        setHideResultGrid(true);
        if (data) {
            let url = '';
            let param = data.value;
            let param1 = String(inputMonth);
            console.log('data', param);
            if(data.value == 'edli' || data.value == 'ec'){
                alert('you can cleck the seach option')
                setisdisablecompanyname(true);
            }else{
                url = local_host1+`/api/v2/medical_insurance/company_name/?month=${param1}&&reporttype=${param}`;  
                setisdisablecompanyname(false);
                makeAPICall3(url);  

            }
        }
        
    }

    return (
        <>
            <div className="report-cardBox">
                <div className="" style={{ marginTop: "2px" }}>
                    <div>
                        <label id="underline_select" htmlFor="underline_select " style={{ fontSize: '15px' }}>Month</label><br />
                        <input type="month" className="cardName filetype" style={{marginTop:'10px' }} onChange={(e) => { getSetInputMonth(e.target.value) }} />
                    </div>
                </div>
                <div className="">
                    <div>
                        <label htmlFor="underline_select " style={{ fontSize: '15px', left: '0px' }}>Reports Type</label> <br />
                        <div className="cardName">
                            <div className="dropdown-container">
                                <Select
                                    options={reporttype_options}
                                    placeholder="Select Report Type"
                                    value={reporttype}
                                    onChange={onchangereporttype}
                                    isSearchable={true}
                                    styles={customStyles}
                                />
                            </div>
                        </div>
                    </div>
                </div>
                <div className="">
                    <div>
                        <label htmlFor="underline_select " style={{ fontSize: '15px', left: '0px' }} >Insurance Company Name</label> <br />
                        <div className="cardName">
                            <div className="dropdown-container" >
                                <Select
                                    options={compynames}
                                    placeholder="Select Company Name"
                                    value={companyname}
                                    onChange={handleChange}
                                    isSearchable={true}
                                    styles={customStyles}
                                    isDisabled={isdisablecompanyname}
                                />
                            </div>
                        </div>
                    </div>
                </div>
               
                <div className="">
                    <div>
                        <label htmlFor="underline_select " style={{ fontSize: '15px' }}> Client Name</label> <br />
                        <div className="cardName">
                            <div className="dropdown-container">
                                <Select
                                    options={clientnames}
                                    placeholder="Select Client Name"
                                    value={clientname}
                                    onChange={handleChange1}
                                    isSearchable={true}
                                    styles={customStyles}
                                    isDisabled={isdisablecompanyname}
                                />
                            </div>
                        </div>
                    </div>
                </div>
                
                {companyname && inputMonth ?
                    <button className="btn" style={{ height: "35px", width: "92px", marginTop: "28px", backgroundColor: "#000055", color: "#ffffff" }} onClick={(e) => { searchClick(e) }}>Search</button>
                    : <button className="btn" disabled={true} style={{ height: "35px", width: "92px", marginTop: "28px", backgroundColor: "#000055", color: "#ffffff" }}>Search</button>
                }
            </div>
            <div className="report" hidden={hideResultGrid}>
                <img src={excelIcon} alt="No Images" style={{ width: '40px', height: '37px' }} className="excel-icon-class" onClick={() => { exportToExcel() }} title="Export" />
                <div className="ag-theme-balham report-layer">
                    <AgGridReact
                        columnDefs={gridColumnDefs}
                        rowData={rowData}
                        paginationPageSize={paginationSize}
                        pagination={true}
                        animateRows={true}
                    >
                    </AgGridReact>
                </div>
            </div>

            <LoaderComponent loaderOpen={loaderOpen} />

        </>
    )
}

export default MedicalInsuranceReport;











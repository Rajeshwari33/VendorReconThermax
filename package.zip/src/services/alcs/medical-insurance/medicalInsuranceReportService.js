import { headers, baseUrl } from "../../common/credentials";

const port = "8002";

export const getFileProcessFromServerNew = () => {
    let url = baseUrl + port + "/api/v2/medical_insurance/generic/reports_new/";
    return ([headers, url]);
} 

export const getFileProcessFromServer = () => {
    let url = baseUrl + port + "/api/v2/medical_insurance/generic/reports/";
    return ([headers, url]);
} 
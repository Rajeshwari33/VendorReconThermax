// App.js
import { useEffect, useState,useMemo,useCallback } from "react";
// import "./App.css";
import "../etlsecound.css";
import hdfcs from '../../../../assets/images/banks/thermax.png';
// import vender from './vendorstatement.json';

import record from './vendorstatement.json';
import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
const GridExample2 = () => {
    const containerStyle = useMemo(() => ({ width: "100%", height: "100%" }), []);
    const gridStyle = useMemo(() => ({ height: "100%", width: "100%" }), []);
    const [rowData, setRowData] = useState();
    const [columnDefs, setColumnDefs] = useState([
      { field: "Date", minWidth: 170 },
      { field: "" },
      { field: "Particulars" },
      { field: "Vch Type" },
      { field: "Vch No." },
      { field: "Debit" },
      { field: "Credit" },
      { field: "INVOICE/ PO NO." },
      { field: "GRN NO" },
      { field: "GST AMT" },
      { field: "TDS AMT" },
      { field: "RETENTION" },
      { field: "UTR NO" },
      { field: "REFERENCE TEXT" },
      { field: "REMARKS" },
      { field: "Match ref" },
      { field: "Amount as per Thermax" },
      { field: "Diff" },
     
   
     
    ]);
    const defaultColDef = useMemo(() => {
      return {
        editable: true,
        sortable: true,
        filter: true,
        resizable: true,
      };
    }, []);
  
    const onGridReady = useCallback((params) => {
      fetch('./vendorstatement.json')
        .then((resp) => resp.json())
        .then((data) => setRowData(data));
    }, []);
  
   
    return (
      <div style={containerStyle}>
        <div style={gridStyle} className="ag-theme-alpine">
          <AgGridReact
            rowData={record}
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}
            sideBar={true}
            suppressMenuHide={true}
            onGridReady={onGridReady}
          ></AgGridReact>
         
        </div>
      </div>
    );
  };

function VendorStatementSagar() 
{
  

  return (
  <div className="scroll">
    <table className="table ">
    <tr className="fontcolor">
        <td>Sagarbhanga Foundry and Engineering (F.Y 2021-22)</td>
        
    </tr>
    <tr className="bold">
        <td>Nasser Avenue, Durgapur-12</td>
        
    </tr>
    <tr className="bold">
        <td>GSTIN/UIN: 19ALSPK3740Q1Z7</td>
        
    </tr>
    <tr className="bold">
        <td>State Name: West Bengal, Code:19</td>
        
    </tr>
    <tr className="bold">
        <td>E-Mail : Sfe_dgp@rediffmail.Com</td>
       
    </tr>
    <tr className="bold">
        <td><img src={hdfcs} alt="" height="40px" width="60px" />Thermax Limited (POWER) - AAACT3910D</td>
        
    </tr>
    <tr className="bold">
        <td>Ledger Account</td>
        
    </tr>
    <tr className="bold">
        <td>GST NO : 27AAACT3910D1ZS.</td>
       
    </tr>
    <br></br>
    <tr className="bold">
        <td>1-Apr-21 to 31-Mar-22</td>
       
    </tr>
    <br></br>
   
</table>

<div  style={{height:"400px"}}><GridExample2/></div>
  </div>
  
  )
}



export default VendorStatementSagar;
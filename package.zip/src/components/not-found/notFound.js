import React from "react";
import { useNavigate } from 'react-router-dom';
import './notFound.css';
import errorRead from '../../assets/images/errorRed.jpg';

function NotFound()
{

    const navigate = useNavigate();

    function navigateToHome() {
        navigate('/');
    };

    return (
        <div>
            <img src={errorRead} alt="No Images" style={{width: '1536px', height: '761px'}} />
            <div className="pagenotfoundtext">OOPS!</div>
            <div className="pagenotfoundtext2">It looks like you're lost</div>
            <div className="pagenotfoundnumber">404</div>
            <div className="backtohomebox">
                <div className="backtohometext" onClick={navigateToHome}>BACK TO HOME</div>
            </div>
        </div>
    );
};

export default NotFound;
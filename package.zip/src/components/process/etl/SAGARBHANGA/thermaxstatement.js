// App.js
import { useEffect, useState,useMemo,useCallback } from "react";
// import "./App.css";
import "../etlsecound.css";
import hdfcs from '../../../../assets/images/banks/thermax.png';
import { AgGridReact } from "ag-grid-react";
import record from "./tharmax.json"

// import 'ag-grid-enterprise';
// import 'npm i ag-grid-enterprise ';

import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";

const GridExample2 = () => {
    const containerStyle = useMemo(() => ({ width: "100%", height: "100%" }), []);
    const gridStyle = useMemo(() => ({ height: "100%", width: "100%" }), []);
    const [rowData, setRowData] = useState();
    const [columnDefs, setColumnDefs] = useState([
      { field: "Div Code", minWidth: 170 },
      { field: "Division Name" },
      { field: "GL Code" },
      { field: "GL description" },
      { field: "Supplier Code" },
      { field: "Doc Category" },
      { field: "Document Number" },
      { field: "Document Date" },
      { field: "GL Date" },
      { field: "Invoice Number" },
      { field: "Supplier Invoice No" },
      { field: "Supplier Invoice Date" },
      { field: "Opening Balance" },
      { field: "GL Debit " },
      { field: "GL Credit" },
      { field: "Narration" },
      { field: "Opening Balance" },
      { field: "INVOICE/ PAYMENT" },
      { field: "EVENT TYPE" },
      { field: "REMARKS" },
      { field: "Match ref" },
      { field: "Recon remark" },
      { field: "Matched/Unmatched" },
      { field: "Reason for diff" },
      { field: "Net Payment" },
      { field: "Annex" },
   
     

   
     
    ]);
    const defaultColDef = useMemo(() => {
      return {
        editable: true,
        sortable: true,
        filter: true,
        resizable: true,
      };
    }, []);
  
    const onGridReady = useCallback((params) => {
      fetch('./tharmax.json')
        .then((resp) => resp.json())
        .then((data) => setRowData(data));
    }, []);
  
   
    return (
      <div style={containerStyle}>
        <div style={gridStyle} className="ag-theme-alpine">
          <AgGridReact
            rowData={record}
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}
            sideBar={true}
            suppressMenuHide={true}
            onGridReady={onGridReady}
          ></AgGridReact>
         
        </div>
      </div>
    );
  };
  

function ThermaxStatementSagar() 
{
    
  return (
 
      <div style={{height:"500px"}}>
        <GridExample2/>
      </div>
      
  )
}



export default ThermaxStatementSagar;
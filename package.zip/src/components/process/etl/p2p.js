import React from "react";
// import React,{useEffect, useState} from 'react';

import "./etlsecound.css";
import { Icon, Input, Button,Dropdown, Grid, Popup,Segment,Select,Tab,Table,Menu , Form, TextArea, Label, Checkbox, GridColumn} from 'semantic-ui-react'



  const InputExampleIconPosition5 = (props) => (
    <Input icon={props.ico} iconPosition='left' placeholder={props.name} />
  )
  const InputExampleIconPosition2 = (props) => (
    <Input icon={props.ico} iconPosition='left'  type="date"placeholder={props.name} />
  )
  
class P2p extends React.Component {

  

    render() {
        
      return (
        <div>
         {/* <h1>hi</h1> */}
         <div className="side">
         <Grid columns='equal' style={{ padding:"10px"}}>
              <Grid.Row style={{ backgroundColor:"#e9e8d9",}}>
              <Grid.Column>
                    <label>Source Name</label>
                    <InputExampleIconPosition5 name="Enter Month" icon="clipboard outline"/>
                </Grid.Column>
                <Grid.Column>
                <label>Contract Number</label>
                    <InputExampleIconPosition5 name="Enter Number" icon="clipboard outline"/>
                </Grid.Column>
                <Grid.Column >
                <label>Contract Start Date</label>
                    <InputExampleIconPosition2 name="Enter Month" icon="clipboard outline"/>
                </Grid.Column>
                <Grid.Column>
                <label>Contract Expriry Date</label>
                    <InputExampleIconPosition2 name="Enter Month" icon="clipboard outline"/>
                </Grid.Column>
                <Grid.Column>
                <label>Vendor Code</label>
                    <InputExampleIconPosition5 name="Enter code" icon="clipboard outline"/>
                </Grid.Column>
                
                
               
             </Grid.Row>

             <Grid.Row style={{ backgroundColor:"#e9e8d9",}}>
              <Grid.Column>
                    <label>Vendor Name</label>
                    <InputExampleIconPosition5 name="Enter Vendor Name" icon="clipboard outline"/>
                </Grid.Column>
                <Grid.Column>
                <label>Contract Purchase</label>
                    <InputExampleIconPosition5 name="Enter Contract Purchase" icon="clipboard outline"/>
                </Grid.Column>
                <Grid.Column >
                <label>Delivery Location</label>
                    <InputExampleIconPosition5 name="Enter Delivery Location" icon="clipboard outline"/>
                </Grid.Column>
                <Grid.Column>
                <label>Contract kind</label>
                    <InputExampleIconPosition5 name="Enter Contract kind" icon="clipboard outline"/>
                </Grid.Column>
                <Grid.Column>
                <label>Expense Category</label>
                    <InputExampleIconPosition5 name="Enter Expense Category" icon="clipboard outline"/>
                </Grid.Column>
                
                
               
             </Grid.Row>
                      
                      
             
             

          </Grid>
  
  
         </div>
        </div>
      );
    }
  }
  
  export default P2p;
  
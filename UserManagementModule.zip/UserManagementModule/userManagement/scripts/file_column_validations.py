from django.contrib.auth import authenticate
from rest_framework import generics, status, viewsets
from rest_framework.response import Response
from rest_framework.decorators import authentication_classes, permission_classes
import logging, json, requests
import io
import os
import json
import re
from rest_framework import status
from rest_framework.views import APIView
import pandas as pd
import numpy as np
from rest_framework.parsers import JSONParser
from django.core import serializers

from UserManagementModule.common.credentials import localhost, headers

import requests

@authentication_classes([])
@permission_classes([])
class RequestView(APIView):
    """
        This method is used to validate json file based on the data type and column_name.
        if it check the column name values contains string datatype or not.
    """
    def post(self, request):
        url = "http://127.0.0.1:8000/api/v2/user_modules/length_validation/"
        data = {
            "column_name":"date",
            "data_type":"length",
            "min_length":"1",
            "max_length":"20"   
        }
        headers = {'Content-type': 'application/json', "Accept": "application/json, text/plain, */*",}
        response = requests.post(url, data=json.dumps(data), headers=headers)
        res = response.json()
        if res.status == 'success':
            message = "success"
        else:
            message = res.status
        return Response({'status': message})

logger = logging.getLogger("user_modules")

@authentication_classes([])
@permission_classes([])
class ValidateSourceNameMinLengthEtl(APIView):
    """
        This method is used to validate source name.
        if source name contains less than 2 char send the erroer message other wise send sucess message.
    """
    def post(self, request):
        try:
            json_data = request.body
            stream = io.BytesIO(json_data)
            python_data = JSONParser().parse(stream)
            print('inside min length function', python_data)
            if python_data['source_name'] and len(python_data['source_name']) > 2:
                return Response({'status':'success'}, status=status.HTTP_200_OK)
            else:
                with open('status.json', 'w') as file:
                    file.truncate()
                data_to_add = {'status':'error', 'msg':'source name contains less than 2 charectors'}
                with open('status.json', 'w') as file:
                    json.dump(data_to_add, file, indent=4)
                return Response({'status':'error', 'msg':'source name contains less than 2 charectors'}, status=status.HTTP_400_BAD_REQUEST)
        except Exception:
            logger.error("Error in Post Method of Validate  SourceName MinLength Etl View!!!", exc_info=True)
            response = {
                'status': "Error"
            }
            return Response(response)


@authentication_classes([])
@permission_classes([])
class ValidateSourceNameMaxLengthEtl(APIView):
    """
        This method is used to validate source name.
        if source name contains more than 20 char send the erroer message other wise send sucess message.
    """
    def post(self, request):
        try:
            json_data = request.body
            stream = io.BytesIO(json_data)
            python_data = JSONParser().parse(stream)
            print('ValidateSourceNameMaxLengthEtl', python_data)
            if python_data['source_name'] and len(python_data['source_name']) < 20:
                return Response({'status':'success'}, status=status.HTTP_200_OK)
            else:
                with open('status.json', 'w') as file:
                    file.truncate()
                data_to_add = {'status':'error', 'msg':'source name contains more than 20 charectors'}
                with open('status.json', 'w') as file:
                    json.dump(data_to_add, file, indent=4)

                return Response({'status':'error', 'msg':'source name contains more than 20 charectors'}, status=status.HTTP_400_BAD_REQUEST)
        except Exception:
            logger.error("Error in Post Method of Validate  SourceName MinLength Etl View!!!", exc_info=True)
            response = {
                'status': "Error"
            }
            return Response(response)



@authentication_classes([])
@permission_classes([])
class ValidateSourceIdentifierMinLengthEtl(APIView):
    """
        This method is used to validate source identifier.
        if source identifier contains less than 2 char send the erroer message other wise send sucess message.
    """
    def post(self, request):
        try:
            json_data = request.body
            stream = io.BytesIO(json_data)
            python_data = JSONParser().parse(stream)
            print('inside min length function', python_data)
            if python_data['source_identifier'] and len(python_data['source_identifier']) > 2:
                return Response({'status':'success'}, status=status.HTTP_200_OK)
            else:
                with open('status.json', 'w') as file:
                    file.truncate()
                data_to_add = {'status':'error', 'msg':'source identifier contains less than 2 charectors'}
                with open('status.json', 'w') as file:
                    json.dump(data_to_add, file, indent=4)
                return Response({'status':'error', 'msg':'source identifier contains less than 2 charectors'}, status=status.HTTP_400_BAD_REQUEST)
        except Exception:
            logger.error("Error in Post Method of Validate  Source Identifier MinLength Etl View!!!", exc_info=True)
            response = {
                'status': "Error"
            }
            return Response(response)



@authentication_classes([])
@permission_classes([])
class ValidateSourceIdentifierMaxLengthEtl(APIView):
    """
        This method is used to validate source identifier.
        if source identifier contains greather than 20 char send the erroer message other wise send sucess message.
    """
    def post(self, request):
        try:
            json_data = request.body
            stream = io.BytesIO(json_data)
            python_data = JSONParser().parse(stream)
            print('inside min length function', python_data)
            if python_data['source_identifier'] and len(python_data['source_identifier']) < 20:
                return Response({'status':'success'}, status=status.HTTP_200_OK)
            else:
                with open('status.json', 'w') as file:
                    file.truncate()
                data_to_add = {'status':'error', 'msg':'source identifier contains more than 20 charectors'}
                with open('status.json', 'w') as file:
                    json.dump(data_to_add, file, indent=4)
                return Response({'status':'error', 'msg':'source identifier contains more than 20 charectors'}, status=status.HTTP_400_BAD_REQUEST)
        except Exception:
            logger.error("Error in Post Method of Validate  Source Identifier MaxLength Etl View!!!", exc_info=True)
            response = {
                'status': "Error"
            }
            return Response(response)


@authentication_classes([])
@permission_classes([])
class ValidateSourceDescriptionMinLengthEtl(APIView):
    """
        This method is used to validate source description.
        if source description contains less than 2 char send the erroer message other wise send sucess message.
    """
    def post(self, request):
        try:
            json_data = request.body
            stream = io.BytesIO(json_data)
            python_data = JSONParser().parse(stream)
            print('inside min length function', python_data)
            if python_data['source_description'] and len(python_data['source_description']) > 2:
                return Response({'status':'success'}, status=status.HTTP_200_OK)
            else:
                with open('status.json', 'w') as file:
                    file.truncate()
                data_to_add = {'status':'error', 'msg':'source description contains less than 2 charectors'}
                with open('status.json', 'w') as file:
                    json.dump(data_to_add, file, indent=4)
                return Response({'status':'error', 'msg':'source description contains less than 2 charectors'}, status=status.HTTP_400_BAD_REQUEST)
        except Exception:
            logger.error("Error in Post Method of Validate  Source description MinLength Etl View!!!", exc_info=True)
            response = {
                'status': "Error"
            }
            return Response(response)


@authentication_classes([])
@permission_classes([])
class ValidateSourceDescriptionMaxLengthEtl(APIView):
    """
        This method is used to validate source description.
        if source description contains more than 20 char send the erroer message other wise send sucess message.
    """
    def post(self, request):
        try:
            json_data = request.body
            stream = io.BytesIO(json_data)
            python_data = JSONParser().parse(stream)
            print('ValidateSourceDescriptionMaxLengthEtl', python_data)
            if python_data['source_description'] and len(python_data['source_description']) < 20:
                return Response({'status':'success'}, status=status.HTTP_200_OK)
            else:
                with open('status.json', 'w') as file:
                    file.truncate()
                data_to_add = {'status':'error', 'msg':'source description contains more than 20 charectors'}
                with open('status.json', 'w') as file:
                    json.dump(data_to_add, file, indent=4)

                return Response({'status':'error', 'msg':'source description contains more than 20 charectors'}, status=status.HTTP_400_BAD_REQUEST)
        except Exception:
            logger.error("Error in Post Method of Validate  Source description MinLength Etl View!!!", exc_info=True)
            response = {
                'status': "Error"
            }
            return Response(response)



@authentication_classes([])
@permission_classes([])
class ValidateSourceFileTypeEtl(APIView):
    """
        This method is used to validate source file.
        if source file contains excel, csv, binary and text send sucess message other wise send the erroer message.
    """
    def post(self, request):
        try:
            json_data = request.body
            stream = io.BytesIO(json_data)
            python_data = JSONParser().parse(stream)
            print('ValidateSourceFileTypeEtl', python_data)
            file_name = python_data['file_name']
            if file_name:
                file_name = file_name.split('.')[-1]
                print('file_name', file_name)
            if python_data['source_type'] and file_name in ['xlsx', 'xlx', 'csv', 'xlsb', 'txt']:
                return Response({'status':'success'}, status=status.HTTP_200_OK)
            else:
                with open('status.json', 'w') as file:
                    file.truncate()
                data_to_add = {'status':'error', 'msg':'source file not contains excel, csv, binary and text '}
                with open('status.json', 'w') as file:
                    json.dump(data_to_add, file, indent=4)

                return Response({'status':'error', 'msg':'source file not contains excel, csv, binary and text '}, status=status.HTTP_400_BAD_REQUEST)
        except Exception:
            logger.error("Error in Post Method of Validate  Source file type Etl View!!!", exc_info=True)
            response = {
                'status': "Error"
            }
            return Response(response)

@authentication_classes([])
@permission_classes([])
class StringValidationView(APIView):
    """
        This method is used to validate json file based on the data type and column_name.
        if it check the column name values contains string datatype or not.
    """
    def post(self, request):
        try:
            json_data = request.body
            stream = io.BytesIO(json_data)
            python_data = JSONParser().parse(stream)
            print('python_data', python_data)
            error_type = ''
            json_data = {}
            if python_data and python_data.__contains__('column_name') and python_data.get('column_name') and python_data.__contains__('data_type') and python_data.get('data_type'):
                column_name = python_data['column_name']
                print('column_name', column_name)
                data_type = python_data['data_type']
                df = pd.DataFrame(json_data)
                df = df.fillna('')
                if data_type == 'text':
                    if df[column_name].dtype == object:
                        print(column_name+' contains string values..')
                    else:
                        error_type = column_name + ' column contains null or string values'
                        # return error_type
                        return Response({'status':error_type})
                else:
                    error_type =  'data_type contans null value or contains diffrent datatype !!!'
                    # return error_type
                    return Response({'status':error_type})
            else:
                error_type =  'python data or column_name or data_type contans null values send both values !!!'
                return Response({'status':error_type})
            return Response({'status':'success'})
        except Exception:
            logger.error("Error in Post Method of String Validation View!!!", exc_info=True)
            response = {
                'status': "Error"
            }
            return Response(response)


@authentication_classes([])
@permission_classes([])
class IntegerValidationView(APIView):
    """
        This method is used to validate json file based on the data type and column_name.
        if it check the column name values contains integer datatype or not.
    """
    def post(self, request):
        try:
            json_data = request.body
            stream = io.BytesIO(json_data)
            python_data = JSONParser().parse(stream)
            print('python_data', python_data)
            error_type = ''
            json_data = {}
            if python_data and python_data.__contains__('column_name') and python_data.get('column_name') and python_data.__contains__('data_type') and python_data.get('data_type'):
                column_name = python_data['column_name']
                print('column_name', column_name)
                data_type = python_data['data_type']
                df = pd.DataFrame(json_data)
                df = df.fillna('')
                if data_type == 'integer':
                    isnumeric = pd.to_numeric(df[column_name], errors='coerce').notnull().all()
                    if not isnumeric:
                        error_type = column_name + ' column contains null or string values'
                        # return error_type
                        return Response({'status':error_type})
                else:
                    error_type =  'data_type contans null value or contains diffrent datatype !!!'
                    # return error_type
                    return Response({'status':error_type})
            else:
                error_type =  'python data or column_name or data_type contans null values send both values !!!'
                return Response({'status':error_type})
            return Response({'status':'success'})
        except Exception:
            logger.error("Error in Post Method of Integer Validation View!!!", exc_info=True)
            response = {
                'status': "Error"
            }
            return Response(response)


@authentication_classes([])
@permission_classes([])
class DecimalValidationView(APIView):
    """
        This method is used to validate json file based on the data type and column_name.
        if it check the column name values contains decimal datatype or not.
    """
    def post(self, request):
        try:
            json_data = request.body
            stream = io.BytesIO(json_data)
            python_data = JSONParser().parse(stream)
            print('python_data', python_data)
            error_type = ''
            json_data = {}
            if python_data and python_data.__contains__('column_name') and python_data.get('column_name') and python_data.__contains__('data_type') and python_data.get('data_type'):
                column_name = python_data['column_name']
                print('column_name', column_name)
                data_type = python_data['data_type']
                df = pd.DataFrame(json_data)
                df = df.fillna('')
                if data_type == 'Decimal':
                    all_decimals = df[column_name].dtype == 'float64' or df[column_name].dtype == 'float32'
                    if not all_decimals:
                        error_type = column_name + ' column not contains decimal values'
                        # return error_type
                        return Response({'status':error_type})
                else:
                    error_type =  'data_type contans null value or contains diffrent datatype !!!'
                    # return error_type
                    return Response({'status':error_type})
            else:
                error_type =  'python data or column_name or data_type contans null values send both values !!!'
                return Response({'status':error_type})
            return Response({'status':'success'})
        except Exception:
            logger.error("Error in Post Method of Decimal Validation View!!!", exc_info=True)
            response = {
                'status': "Error"
            }
            return Response(response)


@authentication_classes([])
@permission_classes([])
class UnqueValidationView(APIView):
    """
        This method is used to validate json file based on the data type and column_name.
        if it check the column name values contains unique values or not.
    """
    def post(self, request):
        try:
            json_data = request.body
            stream = io.BytesIO(json_data)
            python_data = JSONParser().parse(stream)
            print('python_data', python_data)
            error_type = ''
            json_data = {}
            if python_data and python_data.__contains__('column_name') and python_data.get('column_name') and python_data.__contains__('data_type') and python_data.get('data_type'):
                column_name = python_data['column_name']
                print('column_name', column_name)
                data_type = python_data['data_type']
                df = pd.DataFrame(json_data)
                df = df.fillna('')
                if data_type == 'unique':
                    all_decimals = df[column_name].dtype == 'float64' or df[column_name].dtype == 'float32'
                    if df[column_name].duplicated().any():
                        error_type = column_name + ' column not contains unique values'
                        return Response({'status':error_type})
                else:
                    error_type =  'data_type contans null value or contains diffrent datatype !!!'
                    # return error_type
                    return Response({'status':error_type})
            else:
                error_type =  'python data or column_name or data_type contans null values send both values !!!'
                return Response({'status':error_type})
            return Response({'status':'success'})
        except Exception:
            logger.error("Error in Post Method of Unique Validation View!!!", exc_info=True)
            response = {
                'status': "Error"
            }
            return Response(response)

@authentication_classes([])
@permission_classes([])
class DateValidationView(APIView):
    """
        This method is used to validate json file based on the data type and column_name.
        if it check the column name values contains date is valid formate or not.
    """
    def post(self, request):
        try:
            json_data = request.body
            stream = io.BytesIO(json_data)
            python_data = JSONParser().parse(stream)
            print('python_data', python_data)
            error_type = ''
            json_data = {}
            if python_data and python_data.__contains__('column_name') and python_data.get('column_name') and python_data.__contains__('data_type') and python_data.get('data_type'):
                column_name = python_data['column_name']
                print('column_name', column_name)
                data_type = python_data['data_type']
                df = pd.DataFrame(json_data)
                df = df.fillna('')
                if data_type == 'DateFormate':
                    is_date = pd.to_datetime(df[column_name]).notnull().all()
                    print('is_date', is_date)
                    if not is_date:
                        error_type = column_name + ' column contains wrong date formate!!!'
                        return Response({'status':error_type})
                else:
                    error_type =  'data_type contans null value or contains diffrent datatype !!!'
                    return Response({'status':error_type})
            else:
                error_type =  'python data or column_name or data_type contans null values send both values !!!'
                return Response({'status':error_type})
            return Response({'status':'success'})
        except Exception:
            logger.error("Error in Post Method of Date Validation View!!!", exc_info=True)
            response = {
                'status': "Error"
            }
            return Response(response)


@authentication_classes([])
@permission_classes([])
class LengthValidationView(APIView):
    """
        This method is used to validate json file based on the data type and column_name.
        if it check the column name values contains length is less than 2 or not.
    """
    def post(self, request):
        try:
            json_data = request.body
            stream = io.BytesIO(json_data)
            python_data = JSONParser().parse(stream)
            print('python_data', python_data)
            print('localhost', localhost)
            error_type = ''
            json_data = {'date': ['2-04-2019', '7-04-2019', '12-05-2019', '2-04-2019', '2-04-2019'],
        'Column2': [1, 2, 3, 4, 5]}
            if python_data and python_data.__contains__('column_name') and python_data.get('column_name') and python_data.__contains__('data_type') and python_data.get('data_type') and python_data.__contains__('min_length') and python_data.get('min_length') and python_data.__contains__('max_length') and python_data.get('max_length'):
                column_name = python_data['column_name']
                print('column_name', column_name)
                data_type = python_data['data_type']
                min_length = int(python_data['min_length'])
                max_length = int(python_data['max_length'])

                df = pd.DataFrame(json_data)
                df = df.fillna('')
                if data_type == 'length':
                    isMin_len = df[df[column_name].str.len() >= min_length]
                    isMax_len = df[df[column_name].str.len() <= max_length]
                    print('isMin_len', isMin_len)
                    print('isMax_len', isMax_len)
                    if len(isMin_len) == 0:
                        error_type = column_name + ' column contains length is more than 1 !!!'
                        return Response({'status':error_type})

                    if len(isMax_len) == 0:
                        error_type = column_name + ' column contains length is more than 1 !!!'
                        return Response({'status':error_type})
                else:
                    error_type =  'data_type contans null value or contains diffrent datatype !!!'
                    return Response({'status':error_type})
            else:
                error_type =  'python data or column_name or data_type contans null values send both values !!!'
                return Response({'status':error_type})
            return Response({'status':'success'})
        except Exception:
            logger.error("Error in Post Method of Length Validation View!!!", exc_info=True)
            response = {
                'status': "Error"
            }
            return Response(response)



@authentication_classes([])
@permission_classes([])
class YesOrNoValidationView(APIView):
    """
        This method is used to validate json file based on the data type and column_name.
        if it check the column name values contains yes or no.
    """
    def post(self, request):
        try:
            json_data = request.body
            stream = io.BytesIO(json_data)
            python_data = JSONParser().parse(stream)
            print('python_data', python_data)
            error_type = ''
            json_data = {}
            if python_data and python_data.__contains__('column_name') and python_data.get('column_name') and python_data.__contains__('data_type') and python_data.get('data_type'):
                column_name = python_data['column_name']
                print('column_name', column_name)
                data_type = python_data['data_type']
                df = pd.DataFrame(json_data)
                df = df.fillna('')
                if data_type == 'Yes / No':
                    is_YesOrNo = df[column_name].isin(['Yes', 'No']).all()
                    print('is_YesOrNo', is_YesOrNo)
                    if not is_YesOrNo:
                        error_type = column_name + ' column contains other values besides yes or no !!!'
                        return Response({'status':error_type})
                else:
                    error_type =  'data_type contans null value or contains diffrent datatype !!!'
                    return Response({'status':error_type})
            else:
                error_type =  'python data or column_name or data_type contans null values send both values !!!'
                return Response({'status':error_type})
            return Response({'status':'success'})
        except Exception:
            logger.error("Error in Post Method of Yes Or No Validation View!!!", exc_info=True)
            response = {
                'status': "Error"
            }
            return Response(response)


@authentication_classes([])
@permission_classes([])
class TrueOrFalseValidationView(APIView):
    """
        This method is used to validate json file based on the data type and column_name.
        if it check the column name values contains True or False.
    """
    def post(self, request):
        try:
            json_data = request.body
            stream = io.BytesIO(json_data)
            python_data = JSONParser().parse(stream)
            print('python_data', python_data)
            error_type = ''
            json_data = {}
            if python_data and python_data.__contains__('column_name') and python_data.get('column_name') and python_data.__contains__('data_type') and python_data.get('data_type'):
                column_name = python_data['column_name']
                print('column_name', column_name)
                data_type = python_data['data_type']
                df = pd.DataFrame(json_data)
                df = df.fillna('')
                if data_type == 'True / False':
                    is_TrueOrFalse = df[column_name].isin(['True', 'False']).all()
                    print('is_TrueOrFalse', is_TrueOrFalse)
                    if not is_TrueOrFalse:
                        error_type = column_name + ' column contains other values besides True or False !!!'
                        return Response({'status':error_type})
                else:
                    error_type =  'data_type contans null value or contains diffrent datatype !!!'
                    return Response({'status':error_type})
            else:
                error_type =  'python data or column_name or data_type contans null values send both values !!!'
                return Response({'status':error_type})
            return Response({'status':'success'})
        except Exception:
            logger.error("Error in Post Method of True Or False Validation View!!!", exc_info=True)
            response = {
                'status': "Error"
            }
            return Response(response)



@authentication_classes([])
@permission_classes([])
class ChangeDateFormateValidationView(APIView):
    """
        This method is used to change the date one formate to another formate in etl page.
        
    """
    def post(self, request):
        try:
            data1 = request.body
            stream = io.BytesIO(data1)
            python_data = JSONParser().parse(stream)
            print('python_data', python_data)
            error_type = ''
            json_data = {'date': ['2-04-2019', '7-04-2019', '12-05-2019', '2-04-2019', '2-04-2019'],
        'Column2': [1, 2, 3, 4, 5]}
            # json_data = {}
            if python_data and python_data.__contains__('column_name') and python_data.get('column_name') and python_data.__contains__('date_formate') and python_data.get('date_formate'):
                column_name = python_data['column_name']
                print('column_name', column_name)
                date_formate = python_data['date_formate']
                data = pd.DataFrame(json_data)
               
                if json_data:
                    data[column_name] = data[column_name].dt.strftime(date_formate)
                    data = data.to_dict(orient='records')
                    
                    print('df', data)
                else:
                    error_type =  'json_data contains null values !!!'
                    return Response({'status':error_type})
            else:
                error_type =  'python data or column_name or prev value or new value contains null values send all values !!!'
                return Response({'status':error_type})
            return Response({'status':'success', 'data': data})
        except Exception:
            logger.error("Error in Post Method of Change Date Formate Validation View!!!", exc_info=True)
            response = {
                'status': "Error"
            }
            return Response(response) 


@authentication_classes([])
@permission_classes([])
class FieldExtractionView(APIView):
    """
        This method is used to replace the exact value to new value in etl page. 
    """
    def post(self, request):
        try:
            data1 = request.body
            stream = io.BytesIO(data1)
            python_data = JSONParser().parse(stream)
            print('python_data', python_data)
            error_type = ''
            json_data = {'date': ['2-04-2019', '7-04-2019', '12-05-2019', '2-04-2019', '2-04-2019'],
        'Column2': [1, 2, 3, 4, 5]}
            # json_data = {}
            if python_data and python_data.__contains__('column_name') and python_data.get('column_name') and python_data.__contains__('prev_value') and python_data.get('prev_value') and python_data.__contains__('new_value') and python_data.get('new_value'):
                column_name = python_data['column_name']
                print('column_name', column_name)
                prev_value = python_data['prev_value']
                new_value = python_data['new_value']
                data = pd.DataFrame(json_data)
                # data = data.fillna('')df['color'] = df.color.str.replace('e', 'E!')
                if json_data:
                    data[column_name] = data[column_name].str.replace(prev_value,new_value)
                    data = data.to_dict(orient='records')
                    # print('change_date_formate', data[column_name])
                    print('df', data)
                else:
                    error_type =  'json_data contains null values !!!'
                    return Response({'status':error_type})
            else:
                error_type =  'python data or column_name or prev value or new value contains null values send all values !!!'
                return Response({'status':error_type})
            return Response({'status':'success', 'data': data})
        except Exception:
            logger.error("Error in Post Method of Field Extraction View!!!", exc_info=True)
            response = {
                'status': "Error"
            }
            return Response(response) 


@authentication_classes([])
@permission_classes([])
class RoundOffView(APIView):
    """
        This method is used to add the round off to one column in etl page.
        
    """
    def post(self, request):
        try:
            data1 = request.body
            stream = io.BytesIO(data1)
            python_data = JSONParser().parse(stream)
            print('python_data', python_data)
            error_type = ''
            json_data = {'date': ['2-04-2019', '7-04-2019', '12-05-2019', '2-04-2019', '2-04-2019'],
        'Column2': [1, 2, 3, 4, 5],'Column3': [1, 2, 3, 4, 5], 'Column4': [1, 2, 3, 4, 5], 'Column5': [1, 2, 3, 4, 5]
        }
            # json_data = {}
            if python_data and python_data.__contains__('column_name') and python_data.get('column_name') and python_data.__contains__('prev_value') and python_data.get('prev_value') and python_data.__contains__('new_value') and python_data.get('new_value'):
                column_name = python_data['column_name']
                print('column_name', column_name)
                prev_value = python_data['prev_value']
                new_value = python_data['new_value']
                data = pd.DataFrame(json_data)
                temp_cols=data.columns.tolist()
                print('temp_cols', temp_cols)
                element = temp_cols.pop(prev_value)
                print('element', element)
                temp_cols.insert(new_value, element)
                print('temp_cols',temp_cols)
                # data = data.fillna('')df['color'] = df.color.str.replace('e', 'E!')
                if json_data:
                    data[column_name] = data[column_name].round(decimals = new_value)
                    data = data.to_dict(orient='records')
                    # print('change_date_formate', data[column_name])
                    print('df', data)
                else:
                    error_type =  'json_data contains null values !!!'
                    return Response({'status':error_type})
            else:
                error_type =  'python data or column_name or prev value or new value contains null values send all values !!!'
                return Response({'status':error_type})
            return Response({'status':'success', 'data': data})
        except Exception:
            logger.error("Error in Post Method of Round Off View!!!", exc_info=True)
            response = {
                'status': "Error"
            }
            return Response(response)


@authentication_classes([])
@permission_classes([])
class ChangePositionsView(APIView):
    """
        This method is used to change the positions of a columns in etl page.
        
    """
    def post(self, request):
        try:
            data1 = request.body
            stream = io.BytesIO(data1)
            python_data = JSONParser().parse(stream)
            print('python_data', python_data)
            error_type = ''
            json_data = {'date': ['2-04-2019', '7-04-2019', '12-05-2019', '2-04-2019', '2-04-2019'],
                'Column2': [1, 2, 3, 4, 5],'Column3': [1, 2, 3, 4, 5], 'Column4': [1, 2, 3, 4, 5], 'Column5': [1, 2, 3, 4, 5]
            }
            # json_data = {}
            if python_data and python_data.__contains__('column_name') and python_data.get('column_name') and python_data.__contains__('prev_value') and python_data.get('prev_value') and python_data.__contains__('new_value') and python_data.get('new_value'):
                column_name = python_data['column_name']
                print('column_name', column_name)
                prev_value = python_data['prev_value']
                new_value = python_data['new_value']
                data = pd.DataFrame(json_data)
                
                # data = data.fillna('')df['color'] = df.color.str.replace('e', 'E!')
                if json_data and len(json_data) >= int(prev_value) and len(json_data)>=int(new_value):
                    new_cols=data.columns.tolist()
                    print('temp_cols', new_cols)
                    element = new_cols.pop(int(prev_value))
                    print('element', element)
                    new_cols.insert(int(new_value), element)
                    print('temp_cols',new_cols)
                    data = data.reindex(columns=new_cols)
                    data = data.to_dict(orient='records')
                    # print('change_date_formate', data[column_name])
                    print('df', data)
                else:
                    error_type =  'json_data contains null values !!!'
                    return Response({'status':error_type})
            else:
                error_type =  'python data or column_name or prev value or new value contains null values send all values !!!'
                return Response({'status':error_type})
            return Response({'status':'success', 'data': data})
        except Exception:
            logger.error("Error in Post Method of Change Positions View!!!", exc_info=True)
            response = {
                'status': "Error"
            }
            return Response(response)


@authentication_classes([])
@permission_classes([])
class ChangeDateFormateView(APIView):
    """
        This method is used to change the date one formate to another formate in etl page.
        
    """
    def post(self, request):
        try:
            data1 = request.body
            stream = io.BytesIO(data1)
            python_data = JSONParser().parse(stream)
            print('python_data', python_data)
            error_type = ''
            json_data = {'date': ['2-04-2019', '7-04-2019', '12-05-2019', '2-04-2019', '2-04-2019'],
        'Column2': [1, 2, 3, 4, 5]}
            # json_data = {}
            if python_data and python_data.__contains__('column_name') and python_data.get('column_name') and python_data.__contains__('prev_date_formate') and python_data.get('prev_date_formate') and python_data.__contains__('new_date_formate') and python_data.get('new_date_formate'):
                column_name = python_data['column_name']
                print('column_name', column_name)
                prev_date_formate = python_data['prev_date_formate']
                new_date_formate = python_data['new_date_formate']
                data = pd.DataFrame(json_data)
               
                if json_data:
                    data[column_name] = data.to_datetime(df[column_name], formate=prev_date_formate)
                    data[column_name] = data[column_name].dt.strftime(new_date_formate)
                    data = data.to_dict(orient='records')
                    
                    print('df', data)
                else:
                    error_type =  'json_data contains null values !!!'
                    return Response({'status':error_type})
            else:
                error_type =  'python data or column_name or prev value or new value contains null values send all values !!!'
                return Response({'status':error_type})
            return Response({'status':'success', 'data': data})
        except Exception:
            logger.error("Error in Post Method of Change Date Formate View!!!", exc_info=True)
            response = {
                'status': "Error"
            }
            return Response(response) 


# @authentication_classes([])
# @permission_classes([])
# class FileValidationView(APIView):
#     def validate(self, json_data=None, id=None):
#         """
#             This method is used to validate json file based on the data type and text field
#         """
#         try:
#             if json_data and id:
                
#                 source = SourceMaster.objects.filter(sourrce_id=id)
#                 qs_json =serializers.serialize('json', source)
#                 data1 = list(eval(qs_json))
#                 res = [ sub['fields'] for sub in data1]
#                 for sub in res:
#                     res1 = sub['actionss']
#                     data = res1
#                     print('res1', res1)
#                 df = pd.DataFrame(json_data)
#                 df = df.fillna('')
#                 for column in data:
#                     column_name = column['text']
#                     data_type = column['data_type']
#                     if data_type == 'integer':
#                         isnumeric = pd.to_numeric(df[column_name], errors='coerce').notnull().all()
#                         if not isnumeric:
#                             error_type = column_name + ' column contains null or string values'
#                             return error_type
#                     elif data_type == 'Decimal':
#                         all_decimals = df[column_name].dtype == 'float64' or df[column_name].dtype == 'float32'
#                         if not isnumeric:
#                             error_type = column_name + ' column not contains decimal values'
#                             return error_type
#                     elif data_type == 'length':
#                         is_len = df[df[column_name].str.len()>=1]
#                         if len(is_len):
#                             error_type = column_name + ' column contains length is more than !!!'
#                             return error_type
#                     elif data_type == 'DateFormate':
#                         is_date = pd.to_datetime(df[column_name]).notnull().all()
#                         print('is_date', is_date)
#                         if not is_date:
#                             error_type = column_name + ' column contains wrong date formate!!!'
#                             return error_type
#                     elif data_type == 'Yes / No':
#                         is_YesOrNo = df[column_name].isin(['Yes', 'No']).all()
#                         print('is_YesOrNo', is_YesOrNo)
#                         if not is_YesOrNo:
#                             error_type = column_name + ' column contains other values besides yes or no !!!'
#                             return error_type
#             else:
#                 error_type =  'json data or id contans null values send both values !!!'
#                 return error_type
#         except Exception:
#             response = {
#                 Status: "Error"
#             }
#             return Response(response)
#         return Response({status:'success'})


# @authentication_classes([])
# @permission_classes([])
# class ValidationView(APIView):
#     def get(self, request):
#         with open('validation.json', 'r', encoding="utf8") as f:
#             data = json.load(f)
#             response = FileValidationView.validate(self, data, 4)
#             print('response', response)
#         return Response(data, status=status.HTTP_200_OK)
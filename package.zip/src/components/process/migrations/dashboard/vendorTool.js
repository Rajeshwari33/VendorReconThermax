import React, {useState} from 'react';
import './vendorTool.css';
import axios from 'axios';
import {invoiceDetailsToServer, detailedInvoiceToServer} from  '../../../../services/process/migrations/migrationService.js';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-balham.css';
// import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell } from 'recharts';
import {
    BarChart,
    Bar,
    XAxis,
    YAxis,
    CartesianGrid,
    Tooltip,
    Legend
  } from "recharts";



function VendorTool({hidden})
{
    const [inputMonth, setInputMonth] = useState(undefined);
    const [vendorDepartmentSelected, setDepartmentSelected] = useState('');
    const [vendorHidden, setvendorHidden] = useState(true);
    const [invoiceGridHidden, setInvoiceGridHidden] = useState(true);
    const [invoiceCount, setInvoiceCount] = useState('');
    const [rowData, setRowData] = useState(undefined);
    const [columnDefs, setColumnData] = useState(undefined);
    const [paginationSize] = useState(15);
    const PieColors = ["#bce893", "#44a7e1", "#556cfb", "#f4b040"];



    console.log("vinputMonth", inputMonth);
    console.log("vendorDepartmentSelected", vendorDepartmentSelected);


    function getSetInputMonth(data){
        setInputMonth(data);
        console.log(data);
    }

    function monthWisevendor()
    {
        let payload = {
            month: inputMonth,
            department:vendorDepartmentSelected,
            name: "Invoice Details"
        }

        var invoiceCount = invoiceDetailsToServer();
        console.log("sever", invoiceCount);

        axios.post(invoiceCount[1], payload, invoiceCount[0])
        .then(
            response => {
                console.log("Getting Invoice Details!!!", response);
                let responseData = response["data"]; 

                console.log("responseData", responseData);
                if (responseData["Status"] === "Success")
                {
                    let invoiceDetails = responseData["invoiceCount"];
                    // let approvedDetails = responseData["approvedInvoiceCount"];
                    // let paidDetails = responseData["paidInvoiceCount"];
                    // let percentage = responseData["alcsMailsPercentage"]
                    // console.log("approvedDetails", approvedDetails["data"]);
                    // console.log("paidDetails", paidDetails["data"]);
                    // console.log("percentage", percentage);
                    // let utrPendingDetails = responseData["utrPendingReports"];
                   
                    setInvoiceCount(invoiceDetails["data"]);
                    // setutrPendingReport(utrPendingDetails["data"]);
                    // setMailsCount(utrDetails["data"]);
                    // setMailPercent(percentage["data"]);
                    // if (utrTypeSelected === "ALCS Mails Sent To Clients"){
                    //     setUtrHidden(false);
                    //     setPerHidden(true);
                    // }
                    // else if (utrTypeSelected === "ALCS Mails Sent To Clients Percentage"){
                    //     console.log("hiiii")
                    //     setUtrHidden(true);
                    //     setPerHidden(false);
                    // }
                    
                    setvendorHidden(false);
                    setInvoiceGridHidden(true);
                

                }
            }
            
        ).catch(
            error => {
                console.log("Error", error);
                alert("Error in Getting VENDOR Details!!!");
            }
        );
    };

    console.log("invoiceCount", invoiceCount);

    function barChartOnClick(e){
        const status = e.status
        let payload = {
            month: inputMonth,
            department:vendorDepartmentSelected,
            name: "Invoice Details",
            status: status
        }

        var detaildInvoce = detailedInvoiceToServer();
        console.log("brsCredentials", detaildInvoce);

        axios.post(detaildInvoce[1], payload, detaildInvoce[0])
        .then(
            response => {
                console.log("Getting Approved ALCS Details!!!", response);
                let responseData = response["data"]; 
                console.log("responseData", responseData);
                if (responseData["Status"] === "Success")
                {
                    let detailedInvoice = responseData["invoiceDetails"];
                    // let brsDetails = responseData["brsCount"]; 
                    
                    // sessionStorage.setItem("userCredentials", JSON.stringify(userCredentials));
                    // navigate(userCredentials["config"]["default_page"]);
                    console.log("detailedInvoice", detailedInvoice);
                    // setRowData(alcsDetails["data"]);
                    // setAlcsDetailsChartHidden(false);
                    // setApproverName(approverDetails["data"][0]["approved_by"]);
                    // setApprovedOn(approverDetails["data"][0]["approved_date"]);
                    // if (approverDetails["data"].length > 0){
                    //     setApproverHidden(false);
                    // }
                    // else{
                    //     setApproverHidden(true);
                    // }
                        
                    // getBankList();
                    setRowData(detailedInvoice["data"]);
                    setColumnData(detailedInvoice["headers"]);
                    setInvoiceGridHidden(false);
                }
            }
        ).catch(
            error => {
                console.log("Error", error);
                alert("Error in Getting Invoice Details!!!");
            }
        );
    };

    return (
        <>
            <div hidden={hidden}>
                <div className="vendorchartbox1">
                    <div className="vendorchart-box-layer">
                        <table style={{width:"60%",marginTop:"-8px"}}>
                        
                            <tbody>
                                <tr>
                                    <td className="utraddcontracttext">Month</td>
                                    <td>:</td>
                                    <td><input type="month" name="" onChange={(e) => {setInputMonth(e.target.value)}}/></td>
                                
                                    <td className="utraddcontracttext">Department</td>
                                    <td>:</td>
                                    <td>
                                        <select style={{padding:"4px 16px"}}
                                        onChange={(e) => {setDepartmentSelected(e.target.value)}}>
                                            <option>Select Type:</option>
                                            <option value="ADMIN">ADMIN</option>
                                            <option value="SBI">SBI</option>
                                            <option value="ILS">ILS</option>
                                            <option value="CORPORATE">CORPORATE</option>
                                            <option value="STAFFING">STAFFING</option>
                                            <option value="INFRA">INFRA</option>
                                            <option value="STAFF-INF">STAFF-INF</option>
                                        </select>
                                    </td>
                                    
                                    <td><button style={{textAlign: "center",  border: ".1px solid #000055", color: "#ffffff", padding:"4px 16px", borderRadius: "15px", backgroundColor: "#024f9d"}} onClick={monthWisevendor}>
                                        Search
                                    </button>&nbsp;</td>
                                </tr>
                                
                            </tbody>
                        
                        </table>
                    </div>
                </div>
                <div className="vendorchartbox">
                    <div className='vendorrecentOrders' hidden = {vendorHidden}>
                        {/* <div className='vendorlayer'>
                            hh
                        </div> */}
                        <div className='vendorlayer'>
                            {/* <ResponsiveContainer width="10%" aspect={3}> */}
                               
                                <div className="popup-link">
                                    <a href="#popup2">
                                    <BarChart width={550} height={450} layout="vertical" data={invoiceCount} margin={{left:10,right:40,top:40}}>
                                    <Bar dataKey="invoice_count" fill="#44a7e1" barSize={45}  onClick={barChartOnClick}>
                                    {/* {invoiceCount.map((entry, index) => (
                                        <Cell key={`cell-${index}`} fill={PieColors[index]} />
                                        ))} */}
                                    </Bar>
                                    <Tooltip cursor={false} />
                                    <Legend />
                                    {/* <CartesianGrid stroke="#ccc" /> */}
                                    <XAxis type="number" />
                                    <YAxis type="category" dataKey="status"/>
                                   
                                </BarChart>
                                    </a>
                                </div>
                            {/* </ResponsiveContainer> */}
                            {/* <PieChart width={750} height={350} style={{marginLeft:"159px", padding:"1%", textAlign: "center"}} >
                                <Pie data={invoiceCount} dataKey="invoice_count" nameKey="status" cx="50%"
                                cy="50%"
                                innerRadius={60}
                                outerRadius={200}
                                paddingAngle={5}
                                fill="#82ca9d">
                                    {invoiceCount.map((entry, index) => (
                                    <Cell key={`cell-${index}`} fill={PieColors[index]} />
                                    ))}
                                </Pie>
                                <Tooltip content={<this.CustomTooltip />} />
                                <Legend />
                            <XAxis dataKey="status" />
                            <YAxis dataKey="invoice_count"/>
                            onClick={barChartOnClick}
                            </PieChart>  */}
                        </div>

                        
                    </div>
                    
                        <div id="popup2" className="popup-container popup-style-2">
                            <div className="popup-content">
                                <a href="#" className="close">&times;</a>
                                <div className="ag-theme-balham vendorDetails" hidden = {invoiceGridHidden}>
                                    <AgGridReact
                                        columnDefs = {columnDefs}
                                        rowData = {rowData}
                                        paginationPageSize = {paginationSize}
                                        pagination = {true}
                                        animateRows = {true}
                                        isSearchable={true}
                                        style = {{width:"10%"}}
                                    ></AgGridReact>
                                </div>
                            </div>
                        </div>
                    {/* <div className='perRecentOrders' hidden = {perHidden}>
                        <LineChart width={750} height={350} data={mailsPercent} style={{marginLeft:"159px", padding:"1%", textAlign: "center"}} >
                            <Line dataKey="percentage" fill="grey" barSize={85}/>
                            <XAxis dataKey="date" />
                            <YAxis dataKey="percentage"/>
                        </LineChart>
                    </div> */}
                </div>
            </div>
        </>
    );
}

export default  VendorTool;
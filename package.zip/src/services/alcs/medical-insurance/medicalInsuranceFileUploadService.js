import { headers, baseUrl } from "../../common/credentials";

const port = "8002";

export const getFileUploadListFromServerNew = () => {
    let url = baseUrl + port + "/api/v2/medical_insurance/generic/file_uploads_new/";
    return ([headers, url]);
}

export const getFileList = () => {
    let url = baseUrl + port + "/api/v2/medical_insurance/file_type_list/";
    return ([headers, url]);
}
import { headers, baseUrl } from '../../common/credentials.js';

const port = "7000";

export const monthWiseBrsToServer = () => {
    let url = baseUrl + port + "/kpi/month_wise_brs/";
    return ([headers, url]);
}

export const approvedBrsToServer = () => {
    let url = baseUrl + port + "/kpi/approved_brs/";
    return ([headers, url]);
}


export const monthWiseGstToServer = () => {
    let url = baseUrl + port + "/kpi/gst_processed_reports/";
    return ([headers, url]);
}
export const monthWiseUtrToServer = () => {
    let url = baseUrl + port + "/kpi/alcs_client_mails/";
    return ([headers, url]);
}

export const alcsDetailsToServer = () => {
    let url = baseUrl + port + "/kpi/alcs_client_mails_details/";
    return ([headers, url]);
}

export const invoiceDetailsToServer = () => {
    let url = baseUrl + port + "/kpi/invoice_view/";
    return ([headers, url]);
}

export const detailedInvoiceToServer = () => {
    let url = baseUrl + port + "/kpi/invoice_details/";
    return ([headers, url]);
}

export const tsDateToServer = () => {
    let url = baseUrl + port + "/kpi/tds_uploaded_date/";
    return ([headers, url]);
}
// App.js
import { useEffect, useState } from "react";
// import "./App.css";
import "./etlsecound.css";
import hdfcs from './../../../assets/images/banks/thermax.png';


function Details() 
{
  

  return (
  <div>
    <table className="table">
    <tr>
        <td className="fontcolor"><img src={hdfcs} alt="" height="70px" width="90px" />THERMAX LIMITED </td>
       
    </tr>
   <br></br>
   <br></br>
    <tr>
        <td>VENDOR CODE</td>
        <td>146491</td>
        
    </tr>
    <tr className="bold">
        <td>THERMAX VENDOR NAME</td>
        <td>SAGARBHANGA FOUNDRY AND ENGINEERING</td>
       
    </tr>
    <tr>
        <td>RECON DATE</td>
        <td>2023-02-10 17:19:42.831549</td>
       
    </tr>
    <tr>
        <td>RECON DONE TILL</td>
        <td>2022-03-31</td>
       
    </tr>
    <tr>
        <td>VEDNOR CLOSING BAL</td>
        <td> 2,837,666.84 </td>
       
    </tr>
    <tr>
        <td>THERMAX CLOSING BAL</td>
        <td> 7,430,290.52</td>
    </tr>
</table>
  </div>
  )
}



export default Details;
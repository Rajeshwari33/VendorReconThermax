// import React from "react";
import React,{useEffect, useState} from 'react';


import "./etl.css";
import { Accordion } from "https://cdn.skypack.dev/semantic-ui-react@2.1.4";
import { Icon, Input, Button,Dropdown, Grid, Popup,Segment,Select,Tab,Table,Menu , Form, TextArea, Label} from 'semantic-ui-react'
import Home from './home';
import Details from './detail';
import VRS from './vrs';
import VendorDr from './vendorcrdr';
import ThermaxDr from './tharmaxdr';
import VendorStatement from './vendorStatement';
import ThermaxStatement from './tharmaxStatemen';


// temp
const TableExampleStructured = () => (
    <Table celled structured>
      <Table.Header>
        <Table.Row>
          <Table.HeaderCell >ORGANIZATION</Table.HeaderCell>
          <Table.HeaderCell >THERMAX LIMITED</Table.HeaderCell>
          
        </Table.Row>
        <Table.Row>
        <Table.HeaderCell >REPORT GENERATION DATE</Table.HeaderCell>
          <Table.HeaderCell >2023-02-10 17:19:42.831549</Table.HeaderCell>
        </Table.Row>
      </Table.Header>
      <Table.Body>
        <Table.Row>
          <Table.Cell>VEDNOR NAME</Table.Cell>
          <Table.Cell>SAGARBHANGA FOUNDRY AND ENGINEERING</Table.Cell>
        </Table.Row>
        <Table.Row>
          <Table.Cell>REPORT FROM DATE</Table.Cell>
          <Table.Cell>2021-04-01</Table.Cell>
        </Table.Row>
        <Table.Row>
          <Table.Cell>REPORT TO DATE</Table.Cell>
          <Table.Cell>2022-03-31</Table.Cell>
        </Table.Row>
        <Table.Row>
          <Table.Cell>VENDOR CODE</Table.Cell>
          <Table.Cell>146491</Table.Cell>
        </Table.Row>
        <Table.Row>
          <Table.Cell>VENDOR SITE CODE</Table.Cell>
          <Table.Cell>DURGAPUR</Table.Cell>
        </Table.Row>
        <Table.Row>
          <Table.Cell>VENDOR CATEGORY</Table.Cell>
          <Table.Cell>E&C</Table.Cell>
        </Table.Row>
         <Table.Row>
          <Table.Cell>LIABILITY ACCOUNT</Table.Cell>
          <Table.Cell>08-103000-3005-20321-110001-000000-000000</Table.Cell>
        </Table.Row>
        <Table.Row>
          <Table.Cell>DIVISION</Table.Cell>
          <Table.Cell>Power</Table.Cell>
        </Table.Row>
        <Table.Row>
          <Table.Cell>PAN NUMBER</Table.Cell>
          <Table.Cell>ALSPK3740Q</Table.Cell>
        </Table.Row>
        <Table.Row>
          <Table.Cell>GST NUMBER</Table.Cell>
          <Table.Cell>19ALSPK3740Q1Z7</Table.Cell>
        </Table.Row>
      </Table.Body>
      
    </Table>
    
  )

  
// temp
const TableExampleStructured2 = () => (
  <Table celled structured>
    <Table.Header>
      <Table.Row>
        {/* <Table.HeaderCell ></Table.HeaderCell> */}
        <Table.HeaderCell >THERMAX LIMITED</Table.HeaderCell>
        <Table.HeaderCell ></Table.HeaderCell>

        
      </Table.Row>
      
    </Table.Header>
    <Table.Body>
    <Table.Row>
      <Table.Cell >VENDOR CODE</Table.Cell>
        <Table.Cell >2023-02-10 17:19:42.831549</Table.Cell>
      </Table.Row>
      <Table.Row>
        <Table.Cell>THERMAX VENDOR NAME</Table.Cell>
        <Table.Cell>SAGARBHANGA FOUNDRY AND ENGINEERING</Table.Cell>
      </Table.Row>
      <Table.Row>
        <Table.Cell>RECON DATE</Table.Cell>
        <Table.Cell>2021-04-01</Table.Cell>
      </Table.Row>
      <Table.Row>
        <Table.Cell>RECON DONE TILL</Table.Cell>
        <Table.Cell>2022-03-31</Table.Cell>
      </Table.Row>
      <Table.Row>
        <Table.Cell>VEDNOR CLOSING BAL</Table.Cell>
        <Table.Cell>146491</Table.Cell>
      </Table.Row>
      <Table.Row>
        <Table.Cell>THERMAX CLOSING BAL</Table.Cell>
        <Table.Cell>DURGAPUR</Table.Cell>
      </Table.Row>
     
    </Table.Body>
    
  </Table>
  
)



  const TableExampleError = () => (
    <Table celled>
      <Table.Header>
        <Table.Row>
          <Table.HeaderCell>Name</Table.HeaderCell>
          <Table.HeaderCell>Status</Table.HeaderCell>
          <Table.HeaderCell>Notes</Table.HeaderCell>
        </Table.Row>
      </Table.Header>
  
      <Table.Body>
        <Table.Row>
          <Table.Cell>No Name Specified</Table.Cell>
          <Table.Cell>Approved</Table.Cell>
          <Table.Cell>None</Table.Cell>
        </Table.Row>
        <Table.Row error>
          <Table.Cell>Jimmy</Table.Cell>
          <Table.Cell>Cannot pull data</Table.Cell>
          <Table.Cell>None</Table.Cell>
        </Table.Row>
        <Table.Row>
          <Table.Cell>Jamie</Table.Cell>
          <Table.Cell>Approved</Table.Cell>
          <Table.Cell error>
            <Icon name='attention' />
            Classified
          </Table.Cell>
        </Table.Row>
        <Table.Row>
          <Table.Cell>Jill</Table.Cell>
          <Table.Cell>Approved</Table.Cell>
          <Table.Cell>None</Table.Cell>
        </Table.Row>
      </Table.Body>
    </Table>
  )
  
// end tem

const options = [
    { key: 1, text: 'Excel', value: 1 },
    { key: 2, text: 'CSV', value: 2 },
    { key: 3, text: 'Text', value: 3 },
    { key: 4, text: 'Staging DB', value: 4 },

  ]
  const options2 = [
    { key: 1, text: 'Is Null', value: 1 },
    { key: 2, text: 'Yes or NO', value: 2 },
    { key: 3, text: 'Data Formate', value: 3 },
    { key: 4, text: 'Leangth', value: 4 },

  ]
  const optionsclick=[
    {key:1,text:'Fill character' , value:1},
    {key:2,text:'Change date formate' , value:2},
    {key:3,text:'Add decimals' , value:3},
    {key:4,text:'Remove decimal' , value:4},
    {key:5,text:'Round of' , value:5},
    {key:6,text:'Clear Values' , value:6},
    {key:7,text:'Filed Extraction', value:7},


  ]
  const DropdownExampleUpwardSelection = () => (
    <Dropdown
      upward
      search
      selection
      options={optionsclick}
      placeholder='Choose an option'
    />
  )
  const DropdownExampleClearable = () => (
    <Dropdown clearable options={options} selection placeholder='Choose an option' size='mini' />
  )
  const DropdownExampleClearableValitation = () => (
    <Menu compact>
    <Dropdown size='mini' text='Dropdown' options={options2} simple item />
  </Menu>
  )
  const DropdownExampleClearableValitationClick = () => (
    <Menu compact>
    <Dropdown size='mini' text='Dropdown' options={optionsclick} simple item />
  </Menu>
  )

  const InputExampleIconPosition = (Props) => (
    <Input  placeholder={Props.name} size='mini' />
  )
  const InputExampleIconPosition5 = () => (
    <Input icon='folder open outline' iconPosition='left' placeholder='Enter Source Name' />
  )
  const InputDate = (props) => (
    <Input icon={props.icons} iconPosition='left' placeholder='No Of Sheets' type='date'  />
  )
  const InputDateTo = (props) => (
    <Input icon={props.icons} iconPosition='left' placeholder='No Of Sheets' type='date' />
  )
 
  const ButtonExampleSocial = () => (
    <div>
      <Button color='blue'>
        <Icon name='filter' className="button radius"/> Generate VRS
      </Button>
    </div>
  )

  const TableExampleBasic = () => (
    <Table basic>
      <Table.Header>
        <Table.Row>
          <Table.HeaderCell>S.No</Table.HeaderCell>
          <Table.HeaderCell>Column Name</Table.HeaderCell>
          <Table.HeaderCell>Data type</Table.HeaderCell>
          <Table.HeaderCell>Property</Table.HeaderCell>
          <Table.HeaderCell>Validation</Table.HeaderCell>
          <Table.HeaderCell>Tranform 1</Table.HeaderCell>
          <Table.HeaderCell>Look Up</Table.HeaderCell>
          <Table.HeaderCell>Math</Table.HeaderCell>
          <Table.HeaderCell>Comments</Table.HeaderCell>
        </Table.Row>
      </Table.Header>
  
      <Table.Body>
        <Table.Row>
          <Table.Cell>1</Table.Cell>
          <Table.Cell><InputExampleIconPosition name="Coloumn name"/></Table.Cell>
          <Table.Cell><InputExampleIconPosition name="Data Type"/></Table.Cell>
          <Table.Cell><InputExampleIconPosition name="Property"/></Table.Cell>
          <Table.Cell>< DropdownExampleClearableValitation/></Table.Cell>
          <Table.Cell><DropdownExampleClearableValitationClick/></Table.Cell>
          <Table.Cell><DropdownExampleClearableValitationClick/></Table.Cell>
          <Table.Cell><DropdownExampleClearableValitationClick/></Table.Cell>
          <Table.Cell><InputExampleIconPosition/></Table.Cell>
        </Table.Row>
        <Table.Row>
        <Table.Cell>1</Table.Cell>
          <Table.Cell><InputExampleIconPosition name="Coloumn name"/></Table.Cell>
          <Table.Cell><InputExampleIconPosition name="Data Type"/></Table.Cell>
          <Table.Cell><InputExampleIconPosition name="Property"/></Table.Cell>
          <Table.Cell>< DropdownExampleClearableValitation/></Table.Cell>
          <Table.Cell><DropdownExampleClearableValitationClick/></Table.Cell>
          <Table.Cell><DropdownExampleClearableValitationClick/></Table.Cell>
          <Table.Cell><DropdownExampleClearableValitationClick/></Table.Cell>
          <Table.Cell><InputExampleIconPosition/></Table.Cell>
        </Table.Row>
        <Table.Row>
        <Table.Cell>1</Table.Cell>
          <Table.Cell><InputExampleIconPosition name="Coloumn name"/></Table.Cell>
          <Table.Cell><InputExampleIconPosition name="Data Type"/></Table.Cell>
          <Table.Cell><InputExampleIconPosition name="Property"/></Table.Cell>
          <Table.Cell>< DropdownExampleClearableValitation/></Table.Cell>
          <Table.Cell><DropdownExampleClearableValitationClick/></Table.Cell>
          <Table.Cell><DropdownExampleClearableValitationClick/></Table.Cell>
          <Table.Cell><DropdownExampleClearableValitationClick/></Table.Cell>
          <Table.Cell><InputExampleIconPosition/></Table.Cell>
        </Table.Row>
        <Table.Row>
        <Table.Cell>1</Table.Cell>
          <Table.Cell><InputExampleIconPosition name="Coloumn name"/></Table.Cell>
          <Table.Cell><InputExampleIconPosition name="Data Type"/></Table.Cell>
          <Table.Cell><InputExampleIconPosition name="Property"/></Table.Cell>
          <Table.Cell>< DropdownExampleClearableValitation/></Table.Cell>
          <Table.Cell><DropdownExampleClearableValitationClick/></Table.Cell>
          <Table.Cell><DropdownExampleClearableValitationClick/></Table.Cell>
          <Table.Cell><DropdownExampleClearableValitationClick/></Table.Cell>
          <Table.Cell><InputExampleIconPosition/></Table.Cell>
        </Table.Row>
        
      </Table.Body>
    </Table>
  )
  
  const panes = [
    {
      menuItem: { key: 'users', icon: 'file alternate outline', content: 'Home' },
      render: () => <Tab.Pane><Home/></Tab.Pane>,
    },
    {
        menuItem: { key: 'users', icon: 'file alternate outline', content: 'Details' },
        render: () => <Tab.Pane><Details/></Tab.Pane>,
      },
      {
        menuItem: { key: 'users', icon: 'file alternate outline', content: 'VRS' },
        render: () => <Tab.Pane><VRS/></Tab.Pane>,
      },
      {
        menuItem: { key: 'users', icon: 'file alternate outline', content: 'Vendor DR_CR' },
        render: () => <Tab.Pane><VendorDr/></Tab.Pane>,
      },
      {
        menuItem: { key: 'users', icon: 'file alternate outline', content: 'Thermax DR_CR' },
        render: () => <Tab.Pane><ThermaxDr/></Tab.Pane>,
      },
      {
        menuItem: { key: 'users', icon: 'file alternate outline', content: 'Vendor Statement' },
        render: () => <Tab.Pane><VendorStatement/></Tab.Pane>,
      },
      {
        menuItem: { key: 'users', icon: 'file alternate outline', content: 'Thermax Statement' },
        render: () => <Tab.Pane><ThermaxStatement/></Tab.Pane>,
      },
    // {
    //   menuItem: (
    //     <Menu.Item key='messages'>
    //       Sheet 2<Label>15</Label>
    //     </Menu.Item>
    //   ),
    //   render: () => <Tab.Pane>Tab 2 Content</Tab.Pane>,
    // },
  ]
  
  const TabExampleCustomMenuItem = () => <Tab panes={panes} />
  const Selecte = [
    { key: 1, text: 'BRS 00682', value: 1 },
    { key: 2, text: 'BRS 006810', value: 2 },
    { key: 3, text: 'VRS 0068', value: 3 },
    { key: 4, text: 'BRS 00682', value: 4 },

  ]
  const TypeSelecte = () => (
    <Dropdown clearable options={Selecte} selection placeholder='Choose an option' size='mini' />
  )

class Report extends React.Component {
  render() {
    return (
      <div>
       {/* <h1>hi</h1> */}
       <div className="side" style={{ padding:"10px"}}>
       <Grid columns='equal'>
            <Grid.Row style={{ backgroundColor:"#e9e8d9",borderRadius:"12px"}}>
                <Grid.Column width={3}>
                    <TypeSelecte />
                </Grid.Column>
                <Grid.Column width={2}>
                    <InputDate icons="angle double left" />
                </Grid.Column>
                <Grid.Column width={2}>
                   
                    <InputDateTo icons="angle double right" />
                </Grid.Column>
                
                <Grid.Column width={4}>
                   
                    <ButtonExampleSocial/>
                </Grid.Column>
           </Grid.Row>
          
            <Grid.Row style={{ backgroundColor:"#e9e8d9",borderRadius:"12px",marginTop:"10px"}}>
            <Grid.Column >
                <TabExampleCustomMenuItem/>
            </Grid.Column>
            </Grid.Row> 
        </Grid>


       </div>
      </div>
    );
  }
}

export default Report;

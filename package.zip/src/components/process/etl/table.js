// App.js
import { useEffect, useState } from "react";
// import "./App.css";

function Table() 
{
  var json = [
    {
      "key1": "value1",
      
  "Home": [
    {
      "__EMPTY": "ORGANIZATION",
      "__EMPTY_1": "THERMAX LIMITED"
    },
    {
      "__EMPTY": "REPORT GENERATION DATE",
      "__EMPTY_1": "2023-02-10 17:19:42.831549"
    },
    {
      "__EMPTY": "VEDNOR NAME",
      "__EMPTY_1": "SAGARBHANGA FOUNDRY AND ENGINEERING"
    },
    {
      "__EMPTY": "REPORT FROM DATE",
      "__EMPTY_1": "2021-04-01"
    },
    {
      "__EMPTY": "REPORT TO DATE",
      "__EMPTY_1": "2022-03-31"
    },
    {
      "__EMPTY": "VENDOR CODE",
      "__EMPTY_1": "146491"
    },
    {
      "__EMPTY": "VENDOR SITE CODE",
      "__EMPTY_1": "DURGAPUR"
    },
    {
      "__EMPTY": "VENDOR CATEGORY",
      "__EMPTY_1": "E&C"
    },
    {
      "__EMPTY": "LIABILITY ACCOUNT",
      "__EMPTY_1": "08-103000-3005-20321-110001-000000-000000"
    },
    {
      "__EMPTY": "DIVISION",
      "__EMPTY_1": "Power"
    },
    {
      "__EMPTY": "PAN NUMBER",
      "__EMPTY_1": "ALSPK3740Q"
    },
    {
      "__EMPTY": "GST NUMBER",
      "__EMPTY_1": "19ALSPK3740Q1Z7"
    }
  
  ]
}
  ];


  return <table>
  <tbody>
  <tr>
    <td>HI</td>
    {json[0].tests.map(test => <td>{test.__EMPTY}</td> )}
    {json[0].tests.map(test =>  <td>{test.__EMPTY_1}</td>)}
  </tr>
  {/* {
    ["A", "B", "C"].map(test =>
      <tr>
        <td>{test}</td>
        {
          json[0].tests.map(({results}) => 
            results.filter(result => result.name === test)
              .map(testname => <td>{testname.result}</td>))
        }
      </tr>
    )
  } */}
  </tbody>
</table>
}



export default Table;
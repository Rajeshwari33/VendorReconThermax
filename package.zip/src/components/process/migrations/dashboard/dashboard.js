import React, {useState} from 'react';
import './dashboard.css';
import Carousel from 'react-elastic-carousel'; 
import Card from './card.js';
import brs from '../../../../assets/images/processicon/brs.svg';
import consolidation from '../../../../assets/images/processicon/gst.svg';
import medical_ins from '../../../../assets/images/processicon/medical.svg';
import vendor from '../../../../assets/images/processicon/vendor.svg';
import utrmail from '../../../../assets/images/processicon/mail.svg';
import ver from '../../../../assets/images/processicon/cert.svg';
import as from '../../../../assets/images/processicon/as.svg';



// import processImage from '../../../../assets/images/process.svg';


import BRS from './brs';
import GST from './gst';
import UTRMailer from './utrMailer';
import VendorTool from './vendorTool';
import TwentySixASRecon from './twentySixasRecon'
import Insurance from './insurance';
import ComplainceRegister from './complainceRegister';

export default function DashBoard()
{

    const [hideBrsContent, setHideBrsContent] = useState(false);
    const [hideGstContent, setHideGstContent] = useState(true);
    const [hideUtrMailerContent,setHideUtrMailerContent] = useState(true);
    const [hideTwentySixASReconContent, setHideTwentySixASReconContent] = useState(true);
    const [hideVendorToolContent,setHideVendarToolContent] = useState(true);
    const [hideInsuraceContent,setHideInsuranceContent] = useState(true);
    const [hideComplainceRegisterContent,setHideComplainceRegisterContent] = useState(true);

    const breakPoints = [
        {width: 1, itemsToShow: 6},
        
    ];

    const clickedValue = value => {
        // console.log(value);
        if (value === "BRS")
        {
            setHideBrsContent(false);
            setHideGstContent(true);
            setHideUtrMailerContent(true);
            setHideVendarToolContent(true);
            setHideTwentySixASReconContent(true);
        }
        else if (value === "Sales")
        {
            console.log('inside sales');
            setHideBrsContent(true);
            setHideGstContent(false);
            setHideUtrMailerContent(true);
            setHideVendarToolContent(true);
            setHideTwentySixASReconContent(true);
        }
        else if (value === "Invoice")
        {
            setHideUtrMailerContent(false);
            setHideBrsContent(true);
            setHideGstContent(true);
            setHideVendarToolContent(true);
            setHideTwentySixASReconContent(true);
         }
        else if (value === "Ageing") 
        {
            setHideTwentySixASReconContent(false);
            setHideVendarToolContent(true);
            setHideUtrMailerContent(true);
            setHideBrsContent(true);
            setHideGstContent(true);
        }
        else if (value === "P2P")
        {
            setHideVendarToolContent(false);
            setHideUtrMailerContent(true);
            setHideBrsContent(true);
            setHideGstContent(true);
            setHideTwentySixASReconContent(true);
        }
        else if (value === "Insurance")
        {
            setHideInsuranceContent(false);
            setHideVendarToolContent(true);
            setHideUtrMailerContent(true);
            setHideBrsContent(true);
            setHideGstContent(true);
            setHideTwentySixASReconContent(true);

        }
        else if (value === "Complaince register")
        {
            setHideComplainceRegisterContent(false);
            setHideInsuranceContent(true);
            setHideVendarToolContent(true);
            setHideUtrMailerContent(true);
            setHideBrsContent(true);
            setHideGstContent(true);
            setHideTwentySixASReconContent(true);
        }
        else
        {
            setHideBrsContent(true);
            setHideGstContent(true);
            setHideUtrMailerContent(true);
            setHideTwentySixASReconContent(true);
            setHideVendarToolContent(true);
            setHideInsuranceContent(true);
            setHideComplainceRegisterContent(true);


        }
    }


    return (
        <div className="dash">
        <div className='DashBoard'>

            <Carousel breakPoints={breakPoints}>
                {/* <Card className="img" name="BRS" image={brs} clickedValue={clickedValue} /> */}
                <Card name="Sales" className="img" image={consolidation} clickedValue={clickedValue} />
                <Card name="Invoice" className="img" image={utrmail} clickedValue={clickedValue} />
                <Card name="Ageing" className="img" image={as} clickedValue={clickedValue} />
                {/* <Card name="P2P" className="img" image={vendor} clickedValue={clickedValue} />
                <Card name="Insurance" className="img" image={medical_ins} clickedValue={clickedValue} />
                <Card name="Complaince register" className="img" image={ver} clickedValue={clickedValue} /> */}
            </Carousel>

            <div>
                <BRS hidden={hideBrsContent} />
                <GST hidden={hideGstContent} />
                <UTRMailer hidden={hideUtrMailerContent} />
                <TwentySixASRecon hidden={hideTwentySixASReconContent} />
                <VendorTool hidden={hideVendorToolContent} />
                <Insurance hidden={hideInsuraceContent} />
                <ComplainceRegister hidden={hideComplainceRegisterContent} /> 
            </div>

        </div>
        </div>
        
    );
}
from django.contrib.auth import authenticate
from rest_framework import generics, status, viewsets
from rest_framework.response import Response
from rest_framework.decorators import authentication_classes, permission_classes
from .serializers import *
import logging, json, requests
from .models import *
from .packages import data_request as dr
import pandas as pd
import io
import os
from zipfile import ZipFile
import openpyxl
from openpyxl import Workbook
from .tasks import test_func, process_excel_file, process_excel_sheet
import json
import re
from rest_framework import status
from rest_framework.views import APIView
from celery.result import AsyncResult
import pandas as pd
import numpy as np
from rest_framework.parsers import JSONParser
from django.core import serializers
import csv
import pyxlsb
from django.core.files.storage import FileSystemStorage
from celery.result import AsyncResult
from celery import group

# Create your views here.

logger = logging.getLogger("user_modules")

class ModuleSettingsViewSet(viewsets.ModelViewSet):
    queryset = ModuleSettings.objects.all()
    serializer_class = ModuleSettingsSerializer


class TenantsView(generics.GenericAPIView):

    serializer_class = TenantsSerializer

    def post(self, request):
        serializer = self.serializer_class(data = request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)

    def get(self, request):
        active = 0
        is_active = request.data.get("is_active", None)
        tenants_id = request.data.get('tenants_id', None)

        if is_active == "true":
            active = 1

        if tenants_id:
            tenants = Tenants.objects.filter(tenants_id = tenants_id)
        else:
            tenants = Tenants.objects.filter(is_active=active)

        serializer = self.serializer_class(instance=tenants, many=True)

        response_data = {
            "Status": "Success",
            "data": serializer.data
        }

        return Response(response_data, status=status.HTTP_200_OK)

    def put(self):
        pass

    def patch(self):
        pass

    def delete(self):
        pass

class GroupsView(generics.GenericAPIView):

    serializer_class = GroupsSerializer

    def post(self, request):
        serializer = self.serializer_class(data = request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)

    def get(self, request):
        active = 0

        is_active = request.data.get("is_active", None)
        tenants_id = request.data.get("tenants_id", None)
        groups_id = request.data.get("groups_id", None)

        if is_active == "true":
            active = 1

        if tenants_id and groups_id:
            groups = Groups.objects.filter(tenants_id = tenants_id, groups_id = groups_id)
        elif tenants_id and is_active:
            groups = Groups.objects.filter(tenants_id=tenants_id, is_active = active)
        elif tenants_id:
            groups = Groups.objects.filter(tenants_id=tenants_id)
        else:
            groups = Groups.objects.filter(is_active = active)

        serializer = self.serializer_class(instance=groups, many=True)

        response_data = {
            "Status": "Success",
            "data": serializer.data
        }

        return Response(response_data, status=status.HTTP_200_OK)

    def put(self):
        pass

    def patch(self):
        pass

    def delete(self):
        pass

class EntitiesView(generics.GenericAPIView):

    serializer_class = EntitiesSerializer

    def post(self, request):
        serializer = self.serializer_class(data = request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)

    def get(self, request):
        active = 0

        is_active = request.data.get("is_active", None)
        groups_id = request.data.get("groups_id", None)
        entity_id = request.data.get("entity_id", None)

        if is_active == "true":
            active = 1

        if groups_id and entity_id:
            entities = Entities.objects.filter(entity_id = entity_id, groups_id = groups_id)
        elif groups_id and is_active:
            entities = Entities.objects.filter(groups_id = groups_id, is_active = active)
        elif groups_id:
            entities = Entities.objects.filter(groups_id = groups_id)
        else:
            entities = Entities.objects.filter(is_active = active)

        serializer = self.serializer_class(instance = entities, many=True)

        response_data = {
            "Status": "Success",
            "data": serializer.data
        }

        return Response(response_data, status=status.HTTP_200_OK)

class DivisionsView(generics.GenericAPIView):

    serializer_class = DivisionsSerializer

    def post(self, request):
        serializer = self.serializer_class(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)

    def get(self, request):
        active = 0

        is_active = request.data.get("is_active", None)
        entity_id = request.data.get("entity_id", None)
        division_id = request.data.get("division_id", None)

        if is_active == "true":
            active = 1

        if entity_id and division_id:
            divisions = Divisions.objects.filter(entity_id = entity_id, division_id = division_id)
        elif entity_id and is_active:
            divisions = Divisions.objects.filter(entity_id = entity_id, is_active = active)
        elif entity_id:
            divisions = Divisions.objects.filter(entity_id = entity_id)
        else:
            divisions = Divisions.objects.filter(is_active = active)

        serializer = self.serializer_class(instance = divisions, many=True)

        response_data = {
            "Status": "Success",
            "data": serializer.data
        }

        return Response(response_data, status=status.HTTP_200_OK)

class ExternalEntitiesView(generics.GenericAPIView):

    serializer_class = ExternalEntitiesSerializer

    def post(self, request):
        serializer = self.serializer_class(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)

    def get(self, request):
        active = 0

        is_active = request.data.get("is_active", None)
        external_entity_id = request.data.get("external_entity_id", None)

        if is_active == "true":
            active = 1

        if external_entity_id:
            external_entity = ExternalEntities.objects.filter(external_entity_id = external_entity_id)
        else:
            external_entity = ExternalEntities.objects.filter(is_active = active)

        serializer = self.serializer_class(instance = external_entity, many=True)

        response_data = {
            "Status": "Success",
            "data": serializer.data
        }

        return Response(response_data, status=status.HTTP_200_OK)

class ShareHoldingHeaderView(generics.GenericAPIView):

    serializer_class = ShareHoldingHeaderSerializer

    def post(self, request):
        serializer = self.serializer_class(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)

    def get(self, request):
        active = 0

        is_active = request.data.get("is_active", None)
        entity_id = request.data.get("entity_id", None)
        share_hold_head_id = request.data.get("share_hold_head_id", None)

        if is_active == "true":
            active = 1

        if entity_id and share_hold_head_id:
            share_holding_header = ShareHoldingHeader.objects.filter(share_hold_head_id = share_hold_head_id, entity_id = entity_id)
        if entity_id and is_active:
            share_holding_header = ShareHoldingHeader.objects.filter(entity_id = entity_id, is_active = active)
        if entity_id:
            share_holding_header = ShareHoldingHeader.objects.filter(entity_id = entity_id)
        else:
            share_holding_header = ShareHoldingHeader.objects.filter(is_active = active)

        serializer = self.serializer_class(instance = share_holding_header, many=True)

        response_data = {
            "Status": "Success",
            "data": serializer.data
        }

        return Response(response_data, status=status.HTTP_200_OK)


class ShareHoldingDetailsView(generics.GenericAPIView):

    serializer_class = ShareHoldingDetailsSerializer

    def post(self, request):
        serializer = self.serializer_class(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)

    def get(self, request):
        active = 0

        is_active = request.data.get("is_active", None)
        entity_id = request.data.get("entity_id", None)
        share_hold_head_id = request.data.get("share_hold_head_id", None)
        external_entity_id = request.data.get("external_entity_id", None)
        share_hold_detail_id = request.data.get("share_hold_detail_id", None)

        if is_active == "true":
            active = 1

        if entity_id and share_hold_head_id and external_entity_id and share_hold_detail_id:
            share_holding_details = ShareHoldingDetails.objects.filter(entity_id = entity_id, external_entity_id = external_entity_id, share_hold_head_id = share_hold_head_id, share_hold_detail_id = share_hold_detail_id)
        elif entity_id and share_hold_head_id and external_entity_id and is_active:
            share_holding_details = ShareHoldingDetails.objects.filter(entity_id = entity_id, share_hold_head_id = share_hold_head_id, external_entity_id = external_entity_id, is_active = active)
        elif entity_id and share_hold_head_id and external_entity_id:
            share_holding_details = ShareHoldingDetails.objects.filter(entity_id = entity_id, share_hold_head_id = share_hold_head_id, external_entity_id = external_entity_id)
        else:
            share_holding_details = ShareHoldingDetails.objects.filter(is_active = active)

        serializer = self.serializer_class(instance = share_holding_details, many=True)

        response_data = {
            "Status": "Success",
            "data": serializer.data
        }

        return Response(response_data, status=status.HTTP_200_OK)


class UserRolesView(generics.GenericAPIView):

    serializer_class = UserRolesSerializer

    def post(self, request):
        serializer = self.serializer_class(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)

    def get(self, request):
        active = 0

        is_active = request.data.get("is_active", None)
        entity_id = request.data.get("entity_id", None)
        division_id = request.data.get("division_id", None)
        user_role_id = request.data.get("user_role_id", None)

        if is_active == "true":
            active = 1

        if entity_id and division_id and user_role_id:
            user_roles = UserRoles.objects.filter(entity_id = entity_id, division_id = division_id, user_role_id = user_role_id)
        elif entity_id and division_id and is_active:
            user_roles = UserRoles.objects.filter(entity_id = entity_id, division_id = division_id, is_active = active)
        else:
            user_roles = UserRoles.objects.filter(is_active = active)

        serializer = self.serializer_class(instance = user_roles, many=True)

        response_data = {
            "Status": "Success",
            "data": serializer.data
        }

        return Response(response_data, status=status.HTTP_200_OK)


class UserPermissionGroupsView(generics.GenericAPIView):

    serializer_class = UserPermissionGroupsSerializer

    def post(self, request):
        serializer = self.serializer_class(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)

    def get(self, request):
        active = 0

        is_active = request.data.get("is_active", None)
        user_permission_group_id = request.data.get("user_permission_group_id", None)

        if is_active == "true":
            active = 1

        if user_permission_group_id and is_active:
            user_permission_groups = UserPermissionGroups.objects.filter(user_permission_group_id = user_permission_group_id, is_active = active)
        else:
            user_permission_groups = UserPermissionGroups.objects.filter(is_active = active)

        serializer = self.serializer_class(instance = user_permission_groups, many=True)

        response_data = {
            "Status": "Success",
            "data": serializer.data
        }

        return Response(response_data, status=status.HTTP_200_OK)

@authentication_classes([])
@permission_classes([])
class RegisterView(generics.GenericAPIView):

    serializer_class = RegisterSerializer

    def post(self, request):
        user = request.data
        serializer = self.serializer_class(data = user)
        serializer.is_valid(raise_exception=True)
        serializer.save()

        user_data = serializer.data
        return Response(user_data, status=status.HTTP_201_CREATED)

@authentication_classes([])
@permission_classes([])
class ValidateUserView(APIView):

    def post(self, request):
        try:
            user_name = request.data.get("emailAddress", "")
            password = request.data.get("password", "")

            user = authenticate(request, username = user_name, password = password)
            print('user', user)
            if user:

                users = Users.objects.filter(email = user_name, is_active = 1)

                for user in users:
                    user_id = user.user_id

                user_mapping = UserMapping.objects.filter(user_id = user_id, is_active = 1)

                for user_map in user_mapping:
                    # role_id = user_map.role_id
                    user_permission_group_id = user_map.user_permission_group_id

                permission_groups_mapping = PermissionGroupsMapping.objects.filter(user_permission_groups_id = user_permission_group_id, is_active = 1)

                pages_id_list = []
                for permission_groups in permission_groups_mapping:
                    pages_id_list.append(permission_groups.pages_id)

                side_menu_list = []

                for pages_id in pages_id_list:

                    pages = Pages.objects.filter(pages_id = pages_id, is_active = 1)
                    for page in pages:
                        page_config = page.config
                        page_config["id"] = page.pages_id
                        side_menu_list.append(page_config)

                user_process_mapping = UserProcessMapping.objects.filter(user_id = user_id, is_active = 1)

                for process_mapping in user_process_mapping:
                    tenants_id = process_mapping.tenants_id
                    groups_id = process_mapping.groups_id
                    entities_id = process_mapping.entities_id
                    m_processing_layer_id = process_mapping.m_processing_layer_id
                    m_processing_sub_layer_id = process_mapping.m_processing_sub_layer_id
                    processing_layer_id = process_mapping.processing_layer_id
                    config = process_mapping.config
                    processing_layer_name = process_mapping.processing_layer_name

                user_credentials = dict()

                user_credentials["side_menu"] = side_menu_list
                user_credentials["tenants_id"] = tenants_id
                user_credentials["groups_id"] = groups_id
                user_credentials["entities_id"] = entities_id
                user_credentials["user_id"] = user_id
                user_credentials["m_processing_layer_id"] = m_processing_layer_id
                user_credentials["m_processing_sub_layer_id"] = m_processing_sub_layer_id
                user_credentials["processing_layer_id"] = processing_layer_id
                user_credentials["config"] = config
                user_credentials["processing_layer_name"] = processing_layer_name

                response = {
                    "Status": "Success",
                    "Message": "User Validated Successfully!!!",
                    "user_credentials": user_credentials
                }
                return Response(response, status = status.HTTP_200_OK)
            response = {
                "Status": "Error",
                "Message": "User Not Found!!!"
            }
            return Response(response, status = status.HTTP_400_BAD_REQUEST)

        except Exception:
            logger.error("Error in Post Method of Validate User View!!!", exc_info=True)
            response = {
                "Status": "Error"
            }
            return Response(response, status = status.HTTP_400_BAD_REQUEST)

class UserMappingView(generics.GenericAPIView):

    serializer_class = UserMappingSerializer

    def post(self, request):
        pass

# Compliance Certificate

@authentication_classes([])
@permission_classes([])
class ComplianceCertificateFileUpload(generics.GenericAPIView):

    processing_layer_apis = ProcessingLayerAPIS.objects.filter(name='cc_file_uploads', is_active=1)

    for processing_layer in processing_layer_apis:
        cc_file_uploads = processing_layer.value

    server_name = cc_file_uploads["server"]
    port = cc_file_uploads["port"]
    methods = cc_file_uploads["methods"]
    # server_name = "localhost"
    # port = "2201"
    # methods = "data"
    ip_port = server_name + port

    post_file_upload_url = ip_port + methods["post_file_upload"]["url"]
    get_file_upload_url = ip_port + methods["get_file_upload"]["url"]

    header =  {
		"Content-Type": "application/json"
	}

    def get(self, request):
        try:

            data = {k: v[0] for k, v in dict(request.GET).items()}

            file_upload_url = self.get_file_upload_url.replace("{tenants_id}", str(data["tenants_id"])).replace("{groups_id}", str(data["groups_id"])).\
                replace("{entities_id}", str(data["entities_id"])).replace("{m_processing_layer_id}", str(data["m_processing_layer_id"])).\
                replace("{m_processing_sub_layer_id}", str(data["m_processing_sub_layer_id"])).replace("{processing_layer_id}", str(data["processing_layer_id"])).\
                replace("{is_active}", str(data["is_active"]))

            file_upload_properties = {
                "url": file_upload_url,
                "header": self.header,
                "data": ""
            }

            get_file_upload_list = dr.GetResponse(file_upload_properties)
            file_uploads_list_response_data = get_file_upload_list.get_response_data()

            response = {
                "Status": "Success",
                "Message": "Data Fetched Successfully!!!",
                "response_data": file_uploads_list_response_data
            }

            return Response(response, status=status.HTTP_200_OK)

        except Exception:
            logger.error("Error in Get Method of Compliance Certificate File Upload Class!!!", exc_info=True)
            response = {
                "Status": "Error"
            }
            return Response(response, status=status.HTTP_400_BAD_REQUEST)

    def post(self, request):
        try:

            # print(request.POST)
            # print("Files")
            # print(request.FILES)
            type = request.data.get("type", "")

            if type:
                base_url = self.post_file_upload_url

                if type == "post_file_upload":
                    url = base_url + "file_uploads/"

                    data = {k: v[0] for k, v in dict(request.POST).items()}
                    del data["type"]

                    # print("data")
                    # print(data)

                    # post_file_upload_props = {
                    #     "url": url,
                    #     "header": header,
                    #     "data": json.dumps(data),
                    #     "file": {"file": request.FILES["file"]}
                    # }
                    #
                    # post_file_upload = dr.PostFileResponse(post_file_upload_props)
                    # post_file_upload_response = post_file_upload.get_post_file_response()
                    #

                    payload_file = {
                        "file": request.FILES["file"]
                    }

                    post_file_upload_response = requests.post(url, files=payload_file, data=data, verify=False)
                    if post_file_upload_response.content:
                        content_data = json.loads(post_file_upload_response.content)
                        if content_data.get("Status", None) == "Success":
                            response = {
                                "Status": "Success",
                                "Message": "Data Loaded Successfully!!!"
                            }
                            return Response(response, status=status.HTTP_200_OK)
                        else:
                            response = {
                                "Status": "Error",
                                "Message": "Error in Compliance Certificate Service!!!"
                            }
                            return Response(response, status=status.HTTP_400_BAD_REQUEST)

                response = {
                    "Status": "Incorrect",
                    "Message": "Incorrect Type Found!!!"
                }
                return Response(response, status=status.HTTP_200_OK)

            response = {
                "Status": "Error",
                "Message": "Type Not Found!!!"
            }
            return Response(response, status = status.HTTP_400_BAD_REQUEST)

        except Exception:
            logger.error("Error in Post Method of Compliance Certificate File Upload Class!!!", exc_info=True)
            response = {
                "Status": "Error"
            }
            return Response(response, status = status.HTTP_500_INTERNAL_SERVER_ERROR)



# Medical Insurance

@authentication_classes([])
@permission_classes([])
class MedicalInsuranceFileUpload(generics.GenericAPIView):

    processing_layer_apis = ProcessingLayerAPIS.objects.filter(name='mi_file_uploads', is_active=1)
    print('mjkvhmvjhvgjhv')
    for processing_layer in processing_layer_apis:
        cc_file_uploads = processing_layer.value
    
    server_name = cc_file_uploads["server"]
    port = cc_file_uploads["port"]
    methods = cc_file_uploads["methods"]
    ip_port = server_name + port

    post_file_upload_url = ip_port + methods["post_file_upload"]["url"]
    get_file_upload_url = ip_port + methods["get_file_upload"]["url"]

    header = {
        "Content-Type": "application/json"
    }

    def get(self, request):
        try:

            data = {k: v[0] for k, v in dict(request.GET).items()}

            file_upload_url = self.get_file_upload_url.replace("{tenants_id}", str(data["tenants_id"])).replace(
                "{groups_id}", str(data["groups_id"])). \
                replace("{entities_id}", str(data["entities_id"])).replace("{m_processing_layer_id}",
                                                                           str(data["m_processing_layer_id"])). \
                replace("{m_processing_sub_layer_id}", str(data["m_processing_sub_layer_id"])).replace(
                "{processing_layer_id}", str(data["processing_layer_id"])). \
                replace("{is_active}", str(data["is_active"]))

            file_upload_properties = {
                "url": file_upload_url,
                "header": self.header,
                "data": ""
            }

            get_file_upload_list = dr.GetResponse(file_upload_properties)
            file_uploads_list_response_data = get_file_upload_list.get_response_data()

            response = {
                "Status": "Success",
                "Message": "Data Fetched Successfully!!!",
                "response_data": file_uploads_list_response_data
            }

            return Response(response, status=status.HTTP_200_OK)

        except Exception:
            logger.error("Error in Get Method of Medical Insurance File Upload Class!!!", exc_info=True)
            response = {
                "Status": "Error"
            }
            return Response(response, status=status.HTTP_400_BAD_REQUEST)

    def post(self, request):
        try:

            # print(request.POST)
            # print("Files")
            print('ghghghgvfhgfhgfvhghfv',request.FILES)
            type = request.data.get("type", "")

            if type:
                base_url = self.post_file_upload_url

                if type == "post_file_upload":
                    url = base_url + "file_uploads/"

                    data = {k: v[0] for k, v in dict(request.POST).items()}
                    del data["type"]

                    payload_file = {
                        "file": request.FILES["file"]
                    }
                    print('url', url)
                    post_file_upload_response = requests.post(url, files=payload_file, data=data, verify=False)
                    if post_file_upload_response.content:
                        content_data = json.loads(post_file_upload_response.content)
                        if content_data.get("Status", None) == "Success":
                            response = {
                                "Status": "Success",
                                "Message": "Data Loaded Successfully!!!"
                            }
                            return Response(response, status=status.HTTP_200_OK)
                        else:
                            response = {
                                "Status": "Error",
                                "Message": "Error in Medical Insurance Service!!!"
                            }
                            return Response(response, status=status.HTTP_400_BAD_REQUEST)

                response = {
                    "Status": "Incorrect",
                    "Message": "Incorrect Type Found!!!"
                }
                return Response(response, status=status.HTTP_200_OK)

            response = {
                "Status": "Error",
                "Message": "Type Not Found!!!"
            }
            return Response(response, status=status.HTTP_400_BAD_REQUEST)

        except Exception:
            logger.error("Error in Post Method of Compliance Certificate File Upload Class!!!", exc_info=True)
            response = {
                "Status": "Error"
            }
            return Response(response, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


# consolidation

@authentication_classes([])
@permission_classes([])
class ConsolidationFileUpload(generics.GenericAPIView):

    processing_layer_apis = ProcessingLayerAPIS.objects.filter(name='consolidation_file_upload', is_active=1)
    print('mjkvhmvjhvgjhv')
    for processing_layer in processing_layer_apis:
        cc_file_uploads = processing_layer.value
    
    server_name = cc_file_uploads["server"]
    port = cc_file_uploads["port"]
    methods = cc_file_uploads["methods"]
    ip_port = server_name + port

    post_file_upload_url = ip_port + methods["post_file_upload"]["url"]
    get_file_upload_url = ip_port + methods["get_file_upload"]["url"]

    header = {
        "Content-Type": "application/json"
    }

    def get(self, request):
        try:

            data = {k: v[0] for k, v in dict(request.GET).items()}

            file_upload_url = self.get_file_upload_url.replace("{tenants_id}", str(data["tenants_id"])).replace(
                "{groups_id}", str(data["groups_id"])). \
                replace("{entities_id}", str(data["entities_id"])).replace("{m_processing_layer_id}",
                                                                           str(data["m_processing_layer_id"])). \
                replace("{m_processing_sub_layer_id}", str(data["m_processing_sub_layer_id"])).replace(
                "{processing_layer_id}", str(data["processing_layer_id"])). \
                replace("{is_active}", str(data["is_active"]))

            file_upload_properties = {
                "url": file_upload_url,
                "header": self.header,
                "data": ""
            }

            get_file_upload_list = dr.GetResponse(file_upload_properties)
            file_uploads_list_response_data = get_file_upload_list.get_response_data()

            response = {
                "Status": "Success",
                "Message": "Data Fetched Successfully!!!",
                "response_data": file_uploads_list_response_data
            }

            return Response(response, status=status.HTTP_200_OK)

        except Exception:
            logger.error("Error in Get Method of Medical Insurance File Upload Class!!!", exc_info=True)
            response = {
                "Status": "Error"
            }
            return Response(response, status=status.HTTP_400_BAD_REQUEST)

    def post(self, request):
        try:

            # print(request.POST)
            # print("Files")
            print('ghghghgvfhgfhgfvhghfv',request.FILES)
            type = request.data.get("type", "")

            if type:
                base_url = self.post_file_upload_url

                if type == "post_file_upload":
                    url = base_url + "file_uploads/"

                    data = {k: v[0] for k, v in dict(request.POST).items()}
                    print('data', data)
                    del data["type"]

                    payload_file = {
                        "file": request.FILES["file"]
                    }
                    print('url', url)
                    post_file_upload_response = requests.post(url, files=payload_file, data=data, verify=False)
                    if post_file_upload_response.content:
                        content_data = json.loads(post_file_upload_response.content)
                        if content_data.get("Status", None) == "Success":
                            response = {
                                "Status": "Success",
                                "Message": "Data Loaded Successfully!!!"
                            }
                            return Response(response, status=status.HTTP_200_OK)
                        else:
                            response = {
                                "Status": "Error",
                                "Message": "Error in Medical Insurance Service!!!"
                            }
                            return Response(response, status=status.HTTP_400_BAD_REQUEST)

                response = {
                    "Status": "Incorrect",
                    "Message": "Incorrect Type Found!!!"
                }
                return Response(response, status=status.HTTP_200_OK)

            response = {
                "Status": "Error",
                "Message": "Type Not Found!!!"
            }
            return Response(response, status=status.HTTP_400_BAD_REQUEST)

        except Exception:
            logger.error("Error in Post Method of Compliance Certificate File Upload Class!!!", exc_info=True)
            response = {
                "Status": "Error"
            }
            return Response(response, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


# # Medical Insurance

# @authentication_classes([])
# @permission_classes([])
# class MedicalInsuranceFileUpload(generics.GenericAPIView):

#     processing_layer_apis = ProcessingLayerAPIS.objects.filter(name='mi_file_uploads', is_active=1)

#     for processing_layer in processing_layer_apis:
#         cc_file_uploads = processing_layer.value

#     server_name = cc_file_uploads["server"]
#     port = cc_file_uploads["port"]
#     methods = cc_file_uploads["methods"]
#     ip_port = server_name + port

#     post_file_upload_url = ip_port + methods["post_file_upload"]["url"]
#     get_file_upload_url = ip_port + methods["get_file_upload"]["url"]

#     header = {
#         "Content-Type": "application/json"
#     }

#     def get(self, request):
#         try:

#             data = {k: v[0] for k, v in dict(request.GET).items()}

#             file_upload_url = self.get_file_upload_url.replace("{tenants_id}", str(data["tenants_id"])).replace(
#                 "{groups_id}", str(data["groups_id"])). \
#                 replace("{entities_id}", str(data["entities_id"])).replace("{m_processing_layer_id}",
#                                                                            str(data["m_processing_layer_id"])). \
#                 replace("{m_processing_sub_layer_id}", str(data["m_processing_sub_layer_id"])).replace(
#                 "{processing_layer_id}", str(data["processing_layer_id"])). \
#                 replace("{is_active}", str(data["is_active"]))

#             file_upload_properties = {
#                 "url": file_upload_url,
#                 "header": self.header,
#                 "data": ""
#             }

#             get_file_upload_list = dr.GetResponse(file_upload_properties)
#             file_uploads_list_response_data = get_file_upload_list.get_response_data()

#             response = {
#                 "Status": "Success",
#                 "Message": "Data Fetched Successfully!!!",
#                 "response_data": file_uploads_list_response_data
#             }

#             return Response(response, status=status.HTTP_200_OK)

#         except Exception:
#             logger.error("Error in Get Method of Medical Insurance File Upload Class!!!", exc_info=True)
#             response = {
#                 "Status": "Error"
#             }
#             return Response(response, status=status.HTTP_400_BAD_REQUEST)

#     def post(self, request):
#         try:

#             # print(request.POST)
#             # print("Files")
#             # print(request.FILES)
#             type = request.data.get("type", "")

#             if type:
#                 base_url = self.post_file_upload_url

#                 if type == "post_file_upload":
#                     url = base_url + "file_uploads/"

#                     data = {k: v[0] for k, v in dict(request.POST).items()}
#                     del data["type"]

#                     # print("data")
#                     # print(data)

#                     # post_file_upload_props = {
#                     #     "url": url,
#                     #     "header": header,
#                     #     "data": json.dumps(data),
#                     #     "file": {"file": request.FILES["file"]}
#                     # }
#                     #
#                     # post_file_upload = dr.PostFileResponse(post_file_upload_props)
#                     # post_file_upload_response = post_file_upload.get_post_file_response()
#                     #

#                     payload_file = {
#                         "file": request.FILES["file"]
#                     }

#                     post_file_upload_response = requests.post(url, files=payload_file, data=data, verify=False)
#                     if post_file_upload_response.content:
#                         content_data = json.loads(post_file_upload_response.content)
#                         if content_data.get("Status", None) == "Success":
#                             response = {
#                                 "Status": "Success",
#                                 "Message": "Data Loaded Successfully!!!"
#                             }
#                             return Response(response, status=status.HTTP_200_OK)
#                         else:
#                             response = {
#                                 "Status": "Error",
#                                 "Message": "Error in Medical Insurance Service!!!"
#                             }
#                             return Response(response, status=status.HTTP_400_BAD_REQUEST)

#                 response = {
#                     "Status": "Incorrect",
#                     "Message": "Incorrect Type Found!!!"
#                 }
#                 return Response(response, status=status.HTTP_200_OK)

#             response = {
#                 "Status": "Error",
#                 "Message": "Type Not Found!!!"
#             }
#             return Response(response, status=status.HTTP_400_BAD_REQUEST)

#         except Exception:
#             logger.error("Error in Post Method of Compliance Certificate File Upload Class!!!", exc_info=True)
#             response = {
#                 "Status": "Error"
#             }
#             return Response(response, status=status.HTTP_500_INTERNAL_SERVER_ERROR)




# class UploadExcelFilesView(APIView):
#     def post(self, request, format=None):
#         if 'excel_files' not in request.FILES:
#             return Response({'error': 'No files were uploaded'}, status=status.HTTP_400_BAD_REQUEST)
#
#         files = request.FILES.getlist('excel_files')
#         for file in files:
#             file_path = os.path.join('media', file.name)
#             with open(file_path, 'wb') as f:
#                 f.write(file.read())
#             process_excel_file.delay(file_path)
#
#         return Response({'message': 'Files uploaded successfully'}, status=status.HTTP_202_ACCEPTED)



class TaskStatusView(APIView):
    def get(self, request, task_id, format=None):
        result = AsyncResult(task_id)
        if result.ready():
            return Response({'status': 'completed', 'result': result.get()})
        else:
            return Response({'status': 'pending'})


# class ExcelUploadView(APIView):
#     def post(self, request):
#         uploaded_file = request.FILES.get('file')
#         if not uploaded_file:
#             return Response({'error': 'No file uploaded.'}, status=status.HTTP_400_BAD_REQUEST)
#         df = pd.read_excel(uploaded_file)
#         # ... do some processing with the dataframe ...
#         return Response({'message': 'File processed successfully.'}, status=status.HTTP_200_OK)

@authentication_classes([])
@permission_classes([])
class GetFileUpload(APIView):
    def post(self, request):
        try:
            if request.method == 'POST':
                json_data = request.body
                stream = io.BytesIO(json_data)
                python_data = JSONParser().parse(stream)
                print('python_data', python_data)
                id = int(python_data['id'])
                if id:
                    # data = SourceMaster.objects.filter(source_id=id).values()
                    # data_out = list(data)
                    # response_data = json.dumps(data_out)
                    data = SourceMaster.objects.filter(source_id=id).values()
                    data_out = list(data)
                    for sub in data_out:
                        json_list = sub['columns']
                        
                    response_data = json.dumps(json_list)
                    
                    
                    return Response(json.loads(response_data), status=status.HTTP_200_OK)
        except Exception:
            response = {
                "Status": "Error"
            }
            return Response(response, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


@authentication_classes([])
@permission_classes([])
class FetchSourceMasterData(APIView):
    def post(self, request):
        try:
            if request.method == 'POST':
                json_data = request.body
                stream = io.BytesIO(json_data)
                python_data = JSONParser().parse(stream)
                print('python_data', python_data)
                id = int(python_data['id'])
                if id:
                    data = SourceMaster.objects.filter(source_id=id).values()
                    data_out = list(data)
                    for sub in data_out:
                        json_list = sub['actions'] 
                    response_data = json.dumps(json_list)
                    return Response(json.loads(response_data), status=status.HTTP_200_OK)
        except Exception:
            response = {
                "Status": "Error"
            }
            return Response(response, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


# File Upload
@authentication_classes([])
@permission_classes([])
class FileUpload(generics.GenericAPIView):
    def post(self, request):
        try:
            if request.method == 'POST':
                file = request.FILES['file']
                if file.name.endswith('.xlsb'):
                    json_list = []
                    i = 1
                    with pyxlsb.open_workbook(file) as wb:
                        for sheet_name in wb.sheets:
                            df = pd.read_excel(file, engine='pyxlsb')
                            if df.empty:
                                print('DataFrame is empty!')
                            else:
                                has_column_names = all(df.iloc[0].notna())
                            # print('has_column_names', has_column_names)
                            if has_column_names:
                                # print('the first row not contains column names')
                                df = pd.read_excel(file, engine='pyxlsb', skiprows=1)
                            column_names = df.columns
                            print('column_names', column_names)
                            sheet_data = {
                                    'id': i,
                                    'sheet_name': sheet_name,
                                    'column_names': column_names.tolist()
                                }
                            i = i + 1
                            json_list.append(sheet_data)
                    print('sheet_data', sheet_data)
                    return Response(json.loads(json.dumps(json_list)), status=status.HTTP_200_OK)
                
                elif file.name.endswith('.xlsx'):
                    binary_data = file.read()
                    print('column_names1')
                    workbook = openpyxl.load_workbook(io.BytesIO(binary_data))
                    print('column_names1')
                    workbook.save('file.xlsx')
                    print('column_names1')
                    sheet_names = workbook.sheetnames 
                    json_list = []
                    i = 1
                    for worksheet in workbook.worksheets:
                        print('column_names1', worksheet)
                        for row in worksheet.iter_rows(min_row=1, max_row=2, values_only=True):                                      
                            column_names = list(row)
                            print('hggfgf', column_names[0])
                            if not None in column_names:
                                print('column_names12',column_names)
                                sheet_data = {
                                    'id': i,
                                    'sheet_name': sheet_names[i-1],
                                    'column_names': column_names
                                }
                                i = i + 1
                                json_list.append(sheet_data)
                            elif isinstance(column_names[0], str):
                                sheet_data = {
                                    'id': i,
                                    'sheet_name': sheet_names[i-1],
                                    'column_names': column_names
                                }
                                i = i + 1
                                json_list.append(sheet_data)
                    
                    return Response(json.loads(json.dumps(json_list)), status=status.HTTP_200_OK)
        except Exception:
            response = {
                 "Status": "Error"
             }
            return Response(response, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
                
# Sheets Data Upload
@authentication_classes([])
@permission_classes([])
class SheetDataUpload(generics.GenericAPIView):
    def post(self, request):
        print(request.data['sheet_data'])
        if request.method == 'POST':
            saverecord = SourceMaster()
            saverecord.source_name = request.data['source_name'] 
            saverecord.source_type = request.data['source_type']
            saverecord.source_description = request.data['source_description']
            saverecord.source_identifier = request.data['source_identifier']
            saverecord.sheets =  request.data['sheet_data']
            saverecord.columns =  request.data['File_data']
            saverecord.actions = request.data['actions']
            saverecord.save()
            return Response('ok', status=status.HTTP_200_OK)


@authentication_classes([])
@permission_classes([])
class TaskDetailView(APIView):
    def get(self, request, id):
        task = Task.objects.filter(job_id=id)
        serializer = TaskSerializer(task, many=True)
        return Response(serializer.data)


@authentication_classes([])
@permission_classes([])
class UpdateTaskDetail(APIView):
    def post(self, request, id):
        json_data = request.body
        stream = io.BytesIO(json_data)
        python_data = JSONParser().parse(stream)
        if id is not None:
            task = Task.objects.filter(task_id=id).first()
            serializer = TaskSerializer(task, data=python_data)
            if serializer.is_valid():
                serializer.save()
                # serializer_dict = serializer.data
                # serializer_dict["message"] = "updated successfully."
                return Response("updated successfully", status=status.HTTP_200_OK)
            else:
                return Response(serializer.errors,
                                status=status.HTTP_400_BAD_REQUEST)


@authentication_classes([])
@permission_classes([])
class ActionDetailView(APIView):
    def get(self, request, id):
        action = Action.objects.filter(task_id=id)
        serializer = ActionSerializer(action, many=True)
        return Response(serializer.data)

@authentication_classes([])
@permission_classes([])
class GetAllAction(APIView):
    def get(self, request):
        action = Action.objects.all()
        serializer = ActionSerializer(action, many=True)
        return Response(serializer.data)

@authentication_classes([])
@permission_classes([])
class UpdateActionDetail(APIView):
    def post(self, request, id):
        json_data = request.body
        stream = io.BytesIO(json_data)
        python_data = JSONParser().parse(stream)
        if id is not None:
            action = Action.objects.filter(action_id=id).first()
            serializer = ActionSerializer(action, data=python_data)
            if serializer.is_valid():
                serializer.save()
                # serializer_dict = serializer.data
                # serializer_dict["message"] = "updated successfully."
                return Response("updated successfully", status=status.HTTP_200_OK)
            else:
                return Response(serializer.errors,
                                status=status.HTTP_400_BAD_REQUEST)

@authentication_classes([])
@permission_classes([])
class CreateActionView(APIView):
    def post(self, request, *args, **kwargs):
        json_data = request.body
        stream = io.BytesIO(json_data)
        python_data = JSONParser().parse(stream)
        serializer = ActionSerializer(data=python_data)
        if serializer.is_valid():
            serializer.save()
            responsedict = {}
            responsedict["message"] = "created successfully."
            return Response(responsedict, status=status.HTTP_201_CREATED)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@authentication_classes([])
@permission_classes([])
class DeleteTaskView(APIView):
    def delete(self, request, id=None):
        try:
            action = Action.objects.filter(action_id=id)
            action.delete()
        except Exception:
            response = {
                 "Status": "Error"
             }
            return Response(response, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        return Response(status=status.HTTP_204_NO_CONTENT)
        

@authentication_classes([])
@permission_classes([])
class ConditionDetailView(APIView):
    def get(self, request, id):
        condition = Condition.objects.filter(action_id=id)
        serializer = ConditionSerializer(condition, many=True)
        return Response(serializer.data)



@authentication_classes([])
@permission_classes([])
class UpdateCondition(APIView):
    def post(self, request, id):
        json_data = request.body
        stream = io.BytesIO(json_data)
        python_data = JSONParser().parse(stream)
        if id is not None:
            condition = Condition.objects.filter(action_id=id).first()
            serializer = ConditionSerializer(condition, data=python_data)
            print('python_data', serializer)
            if serializer.is_valid():
                serializer.save()
                print('serializer')
                # serializer_dict = serializer.data
                # serializer_dict["message"] = "updated successfully."
                return Response("updated successfully", status=status.HTTP_200_OK)
            else:
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@authentication_classes([])
@permission_classes([])
class JobDetailView(APIView):
    def get(self, request):
        job = Job.objects.all()
        serializer = JobSerializer(job, many=True)
        return Response(serializer.data)


# this api is used create the job data
@authentication_classes([])
@permission_classes([])
class CreateJob(generics.GenericAPIView):
    def post(self, request):
        json_data = request.body
        stream = io.BytesIO(json_data)
        data = JSONParser().parse(stream)
        # data = request.data['form_data']
        try:
            if request.method == 'POST':
                saverecord = Job()
                saverecord.job_name = data['job_name']
                saverecord.job_description = data['job_description']
                saverecord.job_category = data['job_category']
                saverecord.save()
                return Response("created successfully", status=status.HTTP_200_OK)
            
        except Exception:
            response = {
                 "Status": "Error"
             }
            return Response(response, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


@authentication_classes([])
@permission_classes([])
class UpdateJob(APIView):
    def post(self, request, id):
        json_data = request.body
        stream = io.BytesIO(json_data)
        data = JSONParser().parse(stream)
        if id is not None:
            job = Job.objects.filter(job_id=id)
            for obj in job:
                obj.job_name = data['job_name']
                obj.job_description = data['job_description']
                obj.job_category = data['job_category']
                obj.save()
            return Response('updated successfully', status=status.HTTP_200_OK)
        else:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@authentication_classes([])
@permission_classes([])
class DeleteJob(APIView):
    def delete(self, request, id=None):
        try:
            job = Job.objects.filter(job_id=id)
            job.delete()
        except Exception:
            response = {
                 "Status": "Error"
             }
            return Response(response, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        return Response(status=status.HTTP_204_NO_CONTENT)


@authentication_classes([])
@permission_classes([])
class FetchJobDetailView(APIView):
    def get(self, request, id):
        job = Job.objects.filter(job_id=id)
        serializer = JobSerializer(job, many=True)
        return Response(serializer.data)


@authentication_classes([])
@permission_classes([])
class FetchSheets(generics.GenericAPIView):
    def post(self, request):
        id = request.data['File_data']
        print('id', id)
        if request.method == 'POST':
            data = SourceMaster.objects.filter(source_id=id).values()
            data_out = list(data)
            response_data = json.dumps(data_out)
            return Response(json.loads(response_data), status=status.HTTP_200_OK)


@authentication_classes([])
@permission_classes([])
class EtlSecondUpload(generics.GenericAPIView):
    def post(self, request):
        print(request.data['File_data'])
        if request.method == 'POST':
            data = SourceMaster.objects.all().values()
            data_out = list(data)
            response_data = json.dumps(data_out)
            return Response(json.loads(response_data), status=status.HTTP_200_OK)


def filter_clnt_names(f, company_name):
    data = json.load(f)
    df = pd.DataFrame(data)
    df = df.fillna('')
    if data:
        if company_name:
            value = df.loc[df['mis_insurance_company'].str.lower() == company_name.lower()] 
            value1 = value.drop_duplicates(subset='mis_client', keep="first")
            filter_column = value1.loc[:, 'mis_client']
            print('value', value1)
            data = filter_column.to_dict()
            return data
        return 'error'
    return 'error'

@authentication_classes([])
@permission_classes([])
class FetchClientName(generics.GenericAPIView):
    def get(self, request):
        company_name = request.GET.get('com_name', None)
        data = None
        with open('master.json', 'r') as f:
            data = filter_clnt_names(f, company_name)

        return Response(data, status=status.HTTP_200_OK)

# csv_file =pd.read_csv("master.csv", low_memory=False)
       
        # data = csv_file.to_json(orient = "records")
        # csv_file.to_json("master.json",orient = "records")
        

@authentication_classes([])
@permission_classes([])
class FileMasterData(generics.GenericAPIView):
    def get(self, request):
        companyname = request.GET.get('companyname', None)
        clientname = request.GET.get('clientname', None)
        date = request.GET.get('date', None)
        print('date', date)
        date = date.split('-')
        year = int(date[0])
        print('year', year)
        month = date[1]
        print('month', month)

        if month == "01":
            month = 'jan'
        elif month == "02":
            month = 'feb'
        elif month == "03":
            month = 'mar'
        elif month == "04":
            month = 'apr'
        elif month == "05":
            month = 'may'
        elif month == "06":
            month = 'jun'
        elif month == "07":
            month = 'jul'
        elif month == "08":
            month = 'aug'
        elif month == "09":
            month = 'sep'
        elif month == "10":
            month = 'oct'
        elif month == "11":
            month = 'nov'
        elif month == "12":
            month = 'dec'
        
        with open('master.json', 'r') as f:
            data = json.load(f)
            df = pd.DataFrame(data)
            df = df.fillna('')
            
            if data:
                if companyname and clientname:
                    value = df.loc[df['mis_insurance_company'].str.lower() == companyname.lower()] 
                    value1 = value.loc[value['mis_client'].str.lower() == clientname.lower()]
                    value2 = value1.loc[value['ass_month'].str.lower() == month.lower()]
                    value3 = value2.loc[value['ass_year'] == year]
                    data = value3.to_dict(orient='records')
                if companyname:
                    value = df.loc[df['mis_insurance_company'].str.lower() == companyname.lower()]
                    value1 = value.loc[value['ass_month'].str.lower() == month.lower()]
                    value2 = value1.loc[value['ass_year'] == year]
                    data = value2.to_dict(orient='records')
                if clientname:
                    value = df.loc[df['mis_client'].str.lower() == clientname.lower()]
                    data = value.to_dict(orient='records')
                
        return Response(data, status=status.HTTP_200_OK)


import shutil

def create_excel_file(dataframes, file_name, target_location, sheetnames):
    # Create a Pandas Excel writer using the file name
    writer = pd.ExcelWriter(file_name, engine='xlsxwriter')
    
    # Iterate through the dataframes
    for i, df in enumerate(dataframes, start=0):
        # sheet_name = f'Sheet{i}'  # Generate sheet name dynamically
        
        # Write the DataFrame to the sheet
        df.to_excel(writer, sheet_name=sheetnames[i], index=False)
        
        # Get the workbook and worksheet objects
        workbook = writer.book
        worksheet = writer.sheets[sheetnames[i]]
        
        # Add a header with sheet name
        header_format = workbook.add_format({'bold': True, 'size': 14})
        worksheet.set_header('&L&[File]{} &R&[Tab]{}'.format(file_name, sheetnames[i]), {'margin': 0.5, 'align_with_margins': True})
        worksheet.repeat_rows(0)
        worksheet.set_row(0, None, header_format)
    
    # Save the Excel file
    writer.save()
    
    # Move the file to the target location
    destination_path = shutil.copy(file_name, target_location)
    return destination_path


@authentication_classes([])
@permission_classes([])
class CreateTargetFileView(APIView):
    def create(self, json_data=None, sheetNames=None,  target_name=None, target_loc_path=None):
        dataframes = []
        sheetnames = []
        for key, name in enumerate(sheetNames):
            print('name', name, key)
            df = pd.DataFrame()
            dataframes.append(df)
            sheetnames.append(name["text"])
        
        # empty_df = pd.DataFrame()
        for data in json_data:
            print('data', json_data[data])
            json = json_data[data]
            index = int(data)
            for key in json:
                print('key',key)
                excel_file_name = key.split('--')[0]
                print('json', json[key])
                excel_col_name = json[key]
                path = f'C:/Users/DELL/Desktop/workspace/backend/UserManagementModule/excel files/{excel_file_name}'
                df = pd.read_excel(path)
                has_column_names = all(df.iloc[0].notna())
                print('has_column_names', has_column_names)
                if has_column_names:
                    print('the first row not contains column names')
                    df = pd.read_excel(path, skiprows=1)

                print('df', df)
                dataframes[index][excel_col_name] = df[excel_col_name]

        print('empty_df', dataframes)
      # Create multiple sample DataFrames
        df1 = pd.DataFrame({'A': [1, 2, 3], 'B': [4, 5, 6]})
        df2 = pd.DataFrame({'X': [7, 8, 9], 'Y': [10, 11, 12]})
        df3 = pd.DataFrame({'Alpha': ['a', 'b', 'c'], 'Beta': ['d', 'e', 'f']})

        # Specify the file name and target location
        file_name = 'output.xlsx'
        target_location = f'C:/Users/DELL/Desktop/workspace/backend/UserManagementModule/'


        # Create the Excel file with separate sheets for each DataFrame and move it to the target location
        destination_path = create_excel_file(dataframes, file_name, target_location, sheetnames)
        print("File moved to:", destination_path)
        
                


# Sheets Data Upload
@authentication_classes([])
@permission_classes([])
class TargetSheetUpload(generics.GenericAPIView):
    def post(self, request):
        target_name = request.data['target_name']
        target_desc = request.data['target_desc']
        target_placeholder = request.data['target_placeholder']
        target_loc_path = request.data['target_loc_path']
        data = request.data['target_configuration']
        
        # dta1 = request.data['data']
        with open('status.json', 'r') as f:
            data1 = json.load(f) 
        #res = CreateTargetFileView.create(self, data["slectedColumns1"], sheetNames, target_name, target_loc_path)
        # print('data1', data1)
        if request.method == 'POST':
            saverecord = Target()
            saverecord.target_name = target_name
            saverecord.target_description = target_desc
            saverecord.target_placeholder = target_placeholder
            saverecord.target_location = target_loc_path
            saverecord.target_configuration = json.dumps(data1)
            saverecord.save()
            return Response('ok', status=status.HTTP_200_OK)


@authentication_classes([])
@permission_classes([])
class FetchTargetData(generics.GenericAPIView):
    def post(self, request):
        if request.method == 'POST':
            data = Target.objects.all().values('target_id')
            data_out = list(data)
            response_data = json.dumps(data_out)
            return Response(json.loads(response_data), status=status.HTTP_200_OK)

@authentication_classes([])
@permission_classes([])
class GetAllTenants(generics.GenericAPIView):
    def post(self, request):
        if request.method == 'POST':
            data = Target.objects.all().values()
            data_out = list(data)
            response_data = json.dumps(data_out)
            return Response(json.loads(response_data), status=status.HTTP_200_OK)


@authentication_classes([])
@permission_classes([])
class GetTenants(generics.GenericAPIView):
    def post(self, request):
        id = request.data['id']
        if request.method == 'POST':
            data = Target.objects.filter(target_id=id).values()
            data_out = list(data)
            response_data = json.dumps(data_out)
            return Response(json.loads(response_data), status=status.HTTP_200_OK)


@authentication_classes([])
@permission_classes([])
class FileValidationView(APIView):
    def validate(self, json_data=None, id=None):
        """
            This method is used to validate json file based on the data type and text field
        """
        try:
            if json_data and id:
                
                source = SourceMaster.objects.filter(sourrce_id=id)
                qs_json =serializers.serialize('json', source)
                data1 = list(eval(qs_json))
                res = [ sub['fields'] for sub in data1]
                for sub in res:
                    res1 = sub['actionss']
                    data = res1
                    print('res1', res1)
                df = pd.DataFrame(json_data)
                df = df.fillna('')
                for column in data:
                    column_name = column['text']
                    data_type = column['data_type']
                    if data_type == 'integer':
                        isnumeric = pd.to_numeric(df[column_name], errors='coerce').notnull().all()
                        if not isnumeric:
                            error_type = column_name + ' column contains null or string values'
                            return error_type
                    elif data_type == 'Decimal':
                        all_decimals = df[column_name].dtype == 'float64' or df[column_name].dtype == 'float32'
                        if not isnumeric:
                            error_type = column_name + ' column not contains decimal values'
                            return error_type
                    elif data_type == 'length':
                        is_len = df[df[column_name].str.len()>=1]
                        if len(is_len):
                            error_type = column_name + ' column contains length is more than !!!'
                            return error_type
                    elif data_type == 'DateFormate':
                        is_date = pd.to_datetime(df[column_name]).notnull().all()
                        print('is_date', is_date)
                        if not is_date:
                            error_type = column_name + ' column contains wrong date formate!!!'
                            return error_type
                    elif data_type == 'Yes / No':
                        is_YesOrNo = df[column_name].isin(['Yes', 'No']).all()
                        print('is_YesOrNo', is_YesOrNo)
                        if not is_YesOrNo:
                            error_type = column_name + ' column contains other values besides yes or no !!!'
                            return error_type
            else:
                error_type =  'json data or id contans null values send both values !!!'
                return error_type
        except Exception:
            response = {
                Status: "Error"
            }
            return Response(response)
        return Response({status:'success'})


@authentication_classes([])
@permission_classes([])
class ValidationView(APIView):
    def get(self, request):
        with open('validation.json', 'r', encoding="utf8") as f:
            data = json.load(f)
            response = FileValidationView.validate(self, data, 4)
            print('response', response)
        return Response(data, status=status.HTTP_200_OK)


# this api is used for excution engine
@authentication_classes([])
@permission_classes([])
class FileUploadView(APIView):
    def post(self, request):
        json_data = {
        "filename": "example.xlsx",
        "sheetname": "Sheet1",
        "columns": [
            {
            "name": "Name",
            "datatype": "string"
            },
            {
            "name": "Age",
            "datatype": "number"
            },
            {
            "name": "Email",
            "datatype": "string"
            }
        ],
        "rows": [
            {
            "Name": "John",
            "Age": 25,
            "Email": "john@example.com"
            },
            {
            "Name": "Mary",
            "Age": 30,
            "Email": "mary@example.com"
            },
            {
            "Name": "Bob",
            "Age": 35,
            "Email": "bob@example.com"
            }
        ]
        }
        data = json.loads(json.dumps(json_data))
        print(data)
        file_type = 'excel'
        # Iterate through each file in the JSON data
        for file_data in data:
            # filename = file_data['filename']
            # file_type = filename.split('.')[1]
            # sheetname = file_data['sheetname']
            # columns = file_data['columns']
            # rows = file_data['rows']
            print('file_data', file_data)

            if file_type == 'excel':
                process_excel_file.delay(data)
                return Response({'message': 'Excel file processing has started.'}, status=status.HTTP_202_ACCEPTED)
            else:
                return Response({'error': 'Unsupported file type.'}, status=status.HTTP_400_BAD_REQUEST)


@authentication_classes([])
@permission_classes([])
class ExecutionEngineView(APIView):
    def validate(self, id=None, json_data=None):
        """
            This method is used to execute data based on api url
        """
        try:
            if json_data and id:
                process = Process.objects.filter(process_name=id).values('process_id')
                process_data = list(process)
                process_id = process_data[0]['process_id']
                job = Job.objects.filter(process_id=process_id).values('job_id')
                job_data = list(job)
                job_id = job_data[0]['job_id']
                task = Task.objects.filter(job_id=job_id).values('task_id') #forloop
                task_data = list(task)
                if task_data:
                    for task_data in task_data:
                        print('task_data', task_data)
                        task_id = task_data['task_id']
                        action = Action.objects.filter(task_id=task_id).values('action_id')
                        action_data = list(action)
                        print('action_data', action_data)
                        if action_data:
                            for action_data in action_data:
                                action_id = action_data['action_id']
                                condition = Condition.objects.filter(action_id=action_id).values('condition_id', 'api_link')
                                condition_data = list(condition)
                                if condition_data:
                                    for data in condition_data:
                                        print('data', data['api_link'])
                                        with open('status.json', 'r') as f:
                                            file_data = json.load(f)
                                            print("123",file_data)
                                            if file_data and file_data['status'] == 'error':
                                                print("1234",file_data['status'])
                                                with open('status.json', 'w') as file:
                                                    file.truncate()
                                                    return file_data   
                                        sleep(0.1)
                                        result = process_excel_sheet.delay(data['api_link'],  json_data)
                                        print('result', result)
                                else:
                                    error_type =  'condition data contans null values !!!'
                                    return error_type
                        else:
                            error_type =  'action data contans null values !!!'
                            return error_type   
                else:
                    error_type =  'task data contans null values !!!'
                    return error_type
                return {'status':'success'}
            else:
                error_type =  'json data or id contans null values send both values !!!'
                return error_type
        except Exception:
            response = {
                'status': "Error"
            }
            return response
        

from time import sleep
from django_celery_results.models import TaskResult

    

# @authentication_classes([])
# @permission_classes([])
# class SheetDataUpload(generics.GenericAPIView):
#     def post(self, request):
#         print(request.data['sheet_data']) 
#         if request.method == 'POST':
#             process_name = request.data['process_name']
#             source_name = request.data['source_name']
#             source_identifier = request.data['source_identifier']
#             source_description = request.data['source_description']
#             file_name = request.data['file_name']
#             source_type = request.data['source_type']
#             print('file_name', file_name)
#             json_data = {"source_name":source_name, "source_identifier":source_identifier, "source_description": source_description, "file_name":file_name, "source_type":source_type}
#             data_to_add = {'status':'sucess'}
#             with open('status.json', 'w') as file:
#                 json.dump(data_to_add, file, indent=4)
#             response = ExecutionEngineView.validate(self, process_name, json_data)
#             print('response', response)
#             task_result = TaskResult.objects.all()
#             print('task_result', task_result)

#             # task_group = group(process_excel_sheet.s(data['api_link'], {"source_name":source_name}) for data in condition_data)
#             # result = task_group.apply_async()
            
#             # print('result', result)
#             # # Wait for all tasks to complete and get the results
#             # results = result.join()

#             # # Check if any task has an error status
#             # for res in results:
#             #     print('res.status', res.status)

#             return Response(response, status=status.HTTP_200_OK)



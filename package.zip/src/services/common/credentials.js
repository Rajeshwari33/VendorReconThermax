export const headers = {
    'content-type': "application/json",
    "Accept": "application/json, text/plain, */*",
};

export const baseUrl = "http://localhost:";
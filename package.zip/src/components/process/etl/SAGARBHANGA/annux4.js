// App.js
import { useEffect, useState } from "react";
// import "./App.css";
import "../etlsecound.css";
import hdfcs from '../../../../assets/images/banks/thermax.png';


function Annux4() 
{
  

  return (
  <div>
   <table className="table">
    <tr className="bold">
        <td colSpan={7}>Payment made by Thermax not accounted by vendor</td>
        
    </tr>
    <br></br>
    <tr className="fontcolor">
        <td>DATE</td>
        <td>PARTICULARS</td>
        <td>VCH TYPE</td>
        <td>VCH NO.</td>
        <td>Cr/Dr</td>
        <td>DEBIT</td>
        <td>CREDIT</td>
    </tr>
</table>
  </div>
  )
}



export default Annux4;
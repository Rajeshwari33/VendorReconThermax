import re
import pandas as pd

def contraInt(df, cr, dr, contra_no):
    # Create 2 dataframes with reference number, credit and reference number, debit for comparison
    print("Running Contra...")
    # print(df, cr, dr, contra_no)
    columns = ['INVOICE_NUMBER', dr, cr, 'id_i']
    columns_c = ['INVOICE_NUMBER', cr, dr, 'id_i']
    df_d = df[columns]
    df_l = df_d[(df_d[dr] != 0) & (df_d[cr] == 0)]
    df_c = df[columns_c]
    df_r = df_c[(df_c[cr] != 0) & (df_c[dr] == 0)]

    # Merging the above created dataframe credit and debit values based on reference bumber
    df_o = pd.merge(df_l, df_r[['INVOICE_NUMBER', cr, 'id_i']], left_on=['INVOICE_NUMBER', dr], right_on=['INVOICE_NUMBER', cr], how='inner', suffixes=('_left', '_right'))
    df_o.drop_duplicates(subset='id_i_right', keep='first', inplace=True)
    df_o.drop_duplicates(subset='id_i_left', keep='first', inplace=True)
    # df_o.to_excel("contra.xlsx", index=False)

    # Update the unique numbers for all records
    unique_numbers = range(contra_no, contra_no + len(df_o))
    df_o['ID'] = unique_numbers
    # Get the last updated unique number to update in the excel for future reference 
    if len(df_o) <= 0:
        last_contra = contra_no
    else: 
        last_contra = df_o['ID'].values[-1]

    # created the column contra in df_n and update it as 1
    df_o['contra'] = 'Contra'

    reference_dict = df_o.set_index('id_i_right')['ID'].to_dict()
    df['matched_id'] = df['id_i'].map(reference_dict).fillna(df['matched_id'])
    reference_dict = df_o.set_index('id_i_left')['ID'].to_dict()
    df['matched_id'] = df['id_i'].map(reference_dict).fillna(df['matched_id'])
    reference_dict = df_o.set_index('id_i_right')['contra'].to_dict()
    df['status'] = df['id_i'].map(reference_dict).fillna(df['status'])
    reference_dict = df_o.set_index('id_i_left')['contra'].to_dict()
    df['status'] = df['id_i'].map(reference_dict).fillna(df['status'])
    return df, last_contra

def contraInt1(dfi, cr, dr, contra_no):
    # Create 2 dataframes with reference number, credit and reference number, debit for comparison
    print("Running Contra...")
    df = dfi[dfi['status'] == 'UnMatched']
    # df1 = dfi.dropna(subset=['reference_text'])
    # dfe = ext_df[ext_df['status'] == 'UnMatched']
    # df2 = dfe.dropna(subset=['reference_text'])
    
    # print(df2[ext_cr])
    columns_i = ['GL_CODE', 'INVOICE_NUMBER', 'GL_DATE', cr, dr, 'id_i']
    columns_e = ['GL_CODE', 'INVOICE_NUMBER', 'GL_DATE', cr, dr, 'id_i']
    df_l = df[columns_i]
    df_r = df[columns_e]

    df_l = df_l[(df_l[dr] != 0) & (df_l[cr] == 0)]
    df_r = df_r[(df_r[cr] != 0) & (df_r[dr] == 0)]

    grouped = df_l.groupby(['GL_CODE', 'INVOICE_NUMBER', 'GL_DATE', cr]).agg({dr: 'sum'})

    # Reset the index to flatten the grouped DataFrame
    grouped_df = grouped.reset_index()
    # grouped_df['id_i'] = 

    grouped_e = df_r.groupby(['GL_CODE', 'INVOICE_NUMBER', 'GL_DATE', dr]).agg({cr: 'sum'})
    # print(df, cr, dr, contra_no)
    grouped_df1 = grouped_e.reset_index()
    # columns = ['reference_text', dr, 'id_e']
    # columns_c = ['reference_text', cr, 'id_e']
    # df_d = df[columns]
    # df_l = grouped_df[(grouped_df[dr] != 0) & (grouped_df[cr] == 0)]
    # df_c = df[columns_c]
    # df_r = df_c[df_c[cr] != 0]

    # Merging the above created dataframe credit and debit values based on reference bumber
    df_o = pd.merge(grouped_df, grouped_df1[['GL_CODE', 'INVOICE_NUMBER', 'GL_DATE', cr]], left_on=['INVOICE_NUMBER', 'GL_DATE', dr], right_on=['INVOICE_NUMBER', 'GL_DATE', cr], how='inner', suffixes=('_left', '_right'))
    df_o.drop_duplicates(subset='INVOICE_NUMBER', keep='first', inplace=True)
    # df_o.drop_duplicates(subset='id_e_left', keep='first', inplace=True)
    # df_o.to_excel("contra.xlsx", index=False)

    # Update the unique numbers for all records
    unique_numbers = range(contra_no, contra_no + len(df_o))
    df_o['ID'] = unique_numbers
    # Get the last updated unique number to update in the excel for future reference 
    if len(df_o) <= 0:
        last_contra = contra_no
    else: 
        last_contra = df_o['ID'].values[-1]

    # created the column contra in df_n and update it as 1
    df_o['contra'] = 'Contra'
    
    reference_dict = df_o.set_index(['GL_CODE_left', 'INVOICE_NUMBER', 'GL_DATE', dr])['ID'].to_dict()
    df['matched_id'] = df.apply(lambda row: reference_dict.get((row['GL_CODE'], row['INVOICE_NUMBER'], row['GL_DATE'], row[dr]), row['matched_id']), axis=1)
    reference_dict = df_o.set_index(['GL_CODE_right', 'INVOICE_NUMBER', 'GL_DATE', 'GL_CREDIT_left'])['ID'].to_dict()
    df['matched_id'] = df.apply(lambda row: reference_dict.get((row['GL_CODE'], row['INVOICE_NUMBER'], row['GL_DATE'], row[cr]), row['matched_id']), axis=1)
    reference_dict = df_o.set_index(['GL_CODE_left', 'INVOICE_NUMBER', 'GL_DATE', dr])['contra'].to_dict()
    df['status'] = df.apply(lambda row: reference_dict.get((row['GL_CODE'], row['INVOICE_NUMBER'], row['GL_DATE'], row[dr]), row['status']), axis=1)
    reference_dict = df_o.set_index(['GL_CODE_right', 'INVOICE_NUMBER', 'GL_DATE', 'GL_CREDIT_right'])['contra'].to_dict()
    df['status'] = df.apply(lambda row: reference_dict.get((row['GL_CODE'], row['INVOICE_NUMBER'], row['GL_DATE'], row[cr]), row['status']), axis=1)
        
    return df, last_contra

def matching1(int_df, ext_df, int_dr, int_cr, ext_dr, ext_cr, int_date, ext_date, match_no, amt_tolerance):
    # condition1 = int_df['is_unmatched'] == 1
    # condition2 = int_df[~(pd.isna(int_df['reference_text']))]
    dfi = int_df[int_df['status'] == 'UnMatched']
    df1 = dfi.dropna(subset=['SUPPLIER_INVOICE_NO'])
    dfe = ext_df[ext_df['status'] == 'UnMatched']
    df2 = dfe.dropna(subset=['reference_text'])
    
    columns_i = [int_date, 'SUPPLIER_INVOICE_NO', int_dr, int_cr, 'id_i']
    columns_e = [ext_date, 'reference_text', ext_dr, ext_cr, 'id_e']
    df_l = df1[columns_i]
    df_r = df2[columns_e]
    # print(df_l.dtypes)
    # print(df_r.dtypes)
    # int_df.to_excel("dfi.xlsx", index=False) 
    # df1.to_excel("df1.xlsx", index=False) 

    df_merged = df_l.merge(df_r, left_on=['SUPPLIER_INVOICE_NO'], right_on=['reference_text'], how='inner')
    # df_merged.to_excel("df_merged.xlsx", index=False) 
    if df_merged.empty:
        return int_df, ext_df, match_no
    else:
        condition = ((df_merged[int_dr] - df_merged[ext_cr]).abs() <= 50) & ((df_merged[int_cr] - df_merged[ext_dr]).abs() <= 50)
    
        filtered_df1 = df_merged[condition]
        filtered_df2 = filtered_df1.drop_duplicates(subset=['id_i'])
        filtered_df = filtered_df2.drop_duplicates(subset=['id_e'])
        # Update the unique numbers for all records
        unique_numbers = range(match_no, match_no + len(filtered_df))
        filtered_df['ID'] = unique_numbers
        # Get the last updated unique number to update in the excel for future reference 
        if len(filtered_df) <= 0:
            last_match = match_no
        else: 
            last_match = filtered_df['ID'].values[-1]

        # created the column match in df_n and update it as 1
        filtered_df['match'] = 'Matched'

        # Update is_matched =1 and contra id for matched set in internal file
        reference_dict = filtered_df.set_index('id_i')['ID'].to_dict()
        int_df['matched_id'] = int_df['id_i'].map(reference_dict).fillna(int_df['matched_id'])
        reference_dict = filtered_df.set_index('id_i')['match'].to_dict()
        int_df['status'] = int_df['id_i'].map(reference_dict).fillna(int_df['status'])
        # Update is_matched =1 and contra id for matched set in external file
        reference_dict = filtered_df.set_index('id_e')['ID'].to_dict()
        ext_df['matched_id'] = ext_df['id_e'].map(reference_dict).fillna(ext_df['matched_id'])
        reference_dict = filtered_df.set_index('id_e')['match'].to_dict()
        ext_df['status'] = ext_df['id_e'].map(reference_dict).fillna(ext_df['status'])
        return int_df, ext_df, last_match
    # print("df_merged", df_merged)
    # df_l.to_excel("int.xlsx", index=False)
    # df_r.to_excel("ext.xlsx", index=False)
    # int_df.to_excel("output.xlsx", index=False)
    # print("dfi", dfi)

def matching2(int_df, ext_df, int_dr, int_cr, ext_dr, ext_cr, int_date, ext_date, match_no, amt_tolerance):
    # condition1 = int_df['is_unmatched'] == 1
    # condition2 = int_df[~(pd.isna(int_df['reference_text']))]
    dfi = int_df[int_df['status'] == 'UnMatched']
    df1 = dfi.dropna(subset=['reference_text'])
    dfe = ext_df[ext_df['status'] == 'UnMatched']
    df2 = dfe.dropna(subset=['reference_text'])
    
    columns_i = [int_date, 'reference_text', int_dr, int_cr, 'id_i']
    columns_e = [ext_date, 'reference_text', ext_dr, ext_cr, 'id_e']
    df_l = df1[columns_i]
    df_r = df2[columns_e]
    # print(df_l.dtypes)
    # print(df_r.dtypes)
    # int_df.to_excel("dfi.xlsx", index=False) 
    # df1.to_excel("df1.xlsx", index=False) 

    df_merged = df_l.merge(df_r, left_on=['reference_text'], right_on=['reference_text'], how='inner')
    # df_merged.to_excel("df_merged.xlsx", index=False) 
    if df_merged.empty:
        return int_df, ext_df, match_no
    else:
        condition = ((df_merged[int_dr] - df_merged[ext_cr]).abs() <= 50) & ((df_merged[int_cr] - df_merged[ext_dr]).abs() <= 50)
    
        filtered_df1 = df_merged[condition]
        filtered_df2 = filtered_df1.drop_duplicates(subset=['id_i'])
        filtered_df = filtered_df2.drop_duplicates(subset=['id_e'])
        # Update the unique numbers for all records
        unique_numbers = range(match_no, match_no + len(filtered_df))
        filtered_df['ID'] = unique_numbers
        # Get the last updated unique number to update in the excel for future reference 
        if len(filtered_df) <= 0:
            last_match = match_no
        else: 
            last_match = filtered_df['ID'].values[-1]

        # created the column match in df_n and update it as 1
        filtered_df['match'] = 'Matched'

        # Update is_matched =1 and contra id for matched set in internal file
        reference_dict = filtered_df.set_index('id_i')['ID'].to_dict()
        int_df['matched_id'] = int_df['id_i'].map(reference_dict).fillna(int_df['matched_id'])
        reference_dict = filtered_df.set_index('id_i')['match'].to_dict()
        int_df['status'] = int_df['id_i'].map(reference_dict).fillna(int_df['status'])
        # Update is_matched =1 and contra id for matched set in external file
        reference_dict = filtered_df.set_index('id_e')['ID'].to_dict()
        ext_df['matched_id'] = ext_df['id_e'].map(reference_dict).fillna(ext_df['matched_id'])
        reference_dict = filtered_df.set_index('id_e')['match'].to_dict()
        ext_df['status'] = ext_df['id_e'].map(reference_dict).fillna(ext_df['status'])
        return int_df, ext_df, last_match
    # print("df_merged", df_merged)
    # df_l.to_excel("int.xlsx", index=False)
    # df_r.to_excel("ext.xlsx", index=False)
    # int_df.to_excel("output.xlsx", index=False)
    # print("dfi", dfi)

def matching3(int_df, ext_df, int_dr, int_cr, ext_dr, ext_cr, int_date, ext_date, match_no, amt_tolerance):
    # condition1 = int_df['is_unmatched'] == 1
    # condition2 = int_df[~(pd.isna(int_df['reference_text']))]
    dfi = int_df[int_df['status'] == 'UnMatched']
    df1 = dfi.dropna(subset=['reference_text'])
    dfe = ext_df[ext_df['status'] == 'UnMatched']
    df2 = dfe.dropna(subset=['reference_text'])
    
    columns_i = ['DOCUMENT_DATE', 'INVOICE_NUMBER', int_dr, int_cr, 'id_i']
    columns_e = [ext_date, 'reference_text', ext_dr, ext_cr, 'id_e']
    df_l = df1[columns_i]
    df_r = df2[columns_e]
    # grouped = df_l.groupby(['DOCUMENT_DATE', 'INVOICE_NUMBER', int_dr, int_cr], as_index=False)['id_i'].apply(list)

    # # Reset the index to flatten the grouped DataFrame
    # grouped_df = grouped.reset_index()
    # grouped_df.to_excel("grouped.xlsx", index=False) 
    # # grouped_df['id_i'] = 

    # grouped_e = df_r.groupby([ext_date, 'reference_text', ext_dr, ext_cr])
    # # print(df, cr, dr, contra_no)
    # grouped_df1 = grouped_e.reset_index()

    df_merged = df_l.merge(df_r, left_on=['reference_text'], right_on=['reference_text'], how='inner')
    if df_merged.empty:
        return int_df, ext_df, match_no
    else:
        print("The DataFrame contains data.")
        condition = (((df_merged[int_date] - df_merged[ext_date]).dt.days).abs() <= date_tolerance) & ((df_merged[int_dr] - df_merged[ext_cr]).abs() <= amt_tolerance) & ((df_merged[int_cr] - df_merged[ext_dr]).abs() <= amt_tolerance)
        # df_merged['diff'] = ((df_merged[int_date] - df_merged[ext_date]).dt.days).abs()
        filtered_df1 = df_merged[condition]
        filtered_df2 = filtered_df1.drop_duplicates(subset=['id_i'])
        filtered_df = filtered_df2.drop_duplicates(subset=['id_e'])
        # filtered_df.to_excel("output.xlsx", index=False)
        # Update the unique numbers for all records
        unique_numbers = range(match_no, match_no + len(filtered_df))
        filtered_df['ID'] = unique_numbers
        # Get the last updated unique number to update in the excel for future reference 
        if len(filtered_df) <= 0:
            last_match = match_no
        else: 
            last_match = filtered_df['ID'].values[-1]

        # created the column match in df_n and update it as 1
        filtered_df['match'] = 'Matched'

        # Update is_matched =1 and contra id for matched set in internal file
        reference_dict = filtered_df.set_index('id_i')['ID'].to_dict()
        int_df['matched_id'] = int_df['id_i'].map(reference_dict).fillna(int_df['matched_id'])
        reference_dict = filtered_df.set_index('id_i')['match'].to_dict()
        int_df['status'] = int_df['id_i'].map(reference_dict).fillna(int_df['status'])
        # Update is_matched =1 and contra id for matched set in external file
        reference_dict = filtered_df.set_index('id_e')['ID'].to_dict()
        ext_df['matched_id'] = ext_df['id_e'].map(reference_dict).fillna(ext_df['matched_id'])
        reference_dict = filtered_df.set_index('id_e')['match'].to_dict()
        ext_df['status'] = ext_df['id_e'].map(reference_dict).fillna(ext_df['status'])
        int_df.to_excel("match.xlsx", index=False)
        return int_df, ext_df, last_match
    # print("df_merged", df_merged)
    # df_l.to_excel("int.xlsx", index=False)
    # df_r.to_excel("ext.xlsx", index=False)
    # int_df.to_excel("output.xlsx", index=False)
    # print("dfi", dfi)

def groupMatching1(int_df, ext_df, int_dr, int_cr, ext_dr, ext_cr, int_date, ext_date, match_no, amt_tolerance):
    # condition1 = int_df['is_unmatched'] == 1
    # condition2 = int_df[~(pd.isna(int_df['reference_text']))]
    dfi = int_df[int_df['status'] == 'UnMatched']
    df1 = dfi.dropna(subset=['reference_text'])
    dfe = ext_df[ext_df['status'] == 'UnMatched']
    df2 = dfe.dropna(subset=['reference_text'])
    
    # print(df2[ext_cr])
    columns_i = [int_date, 'reference_text', int_dr, int_cr, 'id_i']
    columns_e = [ext_date, 'reference_text', ext_dr, ext_cr, 'id_e']
    df_l = df1[columns_i]
    df_r = df2[columns_e]

    grouped = df_l.groupby([int_date, 'reference_text']).agg({int_dr: 'sum', int_cr: 'sum'})

    # Reset the index to flatten the grouped DataFrame
    grouped_df = grouped.reset_index()
    # grouped_df['id_i'] = 

    grouped_e = df_r.groupby([ext_date, 'reference_text']).agg({ext_dr: 'sum', ext_cr: 'sum'})

    # Reset the index to flatten the grouped DataFrame
    grouped_e_df = grouped_e.reset_index()

    # grouped_df.to_excel("output.xlsx", index=False)
    df_merged = grouped_df.merge(grouped_e_df, left_on=[int_date, 'reference_text'], right_on=[ext_date, 'reference_text'], how='inner')
    if df_merged.empty:
        return int_df, ext_df, match_no
    else:
        condition = ((df_merged[int_dr] - df_merged[ext_cr]).abs() == 0) & ((df_merged[int_cr] - df_merged[ext_dr]).abs() == 0)
    
        filtered_df = df_merged[condition]
        # filtered_df.to_excel("output.xlsx", index=False)
        # Update the unique numbers for all records
        unique_numbers = range(match_no, match_no + len(filtered_df))
        filtered_df['ID'] = unique_numbers
        # Get the last updated unique number to update in the excel for future reference 
        if len(filtered_df) <= 0:
            last_match = match_no
        else: 
            last_match = filtered_df['ID'].values[-1]

        # created the column match in df_n and update it as 1
        filtered_df['match'] = 'GroupMatched'

        # Update is_matched =1 and contra id for matched set in internal file
        reference_dict = filtered_df.set_index('reference_text')['ID'].to_dict()
        int_df['matched_id'] = int_df['reference_text'].map(reference_dict).fillna(int_df['matched_id'])
        ext_df['matched_id'] = ext_df['reference_text'].map(reference_dict).fillna(ext_df['matched_id'])
        reference_dict = filtered_df.set_index('reference_text')['match'].to_dict()
        int_df['status'] = int_df['reference_text'].map(reference_dict).fillna(int_df['status'])
        ext_df['status'] = ext_df['reference_text'].map(reference_dict).fillna(ext_df['status'])
        int_df.to_excel("group1.xlsx", index=False)
        return int_df, ext_df, last_match

def groupMatching2(int_df, ext_df, int_dr, int_cr, ext_dr, ext_cr, int_date, ext_date, match_no, amt_tolerance):
    # condition1 = int_df['is_unmatched'] == 1
    # condition2 = int_df[~(pd.isna(int_df['reference_text']))]
    dfi = int_df[int_df['status'] == 'UnMatched']
    df1 = dfi.dropna(subset=['reference_text'])
    dfe = ext_df[ext_df['status'] == 'UnMatched']
    df2 = dfe.dropna(subset=['reference_text'])
    
    # print(df2[ext_cr])
    columns_i = [int_date, 'reference_text', int_dr, int_cr, 'id_i']
    columns_e = [ext_date, 'reference_text', ext_dr, ext_cr, 'id_e']
    df_l = df1[columns_i]
    df_r = df2[columns_e]

    grouped = df_l.groupby([int_date, 'reference_text']).agg({int_dr: 'sum', int_cr: 'sum'})

    # Reset the index to flatten the grouped DataFrame
    grouped_df = grouped.reset_index()
    # grouped_df['id_i'] = 

    grouped_e = df_r.groupby([ext_date, 'reference_text']).agg({ext_dr: 'sum', ext_cr: 'sum'})

    # Reset the index to flatten the grouped DataFrame
    grouped_e_df = grouped_e.reset_index()

    # grouped_df.to_excel("output.xlsx", index=False)
    df_merged = grouped_df.merge(grouped_e_df, left_on=[int_date, 'reference_text'], right_on=[ext_date, 'reference_text'], how='inner')
    if df_merged.empty:
        return int_df, ext_df, match_no
    else:
        condition = ((df_merged[int_dr] - df_merged[ext_cr]).abs() <= amt_tolerance) & ((df_merged[int_cr] - df_merged[ext_dr]).abs() <= amt_tolerance)
    
        filtered_df = df_merged[condition]
        # filtered_df.to_excel("output.xlsx", index=False)
        # Update the unique numbers for all records
        unique_numbers = range(match_no, match_no + len(filtered_df))
        filtered_df['ID'] = unique_numbers
        # Get the last updated unique number to update in the excel for future reference 
        if len(filtered_df) <= 0:
            last_match = match_no
        else: 
            last_match = filtered_df['ID'].values[-1]

        # created the column match in df_n and update it as 1
        filtered_df['match'] = 'GroupMatched'

        # Update is_matched =1 and contra id for matched set in internal file
        reference_dict = filtered_df.set_index('reference_text')['ID'].to_dict()
        int_df['matched_id'] = int_df['reference_text'].map(reference_dict).fillna(int_df['matched_id'])
        ext_df['matched_id'] = ext_df['reference_text'].map(reference_dict).fillna(ext_df['matched_id'])
        reference_dict = filtered_df.set_index('reference_text')['match'].to_dict()
        int_df['status'] = int_df['reference_text'].map(reference_dict).fillna(int_df['status'])
        ext_df['status'] = ext_df['reference_text'].map(reference_dict).fillna(ext_df['status'])
        int_df.to_excel("group2.xlsx", index=False)
        return int_df, ext_df, last_match

def groupMatching3(int_df, ext_df, int_dr, int_cr, ext_dr, ext_cr, int_date, ext_date, match_no, amt_tolerance, date_tolerance):
    # condition1 = int_df['is_unmatched'] == 1
    # condition2 = int_df[~(pd.isna(int_df['reference_text']))]
    dfi = int_df[int_df['status'] == 'UnMatched']
    df1 = dfi.dropna(subset=['reference_text'])
    dfe = ext_df[ext_df['status'] == 'UnMatched']
    df2 = dfe.dropna(subset=['reference_text'])
   
    # print(df2[ext_cr])
    columns_i = [int_date, 'reference_text', int_dr, int_cr, 'id_i']
    columns_e = [ext_date, 'reference_text', ext_dr, ext_cr, 'id_e']
    df_l = df1[columns_i]
    df_r = df2[columns_e]

    grouped = df_l.groupby([int_date, 'reference_text']).agg({int_dr: 'sum', int_cr: 'sum'})

    # Reset the index to flatten the grouped DataFrame
    grouped_df = grouped.reset_index()
    # grouped_df['id_i'] = 

    grouped_e = df_r.groupby([ext_date, 'reference_text']).agg({ext_dr: 'sum', ext_cr: 'sum'})

    # Reset the index to flatten the grouped DataFrame
    grouped_e_df = grouped_e.reset_index()

    # grouped_df.to_excel("output.xlsx", index=False)
    df_merged = grouped_df.merge(grouped_e_df, left_on=['reference_text'], right_on=['reference_text'], how='inner')
    if df_merged.empty:
        return int_df, ext_df, match_no
    else:
        condition = (((df_merged[int_date] - df_merged[ext_date]).dt.days).abs() <= date_tolerance) & ((df_merged[int_dr] - df_merged[ext_cr]).abs() <= amt_tolerance) & ((df_merged[int_cr] - df_merged[ext_dr]).abs() <= amt_tolerance)
    
        filtered_df = df_merged[condition]
        # filtered_df.to_excel("output.xlsx", index=False)
        # Update the unique numbers for all records
        unique_numbers = range(match_no, match_no + len(filtered_df))
        filtered_df['ID'] = unique_numbers
        # Get the last updated unique number to update in the excel for future reference 
        if len(filtered_df) <= 0:
            last_match = match_no
        else: 
            last_match = filtered_df['ID'].values[-1]

        # created the column match in df_n and update it as 1
        filtered_df['match'] = 'GroupMatched'

        # Update is_matched =1 and contra id for matched set in internal file
        reference_dict = filtered_df.set_index('reference_text')['ID'].to_dict()
        int_df['matched_id'] = int_df['reference_text'].map(reference_dict).fillna(int_df['matched_id'])
        ext_df['matched_id'] = ext_df['reference_text'].map(reference_dict).fillna(ext_df['matched_id'])
        reference_dict = filtered_df.set_index('reference_text')['match'].to_dict()
        int_df['status'] = int_df['reference_text'].map(reference_dict).fillna(int_df['status'])
        ext_df['status'] = ext_df['reference_text'].map(reference_dict).fillna(ext_df['status'])
        int_df.to_excel("group3.xlsx", index=False)
        return int_df, ext_df, last_match

def matching_without_ref(int_df, ext_df, int_dr, int_cr, ext_dr, ext_cr, int_date, ext_date, match_no, amt_tolerance):
    # condition1 = int_df['is_unmatched'] == 1
    # condition2 = int_df[~(pd.isna(int_df['reference_text']))]
    dfi = int_df[int_df['status'] == 'UnMatched']
    # df1 = dfi.dropna(subset=['reference_text'])
    dfe = ext_df[ext_df['status'] == 'UnMatched']
    # df2 = dfe.dropna(subset=['reference_text'])
    
    columns_i = [int_date, 'reference_text', int_dr, int_cr, 'id_i']
    columns_e = [ext_date, 'reference_text', ext_dr, ext_cr, 'id_e']
    df_l = dfi[columns_i]
    df_r = dfe[columns_e]

    df_merged = df_l.merge(df_r, left_on=[int_date], right_on=[ext_date], how='inner')
    if df_merged.empty:
        return int_df, ext_df, match_no
    else:
        condition = ((df_merged[int_dr] - df_merged[ext_cr]).abs() <= amt_tolerance) & ((df_merged[int_cr] - df_merged[ext_dr]).abs() <= amt_tolerance)
    
        filtered_df1 = df_merged[condition]
        filtered_df2 = filtered_df1.drop_duplicates(subset=['id_i'])
        filtered_df = filtered_df2.drop_duplicates(subset=['id_e'])
        filtered_df.to_excel("output.xlsx", index=False)
        # Update the unique numbers for all records
        unique_numbers = range(match_no, match_no + len(filtered_df))
        filtered_df['ID'] = unique_numbers
        # Get the last updated unique number to update in the excel for future reference 
        if len(filtered_df) <= 0:
            last_match = match_no
        else: 
            last_match = filtered_df['ID'].values[-1]

        # created the column match in df_n and update it as 1
        filtered_df['match'] = 'Matched'

        # Update is_matched =1 and contra id for matched set in internal file
        reference_dict = filtered_df.set_index('id_i')['ID'].to_dict()
        int_df['matched_id'] = int_df['id_i'].map(reference_dict).fillna(int_df['matched_id'])
        reference_dict = filtered_df.set_index('id_i')['match'].to_dict()
        int_df['status'] = int_df['id_i'].map(reference_dict).fillna(int_df['status'])
        # Update is_matched =1 and contra id for matched set in external file
        reference_dict = filtered_df.set_index('id_e')['ID'].to_dict()
        ext_df['matched_id'] = ext_df['id_e'].map(reference_dict).fillna(ext_df['matched_id'])
        reference_dict = filtered_df.set_index('id_e')['match'].to_dict()
        ext_df['status'] = ext_df['id_e'].map(reference_dict).fillna(ext_df['status'])
        int_df.to_excel("matchref1.xlsx", index=False)
        return int_df, ext_df, last_match

def matching_without_ref2(int_df, ext_df, int_dr, int_cr, ext_dr, ext_cr, int_date, ext_date, match_no, amt_tolerance, date_tolerance):
    # condition1 = int_df['is_unmatched'] == 1
    # condition2 = int_df[~(pd.isna(int_df['reference_text']))]
    dfi = int_df[int_df['status'] == 'UnMatched']
    # df1 = dfi.dropna(subset=['reference_text'])
    dfe = ext_df[ext_df['status'] == 'UnMatched']
    # df2 = dfe.dropna(subset=['reference_text'])
    # print(df2[ext_cr])
    columns_i = [int_date, 'reference_text', int_dr, int_cr, 'id_i', 'status']
    columns_e = [ext_date, 'reference_text', ext_dr, ext_cr, 'id_e', 'status']
    df_l = dfi[columns_i]
    df_r = dfe[columns_e]

    df_merged = df_l.merge(df_r, left_on=['status'], right_on=['status'], how='inner')
    if df_merged.empty:
        return int_df, ext_df, match_no
    else:
        condition = (((df_merged[int_date] - df_merged[ext_date]).dt.days).abs() <= date_tolerance) & ((df_merged[int_dr] - df_merged[ext_cr]).abs() <= amt_tolerance) & ((df_merged[int_cr] - df_merged[ext_dr]).abs() <= amt_tolerance)
    
        filtered_df1 = df_merged[condition]
        filtered_df2 = filtered_df1.drop_duplicates(subset=['id_i'])
        filtered_df = filtered_df2.drop_duplicates(subset=['id_e'])
        filtered_df.to_excel("output.xlsx", index=False)
        # Update the unique numbers for all records
        unique_numbers = range(match_no, match_no + len(filtered_df))
        filtered_df['ID'] = unique_numbers
        # Get the last updated unique number to update in the excel for future reference 
        if len(filtered_df) <= 0:
            last_match = match_no
        else: 
            last_match = filtered_df['ID'].values[-1]

        # created the column match in df_n and update it as 1
        filtered_df['match'] = 'Matched'

        # Update is_matched =1 and contra id for matched set in internal file
        reference_dict = filtered_df.set_index('id_i')['ID'].to_dict()
        int_df['matched_id'] = int_df['id_i'].map(reference_dict).fillna(int_df['matched_id'])
        reference_dict = filtered_df.set_index('id_i')['match'].to_dict()
        int_df['status'] = int_df['id_i'].map(reference_dict).fillna(int_df['status'])
        # Update is_matched =1 and contra id for matched set in external file
        reference_dict = filtered_df.set_index('id_e')['ID'].to_dict()
        ext_df['matched_id'] = ext_df['id_e'].map(reference_dict).fillna(ext_df['matched_id'])
        reference_dict = filtered_df.set_index('id_e')['match'].to_dict()
        ext_df['status'] = ext_df['id_e'].map(reference_dict).fillna(ext_df['status'])
        int_df.to_excel("matchref2.xlsx", index=False)
        return int_df, ext_df, last_match

def groupUnMatching(int_df, ext_df, int_dr, int_cr, ext_dr, ext_cr, int_date, ext_date, match_no, amt_tolerance):
    
    df1 = int_df[int_df['status'] == 'UnMatched']
    # df1 = dfi.dropna(subset=['reference_text'])
    df2 = ext_df[ext_df['status'] == 'UnMatched']
    # df2 = dfe.dropna(subset=['reference_text'])
   
    # print(df2[ext_cr])
    columns_i = [int_date, 'reference_text', int_dr, int_cr, 'id_i']
    columns_e = [ext_date, 'reference_text', ext_dr, ext_cr, 'id_e']
    df_l = df1[columns_i]
    df_r = df2[columns_e]

    grouped_df = df_l.groupby([int_date, int_dr, int_cr], as_index=False)

    grouped_e_df = df_r.groupby([ext_date, ext_dr, ext_cr], as_index=False)

    df_merged = pd.merge(grouped_df.sum().reset_index(), grouped_e_df.sum().reset_index(), left_on=[int_date], right_on=[ext_date], how='inner')
    if df_merged.empty:
        return int_df, ext_df, match_no
    else:
        condition = ((df_merged[int_dr] - df_merged[ext_cr]).abs() <= amt_tolerance) & ((df_merged[int_cr] - df_merged[ext_dr]).abs() <= amt_tolerance)
    
        filtered_df = df_merged[condition]
        # Update the unique numbers for all records
        unique_numbers = range(match_no, match_no + len(filtered_df))
        filtered_df['ID'] = unique_numbers
        filtered_df.to_excel("filtered_df.xlsx", index=False)
        # Get the last updated unique number to update in the excel for future reference 
        if len(filtered_df) <= 0:
            last_match = match_no
        else: 
            last_match = filtered_df['ID'].values[-1]

        # created the column match in df_n and update it as 1
        filtered_df['match'] = 'GroupUnMatched'

        reference_dict = filtered_df.set_index([int_date, int_dr, int_cr])['ID'].to_dict()
        int_df['matched_id'] = int_df.apply(lambda row: reference_dict.get((row[int_date], row[int_dr], row[int_cr]), row['matched_id']), axis=1)
        reference_dict = filtered_df.set_index([ext_date, ext_dr, ext_cr])['ID'].to_dict()
        ext_df['matched_id'] = ext_df.apply(lambda row: reference_dict.get((row[ext_date], row[ext_dr], row[ext_cr]), row['matched_id']), axis=1)
        reference_dict = filtered_df.set_index([int_date, int_dr, int_cr])['match'].to_dict()
        int_df['status'] = int_df.apply(lambda row: reference_dict.get((row[int_date], row[int_dr], row[int_cr]), row['status']), axis=1)
        reference_dict = filtered_df.set_index([ext_date, ext_dr, ext_cr])['match'].to_dict()
        ext_df['status'] = ext_df.apply(lambda row: reference_dict.get((row[ext_date], row[ext_dr], row[ext_cr]), row['status']), axis=1)
        int_df.to_excel("groupref.xlsx", index=False)
        return int_df, ext_df, last_match

def extract_reference_text(row):
    pattern = r'(NEFT|RTGS)-(\w+)-'
    match = re.search(pattern, row["Transaction Remarks"])
    if match:
        return match.group(2)
    else:
        return row["Transaction Remarks"]
    
def extract_reference_text_int(row):
    pattern = r'CMS'
    match = re.search(pattern, row["TRANSREF"])
    print("match", match)
    if match:
        # reference_text = match.group(2)
        # print("reference_text", reference_text)
        return row["TRANSREF"].lstrip('-')
    else:
        return row["TRANSDESC"].split('-')[0]
    
def extract_reference_text_2605(row):
    pattern = r'CMS'
    pattern1 = r'MMT'
    match = re.search(pattern, row["Transaction Remarks"]) and not re.search(pattern1, row["Transaction Remarks"])
    match1 = re.search(pattern1, row["Transaction Remarks"])
    if match:
        parts = row["Transaction Remarks"].split('/')
        reference_text = parts[1].lstrip()
        if re.search(pattern, reference_text):
            return reference_text
        elif not bool(re.search(r"[a-zA-Z]", reference_text)):
            return reference_text
        else:
            return reference_text.split(' ')[2]
    elif match1:
        parts = row["Transaction Remarks"].split('/')
        reference_text = parts[-1]
        text = reference_text.split('-')[0]
        return text
    
def runVRS(internal_file, extrenal_file, int_start_row, ext_start_row, int_ref_col, ext_ref_col, amount_col, int_cr, int_dr, ext_cr, ext_dr, int_date, ext_date, amt_tolerance, date_tolerance):
    input_file = "input.xlsx"

    # Get the last updated unique number from the file
    print("Reading Input file...")
    input_df = pd.read_excel(input_file, skiprows=0)
    match_no = input_df.at[0, 'Match']
    print("match_no", match_no)
    int_df = pd.read_excel(internal_file, skiprows=0)
    ext_df = pd.read_excel(extrenal_file, skiprows=7)
    int_df["status"] = 'UnMatched'
    int_df["matched_id"] = ''
    int_df["reference_text"] = ''
    ext_df["status"] = 'UnMatched'
    ext_df["matched_id"] = ''
    ext_df["reference_text"] = ''

    int_df["id_i"] = range(1, 1 + len(int_df))
    ext_df["id_e"] = range(1, 1 + len(ext_df))
    # new_column_names = {
    #     ext_cr_i : 'ext_cr',
    #     ext_dr_i : 'ext_dr',
    #     ext_date_i : "ext_date"
    # }
    # ext_df = ext_df.rename(columns=new_column_names)
    # ext_cr = 'ext_cr'
    # ext_dr = 'ext_dr'
    # ext_date = "ext_date"

    # int_df.loc[int_df['status'] == 'GroupUnMatched', 'matched_id'] = ""
    # ext_df.loc[ext_df['status'] == 'GroupUnMatched', 'matched_id'] = ""
    # int_df.loc[int_df['status'] == 'GroupUnMatched', 'status'] = "UnMatched"
    # ext_df.loc[ext_df['status'] == 'GroupUnMatched', 'status'] = "UnMatched"
    # Extract the reference filed and updated into reference_text column , source_code
    # match source_code:
    #     case "HDFC828":
    ext_df["reference_text"] = ext_df[ext_ref_col]
    int_df["reference_text"] = int_df[int_ref_col].str.split('/', expand=True)[1]
    ext_df["reference_text"] = ext_df["reference_text"].astype(str)
    #     case "HDFC295":
    #         ext_df["reference_text"] = ext_df[ext_ref_col].str.lstrip('0')
    #         int_df["reference_text"] = int_df[int_ref_col].str.lstrip('0')
    #     case "HDFC062":
    #         ext_df["reference_text"] = ext_df[ext_ref_col]
    #         int_df["reference_text"] = int_df[int_ref_col].str.lstrip('-')
    #     case "ICICI0240":
    #         ext_df["reference_text"] = [extract_reference_text(row) for _, row in ext_df.iterrows()]
    #         int_df["reference_text"] = [extract_reference_text_int(row) for _, row in int_df.iterrows()]
    #     case "ICICI02605":
    #         ext_df["reference_text"] = [extract_reference_text_2605(row) for _, row in ext_df.iterrows()]
    #         int_df["reference_text"] = int_df[int_ref_col].str.split('-', expand=True)[0]
    #     case "SBI7913":
    #         ext_df["reference_text"] = ext_df[ext_ref_col].str.split(' ', expand=True)[0]
    #         int_df["reference_text"] = int_df[int_ref_col].str.split(' ', expand=True)[0].str.lstrip('-')
    #     case "AXIS18294":
    #         ext_df["reference_text"] = ext_df[ext_ref_col]
    #         int_df["reference_text"] = int_df[int_ref_col].str.lstrip('-')
    # HDFC 828
    # ext_df["reference_text"] = ext_df[ext_ref_col].str.lstrip('0')
    # int_df["reference_text"] = int_df[int_ref_col].str.split('-', expand=True)[0].str.lstrip('0')
    # HDFC 062
    # ext_df["reference_text"] = ext_df[ext_ref_col]
    # int_df["reference_text"] = int_df[int_ref_col].str.lstrip('-')
    # HDFC 295
    # ext_df["reference_text"] = ext_df[ext_ref_col].str.lstrip('0')
    # int_df["reference_text"] = int_df[int_ref_col].str.lstrip('0')
    # SBI 7913
    # ext_df["reference_text"] = ext_df[ext_ref_col].str.split(' ', expand=True)[0]
    # int_df["reference_text"] = int_df[int_ref_col].str.split(' ', expand=True)[0].str.lstrip('-')
    # ICICI 240
    # ext_df["reference_text"] = [extract_reference_text(row) for _, row in ext_df.iterrows()]
    # int_df["reference_text"] = [extract_reference_text_int(row) for _, row in int_df.iterrows()]
    # ICICI 2605
    # ext_df["reference_text"] = [extract_reference_text_2605(row) for _, row in ext_df.iterrows()]
    # int_df["reference_text"] = int_df[int_ref_col].str.split('-', expand=True)[0]
    # AXIS 18294
    # ext_df["reference_text"] = ext_df[ext_ref_col]
    # int_df["reference_text"] = int_df[int_ref_col].str.lstrip('-')
    
    
    # Calling Contra function for internal
    print("Calling Internal Contra function...")
    contra_value = contraInt(int_df, int_cr, int_dr, match_no)
    print("Internal Contra Ran Successfully...")
    int_df = contra_value[0]
    # int_df.loc[int_df['is_contra'] == 1, 'is_unmatched'] = 0
    last_match = contra_value[1] + 1
    # print("last_match_contra_i", last_match)

    # # Calling Contra function for external
    print("Calling external Contra function...")
    contra_value = contraInt1(int_df, int_cr, int_dr, last_match)
    print("external Contra Ran Successfully...")
    int_df = contra_value[0]
    # # ext_df.loc[ext_df['is_contra'] == 1, 'is_unmatched'] = 0
    last_match = contra_value[1] + 1
    # print("last_match_contra_e", last_match)


    # # Matching rule 1
    matching_1 = matching1(int_df, ext_df, int_dr, int_cr, ext_dr, ext_cr, int_date, ext_date, last_match, amt_tolerance)
    print("Matching Rule 1 Ran Successfully...")
    int_df = matching_1[0]
    ext_df = matching_1[1]
    last_match = matching_1[2] + 1
    # print("last_match_match1", last_match)

    # # Matching rule 2
    matching_2 = matching2(int_df, ext_df, int_dr, int_cr, ext_dr, ext_cr, int_date, ext_date, last_match, amt_tolerance)
    print("Matching Rule 2 Ran Successfully...")
    int_df = matching_2[0]
    ext_df = matching_2[1]
    # int_df.loc[int_df['is_matched'] == 1, 'is_unmatched'] = 0
    # ext_df.loc[ext_df['is_matched'] == 1, 'is_unmatched'] = 0
    last_match = matching_2[2] + 1
    # print("last_match_match2", last_match)
    # # input_df.at[0, 'match'] = last_match + 1

    # # Matching rule 3
    matching_3 = matching3(int_df, ext_df, int_dr, int_cr, ext_dr, ext_cr, int_date, ext_date, last_match, amt_tolerance)
    print("Matching Rule 2 Ran Successfully...")
    int_df = matching_3[0]
    ext_df = matching_3[1]
    # int_df.loc[int_df['is_matched'] == 1, 'is_unmatched'] = 0
    # ext_df.loc[ext_df['is_matched'] == 1, 'is_unmatched'] = 0
    last_match = matching_3[2] + 1

    # # Group Matching rule 1
    # # print("last_match", last_match)
    # group_matching_1 = groupMatching1(int_df, ext_df, int_dr, int_cr, ext_dr, ext_cr, int_date, ext_date, last_match, amt_tolerance)
    # print("Group Matching Rule 1 Ran Successfully...")
    # int_df = group_matching_1[0]
    # ext_df = group_matching_1[1]
    # # int_df.loc[int_df['is_grouped'] == 1, 'is_unmatched'] = 0
    # # ext_df.loc[ext_df['is_grouped'] == 1, 'is_unmatched'] = 0
    # last_match = group_matching_1[2] + 1
    # print("last_match_groupmatch1", last_match)
    # # input_df.at[0, 'match'] = last_match + 1

    # # Group Matching rule 2
    # # print("last_match", last_match)
    # group_matching_2 = groupMatching2(int_df, ext_df, int_dr, int_cr, ext_dr, ext_cr, int_date, ext_date, last_match, amt_tolerance)
    # print("Group Matching Rule 2 Ran Successfully...")
    # int_df = group_matching_2[0]
    # ext_df = group_matching_2[1]
    # # int_df.loc[int_df['is_grouped'] == 1, 'is_unmatched'] = 0
    # # ext_df.loc[ext_df['is_grouped'] == 1, 'is_unmatched'] = 0
    # last_match = group_matching_2[2] + 1
    # print("last_match_groupmatch2", last_match)

    # # Group Matching rule 3
    # # print("last_match", last_match)
    # group_matching_3 = groupMatching3(int_df, ext_df, int_dr, int_cr, ext_dr, ext_cr, int_date, ext_date, last_match, amt_tolerance, date_tolerance)
    # print("Group Matching Rule 3 Ran Successfully...")
    # int_df = group_matching_3[0]
    # ext_df = group_matching_3[1]
    # # int_df.loc[int_df['is_grouped'] == 1, 'is_unmatched'] = 0
    # # ext_df.loc[ext_df['is_grouped'] == 1, 'is_unmatched'] = 0
    # last_match = group_matching_3[2] + 1
    # print("last_match_groupmatch3", last_match)

    # # Matching rule without ref 1
    # # print("last_match", last_match2)
    # matching_1 = matching_without_ref(int_df, ext_df, int_dr, int_cr, ext_dr, ext_cr, int_date, ext_date, last_match, amt_tolerance)
    # print("Matching Rule Without Reference 1 Ran Successfully...")
    # int_df = matching_1[0]
    # ext_df = matching_1[1]
    # # int_df.loc[int_df['is_matched'] == 1, 'is_unmatched'] = 0
    # # ext_df.loc[ext_df['is_matched'] == 1, 'is_unmatched'] = 0
    # last_match = matching_1[2] + 1
    # print("last_match_wtot1", last_match)

    # # Matching rule without ref 2
    # print("last_match", last_match)
    # matching_2 = matching_without_ref2(int_df, ext_df, int_dr, int_cr, ext_dr, ext_cr, int_date, ext_date, last_match, amt_tolerance, date_tolerance)
    # print("Matching Rule Without Reference 2 Ran Successfully...")
    # int_df = matching_2[0]
    # ext_df = matching_2[1]
    # # int_df.loc[int_df['is_matched'] == 1, 'is_unmat tched'] = 0
    # last_match = matching_2[2] + 1
    # # print("last_match_wtot2", last_match)

    # print("last_match", last_match)
    # group_unmatching = groupUnMatching(int_df, ext_df, int_dr, int_cr, ext_dr, ext_cr, int_date, ext_date, last_match, amt_tolerance)
    # print("Matching Rule Without Reference 2 Ran Successfully...")
    # int_df = group_unmatching[0]
    # ext_df = group_unmatching[1]
    # # int_df.loc[int_df['is_matched'] == 1, 'is_unmat tched'] = 0
    # last_match = group_unmatching[2] + 1
    # input_df.at[0, source_code] = last_match + 1

    # int_df = int_df.drop('id_i', axis=1)
    # ext_df = ext_df.drop('id_e', axis=1)

    print("Writing the Contra Last value to input file...")
    input_df.to_excel("input.xlsx", index=False)
    print("writing the Final Internal dataframe into excel...")
    int_df.to_excel("internal.xlsx", index=False)
    print("writing the Final External dataframe into excel...")
    ext_df.to_excel("external.xlsx", index=False)
    print('DataFrame is written to Excel File successfully.')
    return int_df, ext_df


extrenal_file = "C:/Applications/AdventsProduct/VRS/Sources/Data/Vendor_GL/input/Vendor_SOA_Sagarbhanga_2022_12_29_18_46_50_872650.xlsx"
internal_file = "C:/Applications/AdventsProduct/VRS/Sources/Data/TMX_GL/input/internal_data_2023_01_06_16_25_14_376214.xlsx"
int_start_row = 0
ext_start_row = 7
int_ref_col = 'INVOICE_NUMBER'
ext_ref_col = "Vch No."
amount_col = 'TRANSAMT'
int_cr = 'GL_CREDIT'
int_dr = 'GL_DEBIT' 
ext_cr = 'Credit' 
ext_dr = 'Debit'
int_date = 'GL_DATE' 
ext_date = 'Date'
amt_tolerance = 2
date_tolerance = 3
runVRS(internal_file, extrenal_file, int_start_row, ext_start_row, int_ref_col, ext_ref_col, amount_col, int_cr, int_dr, ext_cr, ext_dr, int_date, ext_date, amt_tolerance, date_tolerance)
 
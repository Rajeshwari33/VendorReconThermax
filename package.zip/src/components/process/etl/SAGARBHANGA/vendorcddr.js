// App.js
import { useEffect, useState } from "react";
// import "./App.css";
import "../etlsecound.css";
import hdfcs from '../../../../assets/images/banks/thermax.png';


function Vendorcrdr() 
{
  

  return (
  <div>
    <table className="table">
    
    <tr className="bold">
        <td>ORGANIZATION</td>
        <td><img src={hdfcs} alt="" height="40px" width="60px" /> THERMAX LIMITED </td>
    </tr>
    <tr>
        <td>REPORT GENERATION DATE</td>
        <td>2023-01-04 10:15:07.937875</td>
    </tr>
    <br></br>
    <tr className="fontcolor">
        <td>VEDNOR NAME</td>
        <td>HEIN LEHMANN INDIA PRIVATE LIMITED</td>
    </tr>
    <tr>
        <td>REPORT FROM DATE</td>
        <td>2021-04-01</td>
    </tr>
    <tr>
        <td>REPORT TO DATE</td>
        <td>2022-11-30</td>
    </tr>
    <tr>
        <td>VENDOR CODE</td>
        <td>150350</td>
    </tr>
    <tr>
        <td>VENDOR SITE CODE</td>
        <td>CHENNAI</td>
    </tr>
    <tr>
        <td>VENDOR CATEGORY</td>
        <td>Indirect</td>
    </tr>
    <tr>
        <td>LIABILITY ACCOUNT</td>
        <td>08-103000-3005-20321-110001-000000-000000</td>
    </tr>
    <tr>
        <td>DIVISION</td>
        <td>Power</td>
    </tr>
    <tr>
        <td>PAN NUMBER</td>
        <td>AADCH7255C</td>
    </tr>
    <tr>
        <td>GST NUMBER</td>
        <td>33AADCH7255C1ZW</td>
    </tr>
</table>
  </div>
  )
}



export default Vendorcrdr;